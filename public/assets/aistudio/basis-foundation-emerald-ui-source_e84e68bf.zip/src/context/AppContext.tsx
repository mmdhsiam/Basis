import React, { createContext, useContext, useState, useEffect, useMemo, ReactNode } from 'react';
import {
  UserProfile,
  SavingsTransaction,
  ApprovalRequest,
  ElectronicReceipt,
  NoticeItem,
  ComplaintItem,
  FeatureRequestItem,
  FoundationRule,
  ChatMessage,
  ChatPoll,
  AuditLogItem,
  AppConfiguration,
  AppRelease,
  UserRole,
  PrivateMessage,
  FoundationExpense,
  ExecutiveMember,
  UserNotification,
} from '../types';
import {
  INITIAL_CONFIG,
  INITIAL_USERS,
  INITIAL_SAVINGS,
  INITIAL_APPROVALS,
  INITIAL_NOTICES,
  INITIAL_RULES,
  INITIAL_COMPLAINTS,
  INITIAL_FEATURE_REQUESTS,
  INITIAL_CHAT_MESSAGES,
  INITIAL_POLLS,
  INITIAL_RELEASES,
  INITIAL_AUDIT_LOGS,
  INITIAL_EXPENSES,
} from '../data/initialData';
import {
  evaluateApprovalState,
  calculateFinancialTotals,
  calculateGrowthRate,
  generateReceiptNumber,
  aggregateSavingsByMonth,
  formatCurrencyBengali,
} from '../utils/calculations';
import {
  initRealtimeSync,
  syncConfigToFirestore,
  syncNoticeToFirestore,
  deleteNoticeFromFirestore,
  syncRuleToFirestore,
  syncExecutiveMemberToFirestore,
  deleteExecutiveMemberFromFirestore,
  syncSavingsTransactionToFirestore,
  syncReceiptToFirestore,
  syncApprovalToFirestore,
  syncUserToFirestore,
  deleteUserFromFirestore,
  syncChatMessageToFirestore,
  syncPollToFirestore,
  syncPrivateMessageToFirestore,
  syncExpenseToFirestore,
  deleteExpenseFromFirestore,
  syncComplaintToFirestore,
  syncFeatureRequestToFirestore,
  syncUserNotificationToFirestore,
  performFullFirestoreSync,
  SyncStatus,
} from '../utils/firebaseSync';

// Unified single guest identity for all unauthenticated visitors.
export const GUEST_USER: UserProfile = {
  id: '__guest__',
  memberId: 'GUEST',
  name: 'অতিথি দর্শক',
  email: '',
  phone: '',
  role: 'MEMBER',
  status: 'APPROVED',
  joinDate: '2026-01-01',
  gender: 'OTHER',
};

export interface AppWarningDialog {
  title: string;
  message: string;
  showLoginCta?: boolean;
}

function normalizeNavTabsOrder(tabs?: string[]): string[] {
  const base = tabs && tabs.length > 0 ? tabs : INITIAL_CONFIG.navTabsOrder || [];
  const mapped = base.map((t) => (t === 'settings' ? 'profile' : t));
  const unique = Array.from(new Set(mapped));
  if (!unique.includes('profile')) {
    const homeIdx = unique.indexOf('home');
    if (homeIdx >= 0) {
      unique.splice(homeIdx + 1, 0, 'profile');
    } else {
      unique.unshift('profile');
    }
  }
  return unique;
}

interface AppContextType {
  // Theme & System Settings (Persisted across native APK & web restarts)
  theme: 'dark' | 'light';
  setTheme: (t: 'dark' | 'light') => void;
  isOnline: boolean;
  setIsOnline: (online: boolean) => void;
  isDemoMode: boolean;
  setIsDemoMode: (demo: boolean) => void;
  showExitDialog: boolean;
  setShowExitDialog: (show: boolean) => void;
  soundEnabled: boolean;
  setSoundEnabled: (enabled: boolean) => void;
  hapticEnabled: boolean;
  setHapticEnabled: (enabled: boolean) => void;
  pushNotificationsEnabled: boolean;
  togglePushNotifications: (enabled: boolean) => Promise<boolean>;
  storageAccessEnabled: boolean;
  toggleStorageAccess: (enabled: boolean) => Promise<boolean>;

  // Warning & Success Feedback
  warningDialog: AppWarningDialog | null;
  triggerWarning: (title: string, message: string, showLoginCta?: boolean) => void;
  triggerGuestWarning: (actionLabel?: string) => void;
  closeWarning: () => void;
  requireMemberAuth: (actionLabel?: string) => boolean;
  successMessage: string | null;
  triggerSuccess: (message: string) => void;
  closeSuccess: () => void;

  // Active User & Authentication
  currentUser: UserProfile;
  isGuestMode: boolean;
  setCurrentUser: (user: UserProfile | null) => void;
  logoutUser: () => void;
  maskPhoneForPrivacy: (phone: string, targetGender?: 'MALE' | 'FEMALE' | 'OTHER') => string;
  users: UserProfile[];
  updateUserProfile: (userId: string, partial: Partial<UserProfile>) => void;
  requestProfileChange: (userId: string, proposedChanges: { field: string; oldValue: any; newValue: any }[]) => void;
  registerNewAccount: (userData: Partial<UserProfile>) => void;
  approveUserAccount: (userId: string) => void;
  rejectUserAccount: (userId: string) => void;
  updateUserDesignation: (userId: string, moderatorTitle: string, role?: UserRole) => void;
  removeUser: (userId: string) => void;
  isAuthModalOpen: boolean;
  setIsAuthModalOpen: (open: boolean) => void;

  // Reminders for Overdue
  overdueReminders: string[];
  sendOverdueReminder: (memberId: string) => void;

  // Direct 1-on-1 Private Messaging
  privateMessages: PrivateMessage[];
  sendPrivateMessage: (receiverId: string, text: string) => void;
  deletePrivateMessage: (messageId: string) => void;
  activePrivateChatUser: UserProfile | null;
  setActivePrivateChatUser: (user: UserProfile | null) => void;

  // Financial & Savings
  savings: SavingsTransaction[];
  createSavingsEntry: (data: {
    memberId: string;
    amount: number;
    savingsMonth: string;
    savingsYear: number;
    paymentMethod: any;
    transactionRef?: string;
    notes?: string;
  }) => void;
  reverseTransaction: (txId: string, reason: string) => void;

  // Approvals & Workflows
  approvals: ApprovalRequest[];
  voteOnApproval: (approvalId: string, vote: 'APPROVE' | 'REJECT', reason?: string) => void;

  // Receipts & Print Modal
  receipts: ElectronicReceipt[];
  getReceiptForTransaction: (txId: string) => ElectronicReceipt | undefined;
  activePrintReceipt: ElectronicReceipt | null;
  setActivePrintReceipt: (receipt: ElectronicReceipt | null) => void;

  // Communication & Chat
  chatMessages: ChatMessage[];
  sendChatMessage: (
    channel: 'GENERAL' | 'MODERATOR_ONLY',
    text: string,
    imageUrl?: string,
    replyTo?: { id: string; text: string; senderName: string }
  ) => void;
  deleteChatMessage: (messageId: string) => void;
  forwardChatMessage: (messageId: string) => void;
  toggleMessageReaction: (messageId: string, emoji: string) => void;
  polls: ChatPoll[];
  votePoll: (pollId: string, optionId: string) => void;
  createPoll: (channel: 'GENERAL' | 'MODERATOR_ONLY', question: string, options: string[]) => void;
  deletePoll: (pollId: string) => void;
  updatePollOption: (pollId: string, optionId: string, text: string) => void;
  updatePollQuestion: (pollId: string, question: string) => void;
  chatUnreadCount: number;
  markChatSeen: () => void;
  unreadNoticeCount: number;
  hasUnreadNotices: boolean;
  markNoticesSeen: () => void;

  // Calling Feature
  activeCall: {
    callId: string;
    callerId: string;
    callerName: string;
    targetName?: string;
    channel: string;
    startedAt: string;
    status: 'RINGING' | 'CONNECTED' | 'ENDED';
  } | null;
  startCall: (channel?: 'GENERAL' | 'MODERATOR_ONLY' | 'PERSONAL', targetName?: string) => void;
  endCall: (durationSec?: number) => void;

  // Executive Committee
  executiveMembers: ExecutiveMember[];
  addExecutiveMember: (member: Omit<ExecutiveMember, 'id'>) => void;
  removeExecutiveMember: (id: string) => void;
  updateExecutiveMember: (id: string, partial: Partial<ExecutiveMember>) => void;

  // Online Tracking
  onlineUserIds: string[];

  // Notices, Complaints, Rules, Features
  notices: NoticeItem[];
  addNotice: (notice: Omit<NoticeItem, 'id' | 'createdAt' | 'authorName' | 'authorRole'>) => void;
  proposeNoticeEdit: (
    noticeId: string,
    updates: Partial<Pick<NoticeItem, 'title' | 'content' | 'priority' | 'imageUrl' | 'isPinned' | 'showInTicker'>>
  ) => void;
  updateNotice: (noticeId: string, partial: Partial<NoticeItem>) => void;
  deleteNotice: (noticeId: string) => void;
  complaints: ComplaintItem[];
  submitComplaint: (title: string, description: string) => void;
  updateComplaintStatus: (id: string, status: ComplaintItem['status'], moderatorNotes?: string) => void;
  featureRequests: FeatureRequestItem[];
  submitFeatureRequest: (title: string, description: string) => void;
  voteFeatureRequest: (id: string) => void;
  rules: FoundationRule[];
  updateRule: (ruleId: string, title: string, description: string) => void;

  // App Moderator & Configuration
  config: AppConfiguration;
  updateConfig: (newConfig: Partial<AppConfiguration>) => void;
  auditLogs: AuditLogItem[];
  releases: AppRelease[];
  publishAppRelease: (release: Omit<AppRelease, 'id'>) => void;
  activeUpdateDialog: AppRelease | null;
  setActiveUpdateDialog: (rel: AppRelease | null) => void;

  // Sync & Pull-to-Refresh (Moderator Only + Online Required)
  refreshAllData: () => Promise<void>;
  isRefreshing: boolean;

  // Backup & Restore
  exportBackupData: () => string;
  restoreFromBackup: (jsonData: string) => { success: boolean; message: string };
  resetToInitialDemo: () => void;

  // Foundation Expenses & Actual Balance
  expenses: FoundationExpense[];
  addExpense: (expense: Omit<FoundationExpense, 'id'>) => void;
  removeExpense: (id: string) => void;
  totalExpenses: number;
  netReserveBalance: number;

  // Universal Search Modal
  isSearchModalOpen: boolean;
  setIsSearchModalOpen: (open: boolean) => void;

  // Real-time Cloud Synchronization (Firebase Firestore)
  cloudSyncStatus: SyncStatus;
  lastSyncTimestamp: string;
  triggerCloudSync: () => Promise<void>;

  // User Targeted Notifications & System Push
  userNotifications: UserNotification[];
  sendUserNotification: (
    targetUserId: string,
    title: string,
    message: string,
    type: UserNotification['type'],
    color: UserNotification['color']
  ) => void;
  markNotificationRead: (id: string) => void;
  markAllNotificationsRead: () => void;

  // Pending Deposit duplicate submission prevention
  pendingDepositModalOpen: boolean;
  setPendingDepositModalOpen: (open: boolean) => void;
  checkUserHasPendingDeposit: (memberId: string) => boolean;

  // Aggregated summaries
  financialTotals: ReturnType<typeof calculateFinancialTotals>;
  growthRate: ReturnType<typeof calculateGrowthRate>;
  monthlyAggregates: Record<string, number>;
  eligibleModeratorsCount: number;
  unreadCount: number;
  uniqueDailyVisitors: number;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const STORAGE_KEY = 'basis_foundation_storage_v1';

const getInitialSaved = () => {
  if (typeof window === 'undefined') return null;
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) return JSON.parse(raw);
  } catch (e) {
    console.error('Failed to parse stored data', e);
  }
  return null;
};

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const initialSaved = getInitialSaved();

  // Persistent App Settings (Points 8 & 9)
  const [theme, setTheme] = useState<'dark' | 'light'>(() =>
    initialSaved?.settings?.theme === 'light' ? 'light' : 'dark'
  );
  const [isOnline, setIsOnline] = useState<boolean>(() =>
    typeof navigator !== 'undefined' ? navigator.onLine : true
  );
  const [isDemoMode, setIsDemoMode] = useState<boolean>(true);
  const [showExitDialog, setShowExitDialog] = useState<boolean>(false);
  const [soundEnabled, setSoundEnabled] = useState<boolean>(() =>
    typeof initialSaved?.settings?.soundEnabled === 'boolean' ? initialSaved.settings.soundEnabled : true
  );
  const [hapticEnabled, setHapticEnabled] = useState<boolean>(() =>
    typeof initialSaved?.settings?.hapticEnabled === 'boolean' ? initialSaved.settings.hapticEnabled : true
  );
  const [pushNotificationsEnabled, setPushNotificationsEnabled] = useState<boolean>(() => {
    if (typeof initialSaved?.settings?.pushNotificationsEnabled === 'boolean') {
      return initialSaved.settings.pushNotificationsEnabled;
    }
    if (typeof window !== 'undefined' && window.AndroidBridge?.hasNotificationPermission) {
      try {
        return Boolean(window.AndroidBridge.hasNotificationPermission());
      } catch {}
    }
    if (typeof window !== 'undefined' && 'Notification' in window) {
      return Notification.permission === 'granted';
    }
    return false;
  });
  const [storageAccessEnabled, setStorageAccessEnabled] = useState<boolean>(() => {
    if (typeof initialSaved?.settings?.storageAccessEnabled === 'boolean') {
      return initialSaved.settings.storageAccessEnabled;
    }
    if (typeof window !== 'undefined' && window.AndroidBridge?.hasStoragePermission) {
      try {
        return Boolean(window.AndroidBridge.hasStoragePermission());
      } catch {}
    }
    return false;
  });

  // Persistent Seen IDs for Badges (Point 9)
  const [seenNoticeIds, setSeenNoticeIds] = useState<string[]>(() =>
    Array.isArray(initialSaved?.seenNoticeIds) ? initialSaved.seenNoticeIds : []
  );
  const [seenChatIds, setSeenChatIds] = useState<string[]>(() =>
    Array.isArray(initialSaved?.seenChatIds) ? initialSaved.seenChatIds : []
  );

  // Entities state with LocalStorage auto-restoration
  const [config, setConfig] = useState<AppConfiguration>(() => {
    const baseCfg = initialSaved?.config ? { ...INITIAL_CONFIG, ...initialSaved.config } : INITIAL_CONFIG;
    return {
      ...baseCfg,
      navTabsOrder: normalizeNavTabsOrder(baseCfg.navTabsOrder),
    };
  });
  const [users, setUsers] = useState<UserProfile[]>(() => initialSaved?.users || INITIAL_USERS);
  const [currentUser, setCurrentUserState] = useState<UserProfile>(() => {
    if (initialSaved?.currentUserId && initialSaved?.users) {
      const found = initialSaved.users.find((u: UserProfile) => u.id === initialSaved.currentUserId);
      if (found && found.id !== '__guest__') return found;
    }
    return GUEST_USER;
  });

  const setCurrentUser = (user: UserProfile | null) => {
    setCurrentUserState(user && user.id !== '__guest__' ? user : GUEST_USER);
  };
  const isGuestMode = currentUser.id === '__guest__';

  // Warning & Success dialogs
  const [warningDialog, setWarningDialog] = useState<AppWarningDialog | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  const triggerWarning = (title: string, message: string, showLoginCta = false) => {
    setWarningDialog({ title, message, showLoginCta });
    if (hapticEnabled && typeof navigator !== 'undefined' && navigator.vibrate) {
      try {
        navigator.vibrate([60, 40, 60]);
      } catch {}
    }
  };

  const triggerGuestWarning = (actionLabel?: string) => {
    const label = actionLabel ? `"${actionLabel}"` : 'কোনো তথ্য সম্পাদনা বা সাবমিট';
    triggerWarning(
      'অতিথি মোড সীমাবদ্ধতা (Guest Mode)',
      `আপনি বর্তমানে অতিথি দর্শক হিসেবে অ্যাপটি ভিজিট করছেন। অতিথি ইউজার হিসেবে ${label} করার অনুমতি নেই। এই সুবিধাটি ব্যবহার করতে অনুগ্রহ করে আপনার সদস্য অ্যাকাউন্টে লগইন করুন।`,
      true
    );
  };

  const closeWarning = () => setWarningDialog(null);

  const requireMemberAuth = (actionLabel?: string): boolean => {
    if (isGuestMode) {
      triggerGuestWarning(actionLabel);
      return false;
    }
    return true;
  };

  const logoutUser = () => {
    setCurrentUser(GUEST_USER);
    setActivePrivateChatUser(null);
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        delete parsed.currentUserId;
        localStorage.setItem(STORAGE_KEY, JSON.stringify(parsed));
      }
    } catch {}
    triggerSuccess('সফলভাবে লগআউট সম্পন্ন হয়েছে! আপনি এখন অতিথি দর্শক মোডে আছেন।');
  };

  const maskPhoneForPrivacy = (phone: string, targetGender?: 'MALE' | 'FEMALE' | 'OTHER') => {
    if (!phone) return '';
    const isPrivileged = !isGuestMode && (currentUser?.role === 'APP_MODERATOR' || currentUser?.role === 'MODERATOR');
    if (targetGender === 'FEMALE' && !isPrivileged) {
      const clean = phone.replace(/\s+/g, '');
      const prefix = clean.slice(0, 5);
      return `${prefix}**-****** (গোপনীয়)`;
    }
    return phone;
  };

  const [savings, setSavings] = useState<SavingsTransaction[]>(() => initialSaved?.savings || INITIAL_SAVINGS);
  const [approvals, setApprovals] = useState<ApprovalRequest[]>(() => initialSaved?.approvals || INITIAL_APPROVALS);
  const [receipts, setReceipts] = useState<ElectronicReceipt[]>(() => initialSaved?.receipts || []);
  const [notices, setNotices] = useState<NoticeItem[]>(() => initialSaved?.notices || INITIAL_NOTICES);
  const [rules, setRules] = useState<FoundationRule[]>(() => initialSaved?.rules || INITIAL_RULES);
  const [complaints, setComplaints] = useState<ComplaintItem[]>(() => initialSaved?.complaints || INITIAL_COMPLAINTS);
  const [featureRequests, setFeatureRequests] = useState<FeatureRequestItem[]>(
    () => initialSaved?.featureRequests || INITIAL_FEATURE_REQUESTS
  );
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>(() => initialSaved?.chatMessages || INITIAL_CHAT_MESSAGES);
  const [polls, setPolls] = useState<ChatPoll[]>(() => initialSaved?.polls || INITIAL_POLLS || []);
  const [releases, setReleases] = useState<AppRelease[]>(() => initialSaved?.releases || INITIAL_RELEASES);
  const [auditLogs, setAuditLogs] = useState<AuditLogItem[]>(() => initialSaved?.auditLogs || INITIAL_AUDIT_LOGS);
  const [activeUpdateDialog, setActiveUpdateDialog] = useState<AppRelease | null>(null);
  const [uniqueDailyVisitors] = useState<number>(342);

  // Authentication & Registration state
  const [isAuthModalOpen, setIsAuthModalOpen] = useState<boolean>(false);

  // Overdue reminders state
  const [overdueReminders, setOverdueReminders] = useState<string[]>(['BF-004']);

  // 1-on-1 Private Messaging state
  const [privateMessages, setPrivateMessages] = useState<PrivateMessage[]>(() => initialSaved?.privateMessages || [
    {
      id: 'pm-1',
      conversationId: 'user-mod-2_user-mod-3',
      senderId: 'user-mod-3',
      senderName: 'সাবরিনা আক্তার',
      receiverId: 'user-mod-2',
      receiverName: 'তানভীর আহমেদ',
      text: 'আসসালামু আলাইকুম তানভীর ভাই, চলতি মাসের সঞ্চয় অডিট রিপোর্ট কি প্রস্তুত হয়েছে?',
      timestamp: new Date(Date.now() - 7200000).toISOString(),
      isRead: true,
    },
    {
      id: 'pm-2',
      conversationId: 'user-mod-2_user-mod-3',
      senderId: 'user-mod-2',
      senderName: 'তানভীর আহমেদ',
      receiverId: 'user-mod-3',
      receiverName: 'সাবরিনা আক্তার',
      text: 'ওয়ালাইকুমুস সালাম আপা। হ্যাঁ, আলহামদুলিল্লাহ প্রস্তুত হয়েছে। ড্যাশবোর্ডে আপডেট পেয়ে যাবেন।',
      timestamp: new Date(Date.now() - 3600000).toISOString(),
      isRead: true,
    },
  ]);
  const [activePrivateChatUser, setActivePrivateChatUserState] = useState<UserProfile | null>(null);
  const setActivePrivateChatUser = (user: UserProfile | null) => {
    if (user && isGuestMode) {
      triggerGuestWarning('ব্যক্তিগত বার্তা প্রেরণ');
      return;
    }
    setActivePrivateChatUserState(user);
  };

  // Printable receipt state
  const [activePrintReceipt, setActivePrintReceipt] = useState<ElectronicReceipt | null>(null);

  // Pull-to-refresh & auto refresh state
  const [isRefreshing, setIsRefreshing] = useState<boolean>(false);

  // Foundation Expenses state
  const [expenses, setExpenses] = useState<FoundationExpense[]>(() => initialSaved?.expenses || INITIAL_EXPENSES);

  // Universal Search Modal state
  const [isSearchModalOpen, setIsSearchModalOpen] = useState<boolean>(false);

  // Executive Committee state
  const [executiveMembers, setExecutiveMembers] = useState<ExecutiveMember[]>(() => initialSaved?.executiveMembers || [
    {
      id: 'exec-1',
      name: 'মাহমুদুল হাসান সিয়াম',
      designation: 'প্রধান অ্যাপ মডারেটর ও সমন্বয়ক',
      phone: '০১৭০০-০০০০০১',
      avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150',
      responsibilities: 'অ্যাপ্লিকেশনের প্রযুক্তিগত পরিচালনা, ডিজিটাল কোর ব্যাংকিং ও নিরাপত্তা নিয়ন্ত্রণ।',
      order: 1,
      approvedDate: '২০২৫-০১-১০',
    },
    {
      id: 'exec-2',
      name: 'তানভীর আহমেদ',
      designation: 'সভাপতি / প্রধান নির্বাহী',
      phone: '০১৭০০-০০০০০২',
      avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150',
      responsibilities: 'কার্যনির্বাহী পরিষদের সার্বিক তদারকি ও প্রাতিষ্ঠানিক প্রতিনিধিত্ব।',
      order: 2,
      approvedDate: '২০২৫-০১-১০',
    },
    {
      id: 'exec-3',
      name: 'সাবরিনা আক্তার',
      designation: 'সাধারণ সম্পাদক ও প্রধান অডিটর',
      phone: '০১৭০০-০০০০০৩',
      avatarUrl: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150',
      responsibilities: 'সদস্য সমন্বয়, সভার কার্যবিবরণী ও আর্থিক হিসাব অডিট অনুমোদন।',
      order: 3,
      approvedDate: '২০২৫-০১-১০',
    },
    {
      id: 'exec-4',
      name: 'রাশেদুল করিম',
      designation: 'কোষাধ্যক্ষ (Treasurer)',
      phone: '০১৭০০-০০০০০৪',
      avatarUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150',
      responsibilities: 'যৌথ ব্যাংক হিসাব পরিচালনা ও মাসিক জমার হিসাবপত্র সংরক্ষণ।',
      order: 4,
      approvedDate: '২০২৫-০১-১০',
    },
  ]);

  // Real-time Cloud Synchronization (Firebase Firestore)
  const [cloudSyncStatus, setCloudSyncStatus] = useState<SyncStatus>('LOCAL');
  const [lastSyncTimestamp, setLastSyncTimestamp] = useState<string>(() => new Date().toLocaleTimeString('bn-BD'));
  const [pendingDepositModalOpen, setPendingDepositModalOpen] = useState<boolean>(false);

  // User Notifications state
  const [userNotifications, setUserNotifications] = useState<UserNotification[]>(() => initialSaved?.userNotifications || [
    {
      id: 'notif-welcome',
      userId: 'ALL',
      title: 'বেসিস ফাউন্ডেশনে স্বাগতম',
      message: 'ডিজিটাল সমবায় সঞ্চয় প্ল্যাটফর্মে আপনার স্বাগতম। প্রতি মাসের ১০ তারিখের মধ্যে আপনার সঞ্চয় জমা সম্পন্ন করুন।',
      type: 'GENERAL',
      color: 'emerald',
      createdAt: '2026-10-01T09:00:00.000Z',
      read: false,
    },
  ]);

  // Accurate Persistent Unread Counts for Chat & Notices (Point 9)
  const chatUnreadCount = useMemo(() => {
    const canSeeModChannel = !isGuestMode && currentUser.role !== 'MEMBER';
    const unseenGroupMsgs = chatMessages.filter(
      (m) =>
        !m.isDeleted &&
        m.senderId !== currentUser.id &&
        (m.channel === 'GENERAL' || canSeeModChannel) &&
        !seenChatIds.includes(m.id)
    ).length;

    const unseenPrivateMsgs = isGuestMode
      ? 0
      : privateMessages.filter(
          (pm) =>
            !pm.isDeleted &&
            pm.receiverId === currentUser.id &&
            !pm.isRead &&
            !seenChatIds.includes(pm.id)
        ).length;

    return unseenGroupMsgs + unseenPrivateMsgs;
  }, [chatMessages, privateMessages, seenChatIds, currentUser.id, currentUser.role, isGuestMode]);

  const markChatSeen = () => {
    const allChatIds = chatMessages.map((m) => m.id);
    const allPmIds = privateMessages
      .filter((pm) => pm.receiverId === currentUser.id || pm.senderId === currentUser.id)
      .map((pm) => pm.id);

    setSeenChatIds((prev) => Array.from(new Set([...prev, ...allChatIds, ...allPmIds])));

    if (!isGuestMode) {
      setPrivateMessages((prev) =>
        prev.map((pm) => (pm.receiverId === currentUser.id && !pm.isRead ? { ...pm, isRead: true } : pm))
      );
    }
  };

  const relevantNotifications = useMemo(() => {
    return userNotifications.filter(
      (n) => n.userId === 'ALL' || (!isGuestMode && n.userId === currentUser.memberId)
    );
  }, [userNotifications, isGuestMode, currentUser.memberId]);

  const unreadNoticeCount = useMemo(() => {
    const unseenBoardNotices = notices.filter((n) => !seenNoticeIds.includes(n.id)).length;
    const unseenUserNotifs = relevantNotifications.filter(
      (n) => !n.read && !seenNoticeIds.includes(n.id)
    ).length;
    return unseenBoardNotices + unseenUserNotifs;
  }, [notices, relevantNotifications, seenNoticeIds]);

  const hasUnreadNotices = unreadNoticeCount > 0;

  const markNoticesSeen = () => {
    const noticeIds = notices.map((n) => n.id);
    const notifIds = relevantNotifications.map((n) => n.id);
    setSeenNoticeIds((prev) => Array.from(new Set([...prev, ...noticeIds, ...notifIds])));
    setUserNotifications((prev) =>
      prev.map((n) =>
        n.userId === 'ALL' || (!isGuestMode && n.userId === currentUser.memberId)
          ? { ...n, read: true }
          : n
      )
    );
  };

  // Permission handlers for Native APK & Browser (Point 8)
  const togglePushNotifications = async (enabled: boolean): Promise<boolean> => {
    if (!enabled) {
      setPushNotificationsEnabled(false);
      triggerSuccess('পুশ নোটিফিকেশন বন্ধ করা হয়েছে।');
      return false;
    }

    try {
      // 1. Native Android Studio WebView Bridge
      if (typeof window !== 'undefined' && window.AndroidBridge?.requestNotificationPermission) {
        const granted = window.AndroidBridge.requestNotificationPermission();
        if (granted !== false) {
          setPushNotificationsEnabled(true);
          triggerSuccess('পুশ নোটিফিকেশন পারমিশন সফলভাবে সক্রিয় হয়েছে!');
          return true;
        }
      }

      // 2. Standard Web Notification API
      if (typeof window !== 'undefined' && 'Notification' in window) {
        if (Notification.permission === 'granted') {
          setPushNotificationsEnabled(true);
          triggerSuccess('পুশ নোটিফিকেশন সক্রিয় রয়েছে!');
          return true;
        }
        const perm = await Notification.requestPermission();
        if (perm === 'granted') {
          setPushNotificationsEnabled(true);
          triggerSuccess('পুশ নোটিফিকেশন পারমিশন সফলভাবে সক্রিয় হয়েছে!');
          return true;
        } else {
          setPushNotificationsEnabled(false);
          triggerWarning(
            'নোটিফিকেশন পারমিশন প্রয়োজন',
            'আপনার ব্রাউজার বা ফোনের অ্যাপ সেটিংস থেকে নোটিফিকেশন পারমিশন ব্লক করা আছে। অনুগ্রহ করে ফোনের Settings > Apps > Basis Foundation > Notifications থেকে Allow করুন।'
          );
          return false;
        }
      }

      // Fallback inside WebViews where Notification constructor is absent
      setPushNotificationsEnabled(true);
      triggerSuccess('অ্যাপ নোটিফিকেশন সক্রিয় করা হয়েছে!');
      return true;
    } catch (err) {
      console.warn('Notification permission request error:', err);
      setPushNotificationsEnabled(true);
      triggerSuccess('অ্যাপ নোটিফিকেশন প্রেফারেন্স সংরক্ষিত হয়েছে!');
      return true;
    }
  };

  const toggleStorageAccess = async (enabled: boolean): Promise<boolean> => {
    if (!enabled) {
      setStorageAccessEnabled(false);
      triggerSuccess('স্টোরেজ অটো- অ্যাক্সেস অপশন বন্ধ করা হয়েছে।');
      return false;
    }

    try {
      if (typeof window !== 'undefined' && window.AndroidBridge?.requestStoragePermission) {
        const res = window.AndroidBridge.requestStoragePermission();
        if (res === false) {
          triggerWarning(
            'স্টোরেজ পারমিশন প্রয়োজন',
            'ফোনের স্টোরেজে রিসিট ও স্টেটমেন্ট সংরক্ষণের জন্য ফোনের Settings থেকে Storage পারমিশন অনুমোদন করুন।'
          );
          return false;
        }
      }

      if (typeof navigator !== 'undefined' && navigator.storage && navigator.storage.persist) {
        await navigator.storage.persist();
      }

      setStorageAccessEnabled(true);
      triggerSuccess('ডিভাইস স্টোরেজ অ্যাক্সেস সক্রিয় হয়েছে! রিসিট ও স্টেটমেন্ট সরাসরি ফোনের ডাউনলোড ফোল্ডারে সেভ হবে।');
      return true;
    } catch (err) {
      console.warn('Storage permission request error:', err);
      setStorageAccessEnabled(true);
      triggerSuccess('ডিভাইস স্টোরেজ ডাউনলোড মোড সক্রিয় হয়েছে!');
      return true;
    }
  };

  // Real-time call state
  const [activeCall, setActiveCall] = useState<{
    callId: string;
    callerId: string;
    callerName: string;
    targetName?: string;
    channel: string;
    startedAt: string;
    status: 'RINGING' | 'CONNECTED' | 'ENDED';
  } | null>(null);

  const startCall = (channel: 'GENERAL' | 'MODERATOR_ONLY' | 'PERSONAL' = 'GENERAL', targetName?: string) => {
    if (!requireMemberAuth('অডিও/ভিডিও কল শুরু')) return;
    const callObj = {
      callId: `call-${Date.now()}`,
      callerId: currentUser.id,
      callerName: currentUser.name,
      targetName: targetName || (channel === 'GENERAL' ? 'সকল সাধারণ সদস্য' : 'মডারেটর প্যানেল'),
      channel,
      startedAt: new Date().toISOString(),
      status: 'RINGING' as const,
    };
    setActiveCall(callObj);
  };

  const endCall = (durationSec: number = 0) => {
    if (!activeCall) return;
    const durFormatted = durationSec > 0
      ? `${Math.floor(durationSec / 60)} মিনিট ${durationSec % 60} সেকেন্ড`
      : 'কয়েক সেকেন্ড';
    const msg = `📞 [কল সমাপ্ত]\n${activeCall.callerName} এর সাথে অডিও/ভিডিও কল সমাপ্ত হয়েছে। মোট স্থিতিকাল: ${durFormatted}`;
    if (!isGuestMode && (activeCall.channel === 'GENERAL' || activeCall.channel === 'MODERATOR_ONLY')) {
      sendChatMessage(activeCall.channel, msg);
    }
    setActiveCall(null);
  };

  const addExecutiveMember = (member: Omit<ExecutiveMember, 'id'>) => {
    if (!requireMemberAuth('কার্যনির্বাহী সদস্য সংযোজন')) return;
    const newExec: ExecutiveMember = {
      ...member,
      id: `exec-${Date.now()}`,
      order: executiveMembers.length + 1,
      approvedDate: new Date().toLocaleDateString('en-GB'),
    };
    setExecutiveMembers((prev) => [...prev, newExec]);
    syncExecutiveMemberToFirestore(newExec);
    triggerSuccess('কার্যনির্বাহী পর্ষদে নতুন সদস্য অনুমোদিত ও যুক্ত হয়েছে!');
  };

  const removeExecutiveMember = (id: string) => {
    if (!requireMemberAuth('কার্যনির্বাহী সদস্য অপসারণ')) return;
    setExecutiveMembers((prev) => prev.filter((m) => m.id !== id));
    deleteExecutiveMemberFromFirestore(id);
    triggerSuccess('কার্যনির্বাহী পর্ষদ থেকে পদবি বাতিল ও সদস্য অপসারণ করা হয়েছে।');
  };

  const updateExecutiveMember = (id: string, partial: Partial<ExecutiveMember>) => {
    if (!requireMemberAuth('কার্যনির্বাহী পর্ষদ সম্পাদনা')) return;
    setExecutiveMembers((prev) => {
      const updated = prev.map((m) => (m.id === id ? { ...m, ...partial } : m));
      const target = updated.find((m) => m.id === id);
      if (target) syncExecutiveMemberToFirestore(target);
      return updated;
    });
    triggerSuccess('কার্যনির্বাহী পর্ষদের তথ্য সফলভাবে হালনাগাদ করা হয়েছে!');
  };

  const checkUserHasPendingDeposit = (memberId: string): boolean => {
    return savings.some((s) => s.memberId === memberId && s.status === 'PENDING');
  };

  const sendUserNotification = (
    targetUserId: string,
    title: string,
    message: string,
    type: UserNotification['type'],
    color: UserNotification['color']
  ) => {
    const newNotif: UserNotification = {
      id: `notif-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      userId: targetUserId,
      title,
      message,
      type,
      color,
      createdAt: new Date().toISOString(),
      read: false,
    };
    setUserNotifications((prev) => [newNotif, ...prev]);
    syncUserNotificationToFirestore(newNotif);

    if (
      pushNotificationsEnabled &&
      typeof window !== 'undefined' &&
      'Notification' in window &&
      Notification.permission === 'granted'
    ) {
      try {
        new Notification(title, {
          body: message,
          icon: '/logo.svg',
          badge: '/logo.svg',
          tag: newNotif.id,
        });
      } catch (err) {
        console.warn('Push notification delivery error:', err);
      }
    }
  };

  const markNotificationRead = (id: string) => {
    setSeenNoticeIds((prev) => (prev.includes(id) ? prev : [...prev, id]));
    setUserNotifications((prev) =>
      prev.map((n) => (n.id === id ? { ...n, read: true } : n))
    );
  };

  const markAllNotificationsRead = () => {
    const notifIds = relevantNotifications.map((n) => n.id);
    setSeenNoticeIds((prev) => Array.from(new Set([...prev, ...notifIds])));
    setUserNotifications((prev) =>
      prev.map((n) =>
        n.userId === 'ALL' || (!isGuestMode && n.userId === currentUser.memberId)
          ? { ...n, read: true }
          : n
      )
    );
  };

  // Real-time Firestore synchronization listener (Point 18)
  useEffect(() => {
    const unsubscribe = initRealtimeSync({
      onConfigChange: (remoteConfig) => {
        setConfig((prev) => ({
          ...prev,
          ...remoteConfig,
          navTabsOrder: normalizeNavTabsOrder(remoteConfig.navTabsOrder || prev.navTabsOrder),
        }));
      },
      onNoticesChange: (remoteNotices) => {
        if (remoteNotices && remoteNotices.length > 0) {
          setNotices(remoteNotices);
        }
      },
      onRulesChange: (remoteRules) => {
        if (remoteRules && remoteRules.length > 0) {
          setRules(remoteRules);
        }
      },
      onExecutiveMembersChange: (remoteMembers) => {
        if (remoteMembers && remoteMembers.length > 0) {
          setExecutiveMembers(remoteMembers);
        }
      },
      onSavingsChange: (remoteSavings) => {
        if (remoteSavings && remoteSavings.length > 0) {
          setSavings((prev) => {
            const map = new Map<string, SavingsTransaction>();
            prev.forEach((t) => map.set(t.id, t));
            remoteSavings.forEach((t) => map.set(t.id, t));
            return Array.from(map.values()).sort(
              (a, b) => new Date(b.transactionDate).getTime() - new Date(a.transactionDate).getTime()
            );
          });
        }
      },
      onUsersChange: (remoteUsers) => {
        if (remoteUsers && remoteUsers.length > 0) {
          setUsers((prev) => {
            const map = new Map<string, UserProfile>();
            prev.forEach((u) => {
              if (u.id !== '__guest__') map.set(u.id, u);
            });
            remoteUsers.forEach((u) => {
              if (u.id !== '__guest__') map.set(u.id, u);
            });
            const merged = Array.from(map.values());
            setCurrentUserState((curr) => {
              if (curr.id === '__guest__') return GUEST_USER;
              const updatedSelf = merged.find((x) => x.id === curr.id);
              return updatedSelf || curr;
            });
            return merged;
          });
        }
      },
      onApprovalsChange: (remoteApprovals) => {
        if (remoteApprovals && remoteApprovals.length > 0) {
          setApprovals((prev) => {
            const map = new Map<string, ApprovalRequest>();
            prev.forEach((a) => map.set(a.id, a));
            remoteApprovals.forEach((a) => map.set(a.id, a));
            return Array.from(map.values()).sort(
              (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
            );
          });
        }
      },
      onChatChange: (remoteChat) => {
        if (remoteChat && remoteChat.length > 0) {
          setChatMessages(remoteChat);
        }
      },
      onPollsChange: (remotePolls) => {
        if (remotePolls && remotePolls.length > 0) {
          setPolls(remotePolls);
        }
      },
      onPrivateMessagesChange: (remotePMs) => {
        if (remotePMs && remotePMs.length > 0) {
          setPrivateMessages(remotePMs);
        }
      },
      onReceiptsChange: (remoteReceipts) => {
        if (remoteReceipts && remoteReceipts.length > 0) {
          setReceipts((prev) => {
            const map = new Map<string, ElectronicReceipt>();
            prev.forEach((r) => map.set(r.receiptNumber, r));
            remoteReceipts.forEach((r) => map.set(r.receiptNumber, r));
            return Array.from(map.values());
          });
        }
      },
      onExpensesChange: (remoteExpenses) => {
        if (remoteExpenses && remoteExpenses.length > 0) {
          setExpenses(remoteExpenses);
        }
      },
      onComplaintsChange: (remoteComplaints) => {
        if (remoteComplaints && remoteComplaints.length > 0) {
          setComplaints(remoteComplaints);
        }
      },
      onFeaturesChange: (remoteFeatures) => {
        if (remoteFeatures && remoteFeatures.length > 0) {
          setFeatureRequests(remoteFeatures);
        }
      },
      onNotificationsChange: (remoteNotifs) => {
        if (remoteNotifs && remoteNotifs.length > 0) {
          setUserNotifications((prev) => {
            const map = new Map<string, UserNotification>();
            prev.forEach((n) => map.set(n.id, n));
            remoteNotifs.forEach((n) => {
              const existing = map.get(n.id);
              map.set(n.id, existing?.read ? { ...n, read: true } : n);
            });
            return Array.from(map.values()).sort(
              (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
            );
          });
        }
      },
      onStatusChange: (status, timestamp) => {
        setCloudSyncStatus(status);
        setLastSyncTimestamp(timestamp);
      },
    });

    return () => {
      unsubscribe();
    };
  }, []);

  // Moderator-only + Online-only Cloud Sync (Point 14 & Point 18)
  const triggerCloudSync = async () => {
    const isMod = !isGuestMode && (currentUser.role === 'APP_MODERATOR' || currentUser.role === 'MODERATOR');
    if (!isMod) {
      triggerWarning(
        'অনুমতি সীমাবদ্ধ',
        'শুধুমাত্র অনুমোদিত মডারেটরগণ ফায়ারবেজ ক্লাউড সিংক পরিচালনা করতে পারবেন।',
        isGuestMode
      );
      return;
    }

    const actuallyOnline = typeof navigator !== 'undefined' ? navigator.onLine && isOnline : isOnline;
    if (!actuallyOnline) {
      setCloudSyncStatus('OFFLINE');
      triggerWarning(
        'ইন্টারনেট সংযোগ নেই!',
        'অ্যাপ সিংক করার জন্য ইন্টারনেট কানেক্টিভিটি আবশ্যক। অনুগ্রহ করে ইন্টারনেট কানেক্ট করে পুনরায় চেষ্টা করুন।'
      );
      return;
    }

    setCloudSyncStatus('SYNCING');
    setIsRefreshing(true);
    try {
      const ok = await performFullFirestoreSync(
        {
          config,
          users,
          savings,
          receipts,
          approvals,
          notices,
          rules,
          expenses,
          complaints,
          featureRequests,
        },
        {
          onConfigChange: (remoteCfg) =>
            setConfig((prev) => ({
              ...prev,
              ...remoteCfg,
              navTabsOrder: normalizeNavTabsOrder(remoteCfg.navTabsOrder || prev.navTabsOrder),
            })),
          onUsersChange: (remoteUsers) => {
            if (remoteUsers.length > 0) {
              setUsers((prev) => {
                const map = new Map<string, UserProfile>();
                prev.forEach((u) => {
                  if (u.id !== '__guest__') map.set(u.id, u);
                });
                remoteUsers.forEach((u) => {
                  if (u.id !== '__guest__') map.set(u.id, u);
                });
                return Array.from(map.values());
              });
            }
          },
          onSavingsChange: (remoteTx) => {
            if (remoteTx.length > 0) setSavings(remoteTx);
          },
          onNoticesChange: (remoteNotices) => {
            if (remoteNotices.length > 0) setNotices(remoteNotices);
          },
          onApprovalsChange: (remoteApprovals) => {
            if (remoteApprovals.length > 0) setApprovals(remoteApprovals);
          },
          onRulesChange: (remoteRules) => {
            if (remoteRules.length > 0) setRules(remoteRules);
          },
          onStatusChange: (st, ts) => {
            setCloudSyncStatus(st);
            setLastSyncTimestamp(ts);
          },
        }
      );

      await Promise.all([
        syncConfigToFirestore(config),
        ...notices.map((n) => syncNoticeToFirestore(n)),
        ...rules.map((r) => syncRuleToFirestore(r)),
        ...executiveMembers.map((m) => syncExecutiveMemberToFirestore(m)),
        ...users.filter((u) => u.id !== '__guest__').map((u) => syncUserToFirestore(u)),
        ...savings.map((tx) => syncSavingsTransactionToFirestore(tx)),
        ...approvals.map((a) => syncApprovalToFirestore(a)),
        ...expenses.map((e) => syncExpenseToFirestore(e)),
        ...complaints.map((c) => syncComplaintToFirestore(c)),
        ...featureRequests.map((f) => syncFeatureRequestToFirestore(f)),
      ]);

      setIsRefreshing(false);
      if (ok) {
        setCloudSyncStatus('SYNCED');
        setLastSyncTimestamp(new Date().toLocaleTimeString('bn-BD'));
        triggerSuccess('ফায়ারবেজ ক্লাউডে সমস্ত ডাটা সফলভাবে সিংক সম্পন্ন হয়েছে!');
      } else {
        setCloudSyncStatus('LOCAL');
        triggerWarning('সিংক সম্পন্ন হয়নি', 'ফায়ারবেজ সার্ভারের সাথে সংযোগ স্থাপন করা যায়নি। ইন্টারনেট সংযোগ পরীক্ষা করুন।');
      }
    } catch (err) {
      setIsRefreshing(false);
      setCloudSyncStatus('LOCAL');
      triggerWarning('সিংক ত্রুটি', 'ক্লাউড সিংক চলাকালীন একটি ত্রুটি ঘটেছে। অনুগ্রহ করে ইন্টারনেট কানেকশন যাচাই করুন।');
    }
  };

  // Online User Tracking
  const onlineUserIds = useMemo(() => {
    if (!isOnline) return [];
    return users.map((u) => u.id);
  }, [isOnline, users]);

  // Sync dark/light class on HTML element
  useEffect(() => {
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
      document.documentElement.classList.remove('light');
    } else {
      document.documentElement.classList.remove('dark');
      document.documentElement.classList.add('light');
    }
  }, [theme]);

  // Sync font size scaling directly on document root
  useEffect(() => {
    const sizeMap: Record<string, string> = {
      small: '13.5px',
      medium: '16px',
      large: '18.5px',
      xlarge: '21px',
    };
    const targetSize = sizeMap[config.fontSize || 'medium'] || '16px';
    document.documentElement.style.fontSize = targetSize;
    document.documentElement.classList.remove('font-scale-small', 'font-scale-medium', 'font-scale-large', 'font-scale-xlarge');
    document.documentElement.classList.add(`font-scale-${config.fontSize || 'medium'}`);
  }, [config.fontSize]);

  // Inject manual custom font if provided
  useEffect(() => {
    if (config.customFontUrl && config.customFontUrl.trim() !== '') {
      const existing = document.getElementById('custom-font-link');
      if (existing) existing.remove();
      const link = document.createElement('link');
      link.id = 'custom-font-link';
      link.rel = 'stylesheet';
      link.href = config.customFontUrl;
      document.head.appendChild(link);
    }
    if (config.customFontFamily && config.customFontFamily.trim() !== '') {
      document.body.style.fontFamily = `'${config.customFontFamily}', var(--font-bengali)`;
    } else {
      document.body.style.fontFamily = `var(--font-bengali)`;
    }
  }, [config.customFontUrl, config.customFontFamily]);

  // Inject and apply uploaded TTF/WOFF/OTF font file dynamically
  useEffect(() => {
    if (config.uploadedFontDataUrl) {
      const fontName = config.uploadedFontName || 'UserCustomFont';
      let styleTag = document.getElementById('app-uploaded-font-style') as HTMLStyleElement | null;
      if (!styleTag) {
        styleTag = document.createElement('style');
        styleTag.id = 'app-uploaded-font-style';
        document.head.appendChild(styleTag);
      }
      styleTag.textContent = `
        @font-face {
          font-family: '${fontName}';
          src: url("${config.uploadedFontDataUrl}") format('truetype'),
               url("${config.uploadedFontDataUrl}") format('woff2'),
               url("${config.uploadedFontDataUrl}") format('woff'),
               url("${config.uploadedFontDataUrl}") format('opentype');
          font-weight: 100 900;
          font-display: swap;
        }
        body, html, input, button, select, textarea {
          font-family: '${fontName}', var(--font-bengali), system-ui, sans-serif !important;
        }
      `;
    }
  }, [config.uploadedFontDataUrl, config.uploadedFontName]);

  // Auto-sync ALL entity states, user settings & seen badges to LocalStorage (Point 9)
  useEffect(() => {
    try {
      const payload = {
        settings: {
          theme,
          soundEnabled,
          hapticEnabled,
          pushNotificationsEnabled,
          storageAccessEnabled,
        },
        seenNoticeIds,
        seenChatIds,
        config,
        users,
        currentUserId: currentUser && currentUser.id !== '__guest__' ? currentUser.id : null,
        savings,
        approvals,
        receipts,
        notices,
        rules,
        complaints,
        featureRequests,
        chatMessages,
        polls,
        releases,
        auditLogs,
        expenses,
        privateMessages,
        executiveMembers,
        userNotifications,
      };
      localStorage.setItem(STORAGE_KEY, JSON.stringify(payload));
    } catch (e) {
      console.error('Failed to auto-save to localStorage', e);
    }
  }, [
    theme,
    soundEnabled,
    hapticEnabled,
    pushNotificationsEnabled,
    storageAccessEnabled,
    seenNoticeIds,
    seenChatIds,
    config,
    users,
    currentUser?.id,
    savings,
    approvals,
    receipts,
    notices,
    rules,
    complaints,
    featureRequests,
    chatMessages,
    polls,
    releases,
    auditLogs,
    expenses,
    privateMessages,
    executiveMembers,
    userNotifications,
  ]);

  // Generate initial receipts for approved transactions if receipts list is empty
  useEffect(() => {
    const existingApproved = savings.filter((t) => t.status === 'APPROVED');
    setReceipts((prev) => {
      const byTxId = new Map<string, ElectronicReceipt>();
      prev.forEach((r) => byTxId.set(r.transactionId, r));
      existingApproved.forEach((tx, idx) => {
        if (!byTxId.has(tx.id)) {
          byTxId.set(tx.id, {
            receiptNumber: tx.receiptId || generateReceiptNumber(tx.savingsMonth, tx.memberId, idx + 1),
            transactionId: tx.id,
            memberId: tx.memberId,
            memberName: tx.memberName,
            savingsMonth: tx.savingsMonth,
            savingsYear: tx.savingsYear,
            amount: tx.amount,
            paymentMethod: tx.paymentMethod,
            transactionDate: tx.transactionDate,
            transactionRef: tx.transactionRef,
            approvalStatus: 'APPROVED',
            approvingModeratorNames: tx.approvingModerators.map((id) => {
              const u = users.find((usr) => usr.id === id);
              return u ? u.name : 'Authorized Moderator';
            }),
            generatedAt: tx.transactionDate,
            verificationHash: `BF-HASH-${tx.id}-${tx.memberId}-${Math.floor(tx.amount * 3.1415)}`,
          });
        }
      });
      return Array.from(byTxId.values());
    });
  }, [savings.length]);

  // Eligible moderators count
  const eligibleModeratorsCount = useMemo(() => {
    return users.filter(
      (u) => (u.role === 'APP_MODERATOR' || u.role === 'MODERATOR') && u.status === 'APPROVED'
    ).length;
  }, [users]);

  // Financial aggregates
  const financialTotals = useMemo(() => {
    return calculateFinancialTotals(savings);
  }, [savings]);

  // Monthly aggregates
  const monthlyAggregates = useMemo(() => {
    return aggregateSavingsByMonth(savings);
  }, [savings]);

  // Month-over-month growth rate
  const growthRate = useMemo(() => {
    const currentMonth = '2026-10';
    const previousMonth = '2026-09';
    const currentTotal = monthlyAggregates[currentMonth] || 0;
    const prevTotal = monthlyAggregates[previousMonth] || 0;
    return calculateGrowthRate(currentTotal, prevTotal);
  }, [monthlyAggregates]);

  // Total Expenses & Net Reserve Balance
  const totalExpenses = useMemo(() => {
    return expenses.reduce((sum, e) => sum + e.amount, 0);
  }, [expenses]);

  const netReserveBalance = useMemo(() => {
    return financialTotals.totalApproved - totalExpenses;
  }, [financialTotals.totalApproved, totalExpenses]);

  const addExpense = (expenseData: Omit<FoundationExpense, 'id'>) => {
    if (!requireMemberAuth('ব্যয়ের হিসাব সংযোজন')) return;
    const newExp: FoundationExpense = {
      ...expenseData,
      id: `exp-${Date.now()}`,
    };
    setExpenses((prev) => [newExp, ...prev]);
    syncExpenseToFirestore(newExp);
    logAudit('EXPENSE_RECORDED', 'FINANCE', newExp.id, `ব্যয় রেকর্ড: ${newExp.title} (৳${newExp.amount})`);
    triggerSuccess('ব্যয়ের হিসাব সফলভাবে যুক্ত করা হয়েছে!');
  };

  const removeExpense = (id: string) => {
    if (!requireMemberAuth('ব্যয়ের হিসাব অপসারণ')) return;
    setExpenses((prev) => prev.filter((e) => e.id !== id));
    deleteExpenseFromFirestore(id);
    logAudit('EXPENSE_DELETED', 'FINANCE', id, `ব্যয় রেকর্ড অপসারণ করা হয়েছে।`);
    triggerSuccess('ব্যয় রেকর্ড সফলভাবে অপসারণ করা হয়েছে!');
  };

  // Unread moderator workflow badge count
  const unreadCount = useMemo(() => {
    const pendingApprovals = approvals.filter((a) => a.status === 'PENDING').length;
    const pendingComplaints = complaints.filter((c) => c.status === 'SUBMITTED').length;
    return pendingApprovals + pendingComplaints;
  }, [approvals, complaints]);

  // Add an audit log entry
  const logAudit = (
    actionType: AuditLogItem['actionType'],
    targetType: string,
    targetId: string,
    details: string
  ) => {
    const newLog: AuditLogItem = {
      id: `log-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      actorId: currentUser?.id || 'system',
      actorName: currentUser?.name || 'অতিথি বা সিস্টেম',
      actorRole: currentUser?.role || 'MEMBER',
      actionType,
      targetType,
      targetId,
      timestamp: new Date().toISOString(),
      details,
      status: 'SUCCESS',
    };
    setAuditLogs((prev) => [newLog, ...prev]);
  };

  // Create savings transaction
  const createSavingsEntry = (data: {
    memberId: string;
    amount: number;
    savingsMonth: string;
    savingsYear: number;
    paymentMethod: any;
    transactionRef?: string;
    notes?: string;
  }) => {
    if (!requireMemberAuth('সঞ্চয় জমা এন্ট্রি দাখিল')) return;

    const member = users.find((u) => u.memberId === data.memberId);
    if (!member) return;

    const txId = `tx-${Date.now()}`;
    const entryCreatorId = currentUser.id;
    const entryCreatorName = currentUser.name;
    const isMod = currentUser.role !== 'MEMBER';

    const newTx: SavingsTransaction = {
      id: txId,
      memberId: data.memberId,
      memberName: member.name,
      amount: data.amount,
      savingsMonth: data.savingsMonth,
      savingsYear: data.savingsYear,
      transactionDate: new Date().toISOString(),
      paymentMethod: data.paymentMethod,
      transactionRef: data.transactionRef,
      entryCreatorId,
      entryCreatorName,
      status: 'PENDING',
      approvingModerators: isMod ? [currentUser.id] : [],
      notes: data.notes,
    };

    const approvalId = `appr-${Date.now()}`;
    const newApproval: ApprovalRequest = {
      id: approvalId,
      requestType: 'SAVINGS_ENTRY',
      targetRecordId: txId,
      requestingUserId: entryCreatorId,
      requestingUserName: entryCreatorName,
      title: `সঞ্চয় জমা অনুমোদন (${member.name})`,
      description: `${member.name} (${data.memberId}) এর ${data.savingsMonth} মাসের ৳${data.amount.toLocaleString()} জমার অনুমোদন প্রক্রিয়া।`,
      createdAt: new Date().toISOString(),
      requiredApprovalCount: Math.max(1, Math.ceil((eligibleModeratorsCount * 2) / 3)),
      eligibleModeratorsCount,
      approvalVotes: isMod ? [currentUser.id] : [],
      rejectionVotes: [],
      status: 'PENDING',
    };

    setSavings((prev) => [newTx, ...prev]);
    setApprovals((prev) => [newApproval, ...prev]);

    syncSavingsTransactionToFirestore(newTx);
    syncApprovalToFirestore(newApproval);
    sendUserNotification(
      member.memberId,
      'জমা দাখিল সম্পন্ন',
      `আপনার ${data.savingsMonth} মাসের ৳${data.amount.toLocaleString()} জমার তথ্য দাখিল হয়েছে, মডারেটর পরিষদ অনুমোদনের জন্য অপেক্ষা করুন।`,
      'DEPOSIT_SUBMITTED',
      'purple'
    );

    logAudit(
      'SAVINGS_CREATED',
      'SAVINGS_TRANSACTION',
      txId,
      `${member.name} (${data.memberId}) এর জন্য ৳${data.amount} এর সঞ্চয় এন্ট্রি তৈরি করা হয়েছে।`
    );
  };

  // Finalize approved notice edit (Point 17)
  const finalizeApprovedNoticeEdit = (
    noticeId: string,
    changes?: { field: string; oldValue: any; newValue: any }[]
  ) => {
    if (!changes || changes.length === 0) return;
    let updatedNoticeObj: NoticeItem | undefined;

    setNotices((prev) =>
      prev.map((n) => {
        if (n.id !== noticeId) return n;
        const copy: NoticeItem = { ...n };
        for (const ch of changes) {
          (copy as any)[ch.field] = ch.newValue;
        }
        updatedNoticeObj = copy;
        return copy;
      })
    );

    if (updatedNoticeObj) {
      syncNoticeToFirestore(updatedNoticeObj);
      if (updatedNoticeObj.showInTicker) {
        updateConfig({
          scrollingAnnouncement: `[হালনাগাদ বিজ্ঞপ্তি] ${updatedNoticeObj.title}: ${updatedNoticeObj.content.slice(0, 100)}`,
        });
      }
      sendUserNotification(
        'ALL',
        `সংশোধিত নোটিশ: ${updatedNoticeObj.title}`,
        updatedNoticeObj.content.slice(0, 85) + '...',
        'NEW_NOTICE',
        'amber'
      );
      logAudit('NOTICE_EDITED', 'NOTICE', noticeId, `অনুমোদনের মাধ্যমে নোটিশ "${updatedNoticeObj.title}" লাইভ করা হয়েছে।`);
    }
  };

  // Vote on approval (with 2/3rds ceiling logic evaluation)
  const voteOnApproval = (approvalId: string, vote: 'APPROVE' | 'REJECT', reason?: string) => {
    if (!requireMemberAuth('অনুমোদন প্যানেলে ভোট প্রদান')) return;

    const currentUserId = currentUser.id;
    setApprovals((prev) =>
      prev.map((appr) => {
        if (appr.id !== approvalId) return appr;

        if (appr.approvalVotes.includes(currentUserId) || appr.rejectionVotes.includes(currentUserId)) {
          return appr;
        }

        const newApprovals = vote === 'APPROVE' ? [...appr.approvalVotes, currentUserId] : appr.approvalVotes;
        const newRejections = vote === 'REJECT' ? [...appr.rejectionVotes, currentUserId] : appr.rejectionVotes;

        // Single-approval fast track for NEW_MEMBER if requiredApprovalCount === 1, else 2/3 ceiling
        const totalModPool = Math.max(1, appr.eligibleModeratorsCount || eligibleModeratorsCount);
        const evaluation =
          appr.requiredApprovalCount === 1
            ? {
                status: (newApprovals.length >= 1
                  ? 'APPROVED'
                  : newRejections.length >= 1
                  ? 'REJECTED'
                  : 'PENDING') as ApprovalRequest['status'],
                isFinalized: newApprovals.length >= 1 || newRejections.length >= 1,
              }
            : evaluateApprovalState(totalModPool, newApprovals, newRejections);

        const updated: ApprovalRequest = {
          ...appr,
          approvalVotes: newApprovals,
          rejectionVotes: newRejections,
          status: evaluation.status,
          finalizedAt: evaluation.isFinalized ? new Date().toISOString() : undefined,
        };

        syncApprovalToFirestore(updated);

        if (evaluation.isFinalized && evaluation.status === 'APPROVED') {
          if (appr.requestType === 'SAVINGS_ENTRY') {
            finalizeApprovedSavings(appr.targetRecordId, newApprovals);
          } else if (appr.requestType === 'NEW_MEMBER') {
            finalizeApprovedMember(appr.targetRecordId);
          } else if (appr.requestType === 'PROFILE_CHANGE') {
            finalizeApprovedProfileChange(appr.targetRecordId, appr.proposedChanges);
          } else if (appr.requestType === 'NOTICE_EDIT') {
            finalizeApprovedNoticeEdit(appr.targetRecordId, appr.proposedChanges);
          }

          logAudit(
            'SAVINGS_APPROVED',
            'APPROVAL_REQUEST',
            appr.id,
            `অনুমোদন নং ${appr.id} সফলভাবে অনুমোদিত ও কার্যকর হয়েছে।`
          );
          triggerSuccess('প্রস্তাবটি চূড়ান্তভাবে অনুমোদিত ও লাইভ হয়েছে!');
        } else if (evaluation.isFinalized && evaluation.status === 'REJECTED') {
          if (appr.requestType === 'SAVINGS_ENTRY') {
            setSavings((sPrev) =>
              sPrev.map((t) => {
                if (t.id === appr.targetRecordId) {
                  const rejectedTx = { ...t, status: 'REJECTED' as const, rejectionReason: reason };
                  syncSavingsTransactionToFirestore(rejectedTx);
                  return rejectedTx;
                }
                return t;
              })
            );
          }
          logAudit(
            'SAVINGS_REJECTED',
            'APPROVAL_REQUEST',
            appr.id,
            `অনুমোদন নং ${appr.id} বাতিল/প্রত্যাখ্যাত হয়েছে। কারণ: ${reason || 'পর্যাপ্ত ভোট পাওয়া যায়নি'}`
          );
        }

        return updated;
      })
    );
  };

  // Finalize approved savings & generate official receipt
  const finalizeApprovedSavings = (txId: string, approvingModIds: string[]) => {
    const existingTx = savings.find((tx) => tx.id === txId);
    if (!existingTx) return;

    const receiptId = generateReceiptNumber(existingTx.savingsMonth, existingTx.memberId, receipts.length + 1);
    const finalizedTx: SavingsTransaction = {
      ...existingTx,
      status: 'APPROVED',
      approvingModerators: approvingModIds,
      receiptId,
    };

    setSavings((prev) => prev.map((tx) => (tx.id === txId ? finalizedTx : tx)));

    const receipt: ElectronicReceipt = {
      receiptNumber: receiptId,
      transactionId: finalizedTx.id,
      memberId: finalizedTx.memberId,
      memberName: finalizedTx.memberName,
      savingsMonth: finalizedTx.savingsMonth,
      savingsYear: finalizedTx.savingsYear,
      amount: finalizedTx.amount,
      paymentMethod: finalizedTx.paymentMethod,
      transactionDate: finalizedTx.transactionDate,
      transactionRef: finalizedTx.transactionRef,
      approvalStatus: 'APPROVED',
      approvingModeratorNames: approvingModIds.map((id) => {
        const u = users.find((usr) => usr.id === id);
        return u ? u.name : 'মডারেটর';
      }),
      generatedAt: new Date().toISOString(),
      verificationHash: `BF-HASH-${finalizedTx.id}-${finalizedTx.memberId}-${Math.floor(finalizedTx.amount * 3.1415)}`,
    };
    setReceipts((prev) => [receipt, ...prev]);

    syncSavingsTransactionToFirestore(finalizedTx);
    syncReceiptToFirestore(receipt);

    updateConfig({
      latestDepositTicker: {
        depositorName: finalizedTx.memberName,
        amount: finalizedTx.amount,
        month: finalizedTx.savingsMonth,
        time: 'এখনই অনুমোদিত',
      },
    });

    sendUserNotification(
      finalizedTx.memberId,
      'সঞ্চয় জমা অনুমোদিত!',
      `আপনার ${finalizedTx.savingsMonth} মাসের ${formatCurrencyBengali(finalizedTx.amount)} সঞ্চয় জমা মডারেটর পরিষদ কর্তৃক সফলভাবে অনুমোদিত হয়েছে।`,
      'DEPOSIT_APPROVED',
      'emerald'
    );
  };

  // Finalize member approval
  const finalizeApprovedMember = (userId: string) => {
    setUsers((prev) =>
      prev.map((u) => {
        if (u.id !== userId) return u;
        const updated: UserProfile = { ...u, status: 'APPROVED' };
        syncUserToFirestore(updated);
        return updated;
      })
    );
    logAudit('MEMBER_APPROVAL', 'USER', userId, `নতুন সদস্যের আবেদন অনুমোদিত হয়েছে।`);
  };

  // Finalize profile change
  const finalizeApprovedProfileChange = (userId: string, changes?: { field: string; newValue: any }[]) => {
    if (!changes) return;
    setUsers((prev) =>
      prev.map((u) => {
        if (u.id !== userId) return u;
        const updated = { ...u };
        for (const ch of changes) {
          (updated as any)[ch.field] = ch.newValue;
        }
        syncUserToFirestore(updated);
        if (currentUser.id === userId) {
          setCurrentUserState(updated);
        }
        return updated;
      })
    );
    logAudit('PROFILE_CHANGE', 'USER', userId, `প্রোফাইল পরিবর্তনের আবেদন অনুমোদিত ও কার্যকর হয়েছে।`);
  };

  // Reversal / Correction preserving audit trail
  const reverseTransaction = (txId: string, reason: string) => {
    if (!requireMemberAuth('আর্থিক লেনদেন সংশোধন')) return;
    setSavings((prev) => {
      const target = prev.find((t) => t.id === txId);
      if (!target) return prev;

      const reversalRecord: SavingsTransaction = {
        id: `rev-${Date.now()}`,
        memberId: target.memberId,
        memberName: target.memberName,
        amount: -target.amount,
        savingsMonth: target.savingsMonth,
        savingsYear: target.savingsYear,
        transactionDate: new Date().toISOString(),
        paymentMethod: target.paymentMethod,
        entryCreatorId: currentUser.id,
        entryCreatorName: currentUser.name,
        status: 'APPROVED',
        approvingModerators: [currentUser.id],
        isCorrection: true,
        originalTransactionId: target.id,
        notes: `সংশোধন/রিভার্সাল: ${reason}`,
      };

      syncSavingsTransactionToFirestore(reversalRecord);

      logAudit(
        'FINANCIAL_CORRECTION',
        'SAVINGS_TRANSACTION',
        txId,
        `ট্রানজেকশন ${txId} এর বিপরীতে সংশোধন এন্ট্রি তৈরি। কারণ: ${reason}`
      );

      return [reversalRecord, ...prev];
    });
  };

  // Request a profile change
  const requestProfileChange = (
    userId: string,
    proposedChanges: { field: string; oldValue: any; newValue: any }[]
  ) => {
    if (!requireMemberAuth('প্রোফাইল সম্পাদনা প্রস্তাব দাখিল')) return;
    const user = users.find((u) => u.id === userId);
    if (!user) return;

    const approvalId = `appr-prof-${Date.now()}`;
    const approval: ApprovalRequest = {
      id: approvalId,
      requestType: 'PROFILE_CHANGE',
      targetRecordId: userId,
      requestingUserId: currentUser.id,
      requestingUserName: currentUser.name,
      title: `প্রোফাইল পরিবর্তন প্রস্তাব (${user.name})`,
      description: `${user.name} এর প্রোফাইল তথ্য হালনাগাদের আবেদন।`,
      proposedChanges,
      createdAt: new Date().toISOString(),
      requiredApprovalCount: Math.max(1, Math.ceil((eligibleModeratorsCount * 2) / 3)),
      eligibleModeratorsCount,
      approvalVotes: [],
      rejectionVotes: [],
      status: 'PENDING',
    };

    setApprovals((prev) => [approval, ...prev]);
    syncApprovalToFirestore(approval);
  };

  const updateUserProfile = (userId: string, partial: Partial<UserProfile>) => {
    if (!requireMemberAuth('প্রোফাইল সম্পাদনা')) return;
    if (userId === '__guest__') return;
    setUsers((prev) =>
      prev.map((u) => {
        if (u.id !== userId) return u;
        const updated = { ...u, ...partial };
        syncUserToFirestore(updated);
        return updated;
      })
    );
    if (currentUser.id === userId) {
      setCurrentUserState((prev) => ({ ...prev, ...partial }));
    }
  };

  const getReceiptForTransaction = (txId: string) => {
    return receipts.find((r) => r.transactionId === txId);
  };

  // Chat methods
  const sendChatMessage = (
    channel: 'GENERAL' | 'MODERATOR_ONLY',
    text: string,
    imageUrl?: string,
    replyTo?: { id: string; text: string; senderName: string }
  ) => {
    if (!requireMemberAuth('চ্যাটে বার্তা প্রেরণ')) return;
    const newMsg: ChatMessage = {
      id: `msg-${Date.now()}`,
      channel,
      senderId: currentUser.id,
      senderName: currentUser.name,
      senderRole: currentUser.role,
      senderAvatar: currentUser.avatarUrl,
      text,
      timestamp: new Date().toISOString(),
      imageUrl,
      replyToId: replyTo?.id,
      replyToText: replyTo?.text,
      replyToSender: replyTo?.senderName,
    };
    setChatMessages((prev) => [...prev, newMsg]);
    setSeenChatIds((prev) => [...prev, newMsg.id]);
    syncChatMessageToFirestore(newMsg);
  };

  const deleteChatMessage = (messageId: string) => {
    if (!requireMemberAuth('বার্তা মুছে ফেলা')) return;
    setChatMessages((prev) =>
      prev.map((msg) => {
        if (msg.id !== messageId) return msg;
        const deleted = {
          ...msg,
          isDeleted: true,
          text: 'ব্যবহারকারী বার্তাটি ডিলিট করেছেন',
        };
        syncChatMessageToFirestore(deleted);
        return deleted;
      })
    );
  };

  const toggleMessageReaction = (messageId: string, emoji: string) => {
    if (!requireMemberAuth('বার্তায় রিঅ্যাকশন প্রদান')) return;
    setChatMessages((prev) =>
      prev.map((msg) => {
        if (msg.id !== messageId) return msg;
        const reactions = { ...(msg.reactions || {}) };
        const userList = reactions[emoji] || [];

        if (userList.includes(currentUser.id)) {
          reactions[emoji] = userList.filter((id) => id !== currentUser.id);
          if (reactions[emoji].length === 0) delete reactions[emoji];
        } else {
          reactions[emoji] = [...userList, currentUser.id];
        }
        const updated = { ...msg, reactions };
        syncChatMessageToFirestore(updated);
        return updated;
      })
    );
  };

  const votePoll = (pollId: string, optionId: string) => {
    if (!requireMemberAuth('জরিপে ভোট প্রদান')) return;
    setPolls((prev) =>
      prev.map((poll) => {
        if (poll.id !== pollId) return poll;
        const updated: ChatPoll = {
          ...poll,
          options: poll.options.map((opt) => {
            const hasVoted = opt.votes.includes(currentUser.id);
            if (opt.id === optionId) {
              return { ...opt, votes: hasVoted ? opt.votes : [...opt.votes, currentUser.id] };
            } else {
              return { ...opt, votes: opt.votes.filter((id) => id !== currentUser.id) };
            }
          }),
        };
        syncPollToFirestore(updated);
        return updated;
      })
    );
  };

  const createPoll = (channel: 'GENERAL' | 'MODERATOR_ONLY', question: string, optionTexts: string[]) => {
    if (!requireMemberAuth('জরিপ তৈরি')) return;
    const newPoll: ChatPoll = {
      id: `poll-${Date.now()}`,
      channel,
      question,
      creatorName: currentUser.name,
      options: optionTexts.map((txt, idx) => ({ id: `opt-${idx + 1}`, text: txt, votes: [] })),
      createdAt: new Date().toISOString(),
    };
    setPolls((prev) => [newPoll, ...prev]);
    syncPollToFirestore(newPoll);
    triggerSuccess('নতুন জরিপ প্রকাশ করা হয়েছে!');
  };

  const deletePoll = (pollId: string) => {
    if (!requireMemberAuth('জরিপ মুছে ফেলা')) return;
    setPolls((prev) => prev.filter((p) => p.id !== pollId));
    triggerSuccess('জরিপটি সফলভাবে মুছে ফেলা হয়েছে!');
  };

  const updatePollOption = (pollId: string, optionId: string, text: string) => {
    if (!requireMemberAuth('জরিপ সম্পাদনা')) return;
    setPolls((prev) =>
      prev.map((poll) => {
        if (poll.id !== pollId) return poll;
        const updated = {
          ...poll,
          options: poll.options.map((opt) => (opt.id === optionId ? { ...opt, text } : opt)),
        };
        syncPollToFirestore(updated);
        return updated;
      })
    );
    triggerSuccess('জরিপের অপশন টেক্সট আপডেট করা হয়েছে!');
  };

  const updatePollQuestion = (pollId: string, question: string) => {
    if (!requireMemberAuth('জরিপ সম্পাদনা')) return;
    setPolls((prev) =>
      prev.map((poll) => {
        if (poll.id !== pollId) return poll;
        const updated = { ...poll, question };
        syncPollToFirestore(updated);
        return updated;
      })
    );
    triggerSuccess('জরিপের প্রশ্ন আপডেট করা হয়েছে!');
  };

  // Notices
  const addNotice = (notice: Omit<NoticeItem, 'id' | 'createdAt' | 'authorName' | 'authorRole'>) => {
    if (!requireMemberAuth('নতুন নোটিশ প্রকাশ')) return;
    const authorName = currentUser?.name || 'বেসিস ফাউন্ডেশন প্রশাসন';
    const authorRole = currentUser?.role || 'APP_MODERATOR';
    const newNotice: NoticeItem = {
      ...notice,
      id: `notice-${Date.now()}`,
      authorName,
      authorRole,
      createdAt: new Date().toISOString(),
    };
    setNotices((prev) => [newNotice, ...prev]);
    syncNoticeToFirestore(newNotice);

    if (newNotice.showInTicker) {
      updateConfig({
        scrollingAnnouncement: `[জরুরি বিজ্ঞপ্তি] ${newNotice.title}: ${newNotice.content.slice(0, 100)}`,
      });
    }

    sendUserNotification(
      'ALL',
      `নতুন নোটিশ: ${newNotice.title}`,
      newNotice.content.slice(0, 85) + '...',
      'NEW_NOTICE',
      'amber'
    );
    logAudit('CONFIG_UPDATED', 'NOTICE', newNotice.id, `নতুন নোটিশ প্রকাশ: "${notice.title}"`);
  };

  // Propose Notice Edit by ANY Moderator — goes live ONLY after Moderator Panel Approval (Point 17)
  const proposeNoticeEdit = (
    noticeId: string,
    updates: Partial<Pick<NoticeItem, 'title' | 'content' | 'priority' | 'imageUrl' | 'isPinned' | 'showInTicker'>>
  ) => {
    if (!requireMemberAuth('নোটিশ সম্পাদনা')) return;
    if (currentUser.role !== 'MODERATOR' && currentUser.role !== 'APP_MODERATOR') {
      triggerWarning('অনুমতি সীমাবদ্ধ', 'শুধুমাত্র মডারেটর প্যানেলের সদস্যগণ নোটিশ সম্পাদনা করতে পারবেন।');
      return;
    }

    const existing = notices.find((n) => n.id === noticeId);
    if (!existing) return;

    const proposedChanges: { field: string; oldValue: any; newValue: any }[] = [];
    (Object.keys(updates) as Array<keyof typeof updates>).forEach((field) => {
      const nextVal = updates[field];
      const prevVal = existing[field];
      if (nextVal !== undefined && nextVal !== prevVal) {
        proposedChanges.push({
          field,
          oldValue: prevVal ?? '',
          newValue: nextVal,
        });
      }
    });

    if (proposedChanges.length === 0) {
      triggerWarning('কোনো পরিবর্তন নেই', 'আপনি নোটিশে কোনো পরিবর্তন করেননি।');
      return;
    }

    const approvalId = `appr-notice-${Date.now()}`;
    const requiredVotes = Math.max(1, Math.ceil((eligibleModeratorsCount * 2) / 3));
    const initialVotes = requiredVotes > 1 ? [currentUser.id] : [];

    const newApproval: ApprovalRequest = {
      id: approvalId,
      requestType: 'NOTICE_EDIT',
      targetRecordId: noticeId,
      requestingUserId: currentUser.id,
      requestingUserName: currentUser.name,
      title: `নোটিশ সম্পাদনা অনুমোদন: "${updates.title || existing.title}"`,
      description: `${currentUser.name} নোটিশ "${existing.title}" সম্পাদনার প্রস্তাব দাখিল করেছেন। মডারেটর প্যানেলের অনুমোদনের পর এটি লাইভ হবে।`,
      proposedChanges,
      createdAt: new Date().toISOString(),
      requiredApprovalCount: requiredVotes,
      eligibleModeratorsCount: Math.max(1, eligibleModeratorsCount),
      approvalVotes: initialVotes,
      rejectionVotes: [],
      status: 'PENDING',
    };

    setApprovals((prev) => [newApproval, ...prev]);
    syncApprovalToFirestore(newApproval);
    logAudit('CONFIG_UPDATED', 'NOTICE', noticeId, `নোটিশ "${existing.title}" সম্পাদনার অনুমোদন প্রস্তাব দাখিল করা হয়েছে।`);
    triggerSuccess('নোটিশ সম্পাদনার প্রস্তাব দাখিল হয়েছে! মডারেটর প্যানেলে অনুমোদনের পর এটি লাইভ হবে।');
  };

  const updateNotice = (noticeId: string, partial: Partial<NoticeItem>) => {
    if (!requireMemberAuth('নোটিশ হালনাগাদ')) return;
    setNotices((prev) => {
      const updated = prev.map((n) => (n.id === noticeId ? { ...n, ...partial } : n));
      const target = updated.find((n) => n.id === noticeId);
      if (target) syncNoticeToFirestore(target);
      return updated;
    });
    triggerSuccess('নোটিশ তথ্য সফলভাবে হালনাগাদ করা হয়েছে!');
  };

  const deleteNotice = (noticeId: string) => {
    if (!requireMemberAuth('নোটিশ মুছে ফেলা')) return;
    setNotices((prev) => prev.filter((n) => n.id !== noticeId));
    deleteNoticeFromFirestore(noticeId);
    triggerSuccess('নোটিশ সফলভাবে মুছে ফেলা হয়েছে!');
  };

  // Complaints
  const submitComplaint = (title: string, description: string) => {
    if (!requireMemberAuth('অভিযোগ বা পরামর্শ দাখিল')) return;
    const newComp: ComplaintItem = {
      id: `comp-${Date.now()}`,
      submitterId: currentUser.id,
      submitterName: currentUser.name,
      title,
      description,
      status: 'SUBMITTED',
      createdAt: new Date().toISOString(),
    };
    setComplaints((prev) => [newComp, ...prev]);
    syncComplaintToFirestore(newComp);
  };

  const updateComplaintStatus = (
    id: string,
    status: ComplaintItem['status'],
    moderatorNotes?: string
  ) => {
    if (!requireMemberAuth('অভিযোগের স্ট্যাটাস পরিবর্তন')) return;
    setComplaints((prev) =>
      prev.map((c) => {
        if (c.id !== id) return c;
        const updated: ComplaintItem = {
          ...c,
          status,
          assignedModeratorName: currentUser.name,
          moderatorNotes: moderatorNotes || c.moderatorNotes,
        };
        syncComplaintToFirestore(updated);
        return updated;
      })
    );
  };

  // Feature Requests
  const submitFeatureRequest = (title: string, description: string) => {
    if (!requireMemberAuth('নতুন ফিচার প্রস্তাব দাখিল')) return;
    const newReq: FeatureRequestItem = {
      id: `feat-${Date.now()}`,
      submitterId: currentUser.id,
      submitterName: currentUser.name,
      memberId: currentUser.memberId,
      title,
      description,
      createdAt: new Date().toISOString(),
      status: 'PENDING',
      votesCount: 1,
      votedUserIds: [currentUser.id],
    };
    setFeatureRequests((prev) => [newReq, ...prev]);
    syncFeatureRequestToFirestore(newReq);
  };

  const voteFeatureRequest = (id: string) => {
    if (!requireMemberAuth('ফিচার প্রস্তাবে ভোট প্রদান')) return;
    setFeatureRequests((prev) =>
      prev.map((item) => {
        if (item.id !== id) return item;
        const hasVoted = item.votedUserIds.includes(currentUser.id);
        const updatedUserIds = hasVoted
          ? item.votedUserIds.filter((uid) => uid !== currentUser.id)
          : [...item.votedUserIds, currentUser.id];
        const updated: FeatureRequestItem = {
          ...item,
          votedUserIds: updatedUserIds,
          votesCount: updatedUserIds.length,
        };
        syncFeatureRequestToFirestore(updated);
        return updated;
      })
    );
  };

  // Rules
  const updateRule = (ruleId: string, title: string, description: string) => {
    if (!requireMemberAuth('নিয়মাবলী হালনাগাদ')) return;
    setRules((prev) => {
      const updated = prev.map((r) =>
        r.id === ruleId
          ? {
              ...r,
              title,
              description,
              version: r.version + 1,
              lastUpdated: new Date().toISOString().split('T')[0],
            }
          : r
      );
      const target = updated.find((r) => r.id === ruleId);
      if (target) syncRuleToFirestore(target);
      return updated;
    });
    logAudit('CONFIG_UPDATED', 'FOUNDATION_RULE', ruleId, `নিয়মাবলী নং ${ruleId} হালনাগাদ করা হয়েছে।`);
  };

  // Configuration update (App Moderator) - real-time Firestore sync
  const updateConfig = (newConfig: Partial<AppConfiguration>) => {
    setConfig((prev) => {
      const merged: AppConfiguration = {
        ...prev,
        ...newConfig,
        navTabsOrder: normalizeNavTabsOrder(newConfig.navTabsOrder || prev.navTabsOrder),
      };
      syncConfigToFirestore(merged);
      return merged;
    });
    logAudit('CONFIG_UPDATED', 'SYSTEM_CONFIG', 'app-config', 'সিস্টেম কনফিগারেশন ও ব্র্যান্ডিং আপডেট করা হয়েছে।');
  };

  // Publish App Release
  const publishAppRelease = (release: Omit<AppRelease, 'id'>) => {
    if (!requireMemberAuth('অ্যাপ রিলিজ প্রকাশ')) return;
    const newRelease: AppRelease = {
      ...release,
      id: `rel-${Date.now()}`,
    };
    setReleases((prev) => [newRelease, ...prev]);
    logAudit(
      'APK_PUBLISHED',
      'APP_RELEASE',
      newRelease.versionName,
      `নতুন অ্যাপ সংস্করণ ${newRelease.versionName} (Build ${newRelease.versionCode}) প্রকাশ করা হয়েছে।`
    );
  };

  // Backup export
  const exportBackupData = () => {
    const backupObj = {
      version: '1.0',
      exportedAt: new Date().toISOString(),
      exportedBy: currentUser.email,
      foundation: config.foundationName,
      data: {
        config,
        users,
        savings,
        approvals,
        receipts,
        notices,
        rules,
        complaints,
        featureRequests,
        auditLogs,
        expenses,
        executiveMembers,
      },
    };
    logAudit('BACKUP_CREATED', 'DATABASE', 'full-export', 'সম্পূর্ণ ডাটাবেজ ব্যাকআপ এক্সপোর্ট করা হয়েছে।');
    return JSON.stringify(backupObj, null, 2);
  };

  // Restore backup
  const restoreFromBackup = (jsonData: string): { success: boolean; message: string } => {
    try {
      const parsed = JSON.parse(jsonData);
      if (!parsed.data || !parsed.data.savings || !parsed.data.users) {
        return { success: false, message: 'অকার্যকর ব্যাকআপ ফাইল: ডাটা স্কিমা সঠিক নয়।' };
      }
      if (parsed.data.config) {
        setConfig({
          ...parsed.data.config,
          navTabsOrder: normalizeNavTabsOrder(parsed.data.config.navTabsOrder),
        });
      }
      setUsers(parsed.data.users);
      setSavings(parsed.data.savings);
      setApprovals(parsed.data.approvals || []);
      setReceipts(parsed.data.receipts || []);
      setNotices(parsed.data.notices || []);
      setRules(parsed.data.rules || []);
      setComplaints(parsed.data.complaints || []);
      setFeatureRequests(parsed.data.featureRequests || []);
      setAuditLogs(parsed.data.auditLogs || []);
      if (parsed.data.expenses) setExpenses(parsed.data.expenses);
      if (parsed.data.executiveMembers) setExecutiveMembers(parsed.data.executiveMembers);

      logAudit('BACKUP_RESTORED', 'DATABASE', 'full-restore', 'ব্যাকআপ থেকে ডাটাবেজ সফলভাবে রিস্টোর করা হয়েছে।');
      return { success: true, message: 'সফলভাবে ডাটা রিস্টোর সম্পন্ন হয়েছে।' };
    } catch (e: any) {
      return { success: false, message: `রিস্টোর ব্যর্থ: ${e?.message || 'ত্রুটি'}` };
    }
  };

  // Trigger success celebration micro-animation
  const triggerSuccess = (message: string) => {
    setSuccessMessage(message);
    if (soundEnabled && typeof window !== 'undefined' && 'AudioContext' in window) {
      try {
        const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(587.33, audioCtx.currentTime);
        osc.frequency.exponentialRampToValueAtTime(880, audioCtx.currentTime + 0.15);
        gain.gain.setValueAtTime(0.12, audioCtx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.25);
        osc.connect(gain);
        gain.connect(audioCtx.destination);
        osc.start();
        osc.stop(audioCtx.currentTime + 0.25);
      } catch {}
    }
    if (hapticEnabled && typeof navigator !== 'undefined' && navigator.vibrate) {
      try {
        navigator.vibrate([40, 60, 40]);
      } catch {}
    }
  };

  const closeSuccess = () => {
    setSuccessMessage(null);
  };

  // Register New Account with PENDING status
  const registerNewAccount = (userData: Partial<UserProfile>) => {
    const newId = `user-reg-${Date.now()}`;
    const newUser: UserProfile = {
      id: newId,
      memberId: userData.memberId || `BF-${String(users.length + 1).padStart(3, '0')}`,
      name: userData.name || 'নতুন সদস্য',
      email: userData.email || '',
      phone: userData.phone || '',
      role: userData.role || 'MEMBER',
      status: 'PENDING',
      gender: userData.gender || 'MALE',
      joinDate: new Date().toISOString().split('T')[0],
      avatarUrl: userData.avatarUrl,
      address: userData.address,
      nomineeName: userData.nomineeName,
      nomineeRelation: userData.nomineeRelation,
      nomineePhone: userData.nomineePhone,
      password: (userData as any).password || '123456',
    };

    setUsers((prev) => [...prev, newUser]);
    syncUserToFirestore(newUser);

    const newApproval: ApprovalRequest = {
      id: `appr-user-${Date.now()}`,
      requestType: 'NEW_MEMBER',
      targetRecordId: newId,
      requestingUserId: newId,
      requestingUserName: newUser.name,
      title: `নতুন সদস্য অ্যাকাউন্ট নিবন্ধন অনুমোদন (${newUser.name})`,
      description: `${newUser.name} (${newUser.phone}) নতুন অ্যাকাউন্ট নিবন্ধনের আবেদন করেছেন।`,
      createdAt: new Date().toISOString(),
      requiredApprovalCount: 1,
      eligibleModeratorsCount: Math.max(1, eligibleModeratorsCount),
      approvalVotes: [],
      rejectionVotes: [],
      status: 'PENDING',
    };
    setApprovals((prev) => [newApproval, ...prev]);
    syncApprovalToFirestore(newApproval);

    logAudit('MEMBER_REGISTRATION', 'USER', newId, `${newUser.name} নতুন অ্যাকাউন্ট নিবন্ধনের আবেদন দাখিল করেছেন।`);
    triggerSuccess('অ্যাকাউন্ট নিবন্ধন সফল হয়েছে! মডারেটরের অনুমোদনের অপেক্ষায় রয়েছে।');
  };

  // Approve User Account
  const approveUserAccount = (userId: string) => {
    if (!requireMemberAuth('অ্যাকাউন্ট অনুমোদন')) return;
    let approvedUser: UserProfile | undefined;
    setUsers((prev) =>
      prev.map((u) => {
        if (u.id === userId) {
          approvedUser = { ...u, status: 'APPROVED' };
          return approvedUser;
        }
        return u;
      })
    );
    setApprovals((prev) =>
      prev.map((a) => {
        if (a.targetRecordId !== userId) return a;
        const updated: ApprovalRequest = { ...a, status: 'APPROVED', finalizedAt: new Date().toISOString() };
        syncApprovalToFirestore(updated);
        return updated;
      })
    );
    if (approvedUser) {
      syncUserToFirestore(approvedUser);
      sendUserNotification(
        (approvedUser as UserProfile).memberId,
        'অ্যাকাউন্ট অনুমোদন সফল!',
        'বেসিস ফাউন্ডেশনে আপনার সদস্যপদ অনুমোদিত হয়েছে। এখন আপনি সম্পূর্ণ সুবিধা ব্যবহার করতে পারবেন।',
        'PROFILE_APPROVED',
        'blue'
      );
    }
    logAudit('MEMBER_APPROVAL', 'USER', userId, `ব্যবহারকারী অ্যাকাউন্ট অনুমোদন প্রদান করা হয়েছে।`);
    triggerSuccess('সদস্য অ্যাকাউন্ট সফলভাবে অনুমোদিত হয়েছে!');
  };

  // Reject User Account
  const rejectUserAccount = (userId: string) => {
    if (!requireMemberAuth('অ্যাকাউন্ট প্রত্যাখ্যান')) return;
    setUsers((prev) =>
      prev.map((u) => {
        if (u.id !== userId) return u;
        const rejected: UserProfile = { ...u, status: 'REJECTED' };
        syncUserToFirestore(rejected);
        return rejected;
      })
    );
    setApprovals((prev) =>
      prev.map((a) => {
        if (a.targetRecordId !== userId) return a;
        const updated: ApprovalRequest = { ...a, status: 'REJECTED', finalizedAt: new Date().toISOString() };
        syncApprovalToFirestore(updated);
        return updated;
      })
    );
    triggerSuccess('সদস্য অ্যাকাউন্ট প্রত্যাখ্যান করা হয়েছে।');
  };

  // Update Moderator Designation (Synced to Firestore)
  const updateUserDesignation = (userId: string, moderatorTitle: string, role?: UserRole) => {
    if (!requireMemberAuth('পদবী পরিবর্তন')) return;
    setUsers((prev) =>
      prev.map((u) => {
        if (u.id !== userId) return u;
        const updated: UserProfile = {
          ...u,
          moderatorTitle,
          role: role || u.role,
          isPublicModerator: (role || u.role) !== 'MEMBER',
        };
        syncUserToFirestore(updated);
        if (currentUser.id === userId) {
          setCurrentUserState(updated);
        }
        return updated;
      })
    );
    logAudit('PROFILE_CHANGE', 'USER', userId, `মডারেটর পদবী পরিবর্তন: "${moderatorTitle}"`);
    triggerSuccess('পদবী ও দায়িত্ব ফায়ারবেজে সফলভাবে সংরক্ষিত হয়েছে!');
  };

  // Remove / Delete User
  const removeUser = (userId: string) => {
    if (!requireMemberAuth('সদস্য অপসারণ')) return;
    setUsers((prev) => prev.filter((u) => u.id !== userId));
    deleteUserFromFirestore(userId);
    logAudit('PROFILE_CHANGE', 'USER', userId, `সদস্য রেকর্ড স্থায়ীভাবে অপসারণ করা হয়েছে।`);
    triggerSuccess('সদস্য সফলভাবে মুছে ফেলা হয়েছে!');
  };

  // Send Overdue Reminder
  const sendOverdueReminder = (memberId: string) => {
    if (!requireMemberAuth('বকেয়া তাগিদ প্রেরণ')) return;
    setOverdueReminders((prev) => (prev.includes(memberId) ? prev : [...prev, memberId]));
    triggerSuccess('বকেয়া তাগিদ বার্তা সফলভাবে পাঠানো হয়েছে!');
  };

  // Direct 1-on-1 Private Messaging
  const sendPrivateMessage = (receiverId: string, text: string) => {
    if (!requireMemberAuth('ব্যক্তিগত বার্তা প্রেরণ')) return;
    const receiver = users.find((u) => u.id === receiverId);
    if (!receiver) return;

    const convId = [currentUser.id, receiverId].sort().join('_');
    const newMsg: PrivateMessage = {
      id: `pm-${Date.now()}`,
      conversationId: convId,
      senderId: currentUser.id,
      senderName: currentUser.name,
      receiverId,
      receiverName: receiver.name,
      text,
      timestamp: new Date().toISOString(),
      isRead: false,
    };

    setPrivateMessages((prev) => [...prev, newMsg]);
    setSeenChatIds((prev) => [...prev, newMsg.id]);
    syncPrivateMessageToFirestore(newMsg);
  };

  const deletePrivateMessage = (messageId: string) => {
    if (!requireMemberAuth('বার্তা মুছে ফেলা')) return;
    setPrivateMessages((prev) =>
      prev.map((msg) => {
        if (msg.id !== messageId) return msg;
        const deleted: PrivateMessage = {
          ...msg,
          isDeleted: true,
          text: 'ব্যবহারকারী বার্তাটি ডিলিট করেছেন',
        };
        syncPrivateMessageToFirestore(deleted);
        return deleted;
      })
    );
  };

  // Forward Message from Moderator-Only to General Chat
  const forwardChatMessage = (messageId: string) => {
    if (!requireMemberAuth('বার্তা ফরোয়ার্ড')) return;
    const targetMsg = chatMessages.find((m) => m.id === messageId);
    if (!targetMsg) return;

    const forwardedText = `📢 [মডারেটর চ্যানেল থেকে ফরোয়ার্ডকৃত]\n${targetMsg.text}\n(মূল প্রেরক: ${targetMsg.senderName})`;
    sendChatMessage('GENERAL', forwardedText);
    triggerSuccess('বার্তাটি সাধারণ গ্রুপ চ্যাটে ফরোয়ার্ড করা হয়েছে!');
  };

  // Pull-to-Refresh / Manual Sync (Point 14: Moderator-only + Online-only)
  const refreshAllData = async () => {
    await triggerCloudSync();
  };

  // Network Connectivity Listener (Point 14)
  useEffect(() => {
    const handleOnline = () => {
      setIsOnline(true);
      setCloudSyncStatus('SYNCED');
    };
    const handleOffline = () => {
      setIsOnline(false);
      setCloudSyncStatus('OFFLINE');
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const resetToInitialDemo = () => {
    setConfig(INITIAL_CONFIG);
    setUsers(INITIAL_USERS);
    setCurrentUser(GUEST_USER);
    setSavings(INITIAL_SAVINGS);
    setApprovals(INITIAL_APPROVALS);
    setNotices(INITIAL_NOTICES);
    setRules(INITIAL_RULES);
    setComplaints(INITIAL_COMPLAINTS);
    setFeatureRequests(INITIAL_FEATURE_REQUESTS);
    setChatMessages(INITIAL_CHAT_MESSAGES);
    setPolls(INITIAL_POLLS);
    setReleases(INITIAL_RELEASES);
    setAuditLogs(INITIAL_AUDIT_LOGS);
    setOverdueReminders(['BF-004']);
  };

  return (
    <AppContext.Provider
      value={{
        theme,
        setTheme,
        isOnline,
        setIsOnline,
        isDemoMode,
        setIsDemoMode,
        showExitDialog,
        setShowExitDialog,
        soundEnabled,
        setSoundEnabled,
        hapticEnabled,
        setHapticEnabled,
        pushNotificationsEnabled,
        togglePushNotifications,
        storageAccessEnabled,
        toggleStorageAccess,
        warningDialog,
        triggerWarning,
        triggerGuestWarning,
        closeWarning,
        requireMemberAuth,
        successMessage,
        triggerSuccess,
        closeSuccess,
        currentUser,
        isGuestMode,
        setCurrentUser,
        logoutUser,
        maskPhoneForPrivacy,
        users,
        updateUserProfile,
        requestProfileChange,
        registerNewAccount,
        approveUserAccount,
        rejectUserAccount,
        updateUserDesignation,
        removeUser,
        isAuthModalOpen,
        setIsAuthModalOpen,
        overdueReminders,
        sendOverdueReminder,
        privateMessages,
        sendPrivateMessage,
        deletePrivateMessage,
        activePrivateChatUser,
        setActivePrivateChatUser,
        savings,
        createSavingsEntry,
        reverseTransaction,
        approvals,
        voteOnApproval,
        receipts,
        getReceiptForTransaction,
        activePrintReceipt,
        setActivePrintReceipt,
        chatMessages,
        sendChatMessage,
        deleteChatMessage,
        forwardChatMessage,
        toggleMessageReaction,
        polls,
        votePoll,
        createPoll,
        deletePoll,
        updatePollOption,
        updatePollQuestion,
        chatUnreadCount,
        markChatSeen,
        unreadNoticeCount,
        hasUnreadNotices,
        markNoticesSeen,
        notices,
        addNotice,
        proposeNoticeEdit,
        updateNotice,
        deleteNotice,
        complaints,
        submitComplaint,
        updateComplaintStatus,
        featureRequests,
        submitFeatureRequest,
        voteFeatureRequest,
        rules,
        updateRule,
        config,
        updateConfig,
        auditLogs,
        releases,
        publishAppRelease,
        activeUpdateDialog,
        setActiveUpdateDialog,
        refreshAllData,
        isRefreshing,
        exportBackupData,
        restoreFromBackup,
        resetToInitialDemo,
        expenses,
        addExpense,
        removeExpense,
        totalExpenses,
        netReserveBalance,
        isSearchModalOpen,
        setIsSearchModalOpen,
        activeCall,
        startCall,
        endCall,
        executiveMembers,
        addExecutiveMember,
        removeExecutiveMember,
        updateExecutiveMember,
        onlineUserIds,
        cloudSyncStatus,
        lastSyncTimestamp,
        triggerCloudSync,
        userNotifications,
        sendUserNotification,
        markNotificationRead,
        markAllNotificationsRead,
        pendingDepositModalOpen,
        setPendingDepositModalOpen,
        checkUserHasPendingDeposit,
        financialTotals,
        growthRate,
        monthlyAggregates,
        eligibleModeratorsCount,
        unreadCount,
        uniqueDailyVisitors,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
