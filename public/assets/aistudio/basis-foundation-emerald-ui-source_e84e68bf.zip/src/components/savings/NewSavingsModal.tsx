import React, { useState } from 'react';
import { PlusCircle, AlertCircle, ShieldCheck, Building2, CreditCard, Calendar, ChevronLeft, CheckCircle2, Wallet } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { PaymentMethod } from '../../types';
import { toBengaliNumerals, formatCurrencyBengali } from '../../utils/calculations';

interface NewSavingsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const NewSavingsModal: React.FC<NewSavingsModalProps> = ({ isOpen, onClose }) => {
  const { users, createSavingsEntry, currentUser, config, checkUserHasPendingDeposit } = useApp();

  const [memberId, setMemberId] = useState<string>(
    currentUser.role === 'MEMBER' ? currentUser.memberId : (users[0]?.memberId || 'BF-001')
  );
  const [showPendingPopup, setShowPendingPopup] = useState<boolean>(false);
  const [amount, setAmount] = useState<number>(config.defaultMonthlyAmount || 1500);
  const [transactionDate, setTransactionDate] = useState<string>(
    new Date().toISOString().split('T')[0]
  );
  const [savingsMonth, setSavingsMonth] = useState<string>('2026-10');

  // Requirement 14: Dynamic month options that expand when last month is selected
  const [monthOptions, setMonthOptions] = useState([
    { id: '2026-08', label: 'আগস্ট ২০২৬' },
    { id: '2026-09', label: 'সেপ্টেম্বর ২০২৬' },
    { id: '2026-10', label: 'অক্টোবর ২০২৬ (চলতি মাস)' },
    { id: '2026-11', label: 'নভেম্বর ২০২৬ (অগ্রিম)' },
  ]);

  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('BKASH');
  const [transactionRef, setTransactionRef] = useState<string>('');
  const [bankName, setBankName] = useState<string>('ইসলামী ব্যাংক বাংলাদেশ পিএলসি');
  const [bankBranch, setBankBranch] = useState<string>('ধানমন্ডি শাখা');
  const [notes, setNotes] = useState<string>('');

  if (!isOpen) return null;

  const handleMonthChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const chosenVal = e.target.value;
    setSavingsMonth(chosenVal);

    // Requirement 14: When last month is chosen, dynamically generate next month
    const lastItem = monthOptions[monthOptions.length - 1];
    if (lastItem && lastItem.id === chosenVal) {
      const [yStr, mStr] = chosenVal.split('-');
      let year = parseInt(yStr, 10);
      let month = parseInt(mStr, 10) + 1;
      if (month > 12) {
        month = 1;
        year += 1;
      }
      const nextMonthId = `${year}-${String(month).padStart(2, '0')}`;
      const bengaliMonths = [
        'জানুয়ারি', 'ফেব্রুয়ারি', 'মার্চ', 'এপ্রিল', 'মে', 'জুন',
        'জুলাই', 'আগস্ট', 'সেপ্টেম্বর', 'অক্টোবর', 'নভেম্বর', 'ডিসেম্বর'
      ];
      const nextMonthLabel = `${bengaliMonths[month - 1]} ${toBengaliNumerals(year)} (স্বয়ংক্রিয় যুক্ত)`;

      setMonthOptions((prev) => [...prev, { id: nextMonthId, label: nextMonthLabel }]);
      alert(`পরবর্তী মাস "${nextMonthLabel}" সফলভাবে ড্রপডাউনে তৈরি ও যুক্ত করা হয়েছে!`);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (amount <= 0) {
      alert('সঞ্চয়ের পরিমাণ অবশ্যই ধনাত্মক হতে হবে।');
      return;
    }

    // Point 3: Duplicate submission check for pending deposit
    if (checkUserHasPendingDeposit(memberId)) {
      setShowPendingPopup(true);
      return;
    }

    let finalRef = transactionRef.trim();
    if (paymentMethod === 'BANK' || paymentMethod === 'BANK_TRANSFER') {
      const bankDetails = `${bankName} (${bankBranch})`;
      finalRef = finalRef ? `${bankDetails} - ভাউচার: ${finalRef}` : bankDetails;
    }

    createSavingsEntry({
      memberId,
      amount: Number(amount),
      savingsMonth,
      savingsYear: Number(savingsMonth.split('-')[0]),
      paymentMethod,
      transactionRef: finalRef || undefined,
      notes: notes.trim() || undefined,
    });

    onClose();
  };

  const selectedMember = users.find((u) => u.memberId === memberId);

  const inputCls =
    'w-full bg-slate-950 border border-slate-800 rounded-xl px-3 min-h-12 text-sm text-ink focus:outline-none focus:ring-2 focus:ring-emerald-500/50 focus:border-emerald-500';
  const quickAmounts = [500, 1000, 2000, 5000];

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950 sm:bg-slate-950/80 sm:backdrop-blur-sm animate-in fade-in duration-200">
      <div className="mx-auto max-w-lg min-h-full sm:py-6">
        <div className="bg-slate-950 sm:bg-slate-900 sm:border sm:border-slate-800 sm:rounded-[28px] p-4 sm:p-6 space-y-4">
          {/* Header */}
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={onClose}
              aria-label="ফিরে যান"
              className="w-11 h-11 rounded-xl bg-slate-900 border border-slate-800 text-ink flex items-center justify-center cursor-pointer shrink-0"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            <div className="min-w-0">
              <h3 className="text-[22px] font-bold text-ink leading-tight">টাকা জমা</h3>
              <p className="text-[11px] text-slate-400 truncate">২/৩ মডারেটর সিলিং অনুমোদন প্রক্রিয়ার আওতাধীন</p>
            </div>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4 text-xs">
            {/* Member Selection */}
            <div className="rounded-[20px] bg-slate-900 border border-slate-800 p-3 flex items-center gap-3">
              <span className="w-11 h-11 rounded-xl bg-emerald-500/15 text-emerald-400 flex items-center justify-center shrink-0">
                <Wallet className="w-5 h-5" />
              </span>
              <div className="min-w-0 flex-1">
                <label className="text-[11px] text-slate-400 block">সদস্য নির্বাচন করুন</label>
                <select
                  value={memberId}
                  onChange={(e) => setMemberId(e.target.value)}
                  className="w-full bg-transparent text-[14px] font-bold text-ink focus:outline-none cursor-pointer truncate"
                >
                  {users.map((u) => (
                    <option key={u.id} value={u.memberId}>
                      {u.memberId} — {u.name} ({u.phone})
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Amount hero */}
            <div className="relative overflow-hidden rounded-[22px] bg-hero text-white p-4">
              <div className="pointer-events-none absolute -top-16 -right-10 h-40 w-40 rounded-full border-[30px] border-white/[0.06]" />
              <label htmlFor="deposit-amount" className="relative text-[12px] text-white/80 block">জমার পরিমাণ (টাকা)</label>
              <div className="relative flex items-baseline gap-1 mt-1">
                <span className="text-[34px] font-bold">৳</span>
                <input
                  id="deposit-amount"
                  type="number"
                  min="100"
                  step="50"
                  value={amount}
                  onChange={(e) => setAmount(Number(e.target.value))}
                  className="w-full bg-transparent text-[34px] font-bold text-white focus:outline-none placeholder-white/40"
                  required
                />
              </div>
              <span className="relative text-[11px] text-white/80 block">কথায়: {formatCurrencyBengali(amount)}</span>
              <div className="relative grid grid-cols-4 gap-2 mt-3">
                {quickAmounts.map((q) => (
                  <button
                    type="button"
                    key={q}
                    onClick={() => setAmount(q)}
                    className={`min-h-11 rounded-xl text-[13px] font-bold border transition-colors cursor-pointer ${
                      Number(amount) === q
                        ? 'bg-white text-[#075044] border-white'
                        : 'bg-white/10 text-white border-white/25 hover:bg-white/20'
                    }`}
                  >
                    ৳{toBengaliNumerals(q.toLocaleString('en-US'))}
                  </button>
                ))}
              </div>
            </div>

            {/* Month + date */}
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="font-bold text-slate-200">সঞ্চয়ের মাস</label>
                <select value={savingsMonth} onChange={handleMonthChange} className={`${inputCls} cursor-pointer font-bold`}>
                  {monthOptions.map((opt) => (
                    <option key={opt.id} value={opt.id}>
                      {opt.label}
                    </option>
                  ))}
                </select>
              </div>
              <div className="space-y-1">
                <label className="font-bold text-slate-200 flex items-center gap-1.5">
                  <Calendar className="w-3.5 h-3.5 text-emerald-400" />
                  জমার তারিখ
                </label>
                <input
                  type="date"
                  value={transactionDate}
                  onChange={(e) => setTransactionDate(e.target.value)}
                  className={`${inputCls} font-mono font-bold`}
                  required
                />
              </div>
            </div>
            <p className="text-[11px] text-slate-400 -mt-2">
              নির্বাচিত তারিখ: {new Date(transactionDate).toLocaleDateString('bn-BD', { day: 'numeric', month: 'long', year: 'numeric' })}
            </p>

            {/* Payment methods */}
            <div className="space-y-2">
              <label className="text-[15px] font-bold text-ink block">পেমেন্ট মাধ্যম</label>
              <div className="grid grid-cols-2 gap-2.5">
                {[
                  { id: 'BKASH', label: 'বিকাশ' },
                  { id: 'NAGAD', label: 'নগদ' },
                  { id: 'ROCKET', label: 'রকেট' },
                  { id: 'BANK', label: 'ব্যাংক ট্রান্সফার' },
                  { id: 'CASH', label: 'ক্যাশ / সরাসরি' },
                ].map((m) => {
                  const active = paymentMethod === m.id;
                  return (
                    <button
                      type="button"
                      key={m.id}
                      onClick={() => setPaymentMethod(m.id as PaymentMethod)}
                      aria-pressed={active}
                      className={`min-h-14 px-3 rounded-[18px] text-left border-2 transition-all text-[13px] font-bold flex items-center gap-2.5 cursor-pointer ${
                        active
                          ? 'bg-emerald-500/10 border-emerald-500 text-ink'
                          : 'bg-slate-900 border-slate-800 text-slate-300 hover:border-slate-700'
                      }`}
                    >
                      <span className="w-9 h-9 rounded-xl bg-emerald-500/15 text-emerald-400 flex items-center justify-center shrink-0">
                        <CreditCard className="w-4 h-4" />
                      </span>
                      <span className="flex-1 truncate">{m.label}</span>
                      {active && <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Conditional Bank Details Input */}
            {(paymentMethod === 'BANK' || paymentMethod === 'BANK_TRANSFER') && (
              <div className="p-3.5 rounded-[20px] bg-slate-900 border border-slate-800 space-y-2.5">
                <div className="flex items-center gap-1.5 text-emerald-400 font-bold text-xs">
                  <Building2 className="w-4 h-4" />
                  <span>ব্যাংক ডিপোজিট বা ট্রান্সফার তথ্য</span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  <div>
                    <label className="text-[11px] text-slate-400 block mb-1">ব্যাংকের নাম:</label>
                    <input
                      type="text"
                      value={bankName}
                      onChange={(e) => setBankName(e.target.value)}
                      placeholder="যেমন: ইসলামী ব্যাংক / ব্র্যাক ব্যাংক"
                      className={inputCls}
                    />
                  </div>
                  <div>
                    <label className="text-[11px] text-slate-400 block mb-1">শাখা (Branch):</label>
                    <input
                      type="text"
                      value={bankBranch}
                      onChange={(e) => setBankBranch(e.target.value)}
                      placeholder="যেমন: ধানমন্ডি শাখা"
                      className={inputCls}
                    />
                  </div>
                </div>
              </div>
            )}

            {/* Transaction Ref */}
            <div className="space-y-1">
              <label className="font-bold text-slate-200">
                {paymentMethod === 'BANK' ? 'ভাউচার / ডিপোজিট স্লিপ নং' : 'ট্রানজেকশন আইডি / রেফারেন্স'}
              </label>
              <input
                type="text"
                placeholder={paymentMethod === 'BANK' ? 'যেমন: DEP-20261016-092' : 'যেমন: BK-88129384'}
                value={transactionRef}
                onChange={(e) => setTransactionRef(e.target.value)}
                className={`${inputCls} font-mono`}
              />
            </div>

            {/* Notes */}
            <div className="space-y-1">
              <label className="font-bold text-slate-200">মন্তব্য বা বিবরণ (ঐচ্ছিক)</label>
              <input
                type="text"
                placeholder="জমার বিবরণ লিখুন..."
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                className={inputCls}
              />
            </div>

            {/* Summary */}
            <div className="rounded-[20px] bg-slate-900 border border-slate-800 p-4 space-y-2.5">
              <div className="flex items-center justify-between text-[13px] text-slate-400">
                <span>সার্ভিস চার্জ</span>
                <span className="font-bold">৳ ০</span>
              </div>
              <div className="border-t border-slate-800" />
              <div className="flex items-center justify-between">
                <span className="text-[15px] font-bold text-ink">মোট জমা</span>
                <span className="text-[18px] font-bold text-ink">{formatCurrencyBengali(amount)}</span>
              </div>
            </div>

            {/* Approval Policy Note */}
            <div className="p-3 rounded-[16px] bg-emerald-500/10 border border-emerald-500/20 flex items-start gap-2 text-[11px] text-slate-300">
              <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <span>
                নীতিমালা অনুচ্ছেদ ৫: এই এন্ট্রিটি দাখিলের পর অবিলম্বে পেন্ডিং থাকবে। যোগ্য মডারেটরদের ২/৩ অংশ (Ceiling) ভোট প্রদানের পর রসিদ প্রস্তুত হবে এবং মূল তহবিলে যোগ হবে।
              </span>
            </div>

            {/* Action Buttons */}
            <button
              type="submit"
              className="btn-brand w-full min-h-14 rounded-2xl font-bold text-[16px] flex items-center justify-center gap-2 cursor-pointer"
            >
              <PlusCircle className="w-5 h-5" />
              <span>জমা নিশ্চিত করুন</span>
            </button>
            <button
              type="button"
              onClick={onClose}
              className="w-full min-h-11 rounded-2xl text-slate-400 hover:text-ink font-bold text-xs cursor-pointer"
            >
              বাতিল
            </button>
          </form>
        </div>
      </div>

      {/* Point 3: Duplicate Submission Warning Popup */}
      {showPendingPopup && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-slate-950/90 backdrop-blur-md animate-in fade-in duration-200">
          <div className="bg-slate-900 border border-amber-500/50 rounded-3xl max-w-sm w-full p-6 text-center space-y-4 shadow-2xl">
            <div className="w-14 h-14 rounded-3xl bg-amber-500/20 text-amber-400 border border-amber-500/30 flex items-center justify-center mx-auto">
              <AlertCircle className="w-8 h-8" />
            </div>

            <div className="space-y-1.5">
              <h4 className="text-base font-bold text-ink">
                অনুমোদনের অপেক্ষায় রয়েছে!
              </h4>
              <p className="text-xs text-amber-200/90 font-medium leading-relaxed">
                আপনি একবার টাকা জমার তথ্য সাবমিট করেছেন, অনুগ্রহ করে মডারেটর প্যানেলের অনুমোদনের জন্য অপেক্ষা করুন।
              </p>
            </div>

            <div className="pt-2">
              <button
                type="button"
                onClick={() => {
                  setShowPendingPopup(false);
                  onClose();
                }}
                className="w-full py-2.5 px-5 rounded-2xl bg-amber-600 hover:from-amber-500 hover:to-amber-400 text-white font-bold text-xs transition-all cursor-pointer"
              >
                ঠিক আছে, বুঝেছি
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
