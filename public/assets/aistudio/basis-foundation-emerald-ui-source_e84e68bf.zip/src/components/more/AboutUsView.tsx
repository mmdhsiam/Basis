import React from 'react';
import {
  BookOpen,
  ShieldCheck,
  Users,
  Target,
  Award,
  Phone,
  Mail,
  MapPin,
  Building2,
  HeartHandshake,
  CheckCircle2,
  ExternalLink,
  Sparkles,
  HelpCircle,
  Clock,
  Shield,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { Avatar } from '../common/Avatar';
import { toBengaliNumerals, maskPhoneForPrivacy } from '../../utils/calculations';
import { extractDirectImageUrl } from '../../utils/imageUtils';

interface AboutUsViewProps {
  onOpenFirebaseGuide?: () => void;
}

export const AboutUsView: React.FC<AboutUsViewProps> = () => {
  const { config, users, currentUser } = useApp();

  const realUsers = users.filter((u) => u.id !== '__guest__' && u.memberId !== 'GUEST');
  const moderators = realUsers.filter(
    (u) => u.role === 'APP_MODERATOR' || u.role === 'MODERATOR'
  );
  const logoSrc = extractDirectImageUrl(config.logoUrl) || '/logo.svg';

  return (
    <div className="space-y-6 pb-20 max-w-5xl mx-auto">
      {/* 1. Hero Banner with Official Logo */}
      <div className="relative rounded-3xl overflow-hidden border border-emerald-500/30 bg-gradient-to-br from-emerald-950 via-slate-900 to-slate-950 p-6 sm:p-10 shadow-2xl">
        <div className="absolute top-0 right-0 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row items-center gap-6 sm:gap-8 text-center md:text-left">
          {/* Logo Badge */}
          <div className="w-28 h-28 sm:w-32 sm:h-32 rounded-3xl bg-emerald-600 p-1 shrink-0 group hover:scale-105 transition-transform">
            <div className="w-full h-full bg-slate-950 rounded-[22px] flex items-center justify-center p-3 overflow-hidden">
              <img
                src={logoSrc}
                alt="BASIS Foundation Logo"
                className="w-full h-full object-contain"
                onError={(e) => {
                  (e.currentTarget as HTMLImageElement).src = '/logo.svg';
                }}
              />
            </div>
          </div>

          <div className="space-y-2 flex-1">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs font-bold">
              <Sparkles className="w-3.5 h-3.5" />
              <span>ডিজিটাল সমবায় সঞ্চয় ও কল্যাণ প্ল্যাটফর্ম</span>
            </div>
            <h1 className="text-2xl sm:text-4xl font-bold text-ink tracking-tight">
              {config.foundationName}
            </h1>
            <p className="text-emerald-300/90 font-bold text-sm sm:text-base max-w-2xl leading-relaxed">
              {config.foundationSlogan}
            </p>
            <div className="pt-2 flex flex-wrap items-center justify-center md:justify-start gap-4 text-xs text-slate-300">
              <span className="flex items-center gap-1.5 font-medium">
                <Clock className="w-4 h-4 text-emerald-400" />
                <span>প্রতিষ্ঠিত: জানুয়ারি ২০২৫</span>
              </span>
              <span>•</span>
              <span className="flex items-center gap-1.5 font-medium">
                <ShieldCheck className="w-4 h-4 text-blue-400" />
                <span>স্বীকৃতি নং: BF-REG-2025/DH</span>
              </span>
              <span>•</span>
              <span className="flex items-center gap-1.5 font-medium">
                <Users className="w-4 h-4 text-amber-400" />
                <span>সদস্য সংখ্যা: {toBengaliNumerals(realUsers.length)} জন</span>
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* 2. Mission & Core Values Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* আমাদের লক্ষ্য (Mission) */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 sm:p-6 shadow-md space-y-3">
          <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center">
            <Target className="w-6 h-6" />
          </div>
          <h3 className="text-lg font-bold text-ink">আমাদের উদ্দেশ্য ও লক্ষ্য</h3>
          <p className="text-xs text-slate-300 leading-relaxed">
            সদস্যদের মধ্যে নিয়মানুবর্তিত সঞ্চয় অভ্যাস গড়ে তোলা, সুদমুক্ত আর্থিক শৃঙ্খলা নিশ্চিতকরণ এবং জরুরি প্রয়োজনে পারস্পরিক সহমর্মিতা ও সহায়তার আধুনিক প্রাতিষ্ঠানিক রূপদান।
          </p>
        </div>

        {/* স্বচ্ছতা ও ২/৩ অনুমোদন */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 sm:p-6 shadow-md space-y-3">
          <div className="w-12 h-12 rounded-2xl bg-blue-500/20 text-blue-400 border border-blue-500/30 flex items-center justify-center">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <h3 className="text-lg font-bold text-ink">শতভাগ আর্থিক স্বচ্ছতা</h3>
          <p className="text-xs text-slate-300 leading-relaxed">
            কোনো একক ব্যক্তির সিদ্ধান্তে লেনদেন অনুমোদন হয় না। গঠনতন্ত্র অনুযায়ী কমপক্ষে ২/৩ অংশ (Ceiling) যোগ্য মডারেটরের সরাসরি অনুমোদনের পরই অর্থ চূড়ান্ত হিসাবে যুক্ত ও রসিদ তৈরি হয়।
          </p>
        </div>

        {/* ভ্রাতৃত্ববোধ ও কল্যাণ */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 sm:p-6 shadow-md space-y-3">
          <div className="w-12 h-12 rounded-2xl bg-purple-500/20 text-purple-400 border border-purple-500/30 flex items-center justify-center">
            <HeartHandshake className="w-6 h-6" />
          </div>
          <h3 className="text-lg font-bold text-ink">পারস্পরিক আস্থা ও সমবায়</h3>
          <p className="text-xs text-slate-300 leading-relaxed">
            প্রতিটি সদস্যের সঞ্চয় সুরক্ষিত ও ডিজিটাল অডিট ট্রেইল দ্বারা সংরক্ষিত। যেকোনো সময়ে ভেরিফাইড ব্যাংক-স্টাইল পিডিএফ বিবরণী ও অনলাইন লেজার পরীক্ষা করা যায়।
          </p>
        </div>
      </div>

      {/* 3. Executive Committee & Leadership */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-md space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-4">
          <div>
            <h3 className="text-lg font-bold text-ink flex items-center gap-2">
              <Award className="w-5 h-5 text-amber-400" />
              <span>পরিচালনা পর্ষদ ও দায়িত্বপ্রাপ্ত মডারেটরবৃন্দ</span>
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              ফাউন্ডেশনের সুষ্ঠু ব্যবস্থাপনা, আর্থিক হিসাব যাচাই ও সিদ্ধান্ত গ্রহণে নিয়োজিত পর্ষদ।
            </p>
          </div>
          <span className="text-xs font-bold px-3 py-1 rounded-xl bg-slate-800 text-slate-300 self-start sm:self-auto">
            {toBengaliNumerals(moderators.length)} জন দায়িত্বশীল
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {moderators.map((mod) => (
            <div
              key={mod.id}
              className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 hover:border-slate-700 transition-all space-y-3"
            >
              <div className="flex items-center gap-3">
                <Avatar
                  src={mod.avatarUrl}
                  name={mod.name}
                  size="lg"
                  ringColor={mod.role === 'APP_MODERATOR' ? 'ring-amber-500' : 'ring-emerald-500'}
                />
                <div className="overflow-hidden">
                  <div className="flex items-center gap-1.5">
                    <h4 className="font-bold text-sm text-ink truncate">{mod.name}</h4>
                    <CheckCircle2 className="w-3.5 h-3.5 text-blue-400 shrink-0" />
                  </div>
                  <span
                    className={`inline-block text-[10px] font-bold px-2 py-0.2 rounded-full mt-0.5 ${
                      mod.role === 'APP_MODERATOR'
                        ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                        : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                    }`}
                  >
                    {mod.role === 'APP_MODERATOR' ? 'প্রধান অ্যাপ মডারেটর' : 'মডারেটর ও নিরীক্ষক'}
                  </span>
                  <p className="text-[11px] text-slate-400 mt-0.5">সদস্য আইডি: {mod.memberId}</p>
                </div>
              </div>

              <div className="pt-2 border-t border-slate-900 text-xs space-y-1.5 text-slate-300">
                <div className="flex items-center justify-between">
                  <span className="text-slate-500 text-[11px]">মোবাইল:</span>
                  <span className="text-emerald-400 font-mono font-bold flex items-center gap-1">
                    <Phone className="w-3 h-3" />
                    <span>{maskPhoneForPrivacy(mod.phone, mod.gender)}</span>
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-500 text-[11px]">দায়িত্ব:</span>
                  <span className="text-slate-300 font-medium text-[11px]">
                    {mod.role === 'APP_MODERATOR' ? 'অ্যাপ প্রশাসন ও নীতিনির্ধারণ' : 'জমা অনুমোদন ও হিসাব নিরীক্ষা'}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 4. Official Bank Account Information (Synced with BankInformationView) */}
      <div className="bg-gradient-to-r from-emerald-950/40 via-slate-900 to-slate-900 border border-emerald-800/40 rounded-3xl p-6 shadow-md space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center">
              <Building2 className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-ink">অফিসিয়াল ব্যাংক একাউন্ট বিবরণী</h3>
              <p className="text-xs text-slate-400">ব্যাংক ইনফরমেশন ও আমাদের সম্পর্কে ট্যাবে অভিন্ন অফিশিয়াল ব্যাংক বিবরণী</p>
            </div>
          </div>
          <span className="text-xs px-2.5 py-1 rounded-xl bg-emerald-500/10 text-emerald-400 font-bold border border-emerald-500/20 self-start sm:self-auto">
            যৌথ ব্যাংক হিসাব (Joint Account)
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 text-xs pt-1">
          <div className="p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-1">
            <span className="text-[11px] text-slate-500 block">ব্যাংকের নাম:</span>
            <strong className="text-ink text-sm block">
              {config.bankDetails?.bankName || 'সোনালী ব্যাংক পিএলসি'}
            </strong>
            <span className="text-[10px] text-slate-400">
              {config.bankDetails?.branchName || 'উত্তরা মডেল টাউন শাখা, ঢাকা'}
            </span>
          </div>

          <div className="p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-1">
            <span className="text-[11px] text-slate-500 block">হিসাবের নাম (A/C Name):</span>
            <strong className="text-emerald-400 text-sm block">
              {config.bankDetails?.accountName || 'বেসিস সমবায় সঞ্চয় তহবিল'}
            </strong>
            <span className="text-[10px] text-slate-400">Savings Account</span>
          </div>

          <div className="p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-1">
            <span className="text-[11px] text-slate-500 block">হিসাব নম্বর (A/C No):</span>
            <strong className="text-amber-400 font-mono text-sm block">
              {config.bankDetails?.accountNumber || '120.101.8892'}
            </strong>
            <span className="text-[10px] text-slate-400">সঞ্চয়ী হিসাব নম্বর</span>
          </div>

          <div className="p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-1">
            <span className="text-[11px] text-slate-500 block">রাউটিং নম্বর:</span>
            <strong className="text-slate-200 font-mono text-sm block">
              {config.bankDetails?.routingNumber || '200261572'}
            </strong>
            <span className="text-[10px] text-slate-400">ইএফটি / এনপিএসবি সাপোর্টেড</span>
          </div>
        </div>

        {/* Joint Bank Account Holders List (3 demo moderators) with Edit Option for App Moderator */}
        <div className="pt-4 border-t border-slate-800 space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div>
              <h4 className="text-sm font-bold text-ink flex items-center gap-2">
                <Shield className="w-4 h-4 text-emerald-400" />
                <span>যৌথ ব্যাংক একাউন্ট পরিচালনাকারী ৩ জন মডারেটর তালিকা</span>
              </h4>
              <p className="text-[11px] text-slate-400 mt-0.5">
                ব্যাংক হিসাব পরিচালনার জন্য অনুমোদিত যৌথ স্বাক্ষরকারী মডারেটর পরিষদ।
              </p>
            </div>
            {currentUser?.role === 'APP_MODERATOR' && (
              <span className="text-[11px] text-emerald-400 bg-emerald-950/50 border border-emerald-800/60 px-2 py-0.5 rounded-lg font-bold">
                * অ্যাপ মডারেটর প্যানেল থেকে এডিটযোগ্য
              </span>
            )}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1">
            {(config.jointBankAccountHolders || [
              { name: 'মাহমুদুল হাসান সিয়াম', role: 'প্রধান সমন্বয়ক ও একাউন্ট হোল্ডার ১', memberId: 'BF-001', phone: '০১৭০০-০০০০০১' },
              { name: 'তানভীর আহমেদ', role: 'যুগ্ম সমন্বয়ক ও একাউন্ট হোল্ডার ২', memberId: 'BF-002', phone: '০১৭০০-০০০০০২' },
              { name: 'সাবরিনা আক্তার', role: 'কোষাধ্যক্ষ ও একাউন্ট হোল্ডার ৩', memberId: 'BF-003', phone: '০১৭০০-০০০০০৩' },
            ]).map((rawHolder, idx) => {
              const holder =
                typeof rawHolder === 'string'
                  ? (() => {
                      const match = rawHolder.match(/^(.+?)\s*\((.+)\)$/);
                      const parsedName = match ? match[1].trim() : rawHolder.trim();
                      const parsedRole = match ? match[2].trim() : `একাউন্ট হোল্ডার ${toBengaliNumerals(idx + 1)}`;
                      const matchedUser = users.find(
                        (u) => rawHolder.includes(u.name) || u.id === rawHolder || u.memberId === rawHolder
                      );
                      return {
                        name: matchedUser?.name || parsedName,
                        role: matchedUser?.moderatorTitle || parsedRole,
                        memberId: matchedUser?.memberId || `BF-00${idx + 1}`,
                        phone: matchedUser?.phone || '০১৭০০-০০০০০' + (idx + 1),
                      };
                    })()
                  : rawHolder;

              return (
                <div
                  key={idx}
                  className="p-3.5 rounded-2xl bg-slate-950/90 border border-slate-800 flex flex-col justify-between space-y-2 hover:border-emerald-500/40 transition-colors"
                >
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                        স্বাক্ষরকারী #{toBengaliNumerals(idx + 1)}
                      </span>
                      <span className="text-[10px] text-slate-400 font-mono font-bold">{holder.memberId}</span>
                    </div>
                    <h5 className="font-bold text-xs text-ink">{holder.name}</h5>
                    <p className="text-[11px] text-emerald-400/90 font-medium mt-0.5">{holder.role}</p>
                  </div>
                  <div className="pt-1.5 border-t border-slate-900 flex items-center justify-between text-[11px] text-slate-400">
                    <span>ফোন:</span>
                    <span className="text-slate-300 font-mono font-bold">
                      {maskPhoneForPrivacy(
                        holder.phone,
                        holder.name.includes('সাবরিনা') ? 'FEMALE' : 'MALE',
                        currentUser.role
                      )}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* 5. Contact & Support */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-md space-y-4">
        <h3 className="text-base font-bold text-ink flex items-center gap-2">
          <MapPin className="w-5 h-5 text-emerald-400" />
          <span>যোগাযোগ ও কেন্দ্রীয় কার্যালয়</span>
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
          <div className="flex items-center gap-3 p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800">
            <Mail className="w-5 h-5 text-emerald-400 shrink-0" />
            <div>
              <span className="text-slate-500 text-[11px] block">ইমেইল:</span>
              <a href="mailto:contact.mahmudulhasan.bd@gmail.com" className="text-ink font-bold hover:underline">
                contact.mahmudulhasan.bd@gmail.com
              </a>
            </div>
          </div>

          <div className="flex items-center gap-3 p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800">
            <Phone className="w-5 h-5 text-blue-400 shrink-0" />
            <div>
              <span className="text-slate-500 text-[11px] block">হটলাইন / হেল্পডেস্ক:</span>
              <a href="tel:+8801700000000" className="text-ink font-bold hover:underline">
                +880 1700-000000
              </a>
            </div>
          </div>

          <div className="flex items-center gap-3 p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800">
            <MapPin className="w-5 h-5 text-amber-400 shrink-0" />
            <div>
              <span className="text-slate-500 text-[11px] block">ঠিকানা:</span>
              <span className="text-ink font-bold">
                ধানমন্ডি, ঢাকা - ১২০৯, বাংলাদেশ
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* 6. Footer Attribution */}
      <div className="text-center text-xs text-slate-500 space-y-1 pt-4">
        <p className="font-bold text-slate-400">
          {config.footerText || '© ২০২৫-২০২৬ বেসিস ফাউন্ডেশন। সর্বস্বত্ব সংরক্ষিত।'}
        </p>
        <p className="text-[11px]">
          কারিগরি উন্নয়ন ও রক্ষণাবেক্ষণ:{' '}
          <a
            href={config.developerLink || 'https://github.com/mahmudulhasan'}
            target="_blank"
            rel="noopener noreferrer"
            className="text-emerald-400 font-bold hover:underline"
          >
            {config.developerAttribution || 'Mahmudul Hasan Siam'}
          </a>
        </p>
      </div>
    </div>
  );
};
