import React, { useState, useEffect } from 'react';
import {
  FileSpreadsheet,
  ExternalLink,
  Save,
  RefreshCw,
  ShieldAlert,
  CheckCircle2,
  Copy,
  Code,
  BookOpen,
  Smartphone,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const GoogleSheetsView: React.FC = () => {
  const { config, updateConfig, currentUser, isGuestMode, triggerGuestWarning, triggerSuccess, triggerWarning } = useApp();
  const [sheetUrl, setSheetUrl] = useState(
    config.googleSheetsUrl ||
      'https://docs.google.com/spreadsheets/d/1BxiMVs0XRA5nFMdKvBdBZjgmUUqptlbs74OgvE2upms/edit?usp=sharing'
  );
  const [isEditing, setIsEditing] = useState(false);
  // Default to 'view' (/htmlembed) so both Web and Native Android APK display the sheet immediately WITHOUT asking for Google login
  const [mode, setMode] = useState<'edit' | 'view'>('view');
  const [iframeKey, setIframeKey] = useState(0);
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  const isModeratorOrAppMod =
    !isGuestMode && (currentUser.role === 'APP_MODERATOR' || currentUser.role === 'MODERATOR');

  // Keep local sheetUrl synced when Firestore config updates
  useEffect(() => {
    if (config.googleSheetsUrl && !isEditing) {
      setSheetUrl(config.googleSheetsUrl);
    }
  }, [config.googleSheetsUrl, isEditing]);

  const handleSaveUrl = (e: React.FormEvent) => {
    e.preventDefault();
    if (!isModeratorOrAppMod) {
      triggerGuestWarning('গুগল শিট লিংক পরিবর্তন');
      return;
    }
    const trimmed = sheetUrl.trim();
    if (!trimmed.startsWith('https://docs.google.com/spreadsheets/')) {
      triggerWarning(
        'সঠিক গুগল শিট লিংক দিন',
        'অনুগ্রহ করে https://docs.google.com/spreadsheets/d/... ফরম্যাটের বৈধ গুগল স্প্রেডশিট লিংক পেস্ট করুন।',
        false
      );
      return;
    }
    updateConfig({ googleSheetsUrl: trimmed });
    setIsEditing(false);
    setIframeKey((k) => k + 1);
    triggerSuccess('গুগল শিট লিংক সংরক্ষিত ও ক্লাউডে সিঙ্ক হয়েছে');
  };

  const copyCode = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2500);
  };

  // Convert sharing or published URL to login-free embeddable view URL or minimal editor URL
  const getEmbedUrl = (rawUrl: string, targetMode: 'edit' | 'view') => {
    try {
      const clean = rawUrl.trim();
      // Support "Publish to the web" links (/d/e/2PACX-.../pubhtml) directly in view mode
      if (clean.includes('/spreadsheets/d/e/') && targetMode === 'view') {
        const basePub = clean.split('?')[0].replace(/\/pub$/, '/pubhtml');
        return `${basePub}?widget=true&headers=false`;
      }
      if (clean.includes('spreadsheets/d/')) {
        const idMatch = clean.match(/\/spreadsheets\/d\/([a-zA-Z0-9-_]+)/);
        if (idMatch && idMatch[1] && idMatch[1] !== 'e') {
          const sheetId = idMatch[1];
          const gidMatch = clean.match(/[?&#]gid=([0-9]+)/);
          const gidParam = gidMatch ? `&gid=${gidMatch[1]}` : '';
          if (targetMode === 'edit') {
            return `https://docs.google.com/spreadsheets/d/${sheetId}/edit?rm=minimal${gidParam}`;
          } else {
            // /htmlembed renders cleanly inside Android APK WebView & Web browsers without Google login if "Anyone with the link" is enabled
            return `https://docs.google.com/spreadsheets/d/${sheetId}/htmlembed?widget=true&headers=false${gidParam}`;
          }
        }
      }
      return clean;
    } catch {
      return rawUrl;
    }
  };

  const getDirectOpenUrl = (rawUrl: string) => {
    const idMatch = rawUrl.match(/\/spreadsheets\/d\/([a-zA-Z0-9-_]+)/);
    if (idMatch && idMatch[1] && idMatch[1] !== 'e') {
      return `https://docs.google.com/spreadsheets/d/${idMatch[1]}/edit?usp=sharing`;
    }
    return rawUrl;
  };

  const embedSrc = getEmbedUrl(sheetUrl, mode);
  const directOpenUrl = getDirectOpenUrl(sheetUrl);

  const handleModeSwitch = (nextMode: 'edit' | 'view') => {
    if (nextMode === 'edit' && isGuestMode) {
      triggerGuestWarning('গুগল শিট সরাসরি এডিট মোড');
      return;
    }
    setMode(nextMode);
  };

  const appsScriptSnippet = `// Google Apps Script (Webhook) - অটোমেটিক সঞ্চয় রো যুক্তকরণ
function doPost(e) {
  var sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
  var data = JSON.parse(e.postData.contents);
  
  // নতুন সঞ্চয় এন্ট্রি রো যোগ করুন
  sheet.appendRow([
    new Date(),
    data.receiptId || "N/A",
    data.memberId,
    data.memberName,
    data.savingsMonth,
    data.amount,
    data.paymentMethod,
    data.transactionRef || "",
    "ভেরিফাইড (২/৩ অনুমোদিত)"
  ]);
  
  return ContentService.createTextOutput(JSON.stringify({status: "success"}))
    .setMimeType(ContentService.MimeType.JSON);
}`;

  const androidWebViewCookieSnippet = `// MainActivity.kt — Android APK WebView-এ Google Sheets সাপোর্ট
val cookieManager = android.webkit.CookieManager.getInstance()
cookieManager.setAcceptCookie(true)
cookieManager.setAcceptThirdPartyCookies(webView, true)
webView.settings.domStorageEnabled = true
webView.settings.javaScriptEnabled = true`;

  return (
    <div className="space-y-5 pb-20">
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 sm:p-6 shadow-sm space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h2 className="text-xl sm:text-2xl font-bold text-ink flex items-center gap-2">
              <FileSpreadsheet className="w-6 h-6 text-emerald-400" />
              <span>গুগল শিটস ক্লাউড স্প্রেডশিট (Google Sheets Integration)</span>
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              ওয়েব ও নেটিভ Android APK উভয় মাধ্যমেই লগইন ছাড়াই সরাসরি শিট ভিউ এবং অনুমোদিত একাউন্টে এডিট সুবিধা।
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={() => setIframeKey((k) => k + 1)}
              className="py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold flex items-center gap-1.5 transition-colors border border-slate-700 cursor-pointer"
              title="শিট রিলোড করুন"
            >
              <RefreshCw className="w-3.5 h-3.5 text-emerald-400" />
              <span>রিলোড</span>
            </button>

            <a
              href={directOpenUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="py-2 px-3.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center gap-1.5 transition-colors"
            >
              <span>গুগল শিটস অ্যাপে খুলুন / এডিট</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>

            {isModeratorOrAppMod && (
              <button
                onClick={() => setIsEditing(!isEditing)}
                className="py-2 px-3.5 rounded-xl bg-emerald-600/20 text-emerald-400 border border-emerald-500/30 hover:bg-emerald-600/30 text-xs font-bold transition-colors cursor-pointer"
              >
                {isEditing ? 'সম্পাদনা বন্ধ' : 'শিট লিংক পরিবর্তন'}
              </button>
            )}
          </div>
        </div>

        {/* Link Edit Form */}
        {isEditing && isModeratorOrAppMod && (
          <form onSubmit={handleSaveUrl} className="pt-3 border-t border-slate-800 flex flex-col sm:flex-row gap-2">
            <input
              type="url"
              placeholder="গুগল শিট শেয়ারিং লিংক পেস্ট করুন (Anyone with the link)..."
              value={sheetUrl}
              onChange={(e) => setSheetUrl(e.target.value)}
              className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-ink focus:ring-1 focus:ring-emerald-500 font-mono"
              required
            />
            <button
              type="submit"
              className="py-2 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center justify-center gap-1 shrink-0 cursor-pointer"
            >
              <Save className="w-3.5 h-3.5" />
              <span>সংরক্ষণ করুন</span>
            </button>
          </form>
        )}
      </div>

      {/* Frame Controls & View Toggle */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 px-1 text-xs text-slate-300">
        <div className="flex items-center gap-2 flex-wrap">
          <span className="text-slate-400 font-bold">ভিউ মোড:</span>
          <div className="bg-slate-900 p-1 rounded-xl border border-slate-800 flex items-center gap-1">
            <button
              onClick={() => handleModeSwitch('view')}
              className={`py-1.5 px-3 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                mode === 'view'
                  ? 'bg-emerald-600 text-white shadow'
                  : 'text-slate-400 hover:text-ink'
              }`}
            >
              ক্লিন গ্রিড ভিউ (APK ও লগইন ছাড়া ভিউ)
            </button>
            <button
              onClick={() => handleModeSwitch('edit')}
              className={`py-1.5 px-3 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                mode === 'edit'
                  ? 'bg-emerald-600 text-white shadow'
                  : 'text-slate-400 hover:text-ink'
              }`}
            >
              ইন্টারেক্টিভ এডিটর মোড (ওয়েব ব্রাউজার)
            </button>
          </div>
        </div>

        <span className="text-[11px] text-emerald-400 font-bold flex items-center gap-1">
          <CheckCircle2 className="w-3.5 h-3.5" />
          <span>{mode === 'view' ? 'APK-বান্ধব লগইন-মুক্ত এমবেড মোড সক্রিয়' : 'ডিরেক্ট ব্রাউজার সেশন এডিটর মোড সক্রিয়'}</span>
        </span>
      </div>

      {mode === 'edit' && (
        <div className="bg-amber-950/40 border border-amber-500/40 rounded-2xl p-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs text-amber-200">
          <div className="flex items-start gap-2">
            <ShieldAlert className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
            <span>
              <strong>APK ব্যবহারকারীদের জন্য নোট:</strong> নেটিভ APK-এর ভেতরে Google নিরাপত্তার কারণে সরাসরি Google Sign-In ব্লক করে। এখানে লগইন চাইলে <strong>"ক্লিন গ্রিড ভিউ"</strong> চালু করুন অথবা এডিট করতে উপরের <strong>"গুগল শিটস অ্যাপে খুলুন / এডিট"</strong> বাটনে চাপুন।
            </span>
          </div>
          <button
            onClick={() => setMode('view')}
            className="py-1.5 px-3 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 border border-amber-400/40 text-amber-200 font-bold shrink-0 cursor-pointer"
          >
            ক্লিন গ্রিড ভিউতে ফিরুন
          </button>
        </div>
      )}

      {/* Embedded Google Sheet Iframe */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden shadow-2xl relative">
        <iframe
          key={`${iframeKey}-${mode}-${embedSrc}`}
          src={embedSrc}
          title="Google Sheets Live Embed"
          className="w-full h-[650px] border-0 bg-white"
          allow="autoplay; clipboard-write; encrypted-media"
        />
      </div>

      {/* Technical Explanation & Construction Guide: Why APK asks for login & How it is solved */}
      <div className="bg-gradient-to-r from-emerald-950/40 via-slate-900 to-slate-900 border border-emerald-500/30 rounded-3xl p-5 sm:p-6 shadow-md space-y-4">
        <div className="flex items-center gap-2 text-emerald-400 font-bold text-sm">
          <Smartphone className="w-5 h-5 shrink-0" />
          <span>APK ইনস্টল করার পর শিট ভিউতে কেন লগইন করতে বলে এবং স্থায়ী সমাধান ও কনস্ট্রাকশন গাইড:</span>
        </div>

        <div className="p-4 rounded-2xl bg-slate-950/90 border border-amber-500/30 space-y-1.5 text-xs text-slate-300 leading-relaxed">
          <p className="font-bold text-amber-300">কেন ওয়েব অ্যাপে কাজ করলেও APK-তে আগে লগইন চাইতো?</p>
          <p>
            ১. <strong>আলাদা কুকি স্যান্ডবক্স (Isolated WebView Cookie Store):</strong> কম্পিউটার বা ফোনের Chrome ব্রাউজারে আপনার জিমেইল আগে থেকেই লগইন করা থাকে, তাই <code className="text-emerald-400">/edit?rm=minimal</code> লিংক ব্রাউজারের কুকি ব্যবহার করে সরাসরি খুলে যায়। কিন্তু Android APK-এর ভেতরের <code className="text-emerald-400">WebView</code> সম্পূর্ণ আলাদা স্যান্ডবক্স—এতে ফোনের ব্রাউজার বা Gmail অ্যাপের লগইন সেশন থাকে না।
          </p>
          <p>
            ২. <strong>Google OAuth WebView ব্লক নীতি (403 disallowed_useragent):</strong> নিরাপত্তার কারণে Google কোনো এমবেডেড Android WebView-এর ভেতরে সরাসরি Google একাউন্ট লগইন করতে দেয় না এবং থার্ড-পার্টি ফ্রেম কুকি ব্লক থাকলে লগইন স্ক্রিনে আটকে যায়।
          </p>
          <p>
            ৩. <strong>শিটের Restricted পারমিশন:</strong> গুগল শিটের শেয়ারিং যদি <em>"Restricted"</em> থাকে, তবে লগইন ছাড়া কোনো WebView ফ্রেমই শিট পড়তে পারে না।
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
          {/* Step 1 */}
          <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-1.5">
            <div className="w-6 h-6 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold text-xs">
              ১
            </div>
            <h4 className="font-bold text-ink text-xs">গুগল শিট "Anyone with the link" করুন</h4>
            <p className="text-slate-300 text-[11px] leading-relaxed">
              গুগল স্প্রেডশিটে গিয়ে <strong>Share &gt; General access &gt; "Anyone with the link" (Viewer)</strong> চালু রাখুন (অথবা <strong>File &gt; Share &gt; Publish to web</strong> করুন)। নির্দিষ্ট মডারেটর ইমেইলগুলোকে আলাদাভাবে <strong>Editor</strong> দিন।
            </p>
          </div>

          {/* Step 2 */}
          <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-1.5">
            <div className="w-6 h-6 rounded-lg bg-blue-500/20 text-blue-400 flex items-center justify-center font-bold text-xs">
              ২
            </div>
            <h4 className="font-bold text-ink text-xs">APK-এ ডিফল্ট `/htmlembed` ভিউ</h4>
            <p className="text-slate-300 text-[11px] leading-relaxed">
              অ্যাপে এখন ডিফল্টভাবে <strong>ক্লিন গ্রিড ভিউ (<code className="text-emerald-400">/htmlembed</code>)</strong> সেট করা হয়েছে। এতে APK ইনস্টল করার পর কোনো লগইন ছাড়াই সকল সদস্য ও মডারেটর সরাসরি লাইভ শিট দেখতে পাবেন।
            </p>
          </div>

          {/* Step 3 */}
          <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-1.5">
            <div className="w-6 h-6 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold text-xs">
              ৩
            </div>
            <h4 className="font-bold text-ink text-xs">APK থেকে শিট এডিট করার নিয়ম</h4>
            <p className="text-slate-300 text-[11px] leading-relaxed">
              ফোনে APK থেকে শিট এডিট করতে উপরের <strong>"গুগল শিটস অ্যাপে খুলুন / এডিট"</strong> বাটনে চাপুন—এটি ফোনের অফিসিয়াল <strong>Google Sheets App</strong>-এ আপনার লগইন থাকা জিমেইল দিয়ে সরাসরি এডিটর মোডে খুলবে।
            </p>
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-emerald-400 flex items-center gap-1.5">
              <BookOpen className="w-4 h-4" />
              <span>Android Studio `MainActivity.kt` থার্ড-পার্টি কুকি কনফিগারেশন:</span>
            </span>
            <button
              onClick={() => copyCode(androidWebViewCookieSnippet, 'cookie')}
              className="py-1 px-2.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-[11px] font-bold flex items-center gap-1 cursor-pointer"
            >
              <Copy className="w-3 h-3" />
              <span>{copiedKey === 'cookie' ? 'কপি সম্পন্ন!' : 'কোড কপি'}</span>
            </button>
          </div>
          <pre className="font-mono text-[11px] text-emerald-300 overflow-x-auto leading-relaxed">
            {androidWebViewCookieSnippet}
          </pre>
        </div>
      </div>

      {/* Apps Script Automation Snippet */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-sm space-y-3">
        <div className="flex items-center justify-between">
          <h4 className="font-bold text-ink text-sm flex items-center gap-2">
            <Code className="w-4 h-4 text-emerald-400" />
            <span>স্বয়ংক্রিয় সঞ্চয় রো সিঙ্ক কোড (Google Apps Script Webhook)</span>
          </h4>

          <button
            onClick={() => copyCode(appsScriptSnippet, 'script')}
            className="py-1 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold transition-colors flex items-center gap-1 cursor-pointer"
          >
            <Copy className="w-3.5 h-3.5" />
            <span>{copiedKey === 'script' ? 'কপি সম্পন্ন!' : 'স্ক্রিপ্ট কপি'}</span>
          </button>
        </div>

        <p className="text-xs text-slate-400">
          আপনার স্প্রেডশিটে গিয়ে <strong>Extensions &gt; Apps Script</strong>-এ এই কোডটি পেস্ট করে Deploy as Web App করলে যেকোনো অনুমোদিত সঞ্চয় অটোমেটিক নতুন সারিতে যোগ হবে।
        </p>

        <pre className="font-mono text-[11px] text-emerald-300 overflow-x-auto p-3.5 bg-slate-950 rounded-2xl border border-slate-800 leading-relaxed">
          {appsScriptSnippet}
        </pre>
      </div>
    </div>
  );
};
