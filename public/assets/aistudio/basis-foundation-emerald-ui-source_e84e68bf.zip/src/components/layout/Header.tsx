import React from 'react';
import {
  Menu,
  Moon,
  Sun,
  MessageSquare,
  Bell,
  PhoneCall,
  LogIn,
  Edit3,
  User,
  Search,
  Megaphone,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { toBengaliNumerals } from '../../utils/calculations';
import { extractDirectImageUrl } from '../../utils/imageUtils';
import { Avatar } from '../common/Avatar';

interface HeaderProps {
  onOpenDrawer: () => void;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onInitiateCall: () => void;
}

const PAGE_TITLES: Record<string, string> = {
  home: 'হোম ড্যাশবোর্ড',
  members: 'সদস্য তালিকা ও পদবি',
  savings: 'সঞ্চয় খাতা',
  receipts: 'রসিদ ও স্টেটমেন্ট',
  analytics: 'হিসাব বিশ্লেষণ',
  moderator: 'মডারেটর প্যানেল',
  'app-moderator': 'অ্যাপ মডারেটর অ্যাডমিন',
  chat: 'কমিউনিটি চ্যাট',
  notices: 'নোটিশ বোর্ড',
  executive: 'কার্যনির্বাহী পর্ষদ',
  rules: 'গঠনতন্ত্র ও বিধি',
  complaints: 'অভিযোগ প্রতিকার সেল',
  features: 'ফিচার প্রস্তাবনা',
  sheets: 'গুগল শিটস সিঙ্ক',
  profile: 'প্রোফাইল ও সেটিংস',
  bank: 'ব্যাংক ইনফরমেশন',
  'about-us': 'আমাদের সম্পর্কে',
};

export const Header: React.FC<HeaderProps> = ({ onOpenDrawer, activeTab, setActiveTab, onInitiateCall }) => {
  const {
    config,
    currentUser,
    isGuestMode,
    theme,
    setTheme,
    isOnline,
    setIsOnline,
    chatUnreadCount,
    markChatSeen,
    unreadNoticeCount,
    hasUnreadNotices,
    markNoticesSeen,
    setIsAuthModalOpen,
    setIsSearchModalOpen,
    unreadCount,
  } = useApp();

  const isModerator =
    !isGuestMode && currentUser && (currentUser.role === 'APP_MODERATOR' || currentUser.role === 'MODERATOR');

  const resolvedLogoUrl = extractDirectImageUrl(config.logoUrl) || config.logoUrl || '/logo.svg';

  const tickerSpeed = config.tickerSpeed || 'normal';
  const marqueeDuration = tickerSpeed === 'slow' ? '65s' : tickerSpeed === 'fast' ? '22s' : '38s';

  const logoSize = Math.min(Math.max(config.headerLogoSize || 44, 32), 46);
  const titleScale = config.headerTitleScale || 100;

  const announcementText =
    config.scrollingAnnouncement ||
    '[জরুরি বিজ্ঞপ্তি] বেসিস ফাউন্ডেশন ডিজিটাল সঞ্চয় প্ল্যাটফর্মে স্বাগতম। প্রতি মাসের ১০ তারিখের মধ্যে আপনার নিয়মিত সঞ্চয় জমা সম্পন্ন করুন।';

  const urgentTag = '[জরুরি বিজ্ঞপ্তি]';
  const renderAnnouncement = (text: string) =>
    text.includes(urgentTag) ? (
      <span className="inline-flex items-center gap-2">
        <span className="bg-rose-500/15 text-rose-400 border border-rose-500/30 px-2 rounded-md text-[10px] font-bold">
          জরুরি
        </span>
        <span className="text-slate-200">{text.split(urgentTag).join('').trim()}</span>
      </span>
    ) : (
      <span className="text-slate-200">{text}</span>
    );

  const iconBtn =
    'relative w-10 h-10 rounded-xl flex items-center justify-center transition-all cursor-pointer border border-slate-800 bg-slate-900 text-slate-300 hover:text-ink hover:border-slate-700 active:scale-95';
  const iconBtnActive = 'relative w-10 h-10 rounded-xl flex items-center justify-center transition-all cursor-pointer bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 active:scale-95';

  return (
    <header className="sticky top-0 z-40 glass border-x-0 border-t-0 lg:ml-72">
      <div className="max-w-7xl mx-auto px-3 sm:px-5 h-[60px] flex items-center justify-between gap-2">
        {/* Left: menu + brand (mobile) / page title (desktop) */}
        <div className="flex items-center gap-2.5 min-w-0">
          <button
            onClick={onOpenDrawer}
            aria-label="মেনু খুলুন"
            className={`${iconBtn} lg:hidden shrink-0`}
          >
            <Menu className="w-[18px] h-[18px]" />
            {unreadCount > 0 && <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-rose-500 ring-2 ring-slate-950" />}
          </button>

          <button
            onClick={() => setActiveTab('home')}
            className="lg:hidden flex items-center gap-2 min-w-0 cursor-pointer text-left"
            aria-label="হোমে যান"
          >
            <span
              style={{ width: logoSize - 6, height: logoSize - 6 }}
              className="rounded-xl bg-emerald-600 p-[2px] flex items-center justify-center shrink-0"
            >
              <img
                src={resolvedLogoUrl}
                alt="Logo"
                onError={(e) => {
                  (e.currentTarget as HTMLImageElement).src = '/logo.svg';
                }}
                className="w-full h-full object-contain rounded-[10px] bg-slate-950"
              />
            </span>
            <span className="min-w-0 leading-tight">
              <span
                style={{ fontSize: `${(titleScale / 100) * 0.98}rem` }}
                className="block font-bold text-ink truncate"
              >
                {config.foundationName}
              </span>
              <span className="block text-[9px] font-bold tracking-[0.12em] text-emerald-400 uppercase truncate">
                Basis Foundation
              </span>
            </span>
          </button>

          {!isGuestMode && currentUser?.role === 'APP_MODERATOR' && (
            <button
              onClick={() => setActiveTab('app-moderator')}
              title="ফাউন্ডেশন টাইটেল ও লোগো সাইজ পরিবর্তন"
              aria-label="টাইটেল সম্পাদনা"
              className="hidden sm:flex lg:hidden p-1 rounded-lg text-amber-400 hover:bg-slate-800 cursor-pointer"
            >
              <Edit3 className="w-3.5 h-3.5" />
            </button>
          )}

          <div className="hidden lg:block min-w-0">
            <h1 className="text-lg font-bold text-ink truncate leading-tight">
              {PAGE_TITLES[activeTab] || config.foundationName}
            </h1>
            <p className="text-[11px] text-slate-400 font-bold">{config.foundationName}</p>
          </div>
        </div>

        {/* Right: actions */}
        <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
          <button
            onClick={() => setIsSearchModalOpen(true)}
            aria-label="সার্চ করুন"
            className={`${iconBtn} hidden sm:flex sm:w-auto sm:px-3.5 sm:gap-2 text-xs font-bold`}
          >
            <Search className="w-[18px] h-[18px]" />
            <span className="hidden sm:inline text-slate-400">খুঁজুন</span>
          </button>

          <button
            onClick={() => setIsOnline(!isOnline)}
            title={isOnline ? 'ইন্টারনেট সক্রিয় (Online)' : 'ইন্টারনেট বিচ্ছিন্ন (Offline)'}
            aria-label="নেটওয়ার্ক অবস্থা"
            className="hidden md:flex items-center gap-1.5 h-10 px-3 rounded-xl border border-slate-800 bg-slate-900 text-[11px] font-bold cursor-pointer"
          >
            <span className={`w-2 h-2 rounded-full ${isOnline ? 'bg-emerald-400 animate-pulse' : 'bg-rose-500'}`} />
            <span className={isOnline ? 'text-emerald-400' : 'text-rose-400'}>{isOnline ? 'অনলাইন' : 'অফলাইন'}</span>
          </button>

          <button
            onClick={onInitiateCall}
            title="গ্রুপ কল শুরু করুন"
            aria-label="গ্রুপ কল"
            className={`${iconBtn} hidden sm:flex text-emerald-400`}
          >
            <PhoneCall className="w-[18px] h-[18px]" />
          </button>

          <button
            onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
            aria-label="থিম পরিবর্তন করুন"
            title={theme === 'dark' ? 'লাইট মোডে পরিবর্তন করুন' : 'ডার্ক মোডে পরিবর্তন করুন'}
            className={iconBtn}
          >
            {theme === 'dark' ? <Sun className="w-[18px] h-[18px] text-amber-400" /> : <Moon className="w-[18px] h-[18px] text-indigo-500" />}
          </button>

          <button
            onClick={() => {
              markChatSeen();
              setActiveTab('chat');
            }}
            aria-label="ইনবক্স ও চ্যাট"
            className={activeTab === 'chat' ? iconBtnActive : iconBtn}
          >
            <MessageSquare className="w-[18px] h-[18px]" />
            {chatUnreadCount > 0 && (
              <span className="absolute -top-1 -right-1 min-w-[18px] h-[18px] px-1 rounded-full bg-emerald-500 text-[10px] text-white font-bold flex items-center justify-center ring-2 ring-slate-950">
                {toBengaliNumerals(chatUnreadCount)}
              </span>
            )}
          </button>

          <button
            onClick={() => {
              markNoticesSeen();
              setActiveTab('notices');
            }}
            aria-label="নোটিফিকেশন"
            className={activeTab === 'notices' ? iconBtnActive : iconBtn}
          >
            <Bell className="w-[18px] h-[18px]" />
            {hasUnreadNotices && unreadNoticeCount > 0 && (
              <span className="absolute -top-1 -right-1 min-w-[18px] h-[18px] px-1 rounded-full bg-rose-500 text-[10px] text-white font-bold flex items-center justify-center ring-2 ring-slate-950 animate-pulse">
                {toBengaliNumerals(unreadNoticeCount)}
              </span>
            )}
          </button>

          {!isGuestMode && currentUser ? (
            <button
              onClick={() => setActiveTab('profile')}
              className={`rounded-full p-0.5 transition-all cursor-pointer shrink-0 ${
                activeTab === 'profile' ? 'ring-2 ring-emerald-400' : 'hover:ring-2 hover:ring-emerald-400/60'
              }`}
              title={`${currentUser.name} - প্রোফাইল ও সেটিংস`}
              aria-label="প্রোফাইল"
            >
              <Avatar
                src={currentUser.avatarUrl}
                name={currentUser.name}
                size="md"
                ringColor="ring-emerald-500/60"
              />
            </button>
          ) : (
            <>
              <button
                onClick={() => setActiveTab('profile')}
                aria-label="প্রোফাইল ও সেটিংস"
                className={`${activeTab === 'profile' ? iconBtnActive : iconBtn} hidden sm:flex`}
              >
                <User className="w-[18px] h-[18px]" />
              </button>
              <button
                onClick={() => setIsAuthModalOpen(true)}
                className="btn-brand h-10 px-3.5 rounded-xl font-bold text-xs flex items-center gap-1.5 cursor-pointer shrink-0"
              >
                <LogIn className="w-4 h-4" />
                <span>লগইন</span>
              </button>
            </>
          )}
        </div>
      </div>

      {/* Announcement ribbon */}
      <div className="border-t border-slate-800 bg-emerald-500/[0.06]">
        <div className="max-w-7xl mx-auto px-3 sm:px-5 h-8 flex items-center gap-2.5 overflow-hidden">
          <span className="shrink-0 inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-gold-grad text-[10px] font-bold text-amber-950">
            <Megaphone className="w-3 h-3" />
            ঘোষণা
          </span>
          <div className="overflow-hidden relative w-full text-[12px] flex">
            <div
              className="animate-marquee inline-flex items-center gap-10 whitespace-nowrap shrink-0"
              style={{ animationDuration: marqueeDuration }}
            >
              {renderAnnouncement(announcementText)}
              <span className="text-slate-600">•</span>
              {renderAnnouncement(announcementText)}
              <span className="text-slate-600">•</span>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};
