import React, { useState } from 'react';
import { Home, Users, Wallet, Plus, LayoutGrid } from 'lucide-react';

interface BottomNavProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onOpenDrawer: () => void;
  unreadCount: number;
  onNewDeposit?: () => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  activeTab,
  setActiveTab,
  onOpenDrawer,
  unreadCount,
  onNewDeposit,
}) => {
  // Red dot stops blinking once the menu has been opened
  const [hasSeenMenu, setHasSeenMenu] = useState<boolean>(() => {
    try {
      return localStorage.getItem('basis_menu_seen') === 'true';
    } catch {
      return false;
    }
  });

  const handleOpenMenu = () => {
    setHasSeenMenu(true);
    try {
      localStorage.setItem('basis_menu_seen', 'true');
    } catch {
      /* ignore */
    }
    onOpenDrawer();
  };

  const item = (id: string, label: string, Icon: React.ComponentType<{ className?: string }>) => {
    const isActive = activeTab === id;
    return (
      <button
        key={id}
        onClick={() => setActiveTab(id)}
        aria-current={isActive ? 'page' : undefined}
        className="relative flex-1 min-h-12 flex flex-col items-center justify-center gap-0.5 py-1 cursor-pointer select-none"
      >
        <span
          className={`flex items-center justify-center h-7 w-12 rounded-full transition-colors ${
            isActive ? 'glowing-nav-item-active' : 'text-slate-400'
          }`}
        >
          <Icon className="w-[20px] h-[20px]" />
        </span>
        <span className={`text-[11px] leading-none ${isActive ? 'font-bold text-emerald-400' : 'font-medium text-slate-400'}`}>
          {label}
        </span>
      </button>
    );
  };

  return (
    <nav
      aria-label="নিচের নেভিগেশন"
      className="dock fixed bottom-0 left-0 right-0 z-30 lg:hidden select-none"
    >
      <div className="mx-auto max-w-md px-2 pt-1.5 pb-[max(0.375rem,env(safe-area-inset-bottom))] flex items-end">
        {item('home', 'হোম', Home)}
        {item('members', 'সদস্য', Users)}

        {/* Primary action */}
        <div className="flex-1 flex flex-col items-center -mt-5">
          <button
            onClick={onNewDeposit}
            aria-label="নতুন সঞ্চয় জমা দিন"
            className="btn-brand w-12 h-12 rounded-full flex items-center justify-center ring-4 ring-slate-900 cursor-pointer"
          >
            <Plus className="w-6 h-6" />
          </button>
          <span className="mt-0.5 text-[11px] font-bold text-emerald-400 leading-none py-1">জমা</span>
        </div>

        {item('savings', 'সঞ্চয়', Wallet)}

        <button
          onClick={handleOpenMenu}
          aria-label="মেনু"
          className="relative flex-1 min-h-12 flex flex-col items-center justify-center gap-0.5 py-1 cursor-pointer"
        >
          <span className="flex items-center justify-center h-7 w-12 rounded-full text-slate-400">
            <LayoutGrid className="w-[20px] h-[20px]" />
          </span>
          <span className="text-[11px] leading-none font-medium text-slate-400">মেনু</span>
          {unreadCount > 0 && !hasSeenMenu && (
            <span className="absolute top-1 right-4 flex h-2.5 w-2.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75" />
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-rose-500" />
            </span>
          )}
        </button>
      </div>
    </nav>
  );
};
