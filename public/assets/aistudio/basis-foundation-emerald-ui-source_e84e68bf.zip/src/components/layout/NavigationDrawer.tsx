import React from 'react';
import {
  X,
  Home,
  Users,
  Wallet,
  Receipt,
  BarChart3,
  ShieldCheck,
  ShieldAlert,
  Bell,
  BookOpen,
  FileText,
  Lightbulb,
  FileSpreadsheet,
  LogOut,
  Flame,
  Building2,
  User,
  Award,
  Search,
  Sun,
  Moon,
  MessageSquare,
  ChevronRight,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { toBengaliNumerals } from '../../utils/calculations';
import { extractDirectImageUrl } from '../../utils/imageUtils';
import { Avatar } from '../common/Avatar';

interface NavigationDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onShowExitDialog: () => void;
  onOpenFirebaseGuide?: () => void;
}

type Tone = 'emerald' | 'sky' | 'amber' | 'indigo' | 'rose' | 'violet' | 'teal';

/** Tailwind-safe tone → chip classes (literal strings so the compiler can see them) */
const TONES: Record<Tone, string> = {
  emerald: 'bg-emerald-500/15 text-emerald-400',
  sky: 'bg-emerald-500/15 text-emerald-400',
  amber: 'bg-emerald-500/15 text-emerald-400',
  indigo: 'bg-emerald-500/15 text-emerald-400',
  rose: 'bg-emerald-500/15 text-emerald-400',
  violet: 'bg-emerald-500/15 text-emerald-400',
  teal: 'bg-emerald-500/15 text-emerald-400',
};

interface NavDef {
  id: string;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  tone: Tone;
  group: 'main' | 'finance' | 'community' | 'support' | 'admin';
  badge?: string | null;
  badgeClass?: string;
  roles: string[];
}

const GROUPS: { id: NavDef['group']; title: string }[] = [
  { id: 'main', title: 'মূল মেনু' },
  { id: 'finance', title: 'আর্থিক হিসাব' },
  { id: 'community', title: 'কমিউনিটি' },
  { id: 'support', title: 'নীতিমালা ও সহায়তা' },
  { id: 'admin', title: 'প্রশাসন' },
];

const ALL_ROLES = ['APP_MODERATOR', 'MODERATOR', 'MEMBER'];

/**
 * Shared navigation content. Used by the slide-over drawer (mobile / tablet)
 * and by the permanent sidebar (desktop ≥ lg).
 */
export const NavPanel: React.FC<
  Omit<NavigationDrawerProps, 'isOpen'> & { variant: 'drawer' | 'sidebar' }
> = ({ onClose, activeTab, setActiveTab, onShowExitDialog, onOpenFirebaseGuide, variant }) => {
  const {
    currentUser,
    isGuestMode,
    config,
    unreadCount,
    unreadNoticeCount,
    markNoticesSeen,
    setIsSearchModalOpen,
    setIsAuthModalOpen,
    theme,
    setTheme,
  } = useApp();

  const resolvedLogoUrl = extractDirectImageUrl(config.logoUrl) || config.logoUrl || '/logo.svg';

  const navItems: NavDef[] = [
    { id: 'home', label: 'হোম ড্যাশবোর্ড', icon: Home, tone: 'emerald', group: 'main', roles: ALL_ROLES },
    { id: 'profile', label: 'প্রোফাইল ও অ্যাপ সেটিংস', icon: User, tone: 'sky', group: 'main', roles: ALL_ROLES },
    { id: 'savings', label: 'সঞ্চয় খাতা ও নতুন জমা', icon: Wallet, tone: 'emerald', group: 'finance', roles: ALL_ROLES },
    { id: 'receipts', label: 'রসিদ ও পিডিএফ স্টেটমেন্ট', icon: Receipt, tone: 'teal', group: 'finance', roles: ALL_ROLES },
    { id: 'analytics', label: 'হিসাব বিশ্লেষণ ও গ্রাফ', icon: BarChart3, tone: 'violet', group: 'finance', roles: ALL_ROLES },
    { id: 'bank', label: 'ব্যাংক ইনফরমেশন ও হিসাব', icon: Building2, tone: 'indigo', group: 'finance', badge: 'New', badgeClass: 'bg-indigo-500', roles: ALL_ROLES },
    { id: 'sheets', label: 'গুগল শিটস ক্লাউড সিঙ্ক', icon: FileSpreadsheet, tone: 'emerald', group: 'finance', roles: ALL_ROLES },
    { id: 'members', label: 'সদস্য তালিকা ও পদবি', icon: Users, tone: 'sky', group: 'community', roles: ALL_ROLES },
    { id: 'chat', label: 'কমিউনিটি চ্যাট ও ইনবক্স', icon: MessageSquare, tone: 'indigo', group: 'community', roles: ALL_ROLES },
    {
      id: 'notices',
      label: 'নোটিশ বোর্ড',
      icon: Bell,
      tone: 'amber',
      group: 'community',
      badge: unreadNoticeCount > 0 ? toBengaliNumerals(unreadNoticeCount) : null,
      badgeClass: 'bg-rose-500',
      roles: ALL_ROLES,
    },
    { id: 'executive', label: 'কার্যনির্বাহী পর্ষদ', icon: Award, tone: 'amber', group: 'community', badge: 'New', badgeClass: 'bg-amber-500', roles: ALL_ROLES },
    { id: 'rules', label: 'ফাউন্ডেশন গঠনতন্ত্র ও বিধি', icon: FileText, tone: 'rose', group: 'support', roles: ALL_ROLES },
    { id: 'complaints', label: 'অভিযোগ প্রতিকার সেল', icon: FileText, tone: 'teal', group: 'support', roles: ALL_ROLES },
    { id: 'features', label: 'নতুন ফিচারের প্রস্তাবনা', icon: Lightbulb, tone: 'amber', group: 'support', roles: ALL_ROLES },
    { id: 'about-us', label: 'আমাদের সম্পর্কে (About Us)', icon: BookOpen, tone: 'emerald', group: 'support', badge: 'New', badgeClass: 'bg-emerald-500', roles: ALL_ROLES },
    {
      id: 'moderator',
      label: 'মডারেটর প্যানেল',
      icon: ShieldCheck,
      tone: 'amber',
      group: 'admin',
      badge: unreadCount > 0 ? toBengaliNumerals(unreadCount) : null,
      badgeClass: 'bg-rose-500',
      roles: ['APP_MODERATOR', 'MODERATOR'],
    },
    { id: 'app-moderator', label: 'অ্যাপ মডারেটর অ্যাডমিন', icon: ShieldAlert, tone: 'rose', group: 'admin', badge: 'Admin', badgeClass: 'bg-amber-500', roles: ['APP_MODERATOR'] },
  ];

  const rawOrder = config.navTabsOrder || [];
  const customTitles = config.customTabTitles || {};

  const orderOf = (id: string) => {
    const i = rawOrder.indexOf(id);
    return i === -1 ? 999 : i;
  };

  const visibleItems = navItems
    .map((item) => ({ ...item, label: customTitles[item.id] || item.label }))
    .filter((item) =>
      !isGuestMode && currentUser ? item.roles.includes(currentUser.role) : item.roles.includes('MEMBER')
    );

  const handleSelect = (id: string) => {
    if (id === 'notices') markNoticesSeen();
    setActiveTab(id);
    if (variant === 'drawer') onClose();
  };

  const roleLabel =
    currentUser?.role === 'APP_MODERATOR' ? 'অ্যাপ মডারেটর' : currentUser?.role === 'MODERATOR' ? 'মডারেটর' : 'সাধারণ সদস্য';
  const roleChip =
    currentUser?.role === 'APP_MODERATOR'
      ? 'bg-[#d5a23b]/30 text-white border-white/30'
      : currentUser?.role === 'MODERATOR'
      ? 'bg-sky-300/30 text-white border-white/30'
      : 'bg-white/15 text-white border-white/25';

  return (
    <div data-nav-panel className="h-full flex flex-col bg-slate-900 text-slate-100">
      {/* Identity card */}
      <div className="p-3 pb-2">
        <div className="relative overflow-hidden rounded-[22px] bg-hero p-4 text-white">
          <div className="pointer-events-none absolute -top-12 -right-10 h-36 w-36 rounded-full border-[22px] border-white/10" />
          
          <div className="relative flex items-start justify-between gap-2">
            {!isGuestMode && currentUser ? (
              <button
                onClick={() => handleSelect('profile')}
                className="flex items-center gap-3 text-left min-w-0 cursor-pointer"
              >
                <Avatar
                  src={currentUser.avatarUrl}
                  name={currentUser.name}
                  size="lg"
                  ringColor="ring-white/60"
                />
                <div className="min-w-0">
                  <h3 className="font-bold text-sm truncate leading-tight">{currentUser.name}</h3>
                  <p className="text-[11px] text-white/90 font-mono mt-0.5">আইডি: {currentUser.memberId}</p>
                  <span className={`mt-1.5 inline-block text-[10px] font-bold px-2 py-0.5 rounded-full border ${roleChip}`}>
                    {roleLabel}
                  </span>
                </div>
              </button>
            ) : (
              <div className="flex items-center gap-3 min-w-0">
                <div className="w-12 h-12 rounded-2xl bg-white/15 border border-white/25 flex items-center justify-center shrink-0">
                  <User className="w-6 h-6" />
                </div>
                <div className="min-w-0">
                  <h3 className="font-bold text-sm leading-tight">অতিথি দর্শক (Guest)</h3>
                  <button
                    onClick={() => {
                      onClose();
                      setIsAuthModalOpen(true);
                    }}
                    className="mt-1 text-[11px] text-white/90 hover:text-white font-bold underline underline-offset-2 cursor-pointer text-left"
                  >
                    লগইন বা নতুন অ্যাকাউন্ট খুলুন
                  </button>
                </div>
              </div>
            )}

            {variant === 'drawer' && (
              <button
                onClick={onClose}
                aria-label="মেনু বন্ধ করুন"
                className="p-2 rounded-xl bg-white/15 hover:bg-white/25 text-white transition-colors cursor-pointer shrink-0"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* Universal search */}
          <button
            onClick={() => {
              onClose();
              setIsSearchModalOpen(true);
            }}
            className="relative mt-3.5 w-full flex items-center justify-between gap-2 px-3 py-2.5 rounded-2xl bg-white/15 hover:bg-white/25 border border-white/20 text-white text-xs font-bold transition-colors cursor-pointer"
          >
            <span className="flex items-center gap-2.5 min-w-0">
              <Search className="w-4 h-4 shrink-0" />
              <span className="truncate">আইডি, নাম, রসিদ বা তথ্য সার্চ করুন...</span>
            </span>
          </button>
        </div>
      </div>

      {/* Grouped navigation */}
      <nav className="flex-1 overflow-y-auto px-3 pb-3">
        {GROUPS.map((group) => {
          const items = visibleItems
            .filter((i) => i.group === group.id)
            .sort((a, b) => orderOf(a.id) - orderOf(b.id));
          if (items.length === 0) return null;
          return (
            <div key={group.id} className="mt-3 first:mt-1">
              <p className="px-2 pb-1.5 text-[11px] font-bold text-slate-500">
                {group.title}
              </p>
              <div className="space-y-0.5">
                {items.map((item) => {
                  const Icon = item.icon;
                  const isActive = activeTab === item.id;
                  return (
                    <button
                      key={item.id}
                      onClick={() => handleSelect(item.id)}
                      aria-current={isActive ? 'page' : undefined}
                      className={`group w-full flex items-center justify-between gap-2 px-2.5 py-1.5 rounded-xl text-[13px] min-h-11 transition-all cursor-pointer ${
                        isActive
                          ? 'glowing-nav-item-active font-bold'
                          : 'text-slate-300 hover:bg-slate-800 font-bold'
                      }`}
                    >
                      <span className="flex items-center gap-3 min-w-0">
                        <span
                          className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 transition-transform group-hover:scale-105 ${
                            isActive ? 'bg-emerald-600 text-white' : TONES[item.tone]
                          }`}
                        >
                          <Icon className="w-4 h-4" />
                        </span>
                        <span className="truncate text-left">{item.label}</span>
                      </span>

                      {item.badge ? (
                        <span
                          className={`text-[10px] px-1.5 py-0.5 rounded-full text-white font-bold shrink-0 ${
                            item.badgeClass || 'bg-slate-600'
                          }`}
                        >
                          {item.badge}
                        </span>
                      ) : (
                        <ChevronRight
                          className={`w-3.5 h-3.5 shrink-0 ${isActive ? 'text-emerald-400' : 'text-slate-600 opacity-0 group-hover:opacity-100'} transition-opacity`}
                        />
                      )}
                    </button>
                  );
                })}
              </div>
            </div>
          );
        })}

        {onOpenFirebaseGuide && (
          <button
            onClick={() => {
              onClose();
              onOpenFirebaseGuide();
            }}
            className="mt-4 w-full flex items-center justify-between gap-2 px-3 py-2.5 rounded-2xl text-xs font-bold text-amber-400 bg-amber-500/10 border border-amber-500/30 hover:bg-amber-500/20 transition-all cursor-pointer"
          >
            <span className="flex items-center gap-3">
              <span className="w-8 h-8 rounded-xl bg-amber-500/20 flex items-center justify-center">
                <Flame className="w-4 h-4" />
              </span>
              <span>ফায়ারবেজ ও APK বিল্ড গাইড</span>
            </span>
            <span className="text-[10px] px-1.5 py-0.5 rounded bg-amber-500/20 font-bold">নির্দেশনা</span>
          </button>
        )}
      </nav>

      {/* Footer: theme switch + brand + exit */}
      <div className="p-3 border-t border-slate-800 space-y-3 bg-slate-950/40">
        <div className="flex items-center justify-between gap-3">
          <span className="text-[11px] font-bold text-slate-400">থিম</span>
          <div className="flex items-center p-1 rounded-2xl bg-slate-800 border border-slate-700/60">
            <button
              onClick={() => setTheme('light')}
              aria-pressed={theme === 'light'}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-[11px] font-bold transition-all cursor-pointer ${
                theme === 'light' ? 'bg-emerald-600 text-white shadow' : 'text-slate-400 hover:text-ink'
              }`}
            >
              <Sun className="w-3.5 h-3.5" />
              <span>লাইট</span>
            </button>
            <button
              onClick={() => setTheme('dark')}
              aria-pressed={theme === 'dark'}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-[11px] font-bold transition-all cursor-pointer ${
                theme === 'dark' ? 'bg-emerald-600 text-white shadow' : 'text-slate-400 hover:text-ink'
              }`}
            >
              <Moon className="w-3.5 h-3.5" />
              <span>ডার্ক</span>
            </button>
          </div>
        </div>

        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-8 h-8 rounded-xl bg-emerald-600 p-0.5 flex items-center justify-center overflow-hidden shrink-0">
              <img
                src={resolvedLogoUrl}
                alt="Logo"
                onError={(e) => {
                  (e.currentTarget as HTMLImageElement).src = '/logo.svg';
                }}
                className="w-full h-full object-contain rounded-lg bg-slate-950"
              />
            </div>
            <div className="min-w-0 leading-tight">
              <span className="font-bold text-ink text-[12px] block truncate max-w-[150px]">{config.foundationName}</span>
              <span className="text-[10px] text-emerald-400 font-bold">v1.2.0 (Stable)</span>
            </div>
          </div>

          <button
            onClick={() => {
              onClose();
              onShowExitDialog();
            }}
            className="p-2.5 rounded-xl bg-rose-500/10 text-rose-400 hover:bg-rose-500/20 transition-colors cursor-pointer shrink-0"
            title="অ্যাপ থেকে প্রস্থান"
            aria-label="অ্যাপ থেকে প্রস্থান"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};

/** Slide-over drawer for phones & tablets */
export const NavigationDrawer: React.FC<NavigationDrawerProps> = (props) => {
  const { isOpen, onClose } = props;
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex lg:hidden">
      <div
        className="fixed inset-0 bg-slate-950/60 backdrop-blur-sm animate-in fade-in duration-200 cursor-pointer"
        onClick={onClose}
      />
      <aside
        aria-label="প্রধান মেনু"
        className="relative w-[21rem] max-w-[88vw] h-full border-r border-slate-800 shadow-2xl z-10 overflow-hidden animate-drawer"
      >
        <NavPanel {...props} variant="drawer" />
      </aside>
    </div>
  );
};

/** Permanent sidebar for desktop (≥ lg) */
export const SidebarNav: React.FC<Omit<NavigationDrawerProps, 'isOpen'>> = (props) => (
  <aside
    aria-label="প্রধান মেনু"
    className="hidden lg:block fixed left-0 top-0 bottom-0 w-72 z-[45] border-r border-slate-800"
  >
    <NavPanel {...props} variant="sidebar" />
  </aside>
);
