import React, { useMemo, useState } from 'react';
import {
  Wallet,
  TrendingUp,
  TrendingDown,
  Users,
  CheckCircle2,
  Bell,
  PlusCircle,
  FileSpreadsheet,
  ShieldCheck,
  AlertCircle,
  ArrowRight,
  ChevronRight,
  Lightbulb,
  Receipt,
  BarChart3,
  Send,
  Building2,
  MessageSquare,
  BookOpen,
  HelpCircle,
  X,
  Plus,
  LayoutGrid,
  Landmark,
  Award,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import {
  formatCurrencyBengali,
  toBengaliNumerals,
  getBengaliDateParts,
  getMonthNameBengali,
  formatDateTimeBengali,
} from '../../utils/calculations';
import { Avatar } from '../common/Avatar';

interface HomeDashboardProps {
  setActiveTab: (tab: string) => void;
  onOpenNewSavingsModal: () => void;
}

/** Month key (YYYY-MM) in Asia/Dhaka */
const currentMonthKey = (): string => {
  const d = new Date(new Date().toLocaleString('en-US', { timeZone: 'Asia/Dhaka' }));
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
};

const BN_MONTHS = ['জানুয়ারি', 'ফেব্রুয়ারি', 'মার্চ', 'এপ্রিল', 'মে', 'জুন', 'জুলাই', 'আগস্ট', 'সেপ্টেম্বর', 'অক্টোবর', 'নভেম্বর', 'ডিসেম্বর'];
const monthLabel = (key: string): string => {
  const known = getMonthNameBengali(key);
  if (known !== key) return known;
  const [y, m] = key.split('-');
  return `${BN_MONTHS[Number(m) - 1] ?? key} ${toBengaliNumerals(y)}`;
};

/** Circular progress ring */
const Ring: React.FC<{ pct: number }> = ({ pct }) => {
  const r = 34;
  const c = 2 * Math.PI * r;
  return (
    <div className="relative w-[88px] h-[88px] shrink-0">
      <svg viewBox="0 0 88 88" className="w-full h-full -rotate-90">
        <circle cx="44" cy="44" r={r} fill="none" strokeWidth="9" className="stroke-slate-800" />
        <circle
          cx="44"
          cy="44"
          r={r}
          fill="none"
          className="stroke-emerald-400"
          strokeWidth="9"
          strokeLinecap="round"
          strokeDasharray={c}
          strokeDashoffset={c - (Math.min(pct, 100) / 100) * c}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center leading-none">
        <span className="text-lg font-bold text-ink">{toBengaliNumerals(Math.round(pct))}%</span>
        <span className="text-[9px] font-bold text-slate-400 mt-0.5">জমা সম্পন্ন</span>
      </div>
    </div>
  );
};

export const HomeDashboard: React.FC<HomeDashboardProps> = ({ setActiveTab, onOpenNewSavingsModal }) => {
  const {
    currentUser,
    users,
    savings,
    financialTotals,
    growthRate,
    monthlyAggregates,
    notices,
    complaints,
    chatMessages,
    receipts,
    config,
    overdueReminders,
    sendOverdueReminder,
    totalExpenses,
    netReserveBalance,
    isGuestMode,
  } = useApp();

  const selectedMonth = useMemo(currentMonthKey, []);
  const [isOverdueExpanded, setIsOverdueExpanded] = useState(false);
  const [isAlertDismissed, setIsAlertDismissed] = useState(false);

  const isModeratorOrAppMod =
    !isGuestMode && (currentUser?.role === 'APP_MODERATOR' || currentUser?.role === 'MODERATOR');

  const monthDeposits = savings
    .filter((t) => t.savingsMonth === selectedMonth && t.status === 'APPROVED')
    .sort((a, b) => new Date(b.transactionDate).getTime() - new Date(a.transactionDate).getTime());

  const currentMonthTotalAmount = monthDeposits.reduce((sum, t) => sum + t.amount, 0);

  const approvedMembers = users.filter((u) => u.id !== '__guest__' && u.status === 'APPROVED');

  const overdueMembers = users.filter(
    (u) =>
      u.id !== '__guest__' &&
      u.status === 'APPROVED' &&
      !savings.some(
        (t) =>
          t.memberId === u.memberId &&
          t.savingsMonth === selectedMonth &&
          (t.status === 'APPROVED' || t.status === 'PENDING')
      )
  );

  const hasUserDepositedOrPending =
    !isGuestMode && currentUser
      ? savings.some(
          (t) =>
            t.memberId === currentUser.memberId &&
            t.savingsMonth === selectedMonth &&
            (t.status === 'APPROVED' || t.status === 'PENDING')
        )
      : false;

  // Guests must NEVER see the overdue popup
  const isCurrentUserReminded =
    !isGuestMode &&
    currentUser &&
    currentUser.role === 'MEMBER' &&
    !hasUserDepositedOrPending &&
    !isAlertDismissed &&
    (overdueReminders.includes(currentUser.memberId) || !hasUserDepositedOrPending);

  const pinnedNotice = notices.find((n) => n.isPinned) || notices[0];

  const showNet = config.dashboardBalanceDisplay === 'NET_AFTER_EXPENSE';
  const heroValue = showNet ? netReserveBalance : financialTotals.totalApproved;
  const otherValue = showNet ? financialTotals.totalApproved : netReserveBalance;

  const monthEntries = Object.entries(monthlyAggregates).sort(([a], [b]) => a.localeCompare(b));
  const chartMonths = monthEntries.slice(-6);
  const chartMax = Math.max(...chartMonths.map(([, v]) => v), 1);

  const paidPct = approvedMembers.length ? (monthDeposits.length / approvedMembers.length) * 100 : 0;

  const date = getBengaliDateParts();
  const hour = Number(new Date().toLocaleString('en-US', { timeZone: 'Asia/Dhaka', hour: 'numeric', hour12: false })) % 24;
  const greeting = hour < 5 ? 'শুভ রাত্রি' : hour < 12 ? 'শুভ সকাল' : hour < 16 ? 'শুভ দুপুর' : hour < 18 ? 'শুভ বিকাল' : 'শুভ সন্ধ্যা';
  const [showAllServices, setShowAllServices] = useState(false);
  const firstName = !isGuestMode && currentUser ? currentUser.name.split(' ')[0] : 'অতিথি';
  const lastMsg = chatMessages[chatMessages.length - 1];

  const MONTH_SHORT = ['জানু', 'ফেব্রু', 'মার্চ', 'এপ্রিল', 'মে', 'জুন', 'জুলাই', 'আগস্ট', 'সেপ্টে', 'অক্টো', 'নভে', 'ডিসে'];

  // দ্রুত সেবা (primary six, same order as the Emerald Trust design)
  const services: { id: string; title: string; meta: string; icon: React.ComponentType<{ className?: string }>; action: () => void }[] = [
    { id: 'members', title: 'সদস্য তালিকা', meta: `${toBengaliNumerals(users.length)} জন সদস্য`, icon: Users, action: () => setActiveTab('members') },
    { id: 'savings', title: 'জমার হিসাব', meta: 'মাসিক লেজার', icon: Receipt, action: () => setActiveTab('savings') },
    { id: 'analytics', title: 'রিপোর্ট ও চার্ট', meta: 'বিস্তারিত বিশ্লেষণ', icon: BarChart3, action: () => setActiveTab('analytics') },
    { id: 'bank', title: 'ব্যাংক তথ্য', meta: 'নিরাপদ তথ্য', icon: Landmark, action: () => setActiveTab('bank') },
    { id: 'rules', title: 'গঠনতন্ত্র', meta: 'নীতি ও বিধি', icon: ShieldCheck, action: () => setActiveTab('rules') },
    { id: 'all', title: 'সব সেবা', meta: showAllServices ? 'সংক্ষিপ্ত করুন' : `আরো ${toBengaliNumerals(11)}টি`, icon: LayoutGrid, action: () => setShowAllServices((v) => !v) },
  ];

  const moreServices: { id: string; title: string; meta: string; icon: React.ComponentType<{ className?: string }>; show?: boolean }[] = [
    { id: 'receipts', title: 'ই-রসিদ ও স্টেটমেন্ট', meta: receipts[0]?.receiptNumber || 'ডিজিটাল রসিদ', icon: Receipt },
    { id: 'chat', title: 'কমিউনিটি চ্যাট', meta: 'গ্রুপ ও ইনবক্স', icon: MessageSquare },
    { id: 'notices', title: 'নোটিশ বোর্ড', meta: `${toBengaliNumerals(notices.length)} টি নোটিশ`, icon: Bell },
    { id: 'executive', title: 'কার্যনির্বাহী পর্ষদ', meta: 'পদবি ও দায়িত্ব', icon: Award },
    { id: 'complaints', title: 'অভিযোগ সেল', meta: `${toBengaliNumerals(complaints.length)} টি দাখিল`, icon: HelpCircle },
    { id: 'features', title: 'ফিচার ভোট', meta: 'প্রস্তাবনা ও ভোট', icon: Lightbulb },
    { id: 'sheets', title: 'গুগল শীট', meta: 'লাইভ ক্লাউড সিঙ্ক', icon: FileSpreadsheet },
    { id: 'about-us', title: 'আমাদের সম্পর্কে', meta: 'ফাউন্ডেশন পরিচিতি', icon: BookOpen },
    { id: 'profile', title: 'প্রোফাইল ও সেটিংস', meta: 'অ্যাকাউন্ট', icon: Users },
    { id: 'moderator', title: 'মডারেটর প্যানেল', meta: '২/৩ সিলিং ভোট', icon: ShieldCheck, show: isModeratorOrAppMod },
  ];

  const card = 'rounded-[22px] bg-slate-900 border border-slate-800';
  const chip = 'w-10 h-10 shrink-0 rounded-xl bg-emerald-500/15 text-emerald-400 flex items-center justify-center';

  return (
    <div className="space-y-4 animate-rise">
      {/* Greeting */}
      <div className="flex items-end justify-between gap-3 px-1">
        <div className="min-w-0">
          <p className="text-[12px] font-medium text-slate-400">
            {greeting} · {date.weekday}, {date.formatted}
          </p>
          <h2 className="text-[22px] sm:text-2xl font-bold text-ink leading-tight truncate">{firstName}</h2>
        </div>
        <button
          onClick={() => setActiveTab('about-us')}
          className="hidden sm:flex items-center gap-1.5 text-xs font-bold text-emerald-400 hover:text-emerald-300 cursor-pointer"
        >
          <Landmark className="w-4 h-4" />
          আমাদের সম্পর্কে
        </button>
      </div>

      {/* Overdue reminder for the member */}
      {isCurrentUserReminded && (
        <div className="relative overflow-hidden rounded-[22px] border border-rose-500/30 bg-rose-500/10 p-4 flex flex-col sm:flex-row sm:items-center gap-3.5">
          <button
            onClick={() => setIsAlertDismissed(true)}
            aria-label="নোটিশ বন্ধ করুন"
            className="absolute right-2.5 top-2.5 p-1.5 rounded-lg text-rose-400 hover:bg-rose-500/20 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
          <div className="flex items-center gap-3 pr-8">
            <div className="w-11 h-11 rounded-xl bg-rose-500/20 text-rose-400 flex items-center justify-center shrink-0">
              <AlertCircle className="w-5 h-5" />
            </div>
            <div className="min-w-0">
              <span className="text-[11px] font-bold px-2 py-0.5 rounded-md bg-rose-500/20 text-rose-400 border border-rose-500/30">
                জরুরি বকেয়া নোটিশ
              </span>
              <p className="text-ink font-bold text-sm mt-1 leading-snug">
                "আপনি এই মাসের টাকা এখনো জমা দেননি। যথা সময়ে টাকা জমা করার জন্য অনুরোধ করা হলো।"
              </p>
              <p className="text-[11px] text-rose-400 font-medium mt-0.5">
                নির্ধারিত জমা: ৳{toBengaliNumerals(config.defaultMonthlyAmount || 1500)} • শেষ তারিখ: প্রতি মাসের{' '}
                {toBengaliNumerals(config.monthlyDueDay || 10)} তারিখ
              </p>
            </div>
          </div>
          <button
            onClick={onOpenNewSavingsModal}
            className="sm:ml-auto bg-rose-600 text-white min-h-11 px-5 rounded-xl font-bold text-xs flex items-center justify-center gap-2 cursor-pointer shrink-0 active:scale-95 transition-transform"
          >
            <PlusCircle className="w-4 h-4" />
            এখনই টাকা জমা দিন
          </button>
        </div>
      )}

      <div className="grid lg:grid-cols-12 gap-4">
        {/* ------------------------ MAIN COLUMN ------------------------ */}
        <div className="lg:col-span-7 xl:col-span-8 space-y-4 min-w-0">
          {/* Balance card */}
          <section className="relative overflow-hidden rounded-[22px] bg-hero text-white p-4 sm:p-5 shadow-[0_14px_30px_-12px_rgba(7,80,68,0.55)]">
            <div className="pointer-events-none absolute -top-20 -right-14 h-44 w-44 rounded-full border-[34px] border-white/[0.06]" />
            <div className="relative flex items-center justify-between gap-3 text-[12px]">
              <span className="font-medium text-white/85">
                {showNet ? 'প্রকৃত অবশিষ্ট সঞ্চয় (খরচ বাদে)' : 'মোট সঞ্চয়'}
              </span>
              <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-white/15 text-[11px] font-bold">
                <ShieldCheck className="w-3.5 h-3.5" /> সুরক্ষিত
              </span>
            </div>
            <h3 className="relative mt-1 text-[32px] sm:text-[40px] font-bold tracking-tight leading-tight">
              {formatCurrencyBengali(heroValue)}
            </h3>
            <div className="relative flex items-center justify-between gap-2 text-[12px] text-white/75 pb-3 border-b border-white/15">
              <span>
                এই মাসে <b className="text-white">+ {formatCurrencyBengali(currentMonthTotalAmount)}</b>
              </span>
              <span
                className="inline-flex items-center gap-1 font-bold text-white"
                title="গত মাসের তুলনায় প্রবৃদ্ধি"
              >
                {growthRate.isPositive ? <TrendingUp className="w-3.5 h-3.5" /> : <TrendingDown className="w-3.5 h-3.5" />}
                {toBengaliNumerals(growthRate.formatted)}
              </span>
            </div>
            <div className="relative grid grid-cols-2 gap-2.5 pt-3 text-[11px]">
              <div className="rounded-xl bg-white/10 px-3 py-2 min-w-0">
                <p className="text-white/70 truncate">{showNet ? 'গ্রস জমা' : 'খরচ বাদে'}</p>
                <p className="text-[14px] font-bold truncate">{formatCurrencyBengali(otherValue)}</p>
              </div>
              <div className="rounded-xl bg-white/10 px-3 py-2 min-w-0">
                <p className="text-white/70 truncate">মোট খরচ</p>
                <p className="text-[14px] font-bold truncate">{formatCurrencyBengali(totalExpenses)}</p>
              </div>
            </div>
            <div className="relative grid grid-cols-2 gap-2 pt-3">
              <button
                onClick={onOpenNewSavingsModal}
                className="min-h-11 flex items-center justify-center gap-1.5 rounded-xl bg-white text-[#075044] text-[13px] font-bold cursor-pointer active:scale-[0.98] transition-transform"
              >
                <Plus className="w-4 h-4" /> জমা দিন
              </button>
              <button
                onClick={() => setActiveTab('receipts')}
                className="min-h-11 flex items-center justify-center gap-1.5 rounded-xl bg-white/15 border border-white/25 text-white text-[13px] font-bold cursor-pointer active:scale-[0.98] transition-transform"
              >
                <Receipt className="w-4 h-4" /> স্টেটমেন্ট
              </button>
            </div>
          </section>

          {/* দ্রুত সেবা */}
          <section aria-label="দ্রুত সেবা">
            <div className="flex items-center justify-between px-1 mb-2">
              <h3 className="text-[15px] font-bold text-ink">দ্রুত সেবা</h3>
              <button
                onClick={() => setShowAllServices((v) => !v)}
                className="inline-flex items-center gap-1 text-[12px] font-bold text-emerald-400 cursor-pointer"
              >
                {showAllServices ? 'সংক্ষিপ্ত' : 'সব দেখুন'} <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
            <div className="grid grid-cols-3 gap-2.5">
              {services.map((sv) => {
                const Icon = sv.icon;
                return (
                  <button
                    key={sv.id}
                    onClick={sv.action}
                    className={`${card} p-3 text-left min-w-0 hover:border-emerald-500/40 active:scale-[0.97] transition-all cursor-pointer`}
                  >
                    <span className="w-9 h-9 rounded-xl bg-emerald-500/15 text-emerald-400 flex items-center justify-center mb-2">
                      <Icon className="w-[18px] h-[18px]" />
                    </span>
                    <span className="block text-[12px] font-bold text-ink truncate">{sv.title}</span>
                    <span className="block text-[10px] text-slate-400 truncate mt-0.5">{sv.meta}</span>
                  </button>
                );
              })}
            </div>
            {showAllServices && (
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 mt-2.5">
                {moreServices
                  .filter((e) => e.show !== false)
                  .map((e) => {
                    const Icon = e.icon;
                    return (
                      <button
                        key={e.id}
                        onClick={() => setActiveTab(e.id)}
                        className={`${card} p-3 flex items-center gap-2.5 text-left min-w-0 hover:border-emerald-500/40 transition-colors cursor-pointer`}
                      >
                        <span className="w-9 h-9 shrink-0 rounded-xl bg-emerald-500/15 text-emerald-400 flex items-center justify-center">
                          <Icon className="w-[18px] h-[18px]" />
                        </span>
                        <span className="min-w-0 flex-1">
                          <span className="block text-[12px] font-bold text-ink truncate">{e.title}</span>
                          <span className="block text-[10px] text-slate-400 truncate">{e.meta}</span>
                        </span>
                      </button>
                    );
                  })}
              </div>
            )}
          </section>

          {/* সঞ্চয়ের অগ্রগতি */}
          <section aria-label="সঞ্চয়ের অগ্রগতি">
            <div className="flex items-center justify-between px-1 mb-2">
              <h3 className="text-[15px] font-bold text-ink">সঞ্চয়ের অগ্রগতি</h3>
              <span className="text-[11px] text-slate-400">গত {toBengaliNumerals(chartMonths.length || 6)} মাস</span>
            </div>
            <div className={`${card} p-4`}>
              <div className="flex items-center justify-between">
                <strong className="text-[17px] font-bold text-ink">{formatCurrencyBengali(financialTotals.totalApproved)}</strong>
                <span className="text-[11px] font-bold px-2 py-1 rounded-lg bg-emerald-500/15 text-emerald-400">
                  {growthRate.isPositive ? '+' : ''}
                  {toBengaliNumerals(growthRate.formatted)}
                </span>
              </div>
              <div className="h-24 flex items-end gap-3 px-1 pt-3 mt-2 border-b border-slate-800">
                {chartMonths.length === 0 && <p className="text-xs text-slate-500 w-full text-center pb-6">এখনও কোনো মাসিক তথ্য নেই</p>}
                {chartMonths.map(([key, value], i) => (
                  <div key={key} className="flex-1 h-full flex items-end justify-center" title={`${monthLabel(key)}: ${formatCurrencyBengali(value)}`}>
                    <div
                      className={`w-full max-w-[44px] rounded-t-md ${i === chartMonths.length - 1 ? 'bg-emerald-600' : 'bg-emerald-500/30'}`}
                      style={{ height: `${Math.max(8, (value / chartMax) * 100)}%` }}
                    />
                  </div>
                ))}
              </div>
              <div className="flex justify-between gap-2 px-1 pt-1.5 text-[10px] text-slate-400">
                {chartMonths.map(([key], i) => (
                  <span key={key} className={`flex-1 text-center truncate ${i === chartMonths.length - 1 ? 'font-bold text-emerald-400' : ''}`}>
                    {MONTH_SHORT[Number(key.split('-')[1]) - 1] ?? key}
                  </span>
                ))}
              </div>
            </div>
          </section>
        </div>

        {/* ------------------------ SIDE COLUMN ------------------------ */}
        <div className="lg:col-span-5 xl:col-span-4 space-y-4 min-w-0">
          {/* Pinned notice */}
          {pinnedNotice && (
            <section className={`${card} p-3.5`}>
              <div className="flex items-center justify-between mb-1.5">
                <span className="inline-flex items-center gap-1.5 text-[12px] font-bold text-emerald-400">
                  <Bell className="w-4 h-4" /> নোটিশ বোর্ড
                </span>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-emerald-500/15 text-emerald-400">নতুন</span>
              </div>
              <h3 className="font-bold text-ink text-[14px] leading-snug">{pinnedNotice.title}</h3>
              <p className="text-xs text-slate-400 line-clamp-2 leading-relaxed mt-1">{pinnedNotice.content}</p>
              <div className="flex items-center justify-between mt-2.5 text-[11px] text-slate-500">
                <span className="truncate">{pinnedNotice.authorName}</span>
                <button
                  onClick={() => setActiveTab('notices')}
                  className="inline-flex items-center gap-1 text-xs font-bold text-emerald-400 hover:text-emerald-300 cursor-pointer"
                >
                  বিস্তারিত <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </section>
          )}

          {/* KPI row */}
          <section className="grid grid-cols-2 gap-2.5" aria-label="মূল সূচক">
            <button onClick={() => setActiveTab('members')} className={`${card} p-3 text-left flex items-center gap-2.5 hover:border-emerald-500/40 transition-colors cursor-pointer`}>
              <span className={chip}><Users className="w-[18px] h-[18px]" /></span>
              <span className="min-w-0 block">
                <span className="block text-[11px] text-slate-400 truncate">সক্রিয় সদস্য</span>
                <span className="block text-lg font-bold text-ink leading-tight">{toBengaliNumerals(approvedMembers.length)} জন</span>
              </span>
            </button>
            <button onClick={() => setActiveTab('savings')} className={`${card} p-3 text-left flex items-center gap-2.5 hover:border-emerald-500/40 transition-colors cursor-pointer`}>
              <span className={chip}><Wallet className="w-[18px] h-[18px]" /></span>
              <span className="min-w-0 block">
                <span className="block text-[11px] text-slate-400 truncate">জমাদানকারী ({monthLabel(selectedMonth).split(' ')[0]})</span>
                <span className="block text-lg font-bold text-ink leading-tight">{toBengaliNumerals(monthDeposits.length)} জন</span>
              </span>
            </button>
            <button onClick={() => setActiveTab('moderator')} className={`${card} p-3 text-left flex items-center gap-2.5 hover:border-rose-500/40 transition-colors cursor-pointer`}>
              <span className="w-10 h-10 shrink-0 rounded-xl bg-rose-500/15 text-rose-400 flex items-center justify-center"><AlertCircle className="w-[18px] h-[18px]" /></span>
              <span className="min-w-0 block">
                <span className="block text-[11px] text-slate-400 truncate">বকেয়া সদস্য</span>
                <span className="block text-lg font-bold text-ink leading-tight">{toBengaliNumerals(overdueMembers.length)} জন</span>
              </span>
            </button>
            <button onClick={() => setActiveTab('rules')} className={`${card} p-3 text-left flex items-center gap-2.5 hover:border-emerald-500/40 transition-colors cursor-pointer`}>
              <span className="w-10 h-10 shrink-0 rounded-xl bg-amber-500/15 text-amber-400 flex items-center justify-center"><ShieldCheck className="w-[18px] h-[18px]" /></span>
              <span className="min-w-0 block">
                <span className="block text-[11px] text-slate-400 truncate">২/৩ মডারেটর অনুমোদন</span>
                <span className="text-sm font-bold text-emerald-400 leading-tight flex items-center gap-1">
                  সুরক্ষিত <CheckCircle2 className="w-4 h-4" />
                </span>
              </span>
            </button>
          </section>

          {/* Current month collection */}
          <section className={`${card} p-4 space-y-4`}>
            <div className="flex items-center gap-4">
              <Ring pct={paidPct} />
              <div className="min-w-0 flex-1">
                <p className="text-[11px] text-slate-400">{monthLabel(selectedMonth)} এর আদায়</p>
                <p className="text-[22px] font-bold text-ink leading-tight">{formatCurrencyBengali(currentMonthTotalAmount)}</p>
                <p className="text-[11px] text-slate-400 mt-0.5">
                  <strong className="text-emerald-400">{toBengaliNumerals(monthDeposits.length)}</strong> /{' '}
                  {toBengaliNumerals(approvedMembers.length)} জন জমা দিয়েছেন
                </p>
                <button
                  onClick={() => setActiveTab('savings')}
                  className="mt-1 inline-flex items-center gap-0.5 text-xs font-bold text-emerald-400 hover:text-emerald-300 cursor-pointer"
                >
                  সম্পূর্ণ সঞ্চয় খাতা <ChevronRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            <div>
              <p className="text-[11px] font-bold text-slate-400 mb-2">সাম্প্রতিক লেনদেন</p>
              <div className="space-y-2">
                {monthDeposits.slice(0, 4).map((tx) => (
                  <div key={tx.id} className="flex items-center gap-2.5 min-w-0">
                    <Avatar src={users.find((u) => u.memberId === tx.memberId)?.avatarUrl} name={tx.memberName} size="sm" />
                    <div className="min-w-0 flex-1">
                      <h4 className="font-bold text-[13px] text-ink truncate">{tx.memberName}</h4>
                      <span className="text-[10px] text-slate-400 block truncate">
                        {tx.memberId} · {tx.paymentMethod}
                      </span>
                    </div>
                    <span className="font-bold text-[13px] text-emerald-400 shrink-0">+{formatCurrencyBengali(tx.amount)}</span>
                  </div>
                ))}
                {monthDeposits.length === 0 && (
                  <div className="w-full py-3 text-center text-xs text-slate-500">
                    চলতি মাসে এখনও কোনো সঞ্চয় জমা অনুমোদিত হয়নি।
                  </div>
                )}
              </div>
            </div>

            {overdueMembers.length > 0 && (
              <div>
                <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/25 flex items-center justify-between gap-2 text-xs">
                  <div className="flex items-center gap-2 min-w-0">
                    <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
                    <span className="text-slate-200 font-medium">
                      বকেয়া: <strong className="text-rose-400 font-bold">{toBengaliNumerals(overdueMembers.length)} জন</strong> এখনো জমা দেননি
                    </span>
                  </div>
                  <button
                    onClick={() => setIsOverdueExpanded(!isOverdueExpanded)}
                    className="min-h-9 px-3 rounded-lg bg-rose-500/20 hover:bg-rose-500/30 text-rose-400 text-[11px] font-bold shrink-0 cursor-pointer"
                  >
                    {isOverdueExpanded ? 'সংক্ষিপ্ত করুন' : 'তালিকা দেখুন'}
                  </button>
                </div>

                {isOverdueExpanded && (
                  <div className="mt-2 space-y-1.5 p-2 rounded-xl bg-slate-950/60 border border-slate-800 max-h-56 overflow-y-auto">
                    {overdueMembers.map((m) => {
                      const isReminded = overdueReminders.includes(m.memberId);
                      return (
                        <div key={m.id} className="flex items-center justify-between gap-2 p-2 rounded-lg bg-slate-900 text-xs">
                          <div className="flex items-center gap-2 min-w-0">
                            <Avatar src={m.avatarUrl} name={m.name} size="xs" />
                            <span className="text-ink font-medium truncate">{m.name}</span>
                            <span className="text-slate-400 font-mono text-[10px] shrink-0">({m.memberId})</span>
                          </div>
                          <button
                            onClick={() => sendOverdueReminder(m.memberId)}
                            disabled={isReminded}
                            className={`min-h-8 px-2.5 rounded-lg text-[10px] font-bold flex items-center gap-1 shrink-0 cursor-pointer ${
                              isReminded
                                ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30'
                                : 'bg-rose-600 text-white'
                            }`}
                          >
                            <Send className="w-3 h-3" />
                            {isReminded ? 'পাঠানো হয়েছে' : 'তাগিদ পাঠান'}
                          </button>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            )}
          </section>

          {/* Last chat message teaser */}
          {lastMsg && (
            <button
              onClick={() => setActiveTab('chat')}
              className={`${card} w-full p-3 flex items-center gap-3 text-left cursor-pointer hover:border-emerald-500/40 transition-colors`}
            >
              <span className={chip}>
                <MessageSquare className="w-[18px] h-[18px]" />
              </span>
              <span className="min-w-0 flex-1">
                <span className="block text-[11px] font-bold text-emerald-400">সর্বশেষ বার্তা • {lastMsg.senderName}</span>
                <span className="block text-xs text-slate-300 truncate">{lastMsg.text}</span>
              </span>
              <span className="text-[10px] text-slate-500 shrink-0 hidden sm:block">
                {lastMsg.timestamp ? formatDateTimeBengali(lastMsg.timestamp) : ''}
              </span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
