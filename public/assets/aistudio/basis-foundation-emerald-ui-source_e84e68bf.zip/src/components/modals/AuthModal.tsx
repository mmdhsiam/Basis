import React, { useState, useEffect } from 'react';
import {
  X,
  LogIn,
  UserPlus,
  ShieldAlert,
  ShieldCheck,
  CheckCircle2,
  Lock,
  User,
  Eye,
  EyeOff,
  Loader2,
} from 'lucide-react';
import { signInWithEmailAndPassword } from 'firebase/auth';
import { useApp } from '../../context/AppContext';
import { extractDirectImageUrl } from '../../utils/imageUtils';
import { getFirebaseAuth } from '../../utils/firebase';
import { fetchUsersFromFirestore, syncUserToFirestore } from '../../utils/firebaseSync';
import { UserProfile } from '../../types';
import { Avatar } from '../common/Avatar';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const AUTH_SECURITY_STORAGE_KEY = 'basis_auth_security_v1';
const MAX_FAILED_ATTEMPTS = 5;
const SUBMIT_COOLDOWN_MS = 1500;

interface AuthSecurityState {
  failedAttempts: number;
  lockUntil: number;
  lockoutTier: number;
  lastAttemptAt: number;
}

function getSavedSecurityState(): AuthSecurityState {
  try {
    const raw = localStorage.getItem(AUTH_SECURITY_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      return {
        failedAttempts: Number(parsed.failedAttempts) || 0,
        lockUntil: Number(parsed.lockUntil) || 0,
        lockoutTier: Number(parsed.lockoutTier) || 0,
        lastAttemptAt: Number(parsed.lastAttemptAt) || 0,
      };
    }
  } catch {}
  return { failedAttempts: 0, lockUntil: 0, lockoutTier: 0, lastAttemptAt: 0 };
}

function saveSecurityState(state: AuthSecurityState) {
  try {
    localStorage.setItem(AUTH_SECURITY_STORAGE_KEY, JSON.stringify(state));
  } catch {}
}

function toAsciiDigits(input: string): string {
  return input.replace(/[০-৯]/g, (d) => String('০১২৩৪৫৬৭৮৯'.indexOf(d)));
}

function extractPhoneLast10(raw: string): string {
  const digits = toAsciiDigits(raw).replace(/\D/g, '');
  if (digits.length >= 10) {
    return digits.slice(-10);
  }
  return '';
}

function containsMaliciousInput(str: string): boolean {
  if (str.length > 140) return true;
  return /<script|javascript:|onerror=|onload=|\$where|\$ne/i.test(str);
}

function matchUserByIdentifier(list: UserProfile[], rawIdentifier: string): UserProfile | undefined {
  const normalized = toAsciiDigits(rawIdentifier).trim().toLowerCase();
  if (!normalized) return undefined;

  const compactMemberId = normalized.replace(/\s+/g, '');
  const queryPhone10 = extractPhoneLast10(rawIdentifier);

  return list.find((u) => {
    if (!u || u.id === '__guest__') return false;
    const uEmail = (u.email || '').trim().toLowerCase();
    const uMemberId = toAsciiDigits(u.memberId || '').trim().toLowerCase();
    const uMemberIdCompact = uMemberId.replace(/[-_\s]/g, '');
    const queryMemberCompact = compactMemberId.replace(/[-_\s]/g, '');
    const uPhone10 = extractPhoneLast10(u.phone || '');

    if (uEmail && uEmail === normalized) return true;
    if (uMemberId && (uMemberId === compactMemberId || uMemberIdCompact === queryMemberCompact)) return true;
    if (u.id.toLowerCase() === normalized) return true;
    if (queryPhone10.length === 10 && uPhone10.length === 10 && queryPhone10 === uPhone10) return true;
    return false;
  });
}

export const AuthModal: React.FC<AuthModalProps> = ({ isOpen, onClose }) => {
  const { users, setCurrentUser, registerNewAccount, triggerSuccess } = useApp();

  const [mode, setMode] = useState<'LOGIN' | 'REGISTER'>('LOGIN');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Bot honeypot field (Anti-DDoS / Automated Bot Trap)
  const [honeypot, setHoneypot] = useState('');

  // Security lockout countdown
  const [lockSecondsRemaining, setLockSecondsRemaining] = useState(0);

  // Eye toggle state for password visibility
  const [showLoginPassword, setShowLoginPassword] = useState(false);
  const [showRegPassword, setShowRegPassword] = useState(false);
  const [showRegConfirmPassword, setShowRegConfirmPassword] = useState(false);

  // Login form state
  const [loginIdentifier, setLoginIdentifier] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [loginError, setLoginError] = useState<string | null>(null);

  // Register form state
  const [regName, setRegName] = useState('');
  const [regPhoneDigits, setRegPhoneDigits] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regPassword, setRegPassword] = useState('');
  const [regConfirmPassword, setRegConfirmPassword] = useState('');
  const [regGender, setRegGender] = useState<'MALE' | 'FEMALE' | 'OTHER'>('MALE');
  const [regAddress, setRegAddress] = useState('');
  const [regNomineeName, setRegNomineeName] = useState('');
  const [regNomineePhone, setRegNomineePhone] = useState('');
  const [regNomineeRelation, setRegNomineeRelation] = useState('পিতা');
  const [regAvatarUrl, setRegAvatarUrl] = useState('');
  const [regError, setRegError] = useState<string | null>(null);
  const [regSuccess, setRegSuccess] = useState<string | null>(null);

  useEffect(() => {
    if (!isOpen) return;
    const updateCountdown = () => {
      const sec = getSavedSecurityState();
      const diff = Math.ceil((sec.lockUntil - Date.now()) / 1000);
      setLockSecondsRemaining(diff > 0 ? diff : 0);
    };
    updateCountdown();
    const timer = setInterval(updateCountdown, 1000);
    return () => clearInterval(timer);
  }, [isOpen]);

  const handlePhoneInputChange = (raw: string) => {
    const en = toAsciiDigits(raw);
    let clean = en.replace(/\D/g, '');
    if (clean.startsWith('880')) clean = clean.slice(3);
    if (clean.startsWith('0')) clean = clean.slice(1);
    if (clean.length > 10) clean = clean.slice(0, 10);
    setRegPhoneDigits(clean);
  };

  if (!isOpen) return null;

  const recordFailedAttempt = () => {
    const current = getSavedSecurityState();
    const nextFailed = current.failedAttempts + 1;
    if (nextFailed >= MAX_FAILED_ATTEMPTS) {
      const nextTier = Math.min(current.lockoutTier + 1, 3);
      const lockDurationSec = nextTier === 1 ? 60 : nextTier === 2 ? 180 : 600;
      const lockUntil = Date.now() + lockDurationSec * 1000;
      saveSecurityState({
        failedAttempts: 0,
        lockUntil,
        lockoutTier: nextTier,
        lastAttemptAt: Date.now(),
      });
      setLockSecondsRemaining(lockDurationSec);
      setLoginError(
        `একাধিকবার ভুল চেষ্টার কারণে ব্রুট-ফোর্স ও অ্যান্টি-ডিডস নিরাপত্তা লক সক্রিয় হয়েছে। অনুগ্রহ করে ${lockDurationSec} সেকেন্ড পর আবার চেষ্টা করুন।`
      );
    } else {
      saveSecurityState({
        ...current,
        failedAttempts: nextFailed,
        lastAttemptAt: Date.now(),
      });
    }
  };

  const resetSecurityLock = () => {
    saveSecurityState({ failedAttempts: 0, lockUntil: 0, lockoutTier: 0, lastAttemptAt: Date.now() });
    setLockSecondsRemaining(0);
  };

  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError(null);

    // 1. Bot Honeypot Protection
    if (honeypot.trim() !== '') {
      setLoginError('নিরাপত্তা যাচাইকরণ ব্যর্থ হয়েছে।');
      return;
    }

    // 2. Active Lockout Check
    const sec = getSavedSecurityState();
    const now = Date.now();
    if (sec.lockUntil > now) {
      const waitSec = Math.ceil((sec.lockUntil - now) / 1000);
      setLockSecondsRemaining(waitSec);
      setLoginError(`নিরাপত্তা লক সক্রিয় রয়েছে। অনুগ্রহ করে আরও ${waitSec} সেকেন্ড অপেক্ষা করুন।`);
      return;
    }

    // 3. Anti-Flood Request Throttle
    if (now - sec.lastAttemptAt < SUBMIT_COOLDOWN_MS) {
      setLoginError('খুব দ্রুত রিকোয়েস্ট পাঠানো হচ্ছে! অনুগ্রহ করে ২ সেকেন্ড অপেক্ষা করে চেষ্টা করুন।');
      return;
    }
    saveSecurityState({ ...sec, lastAttemptAt: now });

    // 4. Input Sanitization Check
    if (containsMaliciousInput(loginIdentifier) || containsMaliciousInput(loginPassword)) {
      recordFailedAttempt();
      setLoginError('অবৈধ ইনপুট শনাক্ত হয়েছে। সঠিক ফোন নম্বর, ইমেইল বা সদস্য আইডি লিখুন।');
      return;
    }

    const cleanIdentifier = loginIdentifier.trim();
    const cleanPass = toAsciiDigits(loginPassword.trim());
    if (!cleanIdentifier || !cleanPass) {
      setLoginError('অনুগ্রহ করে আপনার ফোন/আইডি/ইমেইল এবং পাসওয়ার্ড উভয়ই লিখুন।');
      return;
    }

    setIsSubmitting(true);
    try {
      // Query live Firestore users first when online so newly registered/updated Firebase users never get "Info Error"
      let candidatePool: UserProfile[] = [...users];
      if (typeof navigator === 'undefined' || navigator.onLine) {
        const remoteUsers = await fetchUsersFromFirestore();
        if (remoteUsers.length > 0) {
          const mergedMap = new Map<string, UserProfile>();
          users.forEach((u) => {
            if (u.id !== '__guest__') mergedMap.set(u.id, u);
          });
          remoteUsers.forEach((u) => {
            if (u.id !== '__guest__') mergedMap.set(u.id, u);
          });
          candidatePool = Array.from(mergedMap.values());
        }
      }

      let matchedUser = matchUserByIdentifier(candidatePool, cleanIdentifier);

      // Optional Firebase Auth fallback for accounts created directly in Firebase Auth Console
      let verifiedViaFirebaseAuth = false;
      if (cleanIdentifier.includes('@') && (typeof navigator === 'undefined' || navigator.onLine)) {
        const auth = getFirebaseAuth();
        if (auth) {
          try {
            const cred = await signInWithEmailAndPassword(auth, cleanIdentifier, loginPassword.trim());
            if (cred.user) {
              verifiedViaFirebaseAuth = true;
              if (!matchedUser) {
                const autoProfile: UserProfile = {
                  id: cred.user.uid,
                  memberId: `BF-${String(candidatePool.length + 1).padStart(3, '0')}`,
                  name: cred.user.displayName || cleanIdentifier.split('@')[0],
                  email: cred.user.email || cleanIdentifier,
                  phone: cred.user.phoneNumber || '',
                  role: 'MEMBER',
                  status: 'APPROVED',
                  joinDate: new Date().toISOString().slice(0, 10),
                  gender: 'MALE',
                  password: loginPassword.trim(),
                };
                await syncUserToFirestore(autoProfile);
                matchedUser = autoProfile;
              }
            }
          } catch {
            // Fall back to Firestore / local user record verification
          }
        }
      }

      if (!matchedUser) {
        recordFailedAttempt();
        setLoginError(
          'প্রদত্ত তথ্য অনুযায়ী কোনো সদস্য অ্যাকাউন্ট পাওয়া যায়নি। সঠিক মোবাইল নম্বর (যেমন: 01711998801), সদস্য আইডি (যেমন: BF-001) অথবা ইমেইল লিখুন।'
        );
        return;
      }

      // Verify Password
      const storedPass = toAsciiDigits(String(matchedUser.password || '123456').trim());
      const rawStoredPass = String(matchedUser.password || '123456').trim();
      const passwordValid =
        verifiedViaFirebaseAuth ||
        loginPassword.trim() === rawStoredPass ||
        cleanPass === storedPass;

      if (!passwordValid) {
        recordFailedAttempt();
        setLoginError('ভুল পাসওয়ার্ড! অনুগ্রহ করে সঠিক পাসওয়ার্ড প্রদান করুন।');
        return;
      }

      // Check account approval status
      if (matchedUser.status === 'PENDING') {
        setLoginError(
          'আপনার অ্যাকাউন্টটি নিবন্ধিত আছে কিন্তু এখনও মডারেটর প্যানেল কর্তৃক অনুমোদিত হয়নি। অনুমোদনের পর লগইন করতে পারবেন।'
        );
        return;
      }

      if (matchedUser.status === 'REJECTED' || matchedUser.status === 'SUSPENDED' || matchedUser.status === 'DISABLED') {
        setLoginError('আপনার অ্যাকাউন্টটি বর্তমানে স্থগিত বা বাতিল অবস্থায় রয়েছে। অনুগ্রহ করে মডারেটর প্যানেলের সাথে যোগাযোগ করুন।');
        return;
      }

      // Successful login
      resetSecurityLock();
      setCurrentUser(matchedUser);
      syncUserToFirestore(matchedUser);
      triggerSuccess(`স্বাগতম, ${matchedUser.name}! সফলভাবে লগইন সম্পন্ন হয়েছে।`);
      onClose();
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleRegisterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setRegError(null);
    setRegSuccess(null);

    if (honeypot.trim() !== '') {
      setRegError('নিরাপত্তা যাচাইকরণ ব্যর্থ হয়েছে।');
      return;
    }

    const sec = getSavedSecurityState();
    if (Date.now() - sec.lastAttemptAt < SUBMIT_COOLDOWN_MS) {
      setRegError('অনুগ্রহ করে কিছুক্ষণ অপেক্ষা করে পুনরায় চেষ্টা করুন।');
      return;
    }
    saveSecurityState({ ...sec, lastAttemptAt: Date.now() });

    if (!regName.trim() || regPhoneDigits.trim().length !== 10) {
      setRegError('দয়া করে পূর্ণ নাম এবং ১০ সংখ্যার সঠিক মোবাইল নম্বর লিখুন (+880 ব্যতীত ১০ সংখ্যা)।');
      return;
    }

    if (containsMaliciousInput(regName) || containsMaliciousInput(regEmail)) {
      setRegError('অবৈধ অক্ষর শনাক্ত হয়েছে। অনুগ্রহ করে সঠিক তথ্য লিখুন।');
      return;
    }

    if (regPassword.length < 6) {
      setRegError('পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে।');
      return;
    }

    if (regPassword !== regConfirmPassword) {
      setRegError('দুইটি পাসওয়ার্ড মেলেনি! দয়া করে সঠিকভাবে মিলিয়ে লিখুন।');
      return;
    }

    const existingDuplicate = matchUserByIdentifier(users, `+880${regPhoneDigits.trim()}`);
    if (existingDuplicate) {
      setRegError('এই মোবাইল নম্বর দিয়ে ইতিমধ্যে একটি অ্যাকাউন্ট নিবন্ধিত রয়েছে! অনুগ্রহ করে লগইন করুন।');
      return;
    }

    const cleanAvatar = extractDirectImageUrl(regAvatarUrl);
    const finalPhone = `+880${regPhoneDigits.trim()}`;

    registerNewAccount({
      name: regName.trim(),
      phone: finalPhone,
      email: regEmail.trim() || `${regPhoneDigits.trim()}@basis.foundation`,
      gender: regGender,
      address: regAddress.trim() || undefined,
      nomineeName: regNomineeName.trim() || undefined,
      nomineePhone: regNomineePhone.trim() || undefined,
      nomineeRelation: regNomineeRelation || undefined,
      avatarUrl: cleanAvatar || undefined,
      role: 'MEMBER',
      joinDate: new Date().toISOString().split('T')[0],
      memberId: `BF-${String(users.length + 1).padStart(3, '0')}`,
      password: regPassword,
    });

    setRegSuccess(
      'আপনার নতুন অ্যাকাউন্ট সফলভাবে তৈরি ও ফায়ারবেজে সংরক্ষিত হয়েছে! অ্যাকাউন্টটি বর্তমানে মডারেটর প্যানেলে অনুমোদনের অপেক্ষায় রয়েছে।'
    );
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950 animate-in fade-in duration-200">
      <div className="mx-auto max-w-md min-h-full flex flex-col">
        {/* Hero (Emerald Trust login) */}
        <div className="relative overflow-hidden bg-hero text-white px-6 pt-10 pb-16">
          <div className="pointer-events-none absolute -top-16 -right-12 h-48 w-48 rounded-full border-[36px] border-white/[0.06]" />
          <div className="pointer-events-none absolute top-24 -left-16 h-36 w-36 rounded-full border-[28px] border-white/[0.05]" />
          <button
            onClick={onClose}
            aria-label="বন্ধ করুন"
            className="absolute top-4 right-4 w-10 h-10 rounded-xl bg-white/15 hover:bg-white/25 text-white flex items-center justify-center transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
          <div className="relative w-14 h-14 rounded-2xl bg-[#d5a23b] p-[3px] flex items-center justify-center shadow-lg">
            <img
              src="/logo.svg"
              alt="লোগো"
              className="w-full h-full object-contain rounded-[14px] bg-white"
              onError={(e) => {
                (e.currentTarget as HTMLImageElement).style.display = 'none';
              }}
            />
          </div>
          <h2 className="relative mt-4 text-[30px] font-bold leading-tight">বেসিস ফাউন্ডেশন</h2>
          <p className="relative mt-1 text-sm text-white/80">সততা, স্বচ্ছতা ও যৌথ সঞ্চয়ে সমৃদ্ধ ভবিষ্যৎ</p>
        </div>

        <div className="mx-4 -mt-9 bg-slate-900 border border-slate-800 rounded-[28px] p-5 shadow-[0_18px_40px_-20px_rgba(7,80,68,0.45)] space-y-4 relative">
          <div>
            <h3 className="text-[22px] font-bold text-ink leading-tight">
              {mode === 'LOGIN' ? 'লগইন করুন' : 'নতুন অ্যাকাউন্ট খুলুন'}
            </h3>
            <p className="text-[13px] text-slate-400 mt-0.5 flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              {mode === 'LOGIN' ? 'আপনার অ্যাকাউন্টে প্রবেশ করুন' : 'নিরাপদ ফায়ারবেজ ক্লাউডে তথ্য সংরক্ষিত হবে'}
            </p>
          </div>

        {/* Tab switch buttons */}
        <div className="grid grid-cols-2 gap-1 bg-slate-950 p-1 rounded-2xl border border-slate-800 text-xs font-bold">
          <button
            type="button"
            onClick={() => {
              setMode('LOGIN');
              setLoginError(null);
            }}
            className={`min-h-10 py-2 rounded-xl transition-all cursor-pointer ${
              mode === 'LOGIN'
                ? 'bg-emerald-600 text-white shadow-md'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            লগইন (Sign In)
          </button>
          <button
            type="button"
            onClick={() => {
              setMode('REGISTER');
              setRegError(null);
              setRegSuccess(null);
            }}
            className={`min-h-10 py-2 rounded-xl transition-all cursor-pointer ${
              mode === 'REGISTER'
                ? 'bg-emerald-600 text-white shadow-md'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            নতুন অ্যাকাউন্ট খুলুন (Register)
          </button>
        </div>

        {/* Hidden Honeypot Trap against automated bot floods */}
        <input
          type="text"
          name="foundation_website_hp"
          value={honeypot}
          onChange={(e) => setHoneypot(e.target.value)}
          tabIndex={-1}
          autoComplete="off"
          aria-hidden="true"
          className="hidden"
        />

        {/* Mode 1: LOGIN */}
        {mode === 'LOGIN' && (
          <form onSubmit={handleLoginSubmit} className="space-y-3.5 text-xs">
            {(loginError || lockSecondsRemaining > 0) && (
              <div className="p-3.5 rounded-2xl bg-rose-950/70 border border-rose-600/80 text-rose-200 flex items-start gap-2.5">
                <ShieldAlert className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                <div className="leading-snug space-y-1">
                  <div>{loginError || 'অতিরিক্ত ভুল চেষ্টার কারণে লগইন সাময়িকভাবে লক করা হয়েছে।'}</div>
                  {lockSecondsRemaining > 0 && (
                    <div className="font-mono font-bold text-amber-300 text-[11px]">
                      পুনরায় চেষ্টা করা যাবে: {lockSecondsRemaining} সেকেন্ড পর
                    </div>
                  )}
                </div>
              </div>
            )}

            <div className="space-y-1">
              <label className="font-bold text-slate-200">ফোন নম্বর / সদস্য আইডি / ইমেইল:</label>
              <div className="relative">
                <User className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  maxLength={80}
                  placeholder="যেমন: 01711998801 বা BF-001 বা ইমেইল"
                  value={loginIdentifier}
                  onChange={(e) => setLoginIdentifier(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-3 min-h-12 py-2.5 text-sm text-ink focus:outline-none focus:ring-1 focus:ring-emerald-500 font-bold"
                  required
                />
              </div>
            </div>

            <div className="space-y-1">
              <label className="font-bold text-slate-200">পাসওয়ার্ড / গোপন পিন:</label>
              <div className="relative">
                <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type={showLoginPassword ? 'text' : 'password'}
                  maxLength={64}
                  placeholder="••••••••"
                  value={loginPassword}
                  onChange={(e) => setLoginPassword(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-10 min-h-12 py-2.5 text-sm text-ink focus:outline-none focus:ring-1 focus:ring-emerald-500"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowLoginPassword(!showLoginPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-ink"
                  title={showLoginPassword ? 'পাসওয়ার্ড লুকান' : 'পাসওয়ার্ড দেখুন'}
                >
                  {showLoginPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={isSubmitting || lockSecondsRemaining > 0}
              className="w-full min-h-12 px-4 rounded-2xl btn-brand disabled:opacity-50 font-bold text-sm transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              {isSubmitting ? <Loader2 className="w-4 h-4 animate-spin" /> : <LogIn className="w-4 h-4" />}
              <span>{isSubmitting ? 'যাচাই করা হচ্ছে...' : 'লগইন করুন'}</span>
            </button>
          </form>
        )}

        {/* Mode 2: REGISTER */}
        {mode === 'REGISTER' && (
          <form onSubmit={handleRegisterSubmit} className="space-y-3 text-xs">
            {regError && (
              <div className="p-3.5 rounded-2xl bg-rose-950/70 border border-rose-600/80 text-rose-200 flex items-start gap-2.5">
                <ShieldAlert className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                <div className="leading-snug">{regError}</div>
              </div>
            )}

            {regSuccess && (
              <div className="p-3.5 rounded-2xl bg-emerald-950/70 border border-emerald-600/80 text-emerald-200 flex items-start gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <div className="leading-snug">{regSuccess}</div>
              </div>
            )}

            <div className="space-y-1">
              <label className="font-bold text-slate-200">আপনার পূর্ণ নাম:</label>
              <input
                type="text"
                maxLength={80}
                placeholder="যেমন: মোঃ সাকিব আল হাসান"
                value={regName}
                onChange={(e) => setRegName(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 min-h-11 py-2 text-sm text-ink focus:outline-none focus:ring-1 focus:ring-emerald-500 font-bold"
                required
              />
            </div>

            <div className="grid grid-cols-2 gap-2.5">
              <div className="space-y-1">
                <label className="font-bold text-slate-200">মোবাইল নম্বর:</label>
                <div className="flex items-center">
                  <span className="bg-slate-800 border border-slate-700 text-emerald-400 font-mono font-bold px-2.5 py-2 rounded-l-xl text-xs select-none">
                    +880
                  </span>
                  <input
                    type="tel"
                    placeholder="1712345678"
                    value={regPhoneDigits}
                    onChange={(e) => handlePhoneInputChange(e.target.value)}
                    maxLength={11}
                    className="flex-1 bg-slate-950 border border-l-0 border-slate-800 rounded-r-xl px-3 py-2 text-xs text-ink focus:outline-none focus:ring-1 focus:ring-emerald-500 font-mono font-bold"
                    required
                  />
                </div>
                <p className="text-[10px] text-slate-400">১০ সংখ্যা লিখুন (০ ছাড়া)</p>
              </div>

              <div className="space-y-1">
                <label className="font-bold text-slate-200">লিঙ্গ (Gender):</label>
                <select
                  value={regGender}
                  onChange={(e) => setRegGender(e.target.value as any)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 min-h-11 py-2 text-sm text-ink font-bold focus:outline-none focus:ring-1 focus:ring-emerald-500"
                >
                  <option value="MALE">পুরুষ (Male)</option>
                  <option value="FEMALE">নারী (Female)</option>
                  <option value="OTHER">অন্যান্য (Other)</option>
                </select>
              </div>
            </div>

            <div className="space-y-1">
              <label className="font-bold text-slate-200">ইমেইল ঠিকানা:</label>
              <input
                type="email"
                maxLength={80}
                placeholder="youremail@example.com"
                value={regEmail}
                onChange={(e) => setRegEmail(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 min-h-11 py-2 text-sm text-ink focus:outline-none focus:ring-1 focus:ring-emerald-500"
              />
            </div>

            <div className="space-y-1.5 bg-slate-950 p-3 rounded-2xl border border-slate-800">
              <label className="font-bold text-slate-200">প্রোফাইল ছবি হোস্টেড লিংক (ImgBB / PostImages / Direct):</label>
              <div className="flex items-center gap-2.5">
                <Avatar
                  src={extractDirectImageUrl(regAvatarUrl)}
                  name={regName || 'সদস্য'}
                  size="md"
                />
                <input
                  type="text"
                  placeholder="https://i.ibb.co/... বা HTML/BBCode পেস্ট করুন"
                  value={regAvatarUrl}
                  onChange={(e) => setRegAvatarUrl(e.target.value)}
                  className="flex-1 bg-slate-900 border border-slate-800 rounded-xl px-2.5 py-1.5 text-xs text-slate-200 font-mono"
                />
              </div>
              <p className="text-[10px] text-slate-400">
                * ভিউয়ার লিংক বা HTML বা BBCode কোড দিলেও স্বয়ংক্রিয়ভাবে লাইভ প্রিভিউ লোড হবে।
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 p-3 rounded-2xl bg-slate-950 border border-slate-800">
              <div className="space-y-1">
                <label className="font-bold text-slate-200 flex items-center gap-1">
                  <Lock className="w-3.5 h-3.5 text-emerald-400" />
                  <span>পাসওয়ার্ড তৈরি করুন:</span>
                </label>
                <div className="relative">
                  <input
                    type={showRegPassword ? 'text' : 'password'}
                    maxLength={64}
                    placeholder="কমপক্ষে ৬ অক্ষর"
                    value={regPassword}
                    onChange={(e) => setRegPassword(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-xl pl-3 pr-8 py-2 text-xs text-ink focus:outline-none focus:ring-1 focus:ring-emerald-500 font-mono"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowRegPassword(!showRegPassword)}
                    className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-ink"
                  >
                    {showRegPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                  </button>
                </div>
              </div>

              <div className="space-y-1">
                <label className="font-bold text-slate-200 flex items-center gap-1">
                  <Lock className="w-3.5 h-3.5 text-emerald-400" />
                  <span>পাসওয়ার্ড পুনরায় লিখুন:</span>
                </label>
                <div className="relative">
                  <input
                    type={showRegConfirmPassword ? 'text' : 'password'}
                    maxLength={64}
                    placeholder="পুনরায় একই পাসওয়ার্ড"
                    value={regConfirmPassword}
                    onChange={(e) => setRegConfirmPassword(e.target.value)}
                    className={`w-full bg-slate-900 border rounded-xl pl-3 pr-8 py-2 text-xs text-ink focus:outline-none font-mono ${
                      regConfirmPassword.length > 0
                        ? regPassword === regConfirmPassword
                          ? 'border-emerald-500/80 ring-1 ring-emerald-500/50'
                          : 'border-rose-500/80 ring-1 ring-rose-500/50'
                        : 'border-slate-800 focus:ring-1 focus:ring-emerald-500'
                    }`}
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowRegConfirmPassword(!showRegConfirmPassword)}
                    className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-ink"
                  >
                    {showRegConfirmPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                  </button>
                </div>
              </div>

              {regConfirmPassword.length > 0 && (
                <div className="col-span-full text-[11px] font-bold pt-0.5">
                  {regPassword === regConfirmPassword ? (
                    <span className="text-emerald-400 flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>পাসওয়ার্ড দুটি হুবহু মিলেছে!</span>
                    </span>
                  ) : (
                    <span className="text-rose-400 flex items-center gap-1">
                      <ShieldAlert className="w-3.5 h-3.5" />
                      <span>পাসওয়ার্ড দুটি মিলেনি, দয়া করে মিলিয়ে লিখুন।</span>
                    </span>
                  )}
                </div>
              )}
            </div>

            <div className="grid grid-cols-2 gap-2.5">
              <div className="space-y-1">
                <label className="font-semibold text-slate-300">নমিনীর নাম:</label>
                <input
                  type="text"
                  maxLength={80}
                  placeholder="নমিনীর নাম"
                  value={regNomineeName}
                  onChange={(e) => setRegNomineeName(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 min-h-11 py-2 text-sm text-ink"
                />
              </div>

              <div className="space-y-1">
                <label className="font-semibold text-slate-300">নমিনীর সাথে সম্পর্ক:</label>
                <select
                  value={regNomineeRelation}
                  onChange={(e) => setRegNomineeRelation(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 min-h-11 py-2 text-sm text-ink font-bold focus:outline-none focus:ring-1 focus:ring-emerald-500"
                >
                  <option value="পিতা">পিতা (Father)</option>
                  <option value="মাতা">মাতা (Mother)</option>
                  <option value="স্বামী">স্বামী (Husband)</option>
                  <option value="স্ত্রী">স্ত্রী (Wife)</option>
                  <option value="সন্তান">সন্তান / পুত্র / কন্যা (Child)</option>
                  <option value="ভাই">ভাই (Brother)</option>
                  <option value="বোন">বোন (Sister)</option>
                  <option value="অভিভাবক / অন্যান্য">অভিভাবক / অন্যান্য (Other)</option>
                </select>
              </div>
            </div>

            <div className="space-y-1">
              <label className="font-semibold text-slate-300">বর্তমান ঠিকানা:</label>
              <input
                type="text"
                maxLength={120}
                placeholder="বাড়ি, রোড, এলাকা, জেলা"
                value={regAddress}
                onChange={(e) => setRegAddress(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 min-h-11 py-2 text-sm text-ink"
              />
            </div>

            <div className="pt-2">
              <button
                type="submit"
                disabled={regPassword.length < 6 || regPassword !== regConfirmPassword}
                className="w-full min-h-12 px-4 rounded-2xl btn-brand disabled:opacity-50 font-bold text-sm transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <UserPlus className="w-4 h-4" />
                <span>নিবন্ধন জমা দিন (মডারেটর প্যানেল অনুমোদনের জন্য)</span>
              </button>
            </div>
          </form>
        )}
        </div>
        <p className="text-center text-[12px] text-slate-400 px-6 py-6">
          চালিয়ে গেলে আপনি আমাদের শর্তাবলী মেনে নিচ্ছেন
        </p>
      </div>
    </div>
  );
};
