import React, { useState } from 'react';
import { DownloadCloud, CheckCircle2, AlertCircle, X, ShieldCheck } from 'lucide-react';
import { AppRelease } from '../../types';
import { toBengaliNumerals } from '../../utils/calculations';

interface AppUpdateModalProps {
  release: AppRelease | null;
  onClose: () => void;
}

export const AppUpdateModal: React.FC<AppUpdateModalProps> = ({ release, onClose }) => {
  const [downloadProgress, setDownloadProgress] = useState<number | null>(null);
  const [isDownloaded, setIsDownloaded] = useState<boolean>(false);

  const [showExitWarning, setShowExitWarning] = useState<boolean>(false);

  const [statusMessage, setStatusMessage] = useState<string | null>(null);

  if (!release) return null;

  const handleStartDownload = () => {
    // Open APK file download directly via anchor download/target
    if (release.downloadUrl) {
      const url = release.downloadUrl;
      const link = document.createElement('a');
      link.href = url;
      link.download = `BasisFoundation-v${release.versionName}.apk`;
      link.target = '_blank';
      link.rel = 'noopener noreferrer';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }

    setDownloadProgress(10);
    const interval = setInterval(() => {
      setDownloadProgress((prev) => {
        if (prev === null) return 20;
        if (prev >= 100) {
          clearInterval(interval);
          setIsDownloaded(true);
          return 100;
        }
        return prev + 25;
      });
    }, 350);
  };

  const handleInstallApk = () => {
    setStatusMessage(
      `APK ফাইল ডাউনলোড ও সাইনিং যাচাই সম্পন্ন! প্যাকেজ ভার্সন: ${release.versionName}। ডাউনলোড ফোল্ডার থেকে ইনস্টল করুন।`
    );
    setTimeout(() => {
      onClose();
    }, 1400);
  };

  const handleMandatoryDecline = () => {
    setShowExitWarning(true);
    setTimeout(() => {
      if (window.AndroidBridge?.exitApp) {
        window.AndroidBridge.exitApp();
      } else {
        window.location.reload();
      }
    }, 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-md w-full p-6 shadow-2xl space-y-4">
        {/* Top Header */}
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 border border-emerald-500/30 text-emerald-400 flex items-center justify-center">
              <DownloadCloud className="w-6 h-6" />
            </div>
            <div>
              <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider ${
                release.isMandatory
                  ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                  : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
              }`}>
                {release.isMandatory ? '🚨 বাধ্যতামূলক সিকিউরিটি আপডেট' : 'নতুন সংস্করণ উপলভ্য'}
              </span>
              <h3 className="text-lg font-bold text-ink mt-1">
                BASIS FOUNDATION {release.versionName}
              </h3>
              <p className="text-xs text-slate-400">
                বিল্ড কোড: <strong className="text-ink font-bold">{toBengaliNumerals(release.versionCode)}</strong> • সাইজ: {(release.fileSizeBytes / (1024 * 1024)).toFixed(1)} MB
              </p>
            </div>
          </div>

          {!release.isMandatory && (
            <button
              onClick={onClose}
              className="p-1 rounded-lg text-slate-400 hover:text-ink hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          )}
        </div>

        {/* Status Message Banner */}
        {statusMessage && (
          <div className="p-3 rounded-2xl bg-emerald-950/80 border border-emerald-500/40 text-emerald-200 text-xs font-bold flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>{statusMessage}</span>
          </div>
        )}

        {/* Exit Warning Banner if user tries to decline mandatory update */}
        {showExitWarning && (
          <div className="p-3.5 rounded-2xl bg-rose-950 border border-rose-600 text-rose-200 text-xs space-y-1 animate-pulse">
            <div className="flex items-center gap-2 font-bold text-ink">
              <AlertCircle className="w-4 h-4 text-rose-400" />
              <span>প্রবেশাধিকার স্থগিত! স্বয়ংক্রিয় প্রস্থান প্রক্রিয়া সক্রিয়...</span>
            </div>
            <p className="leading-relaxed">
              নিউ অ্যাপ আপডেট না করলে অ্যাপে প্রবেশের অনুমতি নেই। অ্যাপ থেকে স্বয়ংক্রিয়ভাবে এক্সিট করা হচ্ছে...
            </p>
          </div>
        )}

        {/* Release Notes */}
        <div className="bg-slate-950 border border-slate-800/80 rounded-2xl p-4 text-xs space-y-3">
          <div>
            <h4 className="font-bold text-slate-200">আপডেট বিবরণ:</h4>
            <p className="text-slate-400 mt-0.5">{release.releaseNotes}</p>
          </div>

          {release.featureList && release.featureList.length > 0 && (
            <div>
              <h4 className="font-bold text-emerald-400">নতুন ফিচারসমূহ:</h4>
              <ul className="list-disc list-inside text-slate-300 mt-1 space-y-0.5">
                {release.featureList.map((f, i) => (
                  <li key={i}>{f}</li>
                ))}
              </ul>
            </div>
          )}

          {release.bugFixList && release.bugFixList.length > 0 && (
            <div>
              <h4 className="font-bold text-amber-400">সমাধানকৃত বিষয়াদি:</h4>
              <ul className="list-disc list-inside text-slate-300 mt-1 space-y-0.5">
                {release.bugFixList.map((b, i) => (
                  <li key={i}>{b}</li>
                ))}
              </ul>
            </div>
          )}
        </div>

        {/* Integrity Check Information */}
        <div className="flex items-center gap-2 text-[11px] text-slate-400 bg-slate-800/40 p-2.5 rounded-xl border border-slate-700/50">
          <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
          <span className="truncate">APK SHA256 চেকসাম: {release.apkSha256}</span>
        </div>

        {/* Download Progress Bar */}
        {downloadProgress !== null && (
          <div className="space-y-1.5">
            <div className="flex justify-between text-xs text-slate-300 font-bold">
              <span>{isDownloaded ? 'ব্রাউজারে ডাউনলোড সম্পন্ন!' : 'ডিফল্ট ব্রাউজারে APK ডাউনলোড হচ্ছে...'}</span>
              <span>{toBengaliNumerals(downloadProgress)}%</span>
            </div>
            <div className="w-full bg-slate-800 rounded-full h-2 overflow-hidden">
              <div
                className="bg-emerald-500 h-2 rounded-full transition-all duration-300"
                style={{ width: `${downloadProgress}%` }}
              />
            </div>
          </div>
        )}

        {/* Action Buttons */}
        <div className="pt-2 space-y-2">
          {!isDownloaded ? (
            <button
              onClick={handleStartDownload}
              disabled={downloadProgress !== null}
              className="w-full py-3 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-sm transition-colors flex items-center justify-center gap-2 disabled:opacity-50 cursor-pointer"
            >
              <DownloadCloud className="w-4 h-4" />
              <span>{downloadProgress !== null ? 'ব্রাউজারে ডাউনলোড হচ্ছে...' : 'এখনই ডাউনলোড ও আপডেট করুন'}</span>
            </button>
          ) : (
            <button
              onClick={handleInstallApk}
              className="w-full py-3 px-4 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-sm transition-colors flex items-center justify-center gap-2 cursor-pointer"
            >
              <CheckCircle2 className="w-4 h-4 text-slate-950" />
              <span>ইনস্টলেশন সম্পন্ন করুন</span>
            </button>
          )}

          {release.isMandatory ? (
            <button
              onClick={handleMandatoryDecline}
              className="w-full py-2 text-xs text-rose-400 hover:text-rose-300 font-bold transition-colors cursor-pointer"
            >
              আপডেট না করে অ্যাপ থেকে প্রস্থান করুন
            </button>
          ) : (
            <button
              onClick={onClose}
              className="w-full py-2 text-xs text-slate-400 hover:text-slate-200 transition-colors cursor-pointer"
            >
              পরে আপডেট করব
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
