import React, { useState } from 'react';
import {
  ShieldCheck,
  CheckCircle2,
  XCircle,
  UserCheck,
  AlertCircle,
  Send,
  Edit3,
  Save,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { toBengaliNumerals } from '../../utils/calculations';
import { Avatar } from '../common/Avatar';

interface ModeratorPanelProps {
  onOpenReceipt: (txId: string) => void;
  setActiveTab: (tab: string) => void;
}

export const ModeratorPanel: React.FC<ModeratorPanelProps> = ({
  setActiveTab,
}) => {
  const {
    currentUser,
    isGuestMode,
    approvals,
    voteOnApproval,
    users,
    savings,
    eligibleModeratorsCount,
    config,
    complaints,
    updateComplaintStatus,
    approveUserAccount,
    rejectUserAccount,
    updateUserDesignation,
    sendOverdueReminder,
    overdueReminders,
  } = useApp();

  const [activeSubTab, setActiveSubTab] = useState<
    'APPROVALS' | 'PENDING_ACCOUNTS' | 'DESIGNATIONS' | 'OVERDUE' | 'COMPLAINTS'
  >('APPROVALS');

  // Edit designation local state
  const [editingUserId, setEditingUserId] = useState<string | null>(null);
  const [editingTitle, setEditingTitle] = useState('');

  // Restrict Guests and ordinary members
  if (isGuestMode || currentUser.role === 'MEMBER') {
    return (
      <div className="p-8 text-center bg-slate-900 border border-slate-800 rounded-3xl max-w-md mx-auto my-12 space-y-3">
        <AlertCircle className="w-10 h-10 text-rose-500 mx-auto" />
        <h3 className="text-base font-bold text-ink">অননুমোদিত প্রবেশাধিকার</h3>
        <p className="text-xs text-slate-400">
          এই বিভাগটি শুধুমাত্র বেসিস ফাউন্ডেশনের অনুমোদিত মডারেটরদের জন্য সংরক্ষিত।
        </p>
      </div>
    );
  }

  // Pending approvals (including Savings, Profile Change, and Notice Edit)
  const pendingApprovals = approvals.filter((a) => a.status === 'PENDING' && a.requestType !== 'NEW_MEMBER');

  // Pending User Accounts awaiting moderator approval
  const pendingUsers = users.filter((u) => u.id !== '__guest__' && u.status === 'PENDING');

  // Point 13: Show ONLY Firebase Moderators in Moderator Panel (no regular member list)
  const firebaseModerators = users.filter(
    (u) => u.id !== '__guest__' && (u.role === 'APP_MODERATOR' || u.role === 'MODERATOR')
  );

  // Overdue Members for current month
  const currentMonthKey = '2026-10';
  const currentMonthDeposits = savings.filter(
    (t) => t.savingsMonth === currentMonthKey && t.status === 'APPROVED'
  );
  const depositedIds = new Set(currentMonthDeposits.map((t) => t.memberId));
  const overdueMembers = users.filter(
    (u) => u.id !== '__guest__' && u.status === 'APPROVED' && !depositedIds.has(u.memberId)
  );

  const handleStartEditDesignation = (userId: string, currentTitle?: string) => {
    setEditingUserId(userId);
    setEditingTitle(currentTitle || '');
  };

  const handleSaveDesignation = (userId: string) => {
    updateUserDesignation(userId, editingTitle.trim());
    setEditingUserId(null);
  };

  const getFieldLabelBn = (field: string) => {
    switch (field) {
      case 'title':
        return 'শিরোনাম';
      case 'content':
        return 'বিস্তারিত বিবরণ';
      case 'priority':
        return 'গুরুত্ব';
      case 'showInTicker':
        return 'শীর্ষ ঘোষণা স্ক্রলিং';
      case 'isPinned':
        return 'পিন স্ট্যাটাস';
      default:
        return field;
    }
  };

  return (
    <div className="space-y-5 pb-16">
      {/* Top Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-sm space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-blue-400" />
              <h2 className="text-xl font-bold text-ink">মডারেটর নির্বাহী প্যানেল (Moderator Panel)</h2>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              অনুমোদন অনুরোধ (জমা, প্রোফাইল ও নোটিশ এডিট), নতুন অ্যাকাউন্ট অনুমোদন, ফায়ারবেজ মডারেটর প্যানেল তথ্য ও অভিযোগ নিষ্পত্তি।
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setActiveTab('chat')}
              className="py-2 px-3.5 rounded-xl bg-blue-600/20 text-blue-400 border border-blue-500/30 hover:bg-blue-600/30 font-semibold text-xs transition-colors cursor-pointer"
            >
              মডারেটর-অনলি চ্যাট
            </button>
          </div>
        </div>

        {/* Sub-Navigation Pills */}
        <div className="flex items-center gap-2 pt-2 border-t border-slate-800 overflow-x-auto scrollbar-none">
          <button
            onClick={() => setActiveSubTab('APPROVALS')}
            className={`py-2 px-4 rounded-xl text-xs font-bold transition-colors shrink-0 flex items-center gap-1.5 cursor-pointer ${
              activeSubTab === 'APPROVALS'
                ? 'bg-emerald-600 text-white shadow-md'
                : 'bg-slate-950 text-slate-300 hover:bg-slate-800'
            }`}
          >
            <span>অনুমোদন ওয়ার্কফ্লো</span>
            {pendingApprovals.length > 0 && (
              <span className="bg-rose-500 text-white text-[10px] px-1.5 py-0.2 rounded-full font-bold">
                {toBengaliNumerals(pendingApprovals.length)}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveSubTab('PENDING_ACCOUNTS')}
            className={`py-2 px-4 rounded-xl text-xs font-bold transition-colors shrink-0 flex items-center gap-1.5 cursor-pointer ${
              activeSubTab === 'PENDING_ACCOUNTS'
                ? 'bg-blue-600 text-white shadow-md'
                : 'bg-slate-950 text-slate-300 hover:bg-slate-800'
            }`}
          >
            <UserCheck className="w-3.5 h-3.5" />
            <span>নতুন অ্যাকাউন্ট অনুমোদন</span>
            {pendingUsers.length > 0 && (
              <span className="bg-amber-400 text-slate-950 text-[10px] px-1.5 py-0.2 rounded-full font-bold">
                {toBengaliNumerals(pendingUsers.length)}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveSubTab('DESIGNATIONS')}
            className={`py-2 px-4 rounded-xl text-xs font-bold transition-colors shrink-0 flex items-center gap-1.5 cursor-pointer ${
              activeSubTab === 'DESIGNATIONS'
                ? 'bg-emerald-600 text-white shadow-md'
                : 'bg-slate-950 text-slate-300 hover:bg-slate-800'
            }`}
          >
            <Edit3 className="w-3.5 h-3.5" />
            <span>ফায়ারবেজ মডারেটর তালিকা ({toBengaliNumerals(firebaseModerators.length)})</span>
          </button>

          <button
            onClick={() => setActiveSubTab('OVERDUE')}
            className={`py-2 px-4 rounded-xl text-xs font-bold transition-colors shrink-0 flex items-center gap-1.5 cursor-pointer ${
              activeSubTab === 'OVERDUE'
                ? 'bg-emerald-600 text-white shadow-md'
                : 'bg-slate-950 text-slate-300 hover:bg-slate-800'
            }`}
          >
            <span>বকেয়া সঞ্চয় ও রিমাইন্ডার ({toBengaliNumerals(overdueMembers.length)})</span>
          </button>

          <button
            onClick={() => setActiveSubTab('COMPLAINTS')}
            className={`py-2 px-4 rounded-xl text-xs font-bold transition-colors shrink-0 flex items-center gap-1.5 cursor-pointer ${
              activeSubTab === 'COMPLAINTS'
                ? 'bg-emerald-600 text-white shadow-md'
                : 'bg-slate-950 text-slate-300 hover:bg-slate-800'
            }`}
          >
            <span>অভিযোগ পর্যবেক্ষণ</span>
          </button>
        </div>
      </div>

      {/* SubTab 1: Approvals Workflow Engine (Savings, Profile Change, Notice Edit) */}
      {activeSubTab === 'APPROVALS' && (
        <div className="space-y-4">
          <div className="p-3.5 rounded-2xl bg-blue-950/30 border border-blue-900/50 flex items-start gap-2.5 text-xs text-blue-200">
            <ShieldCheck className="w-4 h-4 text-blue-400 shrink-0 mt-0.5" />
            <div>
              <strong className="font-semibold text-ink">২/৩ সিলিং অনুমোদন নীতি সক্রিয়:</strong>{' '}
              বর্তমানে অনুমোদিত মডারেটর সংখ্যা {toBengaliNumerals(eligibleModeratorsCount)} জন।
              আর্থিক এন্ট্রি, প্রোফাইল সংশোধন ও নোটিশ সম্পাদনা লাইভ করতে নূন্যতম{' '}
              <strong className="text-emerald-400 font-bold">
                {toBengaliNumerals(Math.max(1, Math.ceil((eligibleModeratorsCount * 2) / 3)))} জনের
              </strong>{' '}
              অনুমোদন ভোট আবশ্যক।
            </div>
          </div>

          <div className="space-y-3">
            <h3 className="font-bold text-ink text-sm">
              মুলতুবি অনুরোধসমূহ ({toBengaliNumerals(pendingApprovals.length)})
            </h3>

            {pendingApprovals.map((appr) => {
              const hasVoted =
                appr.approvalVotes.includes(currentUser.id) ||
                appr.rejectionVotes.includes(currentUser.id);

              const badgeLabel =
                appr.requestType === 'SAVINGS_ENTRY'
                  ? 'সঞ্চয় জমা'
                  : appr.requestType === 'NOTICE_EDIT'
                  ? 'নোটিশ সম্পাদনা'
                  : appr.requestType === 'NEW_MEMBER'
                  ? 'নতুন সদস্য'
                  : 'প্রোফাইল সংশোধন';

              return (
                <div
                  key={appr.id}
                  className="bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-sm space-y-3"
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded border ${
                          appr.requestType === 'NOTICE_EDIT'
                            ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                            : 'bg-blue-500/20 text-blue-400 border-blue-500/30'
                        }`}
                      >
                        {badgeLabel}
                      </span>
                      <h4 className="font-bold text-ink text-sm sm:text-base">{appr.title}</h4>
                    </div>

                    <span className="text-xs text-slate-400">
                      তারিখ: {new Date(appr.createdAt).toLocaleDateString('en-GB')}
                    </span>
                  </div>

                  <p className="text-xs text-slate-300 leading-relaxed">{appr.description}</p>

                  {/* Proposed Changes Diff Viewer (for NOTICE_EDIT and PROFILE_CHANGE) */}
                  {appr.proposedChanges && appr.proposedChanges.length > 0 && (
                    <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-2 text-xs">
                      <div className="font-bold text-amber-300 text-[11px]">প্রস্তাবিত পরিবর্তনসমূহ:</div>
                      {appr.proposedChanges.map((ch, idx) => (
                        <div key={idx} className="space-y-0.5 border-t border-slate-900 pt-1.5 first:border-t-0 first:pt-0">
                          <span className="font-bold text-slate-400">{getFieldLabelBn(ch.field)}:</span>
                          <div className="text-rose-300/80 line-through text-[11px] whitespace-pre-line">
                            {String(ch.oldValue)}
                          </div>
                          <div className="text-emerald-300 font-bold text-[11px] whitespace-pre-line">
                            {String(ch.newValue)}
                          </div>
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Vote Progress Tracker */}
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-2">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2 text-xs">
                        <span className="text-slate-400 font-bold">ভোট অগ্রগতি:</span>
                        <span className="text-emerald-400 font-bold">
                          {toBengaliNumerals(appr.approvalVotes.length)} জন অনুমোদিত
                        </span>
                        <span className="text-slate-500">/</span>
                        <span className="text-slate-300 font-bold">
                          প্রয়োজন: {toBengaliNumerals(appr.requiredApprovalCount)} ভোট
                        </span>
                      </div>
                      <div className="w-48 bg-slate-950 rounded-full h-1.5 overflow-hidden border border-slate-800">
                        <div
                          className="bg-emerald-500 h-1.5 rounded-full"
                          style={{
                            width: `${Math.min(
                              100,
                              (appr.approvalVotes.length / Math.max(1, appr.requiredApprovalCount)) * 100
                            )}%`,
                          }}
                        />
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => voteOnApproval(appr.id, 'APPROVE')}
                        disabled={hasVoted}
                        className="py-1.5 px-3.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 text-white font-bold text-xs transition-colors flex items-center gap-1 shadow-sm cursor-pointer"
                      >
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>{hasVoted ? 'ভোট প্রদান সম্পন্ন' : 'অনুমোদন ভোট দিন'}</span>
                      </button>

                      <button
                        onClick={() => voteOnApproval(appr.id, 'REJECT', 'মডারেটর কর্তৃক বাতিল')}
                        disabled={hasVoted}
                        className="py-1.5 px-3 rounded-xl bg-rose-950/70 hover:bg-rose-900 border border-rose-800 text-rose-300 disabled:opacity-40 font-bold text-xs transition-colors flex items-center gap-1 cursor-pointer"
                      >
                        <XCircle className="w-3.5 h-3.5" />
                        <span>প্রত্যাখ্যান</span>
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}

            {pendingApprovals.length === 0 && (
              <div className="text-center py-12 bg-slate-900 border border-slate-800 rounded-2xl">
                <p className="text-xs text-slate-400">বর্তমানে কোনো মুলতুবি অনুমোদন অনুরোধ নেই।</p>
              </div>
            )}
          </div>
        </div>
      )}

      {/* SubTab 2: Pending User Accounts Awaiting Approval */}
      {activeSubTab === 'PENDING_ACCOUNTS' && (
        <div className="space-y-4">
          <div className="p-3.5 rounded-2xl bg-blue-950/30 border border-blue-900/50 flex items-start gap-2.5 text-xs text-blue-200">
            <UserCheck className="w-4 h-4 text-blue-400 shrink-0 mt-0.5" />
            <div>
              <strong className="font-semibold text-ink">নতুন সদস্য অ্যাকাউন্ট যাচাই ও অনুমোদন:</strong>{' '}
              ব্যবহারকারীরা যখন অ্যাপের "নতুন অ্যাকাউন্ট খুলুন" সেকশন থেকে রেজিস্ট্রেশন করেন, তখন তাদের অ্যাকাউন্ট এখানে জমা হয়।
              মডারেটরের অনুমোদনের পরই ব্যবহারকারী অ্যাপে সফলভাবে লগইন করতে পারবেন।
            </div>
          </div>

          <div className="space-y-3">
            <h3 className="font-bold text-ink text-sm">
              অনুমোদনের অপেক্ষমাণ অ্যাকাউন্টসমূহ ({toBengaliNumerals(pendingUsers.length)})
            </h3>

            {pendingUsers.map((u) => (
              <div
                key={u.id}
                className="bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4 text-xs"
              >
                <div className="flex items-center gap-3">
                  <Avatar src={u.avatarUrl} name={u.name} size="lg" ringColor="ring-amber-500" />
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <strong className="text-ink font-bold text-sm">{u.name}</strong>
                      <span className="font-mono text-emerald-400 font-bold">({u.memberId})</span>
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 font-bold">
                        অপেক্ষমাণ
                      </span>
                    </div>
                    <p className="text-slate-300">
                      মোবাইল: <span className="font-mono">{u.phone}</span> • ইমেইল: {u.email}
                    </p>
                    <p className="text-slate-400 text-[11px]">
                      লিঙ্গ: {u.gender === 'MALE' ? 'পুরুষ' : u.gender === 'FEMALE' ? 'নারী' : 'অন্যান্য'} • নমিনী:{' '}
                      {u.nomineeName || 'N/A'} ({u.nomineeRelation || ''}) • ঠিকানা: {u.address || 'N/A'}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0 self-end sm:self-center">
                  <button
                    onClick={() => approveUserAccount(u.id)}
                    className="py-2 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs transition-all flex items-center gap-1.5 cursor-pointer"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>অনুমোদন করুন</span>
                  </button>
                  <button
                    onClick={() => rejectUserAccount(u.id)}
                    className="py-2 px-3 rounded-xl bg-rose-950/70 hover:bg-rose-900 text-rose-300 font-bold text-xs border border-rose-800 transition-all flex items-center gap-1 cursor-pointer"
                  >
                    <XCircle className="w-4 h-4" />
                    <span>বাতিল</span>
                  </button>
                </div>
              </div>
            ))}

            {pendingUsers.length === 0 && (
              <div className="text-center py-12 bg-slate-900 border border-slate-800 rounded-2xl">
                <p className="text-xs text-slate-400">বর্তমানে কোনো অপেক্ষমাণ অ্যাকাউন্ট নেই।</p>
              </div>
            )}
          </div>
        </div>
      )}

      {/* SubTab 3: Point 13 — Firebase Moderators Info & Designation Management ONLY */}
      {activeSubTab === 'DESIGNATIONS' && (
        <div className="space-y-4">
          <div className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 text-xs text-slate-300 space-y-1">
            <h4 className="font-bold text-ink text-sm flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>ফায়ারবেজ মডারেটর প্যানেল তথ্য ও পদবি ব্যবস্থাপনা</span>
            </h4>
            <p className="text-slate-400">
              এখানে শুধুমাত্র ফায়ারবেজে নিবন্ধিত ও অনুমোদিত মডারেটরদের তথ্য সংরক্ষিত ও প্রদর্শিত হচ্ছে। যেকোনো মডারেটরের দাপ্তরিক পদবি এখান থেকে হালনাগাদ করা যাবে।
            </p>
          </div>

          <div className="space-y-2.5">
            {firebaseModerators.map((u) => {
              const isEditing = editingUserId === u.id;

              return (
                <div
                  key={u.id}
                  className="bg-slate-900 border border-slate-800 rounded-2xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs"
                >
                  <div className="flex items-center gap-3">
                    <Avatar
                      src={u.avatarUrl}
                      name={u.name}
                      size="md"
                      ringColor={u.role === 'APP_MODERATOR' ? 'ring-amber-500' : 'ring-blue-500'}
                    />
                    <div className="space-y-0.5">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <strong className="text-ink font-bold">{u.name}</strong>
                        <CheckCircle2 className="w-3.5 h-3.5 text-blue-400 fill-blue-500 text-ink inline-block" />
                        <span className="font-mono text-emerald-400 text-[11px] font-bold">({u.memberId})</span>
                        <span
                          className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${
                            u.role === 'APP_MODERATOR'
                              ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                              : 'bg-blue-500/20 text-blue-300 border border-blue-500/30'
                          }`}
                        >
                          {u.role === 'APP_MODERATOR' ? 'APP MODERATOR' : 'MODERATOR'}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-400">
                        পদবি:{' '}
                        <span className="text-emerald-300 font-bold">
                          {u.moderatorTitle || (u.role === 'APP_MODERATOR' ? 'প্রধান অ্যাপ মডারেটর' : 'মডারেটর')}
                        </span>{' '}
                        • মোবাইল: <span className="font-mono text-slate-300">{u.phone}</span> • ইমেইল:{' '}
                        <span className="font-mono text-slate-300">{u.email}</span>
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    {isEditing ? (
                      <div className="flex items-center gap-2 w-full sm:w-auto">
                        <input
                          type="text"
                          placeholder="নতুন পদবি লিখুন (যেমন: সভাপতি/অর্থ সম্পাদক)"
                          value={editingTitle}
                          onChange={(e) => setEditingTitle(e.target.value)}
                          className="bg-slate-950 border border-slate-700 rounded-xl px-3 py-1.5 text-xs text-ink w-52 font-bold"
                        />
                        <button
                          onClick={() => handleSaveDesignation(u.id)}
                          className="py-1.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center gap-1 shadow cursor-pointer"
                        >
                          <Save className="w-3.5 h-3.5" />
                          <span>সংরক্ষণ</span>
                        </button>
                        <button
                          onClick={() => setEditingUserId(null)}
                          className="py-1.5 px-2.5 rounded-xl bg-slate-800 text-slate-400 text-xs cursor-pointer"
                        >
                          বাতিল
                        </button>
                      </div>
                    ) : (
                      <button
                        onClick={() => handleStartEditDesignation(u.id, u.moderatorTitle)}
                        className="py-1.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs flex items-center gap-1.5 border border-slate-700 cursor-pointer"
                      >
                        <Edit3 className="w-3.5 h-3.5 text-emerald-400" />
                        <span>পদবি পরিবর্তন</span>
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* SubTab 4: Overdue List & Reminder Dispatch */}
      {activeSubTab === 'OVERDUE' && (
        <div className="space-y-4">
          <div className="p-3.5 rounded-2xl bg-rose-950/30 border border-rose-900/50 flex items-start gap-2.5 text-xs text-rose-200">
            <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
            <div>
              <strong className="font-semibold text-ink">বকেয়া তাগিদ ব্যবস্থার সক্রিয়করণ:</strong>{' '}
              নিবন্ধিত সদস্যকে "তাগিদ পাঠান" বাটনে ক্লিক করলে তার অ্যাপে ও হোম ড্যাশবোর্ডে লাল বক্স আকারে তাগিদ প্রদর্শিত হবে (অতিথি ইউজারদের এটি দেখানো হয় না)।
            </div>
          </div>

          <div className="space-y-2.5">
            {overdueMembers.map((m) => {
              const isReminded = overdueReminders.includes(m.memberId);

              return (
                <div
                  key={m.id}
                  className="bg-slate-900 border border-slate-800 rounded-2xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs"
                >
                  <div className="flex items-center gap-3">
                    <Avatar src={m.avatarUrl} name={m.name} size="md" />
                    <div>
                      <div className="flex items-center gap-2">
                        <strong className="text-ink font-bold">{m.name}</strong>
                        <span className="font-mono text-emerald-400 font-bold">({m.memberId})</span>
                      </div>
                      <p className="text-[11px] text-slate-400 mt-0.5">
                        মোবাইল: {m.phone} • বকেয়া মাস: অক্টোবর ২০২৬ (৳
                        {toBengaliNumerals(config.defaultMonthlyAmount || 1500)})
                      </p>
                    </div>
                  </div>

                  <button
                    onClick={() => sendOverdueReminder(m.memberId)}
                    disabled={isReminded}
                    className={`py-2 px-4 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                      isReminded
                        ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                        : 'bg-rose-600 hover:bg-rose-500 text-white'
                    }`}
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>{isReminded ? 'তাগিদ পাঠানো হয়েছে (সক্রিয়)' : 'তাগিদ পাঠান'}</span>
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* SubTab 5: Complaints Resolution */}
      {activeSubTab === 'COMPLAINTS' && (
        <div className="space-y-3">
          <h3 className="font-bold text-ink text-sm">সদস্য অভিযোগ ও প্রতিকার ট্র্যাকিং</h3>
          <div className="space-y-3">
            {complaints.map((comp) => (
              <div
                key={comp.id}
                className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-2.5"
              >
                <div className="flex items-center justify-between">
                  <span className="font-bold text-ink text-sm">{comp.title}</span>
                  <span
                    className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                      comp.status === 'RESOLVED'
                        ? 'bg-emerald-500/20 text-emerald-400'
                        : comp.status === 'IN_PROGRESS'
                        ? 'bg-blue-500/20 text-blue-400'
                        : 'bg-amber-500/20 text-amber-400'
                    }`}
                  >
                    {comp.status}
                  </span>
                </div>
                <p className="text-xs text-slate-300">{comp.description}</p>
                <div className="flex items-center justify-between text-xs text-slate-400 pt-1 border-t border-slate-800">
                  <span>দাখিলকারী: {comp.submitterName}</span>
                  <div className="flex items-center gap-2">
                    {comp.status !== 'RESOLVED' && (
                      <button
                        onClick={() =>
                          updateComplaintStatus(comp.id, 'RESOLVED', 'সমস্যার সন্তোষজনক সমাধান করা হয়েছে।')
                        }
                        className="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-[11px] cursor-pointer"
                      >
                        সমাধান নিশ্চিত করুন
                      </button>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
