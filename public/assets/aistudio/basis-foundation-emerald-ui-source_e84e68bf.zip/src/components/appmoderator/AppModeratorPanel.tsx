import React, { useState } from 'react';
import {
  ShieldAlert,
  Settings,
  DownloadCloud,
  Database,
  FileCode,
  CheckCircle2,
  AlertTriangle,
  Upload,
  RefreshCw,
  ExternalLink,
  Save,
  FileText,
  Key,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { toBengaliNumerals } from '../../utils/calculations';
import { NativeAndroidSpecView } from '../android/NativeAndroidSpecView';
import { UserRole, AccountStatus } from '../../types';
import { UserCheck, Users, Building2, Trash2, Edit3, Type, UserPlus, Check, X, ArrowUp, ArrowDown, Layers, ListOrdered } from 'lucide-react';
import { Avatar } from '../common/Avatar';
import { extractDirectImageUrl } from '../../utils/imageUtils';

export const AppModeratorPanel: React.FC = () => {
  const {
    currentUser,
    config,
    updateConfig,
    users,
    updateUserProfile,
    updateUserDesignation,
    approveUserAccount,
    rejectUserAccount,
    removeUser,
    releases,
    publishAppRelease,
    setActiveUpdateDialog,
    exportBackupData,
    restoreFromBackup,
    auditLogs,
    resetToInitialDemo,
    triggerSuccess,
    triggerWarning,
  } = useApp();

  const realUsers = users.filter((u) => u.id !== '__guest__' && u.memberId !== 'GUEST');

  const [activeTab, setActiveTab] = useState<
    'BRANDING' | 'MEMBERS_ROLES' | 'PENDING_ACCOUNTS' | 'FONTS' | 'TABS_ORDER' | 'RELEASES' | 'BACKUP' | 'AUDIT' | 'ANDROID_SPEC'
  >('BRANDING');

  const DEFAULT_APP_TABS = [
    { id: 'home', label: 'হোম ড্যাশবোর্ড' },
    { id: 'profile', label: 'প্রোফাইল ও অ্যাপ সেটিংস' },
    { id: 'bank', label: 'ব্যাংক ইনফরমেশন ও হিসাব' },
    { id: 'about-us', label: 'আমাদের সম্পর্কে (About Us)' },
    { id: 'members', label: 'সদস্য তালিকা ও পদবি' },
    { id: 'savings', label: 'সঞ্চয় খাতা ও নতুন জমা' },
    { id: 'receipts', label: 'রসিদ ও পিডিএফ স্টেটমেন্ট' },
    { id: 'analytics', label: 'হিসাব বিশ্লেষণ ও গ্রাফ' },
    { id: 'moderator', label: 'মডারেটর প্যানেল' },
    { id: 'notices', label: 'নোটিশ বোর্ড' },
    { id: 'rules', label: 'ফাউন্ডেশন গঠনতন্ত্র ও বিধি' },
    { id: 'complaints', label: 'অভিযোগ প্রতিকার সেল' },
    { id: 'features', label: 'নতুন ফিচারের প্রস্তাবনা' },
    { id: 'sheets', label: 'গুগল শিটস ক্লাউড সিঙ্ক' },
  ];

  const [tabsOrder, setTabsOrder] = useState<string[]>(() => {
    const base =
      config.navTabsOrder && config.navTabsOrder.length > 0
        ? config.navTabsOrder.filter((id) => id !== 'settings')
        : DEFAULT_APP_TABS.map((t) => t.id);
    return base.includes('profile') ? base : ['home', 'profile', ...base.filter((id) => id !== 'home')];
  });

  const [customTitles, setCustomTitles] = useState<Record<string, string>>(() => {
    return config.customTabTitles || {};
  });

  // Local config form state
  const [foundationName, setFoundationName] = useState(config.foundationName);
  const [foundationSlogan, setFoundationSlogan] = useState(config.foundationSlogan);
  const [logoUrl, setLogoUrl] = useState(config.logoUrl || '/logo.svg');
  const [footerText, setFooterText] = useState(config.footerText);
  const [developerAttribution, setDeveloperAttribution] = useState(config.developerAttribution);
  const [developerLink, setDeveloperLink] = useState(config.developerLink);
  const [scrollingAnnouncement, setScrollingAnnouncement] = useState(config.scrollingAnnouncement);
  const [receiptWatermarkText, setReceiptWatermarkText] = useState(config.receiptWatermarkText);
  const [receiptWatermarkImageUrl, setReceiptWatermarkImageUrl] = useState(config.receiptWatermarkImageUrl || '');
  const [statementWatermarkText, setStatementWatermarkText] = useState(config.statementWatermarkText);
  const [statementWatermarkImageUrl, setStatementWatermarkImageUrl] = useState(config.statementWatermarkImageUrl || '');
  const [moderatorPanelSignatureImageUrl, setModeratorPanelSignatureImageUrl] = useState(config.moderatorPanelSignatureImageUrl || '');
  const [generalSecretarySignatureImageUrl, setGeneralSecretarySignatureImageUrl] = useState(config.generalSecretarySignatureImageUrl || '');
  const [customFontUrl, setCustomFontUrl] = useState(config.customFontUrl || '');
  const [customFontFamily, setCustomFontFamily] = useState(config.customFontFamily || 'Hind Siliguri');
  const [fontSize, setFontSize] = useState(config.fontSize || 'medium');
  const [monthlyDueDay, setMonthlyDueDay] = useState(config.monthlyDueDay);

  // Requirement 10: Header Clock Position, Font, and Date/Weekday Order
  const [clockPosition, setClockPosition] = useState<'LEFT' | 'CENTER' | 'RIGHT'>(
    config.clockPosition || 'RIGHT'
  );
  const [clockFont, setClockFont] = useState<'FONT_MONO' | 'FONT_SANS'>(
    config.clockFont || 'FONT_MONO'
  );
  const [dateOrder, setDateOrder] = useState<'DATE_FIRST' | 'TIME_FIRST'>(
    config.dateOrder || 'DATE_FIRST'
  );
  const [headerMode, setHeaderMode] = useState<'REGULAR' | 'EXTENDED'>(
    config.headerMode || 'REGULAR'
  );
  const [clockScale, setClockScale] = useState<'SMALL' | 'MEDIUM' | 'LARGE'>(
    config.clockScale || 'MEDIUM'
  );

  // New release publish state (Requirement 10: APK file input box)
  const [newVersionName, setNewVersionName] = useState('v1.3.0');
  const [newVersionCode, setNewVersionCode] = useState(130);
  const [apkDownloadUrl, setApkDownloadUrl] = useState(
    'https://github.com/mahmudul-siam/basis-foundation/releases/download/v1.3.0/basis-foundation.apk'
  );
  const [releaseNotes, setReleaseNotes] = useState('নতুন সঞ্চয় ক্যালেন্ডার, লাইভ আপডেট ও পার্সোনাল মেসেজিং ফিচার যুক্ত করা হয়েছে।');
  const [isMandatory, setIsMandatory] = useState(true);

  // Member editing in Moderator Panel (Requirement 3)
  const [editingMemberId, setEditingMemberId] = useState<string | null>(null);
  const [editingMemberName, setEditingMemberName] = useState('');

  // Backup restore state
  const [restoreJsonInput, setRestoreJsonInput] = useState('');
  const [restoreFeedback, setRestoreFeedback] = useState<string | null>(null);

  // Enforce Section 13: "The App Moderator Panel must be accessible only to APP_MODERATOR."
  if (currentUser.role !== 'APP_MODERATOR') {
    return (
      <div className="p-8 text-center bg-slate-900 border border-slate-800 rounded-3xl max-w-md mx-auto my-12 space-y-3">
        <AlertTriangle className="w-10 h-10 text-rose-500 mx-auto" />
        <h3 className="text-base font-bold text-ink">অননুমোদিত প্রবেশাধিকার</h3>
        <p className="text-xs text-slate-400">
          এই বিভাগটি শুধুমাত্র প্রধান অ্যাপ মডারেটর (APP_MODERATOR) এর জন্য সংরক্ষিত।
        </p>
      </div>
    );
  }

  const handleSaveConfig = (e: React.FormEvent) => {
    e.preventDefault();
    const normalizedLogo = extractDirectImageUrl(logoUrl.trim()) || '/logo.svg';
    setLogoUrl(normalizedLogo);
    updateConfig({
      foundationName,
      foundationSlogan,
      logoUrl: normalizedLogo,
      footerText,
      developerAttribution,
      developerLink,
      scrollingAnnouncement,
      receiptWatermarkText,
      receiptWatermarkImageUrl: extractDirectImageUrl(receiptWatermarkImageUrl.trim()),
      statementWatermarkText,
      statementWatermarkImageUrl: extractDirectImageUrl(statementWatermarkImageUrl.trim()),
      moderatorPanelSignatureImageUrl: extractDirectImageUrl(moderatorPanelSignatureImageUrl.trim()),
      generalSecretarySignatureImageUrl: extractDirectImageUrl(generalSecretarySignatureImageUrl.trim()),
      customFontUrl,
      customFontFamily,
      fontSize: fontSize as any,
      monthlyDueDay: Number(monthlyDueDay),
      clockPosition,
      clockFont,
      dateOrder,
      headerMode,
      clockScale,
    });
    triggerSuccess('কনফিগারেশন, হোস্টেড লোগো ও ব্র্যান্ডিং তথ্য সফলভাবে সংরক্ষিত হয়েছে!');
  };

  const handlePublishRelease = (e: React.FormEvent) => {
    e.preventDefault();
    const newRel = {
      versionName: newVersionName,
      versionCode: Number(newVersionCode),
      releaseDate: new Date().toISOString().split('T')[0],
      releaseNotes,
      featureList: ['নতুন সঞ্চয় ক্যালেন্ডার', 'পুশ আপডেট ডাউনলোড', '১-অন-১ চ্যাট'],
      bugFixList: ['ফন্ট রেন্ডারিং ও টেক্সট ব্রেক সমাধান', 'রসিদ প্রিভিউ ফিক্স'],
      isMandatory,
      minSupportedVersion: '1.0.0',
      downloadUrl: apkDownloadUrl.trim() || `https://github.com/mahmudul-siam/basis-foundation/releases/download/${newVersionName}/basis-foundation.apk`,
      fileSizeBytes: 24500000,
      apkSha256: '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08',
    };
    publishAppRelease(newRel);
    setActiveUpdateDialog({ ...newRel, id: `rel-${Date.now()}` });
    triggerSuccess(`নতুন এপিকে সংস্করণ ${newVersionName} সফলভাবে পুশ করা হয়েছে!`);
  };

  const handleExportBackup = () => {
    const dataStr = exportBackupData();
    const blob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `basis_foundation_backup_${new Date().toISOString().slice(0, 10)}.json`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const handleExecuteRestore = () => {
    if (!restoreJsonInput.trim()) {
      triggerWarning('ব্যাকআপ JSON প্রয়োজন', 'অনুগ্রহ করে ব্যাকআপ JSON ডাটা বক্সে পেস্ট করুন।', false);
      return;
    }
    const result = restoreFromBackup(restoreJsonInput.trim());
    setRestoreFeedback(result.message);
    if (result.success) {
      triggerSuccess('ডাটাবেজ সফলভাবে রিস্টোর সম্পন্ন হয়েছে!');
      setRestoreJsonInput('');
    }
  };

  return (
    <div className="space-y-5 pb-16">
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-sm space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2">
              <ShieldAlert className="w-5 h-5 text-amber-400" />
              <h2 className="text-xl font-bold text-ink">অ্যাপ মডারেটর প্রশাসনিক কনসোল</h2>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              অ্যাপ্লিকেশন ব্র্যান্ডিং, স্ক্রোলিং নোটিশ, এপিকে রিলিজ ম্যানেজমেন্ট, এবং ব্যাকআপ রিকভারি।
            </p>
          </div>
        </div>

        {/* Tab navigation */}
        <div className="flex items-center gap-2 pt-2 border-t border-slate-800 overflow-x-auto scrollbar-none">
          {[
            { id: 'BRANDING', label: 'ব্র্যান্ডিং ও টেক্সট কনফিগারেশন' },
            { id: 'MEMBERS_ROLES', label: 'সদস্য ও পদবি নিয়ন্ত্রণ' },
            {
              id: 'PENDING_ACCOUNTS',
              label: `নতুন অ্যাকাউন্ট অনুমোদন ${
                users.filter((u) => u.status === 'PENDING').length > 0
                  ? `(${toBengaliNumerals(users.filter((u) => u.status === 'PENDING').length)})`
                  : ''
              }`,
            },
            { id: 'FONTS', label: 'ফন্ট ও টাইপোগ্রাফি ওয়েট' },
            { id: 'TABS_ORDER', label: 'ট্যাব ব্যবস্থাপনা ও শিরোনাম' },
            { id: 'RELEASES', label: 'অ্যাপ্লিকেশন আপডেট ও এপিকে' },
            { id: 'BACKUP', label: 'ব্যাকআপ ও রিকভারি' },
            { id: 'AUDIT', label: 'অডিট লগ ও নিরাপত্তা ট্রেইল' },
            { id: 'ANDROID_SPEC', label: 'নেটিভ অ্যান্ড্রয়েড আর্কিটেকচার (APK)' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`py-2 px-3.5 rounded-xl text-xs font-bold transition-colors shrink-0 ${
                activeTab === tab.id
                  ? 'bg-amber-600 text-white shadow-md'
                  : 'bg-slate-950 text-slate-300 hover:bg-slate-800'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Tab 1: Branding & Settings */}
      {activeTab === 'BRANDING' && (
        <form onSubmit={handleSaveConfig} className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4 text-xs">
          <h3 className="font-bold text-ink text-base">ফাউন্ডেশন ব্র্যান্ডিং, লোগো ও ডায়নামিক টেক্সট</h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1">
              <label className="font-semibold text-slate-300">ফাউন্ডেশনের পূর্ণ নাম:</label>
              <input
                type="text"
                value={foundationName}
                onChange={(e) => setFoundationName(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-xs text-slate-200 focus:ring-1 focus:ring-amber-500"
              />
            </div>

            <div className="space-y-1">
              <label className="font-semibold text-slate-300">ফাউন্ডেশনের স্লোগান:</label>
              <input
                type="text"
                value={foundationSlogan}
                onChange={(e) => setFoundationSlogan(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-xs text-slate-200 focus:ring-1 focus:ring-amber-500"
              />
            </div>

            {/* Logo URL with Live Preview & Hosted Image Presets (Requirement 17) */}
            <div className="col-span-full space-y-2.5 bg-slate-950 p-4 rounded-2xl border border-slate-800">
              <div className="flex items-center justify-between">
                <label className="font-bold text-slate-200 text-xs">অ্যাপ লোগো হোস্টেড ইমেজ ইউআরএল (Hosted Logo Image URL):</label>
                <span className="text-[10px] text-emerald-400 font-bold px-2 py-0.5 rounded bg-emerald-500/10 border border-emerald-500/20">
                  হোস্টেড লিংক সাপোর্ট
                </span>
              </div>

              <div className="flex items-center gap-3">
                <div className="w-14 h-14 rounded-2xl bg-slate-900 border border-emerald-500/40 p-1 flex items-center justify-center shrink-0 shadow-inner overflow-hidden">
                  <img
                    src={extractDirectImageUrl(logoUrl) || '/logo.svg'}
                    alt="Logo Preview"
                    onError={(e) => {
                      (e.currentTarget as HTMLImageElement).src = '/logo.svg';
                    }}
                    className="w-full h-full object-contain rounded-xl"
                  />
                </div>
                <div className="flex-1 space-y-1">
                  <input
                    type="text"
                    placeholder="Google Drive / ImgBB / Imgur / Postimages / যেকোনো হোস্টেড ইমেজ লিংক পেস্ট করুন..."
                    value={logoUrl}
                    onChange={(e) => setLogoUrl(e.target.value)}
                    onBlur={(e) => {
                      const direct = extractDirectImageUrl(e.target.value.trim());
                      if (direct) setLogoUrl(direct);
                    }}
                    className="w-full bg-slate-900 border border-slate-800 rounded-xl p-2.5 text-xs text-slate-200 font-mono focus:ring-1 focus:ring-amber-500"
                  />
                  <p className="text-[10px] text-slate-400">
                    প্রোফাইল ছবির মতোই Google Drive শেয়ার লিংক, Dropbox, Imgur, ImgBB, Postimages ও ডিরেক্ট PNG/SVG/JPG লিংক স্বয়ংক্রিয়ভাবে সাপোর্ট করে।
                  </p>
                </div>
              </div>

              {/* Requirement 17: Various Hosted Image Link Presets */}
              <div className="space-y-1.5 pt-1 border-t border-slate-900">
                <span className="text-[11px] text-slate-400 font-bold block">
                  জনপ্রিয় হোস্টিং সার্ভিস বা স্যাম্পল লিংক (ক্লিক করে নির্বাচন করুন):
                </span>
                <div className="flex flex-wrap gap-2">
                  {[
                    { label: 'ডিফল্ট ভেক্টর লোগো', url: '/logo.svg' },
                    { label: 'Cloudinary হোস্টেড', url: 'https://images.unsplash.com/photo-1579546929518-9e396f3cc809?w=200&auto=format&fit=crop&q=60' },
                    { label: 'Imgur / Postimages', url: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=200&auto=format&fit=crop&q=60' },
                    { label: 'Google Drive Direct', url: 'https://images.unsplash.com/photo-1557683316-973673baf926?w=200&auto=format&fit=crop&q=60' },
                  ].map((preset) => (
                    <button
                      key={preset.label}
                      type="button"
                      onClick={() => setLogoUrl(preset.url)}
                      className={`text-[10px] px-2.5 py-1 rounded-xl border transition-colors cursor-pointer ${
                        logoUrl === preset.url
                          ? 'bg-amber-600/30 border-amber-500 text-amber-300 font-bold'
                          : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-ink'
                      }`}
                    >
                      {preset.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div className="col-span-full space-y-1">
              <label className="font-semibold text-slate-300">স্ক্রোলিং ঘোষণা টেক্সট (Marquee Announcement):</label>
              <textarea
                rows={2}
                value={scrollingAnnouncement}
                onChange={(e) => setScrollingAnnouncement(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-xs text-slate-200 focus:ring-1 focus:ring-amber-500"
              />
            </div>

            {/* Receipt Watermark Text & Image Link (Requirement 7) */}
            <div className="space-y-1">
              <label className="font-semibold text-slate-300">রসিদ ওয়াটারমার্ক টেক্সট:</label>
              <input
                type="text"
                value={receiptWatermarkText}
                onChange={(e) => setReceiptWatermarkText(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-xs text-slate-200 focus:ring-1 focus:ring-amber-500"
              />
            </div>

            <div className="space-y-1">
              <label className="font-semibold text-slate-300">রসিদ ওয়াটারমার্ক হোস্টেড ইমেজ লিংক (ঐচ্ছিক):</label>
              <input
                type="url"
                placeholder="https://.../watermark.png"
                value={receiptWatermarkImageUrl}
                onChange={(e) => setReceiptWatermarkImageUrl(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-xs text-slate-200 font-mono"
              />
            </div>

            {/* Statement Watermark Text & Image Link (Requirement 7) */}
            <div className="space-y-1">
              <label className="font-semibold text-slate-300">স্টেটমেন্ট ওয়াটারমার্ক টেক্সট:</label>
              <input
                type="text"
                value={statementWatermarkText}
                onChange={(e) => setStatementWatermarkText(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-xs text-slate-200 focus:ring-1 focus:ring-amber-500"
              />
            </div>

            <div className="space-y-1">
              <label className="font-semibold text-slate-300">স্টেটমেন্ট ওয়াটারমার্ক হোস্টেড ইমেজ লিংক (ঐচ্ছিক):</label>
              <input
                type="url"
                placeholder="https://.../statement-bg.png"
                value={statementWatermarkImageUrl}
                onChange={(e) => setStatementWatermarkImageUrl(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-xs text-slate-200 font-mono"
              />
            </div>

            {/* Requirement 11: Moderator Panel & General Secretary Signature Images */}
            <div className="p-4 rounded-2xl bg-slate-950/80 border border-amber-900/40 space-y-3">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-amber-400" />
                <h4 className="font-bold text-amber-300 text-xs">রসিদ ও স্টেটমেন্টের অফিসিয়াল স্বাক্ষর ইমেজ সেটিংস (Requirement 11)</h4>
              </div>

              <div className="space-y-1.5">
                <label className="font-semibold text-slate-300">"মডারেটর প্যানেল" এর সিগনেচার হোস্টেড ইমেজ লিংক:</label>
                <div className="flex items-center gap-3">
                  <input
                    type="url"
                    placeholder="https://i.ibb.co/.../moderator-sign.png"
                    value={moderatorPanelSignatureImageUrl}
                    onChange={(e) => setModeratorPanelSignatureImageUrl(e.target.value)}
                    className="flex-1 bg-slate-900 border border-slate-800 rounded-xl p-2.5 text-xs text-slate-200 font-mono"
                  />
                  {moderatorPanelSignatureImageUrl && (
                    <div className="w-24 h-10 bg-white rounded-lg p-1 border border-slate-700 flex items-center justify-center shrink-0">
                      <img
                        src={extractDirectImageUrl(moderatorPanelSignatureImageUrl)}
                        alt="Preview"
                        className="max-h-full object-contain"
                      />
                    </div>
                  )}
                </div>
                <p className="text-[11px] text-slate-400">* স্টেটমেন্টে প্রধান অ্যাপ মডারেটরের স্বাক্ষরের জায়গায় "মডারেটর প্যানেল" এবং এই ইমেজটি দৃশ্যমান হবে।</p>
              </div>

              <div className="space-y-1.5 pt-2 border-t border-slate-900">
                <label className="font-semibold text-slate-300">সাধারণ সম্পাদক / নিরীক্ষক সিগনেচার হোস্টেড ইমেজ লিংক:</label>
                <div className="flex items-center gap-3">
                  <input
                    type="url"
                    placeholder="https://i.ibb.co/.../sec-sign.png"
                    value={generalSecretarySignatureImageUrl}
                    onChange={(e) => setGeneralSecretarySignatureImageUrl(e.target.value)}
                    className="flex-1 bg-slate-900 border border-slate-800 rounded-xl p-2.5 text-xs text-slate-200 font-mono"
                  />
                  {generalSecretarySignatureImageUrl && (
                    <div className="w-24 h-10 bg-white rounded-lg p-1 border border-slate-700 flex items-center justify-center shrink-0">
                      <img
                        src={extractDirectImageUrl(generalSecretarySignatureImageUrl)}
                        alt="Preview"
                        className="max-h-full object-contain"
                      />
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Manual Custom Font URL Injection (Requirement 8) */}
            <div className="space-y-1">
              <label className="font-semibold text-slate-300">ম্যানুয়াল ফন্ট সিএসএস লিংক (Google Fonts / Webfont URL):</label>
              <input
                type="url"
                placeholder="https://fonts.googleapis.com/css2?family=Tiro+Bangla..."
                value={customFontUrl}
                onChange={(e) => setCustomFontUrl(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-xs text-slate-200 font-mono"
              />
            </div>

            <div className="space-y-1">
              <label className="font-semibold text-slate-300">ফন্ট ফ্যামিলির নাম (Font Family):</label>
              <input
                type="text"
                placeholder="Hind Siliguri (Default)"
                value={customFontFamily}
                onChange={(e) => setCustomFontFamily(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-xs text-slate-200 font-mono"
              />
            </div>

            {/* Font Scale Control (Requirement 10) */}
            <div className="space-y-1">
              <label className="font-semibold text-slate-300">ফন্ট সাইজ স্কেল (Font Scaling):</label>
              <div className="flex gap-2">
                {(['small', 'medium', 'large'] as const).map((sz) => (
                  <button
                    key={sz}
                    type="button"
                    onClick={() => setFontSize(sz)}
                    className={`flex-1 py-2 rounded-xl text-xs font-bold capitalize transition-colors ${
                      fontSize === sz
                        ? 'bg-amber-600 text-white'
                        : 'bg-slate-950 text-slate-400 border border-slate-800'
                    }`}
                  >
                    {sz === 'small' ? 'ছোট (14px)' : sz === 'medium' ? 'স্বাভাবিক (16px)' : 'বড় (18px)'}
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-1">
              <label className="font-semibold text-slate-300">মাসিক জমা ডিউ ডেট (তারিখ):</label>
              <input
                type="number"
                min="1"
                max="31"
                value={monthlyDueDay}
                onChange={(e) => setMonthlyDueDay(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-xs text-slate-200 focus:ring-1 focus:ring-amber-500 font-bold"
              />
            </div>

            <div className="space-y-1">
              <label className="font-semibold text-slate-300">ডেভেলপার স্বীকৃতি টেক্সট (Attribution):</label>
              <input
                type="text"
                value={developerAttribution}
                onChange={(e) => setDeveloperAttribution(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-xs text-slate-200 focus:ring-1 focus:ring-amber-500 font-medium"
              />
            </div>

            <div className="space-y-1">
              <label className="font-semibold text-slate-300">ডেভেলপার হাইপারলিংক:</label>
              <input
                type="text"
                value={developerLink}
                onChange={(e) => setDeveloperLink(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-xs text-slate-200 focus:ring-1 focus:ring-amber-500 font-mono"
              />
            </div>

            <div className="space-y-1">
              <label className="font-semibold text-slate-300">ফুটার কপিরাইট টেক্সট:</label>
              <input
                type="text"
                value={footerText}
                onChange={(e) => setFooterText(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-xs text-slate-200 focus:ring-1 focus:ring-amber-500"
              />
            </div>

            <div className="space-y-1">
              <label className="font-semibold text-slate-300">মাসিক জমা ডিউ ডেট (তারিখ):</label>
              <input
                type="number"
                min="1"
                max="31"
                value={monthlyDueDay}
                onChange={(e) => setMonthlyDueDay(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-xs text-slate-200 focus:ring-1 focus:ring-amber-500 font-bold"
              />
            </div>

            {/* Requirement 4 & 6: Header Date Scale, Logo Size, Title Scale & Ticker Speed */}
            <div className="col-span-full p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-4">
              <h4 className="font-bold text-ink text-xs flex items-center gap-2 border-b border-slate-800 pb-2">
                <span>হেডার এলিমেন্ট সাইজ (+, -) ও স্ক্রোলিং স্পিড নিয়ন্ত্রণ</span>
              </h4>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                {/* 1. Header Date & Day Scale */}
                <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 space-y-2">
                  <span className="text-[11px] font-bold text-slate-300 block">তারিখ ও বার স্কেল (Date Scale):</span>
                  <div className="flex items-center justify-between gap-2">
                    <button
                      type="button"
                      onClick={() => updateConfig({ headerDateScale: Math.max(70, (config.headerDateScale || 100) - 5) })}
                      className="w-8 h-8 rounded-lg bg-slate-800 hover:bg-slate-700 text-ink font-bold text-sm flex items-center justify-center transition-colors cursor-pointer"
                    >
                      -
                    </button>
                    <span className="font-mono text-emerald-400 font-bold text-sm">
                      {config.headerDateScale || 100}%
                    </span>
                    <button
                      type="button"
                      onClick={() => updateConfig({ headerDateScale: Math.min(160, (config.headerDateScale || 100) + 5) })}
                      className="w-8 h-8 rounded-lg bg-slate-800 hover:bg-slate-700 text-ink font-bold text-sm flex items-center justify-center transition-colors cursor-pointer"
                    >
                      +
                    </button>
                  </div>
                </div>

                {/* 2. Header Logo Size */}
                <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 space-y-2">
                  <span className="text-[11px] font-bold text-slate-300 block">হেডার লোগো সাইজ (Logo Size):</span>
                  <div className="flex items-center justify-between gap-2">
                    <button
                      type="button"
                      onClick={() => updateConfig({ headerLogoSize: Math.max(28, (config.headerLogoSize || 44) - 2) })}
                      className="w-8 h-8 rounded-lg bg-slate-800 hover:bg-slate-700 text-ink font-bold text-sm flex items-center justify-center transition-colors cursor-pointer"
                    >
                      -
                    </button>
                    <span className="font-mono text-amber-400 font-bold text-sm">
                      {config.headerLogoSize || 44}px
                    </span>
                    <button
                      type="button"
                      onClick={() => updateConfig({ headerLogoSize: Math.min(72, (config.headerLogoSize || 44) + 2) })}
                      className="w-8 h-8 rounded-lg bg-slate-800 hover:bg-slate-700 text-ink font-bold text-sm flex items-center justify-center transition-colors cursor-pointer"
                    >
                      +
                    </button>
                  </div>
                </div>

                {/* 3. Header Title Scale */}
                <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 space-y-2">
                  <span className="text-[11px] font-bold text-slate-300 block">ফাউন্ডেশন নাম স্কেল (Title Scale):</span>
                  <div className="flex items-center justify-between gap-2">
                    <button
                      type="button"
                      onClick={() => updateConfig({ headerTitleScale: Math.max(70, (config.headerTitleScale || 100) - 5) })}
                      className="w-8 h-8 rounded-lg bg-slate-800 hover:bg-slate-700 text-ink font-bold text-sm flex items-center justify-center transition-colors cursor-pointer"
                    >
                      -
                    </button>
                    <span className="font-mono text-blue-400 font-bold text-sm">
                      {config.headerTitleScale || 100}%
                    </span>
                    <button
                      type="button"
                      onClick={() => updateConfig({ headerTitleScale: Math.min(160, (config.headerTitleScale || 100) + 5) })}
                      className="w-8 h-8 rounded-lg bg-slate-800 hover:bg-slate-700 text-ink font-bold text-sm flex items-center justify-center transition-colors cursor-pointer"
                    >
                      +
                    </button>
                  </div>
                </div>

                {/* 4. Ticker Scrolling Speed (Point 4) */}
                <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 space-y-2">
                  <span className="text-[11px] font-bold text-slate-300 block">ঘোষণা স্ক্রোলিং স্পিড (Ticker Speed):</span>
                  <div className="flex gap-1">
                    {(['slow', 'normal', 'fast'] as const).map((spd) => (
                      <button
                        key={spd}
                        type="button"
                        onClick={() => updateConfig({ tickerSpeed: spd })}
                        className={`flex-1 py-1.5 px-1 rounded-lg text-[10px] font-bold transition-all cursor-pointer ${
                          (config.tickerSpeed || 'normal') === spd
                            ? 'bg-amber-600 text-white shadow'
                            : 'bg-slate-950 text-slate-400 border border-slate-800'
                        }`}
                      >
                        {spd === 'slow' ? 'ধীর' : spd === 'normal' ? 'স্বাভাবিক' : 'দ্রুত'}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* Requirement 14: Joint Bank Account Holders Editor (3 Demo members & edit) */}
            <div className="col-span-full p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-3">
              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <div>
                  <h4 className="font-bold text-ink text-xs flex items-center gap-2">
                    <Building2 className="w-4 h-4 text-emerald-400" />
                    <span>যৌথ ব্যাংক একাউন্ট হোল্ডারদের তালিকা (৩ জনের ডেমু ও এডিট)</span>
                  </h4>
                  <p className="text-[11px] text-slate-400 mt-0.5">
                    আমাদের সম্পর্কে ও ব্যাংক ইনফরমেশন উভয় ট্যাবে এই তালিকাটি সিংক থাকবে।
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    const current = config.jointBankAccountHolders || [
                      'তানভীর আহমেদ (সভাপতি)',
                      'সাবরিনা আক্তার (সাধারণ সম্পাদক)',
                      'রাশেদুল করিম (কোষাধ্যক্ষ)',
                    ];
                    updateConfig({ jointBankAccountHolders: [...current, 'নতুন হোল্ডার (পদবি)'] });
                  }}
                  className="py-1 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-colors cursor-pointer"
                >
                  + নতুন যোগ করুন
                </button>
              </div>

              <div className="space-y-2">
                {(config.jointBankAccountHolders || [
                  'তানভীর আহমেদ (সভাপতি)',
                  'সাবরিনা আক্তার (সাধারণ সম্পাদক)',
                  'রাশেদুল করিম (কোষাধ্যক্ষ)',
                ]).map((holder, idx) => (
                  <div key={idx} className="flex items-center gap-2">
                    <span className="text-amber-400 font-bold font-mono text-xs w-5">{idx + 1}.</span>
                    <input
                      type="text"
                      value={holder}
                      onChange={(e) => {
                        const next = [...(config.jointBankAccountHolders || [
                          'তানভীর আহমেদ (সভাপতি)',
                          'সাবরিনা আক্তার (সাধারণ সম্পাদক)',
                          'রাশেদুল করিম (কোষাধ্যক্ষ)',
                        ])];
                        next[idx] = e.target.value;
                        updateConfig({ jointBankAccountHolders: next });
                      }}
                      className="flex-1 bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-ink focus:ring-1 focus:ring-amber-500"
                    />
                    <button
                      type="button"
                      onClick={() => {
                        const current = config.jointBankAccountHolders || [
                          'তানভীর আহমেদ (সভাপতি)',
                          'সাবরিনা আক্তার (সাধারণ সম্পাদক)',
                          'রাশেদুল করিম (কোষাধ্যক্ষ)',
                        ];
                        const next = current.filter((_, i) => i !== idx);
                        updateConfig({ jointBankAccountHolders: next });
                      }}
                      className="p-2 rounded-xl bg-rose-950/60 text-rose-400 hover:bg-rose-900 border border-rose-900/50 cursor-pointer"
                      title="অপসারণ করুন"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="pt-3 border-t border-slate-800 flex justify-end">
            <button
              type="submit"
              className="py-2.5 px-5 rounded-xl bg-amber-600 hover:bg-amber-500 text-white font-bold text-xs transition-colors flex items-center gap-1.5"
            >
              <Save className="w-4 h-4" />
              <span>পরিবর্তন সংরক্ষণ করুন</span>
            </button>
          </div>
        </form>
      )}

      {/* Tab 2: Application Releases & APK Management (Section 21) */}
      {activeTab === 'RELEASES' && (
        <div className="space-y-4">
          {/* Publish New Release Form */}
          <form onSubmit={handlePublishRelease} className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4 text-xs">
            <h3 className="font-bold text-ink text-base flex items-center gap-2">
              <DownloadCloud className="w-5 h-5 text-amber-400" />
              <span>নতুন এপিকে সংস্করণ প্রকাশ ও ডিস্ট্রিবিউশন (Publish APK)</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="space-y-1">
                <label className="font-semibold text-slate-300">ভার্সন নাম (Version Name):</label>
                <input
                  type="text"
                  value={newVersionName}
                  onChange={(e) => setNewVersionName(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-xs text-slate-200 font-mono"
                  placeholder="v1.2.0"
                  required
                />
              </div>

              <div className="space-y-1">
                <label className="font-semibold text-slate-300">বিল্ড কোড (Version Code):</label>
                <input
                  type="number"
                  value={newVersionCode}
                  onChange={(e) => setNewVersionCode(Number(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-xs text-slate-200 font-mono font-bold"
                  required
                />
              </div>

              <div className="space-y-1 flex flex-col justify-center">
                <label className="font-semibold text-slate-300">বাধ্যতামূলক আপডেট:</label>
                <label className="flex items-center gap-2 cursor-pointer mt-1">
                  <input
                    type="checkbox"
                    checked={isMandatory}
                    onChange={(e) => setIsMandatory(e.target.checked)}
                    className="w-4 h-4 rounded text-amber-600 focus:ring-amber-500"
                  />
                  <span className="text-slate-300">সকল গ্রাহকের জন্য বাধ্যতামূলক</span>
                </label>
              </div>

              <div className="col-span-full space-y-1">
                <label className="font-semibold text-slate-300">
                  এপিকে ফাইল ইনপুট / ডাউনলোড লিংক (APK File / Direct Hosted Download Link):
                </label>
                <input
                  type="url"
                  placeholder="https://.../basis-foundation-v1.3.0.apk বা ড্রাইভ/ড্রপবক্স ডিরেক্ট লিংক"
                  value={apkDownloadUrl}
                  onChange={(e) => setApkDownloadUrl(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-xs text-ink font-mono"
                  required
                />
                <p className="text-[11px] text-slate-400">
                  * এখানে এপিকে ডাউনলোড লিংক প্রদান করলে সকল ব্যবহারকারীর হোম স্ক্রিনে বাধ্যতামূলক/ঐচ্ছিক আপডেট পপআপ যাবে এবং ডিফল্ট ব্রাউজারে ডাউনলোড হবে।
                </p>
              </div>

              <div className="col-span-full space-y-1">
                <label className="font-semibold text-slate-300">রিলিজ নোট (Release Notes):</label>
                <textarea
                  rows={2}
                  value={releaseNotes}
                  onChange={(e) => setReleaseNotes(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-xs text-slate-200"
                  required
                />
              </div>
            </div>

            <div className="pt-2 flex justify-end">
              <button
                type="submit"
                className="py-2.5 px-5 rounded-xl bg-amber-600 hover:bg-amber-500 text-white font-bold text-xs transition-colors flex items-center gap-1.5"
              >
                <DownloadCloud className="w-4 h-4" />
                <span>এপিকে রিলিজ প্রকাশ করুন</span>
              </button>
            </div>
          </form>

          {/* Published Releases List */}
          <div className="space-y-3">
            <h4 className="font-bold text-ink text-sm">প্রকাশিত সংস্করণসমূহ ({toBengaliNumerals(releases.length)})</h4>
            {releases.map((rel) => (
              <div
                key={rel.id}
                className="bg-slate-900 border border-slate-800 rounded-2xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-ink text-base">{rel.versionName}</span>
                    <span className="font-mono text-[11px] px-2 py-0.5 rounded bg-slate-950 text-slate-300 border border-slate-800">
                      Code: {rel.versionCode}
                    </span>
                    {rel.isMandatory && (
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-rose-500/20 text-rose-400 border border-rose-500/30">
                        বাধ্যতামূলক
                      </span>
                    )}
                  </div>
                  <p className="text-slate-400">{rel.releaseNotes}</p>
                  <p className="font-mono text-[10px] text-slate-500">SHA256: {rel.apkSha256}</p>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <button
                    onClick={() => setActiveUpdateDialog(rel)}
                    className="py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-emerald-400 font-semibold text-xs transition-colors flex items-center gap-1"
                  >
                    <span>আপডেট ডায়ালগ টেস্ট করুন</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab 3: Backup & Recovery (Section 20) */}
      {activeTab === 'BACKUP' && (
        <div className="space-y-4 text-xs">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-3">
            <h3 className="font-bold text-ink text-base flex items-center gap-2">
              <Database className="w-5 h-5 text-emerald-400" />
              <span>পূর্ণাঙ্গ ডাটাবেজ ব্যাকআপ ও রিস্টোর (Backup & Recovery)</span>
            </h3>
            <p className="text-slate-400 leading-relaxed">
              সদস্য প্রোফাইল, সঞ্চয় লেনদেন, ২/৩ সিলিং ভোট ইতিহাস, রসিদ এবং অডিট লগসমূহ একটি সম্পূর্ণ সুরক্ষিত ভেরিফাইড JSON ফাইলে এক্সপোর্ট করুন অথবা পূর্বের ব্যাকআপ থেকে রিস্টোর করুন।
            </p>

            <div className="pt-2 flex flex-wrap gap-3">
              <button
                onClick={handleExportBackup}
                className="py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs transition-colors flex items-center gap-1.5"
              >
                <DownloadCloud className="w-4 h-4" />
                <span>সম্পূর্ণ ডাটাবেজ ব্যাকআপ ডাউনলোড (JSON)</span>
              </button>

              <button
                onClick={resetToInitialDemo}
                className="py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold text-xs transition-colors flex items-center gap-1.5"
              >
                <RefreshCw className="w-4 h-4" />
                <span>ডেমো ডাটা রিসেট করুন</span>
              </button>
            </div>
          </div>

          {/* Restore JSON input */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-3">
            <h4 className="font-bold text-ink text-sm">ব্যাকআপ থেকে ডাটা রিস্টোর (Restore from JSON)</h4>
            <textarea
              rows={4}
              placeholder="এখানে এক্সপোর্টকৃত ব্যাকআপ JSON কোড পেস্ট করুন..."
              value={restoreJsonInput}
              onChange={(e) => setRestoreJsonInput(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs text-slate-200 font-mono focus:ring-1 focus:ring-amber-500"
            />
            {restoreFeedback && (
              <p className="text-xs text-amber-400 font-semibold">{restoreFeedback}</p>
            )}

            <button
              onClick={handleExecuteRestore}
              className="py-2 px-4 rounded-xl bg-amber-600 hover:bg-amber-500 text-white font-bold text-xs shadow transition-colors flex items-center gap-1.5"
            >
              <Upload className="w-4 h-4" />
              <span>ডাটা রিস্টোর প্রক্রিয়া সম্পন্ন করুন</span>
            </button>
          </div>
        </div>
      )}

      {/* Tab 4: Audit Logs (Section 26) */}
      {activeTab === 'AUDIT' && (
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-ink text-base">সিস্টেম অডিট ট্রেইল (Immutable Audit Logs)</h3>
            <span className="text-xs text-slate-400">সর্বশেষ {toBengaliNumerals(auditLogs.length)} টি রেকর্ড</span>
          </div>

          <div className="space-y-2">
            {auditLogs.map((log) => (
              <div
                key={log.id}
                className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 text-xs space-y-1 font-mono"
              >
                <div className="flex items-center justify-between text-slate-400 text-[11px]">
                  <span className="text-emerald-400 font-bold">[{log.actionType}]</span>
                  <span>{new Date(log.timestamp).toLocaleString('en-GB')}</span>
                </div>
                <p className="text-slate-200 font-sans">{log.details}</p>
                <div className="text-[10px] text-slate-500 flex items-center gap-2">
                  <span>কর্তা: {log.actorName} ({log.actorRole})</span>
                  <span>•</span>
                  <span>টার্গেট: {log.targetType} #{log.targetId}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab: Member & Moderator Roles Management */}
      {activeTab === 'MEMBERS_ROLES' && (
        <div className="space-y-4 text-xs">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-bold text-ink text-base flex items-center gap-2">
                  <UserCheck className="w-5 h-5 text-amber-400" />
                  <span>সদস্য পদবী ও মডারেটর ভূমিকা নিয়ন্ত্রণ (Role & Access Management)</span>
                </h3>
                <p className="text-slate-400 mt-0.5">
                  প্রধান অ্যাপ মডারেটর যেকোনো সদস্যের রোল (মডারেটর বা সাধারণ সদস্য) পরিবর্তন ও স্থিতি নির্ধারণ করতে পারবেন।
                </p>
              </div>
              <span className="text-xs font-bold px-3 py-1 rounded-xl bg-slate-800 text-slate-300">
                মোট: {toBengaliNumerals(realUsers.length)} জন সদস্য
              </span>
            </div>

            <div className="space-y-2.5 pt-2">
              {realUsers.map((u) => (
                <div
                  key={u.id}
                  className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                >
                  <div className="flex items-center gap-3">
                    <Avatar
                      src={u.avatarUrl}
                      name={u.name}
                      size="md"
                      ringColor={u.role === 'APP_MODERATOR' ? 'ring-amber-500' : u.role === 'MODERATOR' ? 'ring-blue-500' : 'ring-slate-700'}
                    />
                    <div>
                      {editingMemberId === u.id ? (
                        <div className="flex items-center gap-1.5 my-1">
                          <input
                            type="text"
                            value={editingMemberName}
                            onChange={(e) => setEditingMemberName(e.target.value)}
                            className="bg-slate-900 border border-slate-700 rounded-lg px-2 py-1 text-xs text-ink font-bold w-40"
                          />
                          <button
                            type="button"
                            onClick={() => {
                              if (editingMemberName.trim()) {
                                updateUserProfile(u.id, { name: editingMemberName.trim() });
                                setEditingMemberId(null);
                              }
                            }}
                            className="py-1 px-2 rounded-lg bg-emerald-600 text-white text-[11px] font-bold"
                          >
                            সংরক্ষণ
                          </button>
                          <button
                            type="button"
                            onClick={() => setEditingMemberId(null)}
                            className="py-1 px-2 rounded-lg bg-slate-800 text-slate-400 text-[11px]"
                          >
                            বাতিল
                          </button>
                        </div>
                      ) : (
                        <div className="flex items-center gap-2">
                          <strong className="text-ink font-bold text-sm">{u.name}</strong>
                          <button
                            type="button"
                            onClick={() => {
                              setEditingMemberId(u.id);
                              setEditingMemberName(u.name);
                            }}
                            title="নাম এডিট করুন"
                            className="text-slate-400 hover:text-ink p-0.5 rounded cursor-pointer"
                          >
                            <Edit3 className="w-3.5 h-3.5 text-amber-400" />
                          </button>
                          <span className="font-mono text-emerald-400 text-xs font-bold">({u.memberId})</span>
                        </div>
                      )}
                      <p className="text-[11px] text-slate-400">{u.phone} • যোগদানের তারিখ: {u.joinDate}</p>
                    </div>
                  </div>

                  <div className="flex flex-wrap items-center gap-2 self-end sm:self-center">
                    {/* Requirement 11: Edit Member / Moderator Designation */}
                    <div className="flex items-center gap-1">
                      <label className="text-[10px] text-slate-400 font-bold">পদবি (Designation):</label>
                      <input
                        type="text"
                        placeholder="যেমন: সভাপতি / সাধারণ সম্পাদক"
                        defaultValue={u.moderatorTitle || ''}
                        onBlur={(e) => {
                          if (e.target.value !== (u.moderatorTitle || '')) {
                            updateUserDesignation(u.id, e.target.value.trim(), u.role);
                          }
                        }}
                        className="bg-slate-900 border border-slate-700 text-xs text-amber-300 font-bold rounded-xl px-2.5 py-1.5 w-36 focus:outline-none focus:ring-1 focus:ring-amber-500"
                      />
                    </div>

                    <div className="flex items-center gap-1">
                      <label className="text-[10px] text-slate-400 font-bold">রোল:</label>
                      <select
                        value={u.role}
                        onChange={(e) => {
                          const newRole = e.target.value as UserRole;
                          updateUserProfile(u.id, {
                            role: newRole,
                            isPublicModerator: newRole !== 'MEMBER',
                          });
                          triggerSuccess(`${u.name} এর রোল "${newRole}" এ পরিবর্তিত হয়েছে!`);
                        }}
                        disabled={u.id === currentUser.id}
                        className="bg-slate-900 border border-slate-700 text-xs text-ink font-bold rounded-xl px-2 py-1.5 focus:outline-none focus:ring-1 focus:ring-amber-500 disabled:opacity-60 cursor-pointer"
                      >
                        <option value="MEMBER">সাধারণ সদস্য (MEMBER)</option>
                        <option value="MODERATOR">মডারেটর (MODERATOR)</option>
                        <option value="APP_MODERATOR">অ্যাপ মডারেটর (APP_MODERATOR)</option>
                      </select>
                    </div>

                    <div className="flex items-center gap-1">
                      <label className="text-[10px] text-slate-400 font-bold">স্ট্যাটাস:</label>
                      <select
                        value={u.status}
                        onChange={(e) => {
                          updateUserProfile(u.id, { status: e.target.value as AccountStatus });
                          triggerSuccess(`${u.name} এর একাউন্ট স্ট্যাটাস আপডেট হয়েছে!`);
                        }}
                        disabled={u.id === currentUser.id}
                        className="bg-slate-900 border border-slate-700 text-xs text-emerald-400 font-bold rounded-xl px-2 py-1.5 focus:outline-none focus:ring-1 focus:ring-amber-500 disabled:opacity-60 cursor-pointer"
                      >
                        <option value="APPROVED">অনুমোদিত (APPROVED)</option>
                        <option value="PENDING">অপেক্ষমান (PENDING)</option>
                        <option value="SUSPENDED">স্থগিত (SUSPENDED)</option>
                      </select>
                    </div>

                    {/* Requirement 3: Remove Member button for App Moderator */}
                    {u.id !== currentUser.id && (
                      <button
                        type="button"
                        onClick={() => {
                          if (confirm(`আপনি কি নিশ্চিতভাবে ${u.name} (${u.memberId}) এর সকল তথ্য স্থায়ীভাবে অপসারণ বা রিমুভ করতে চান?`)) {
                            removeUser(u.id);
                          }
                        }}
                        title="সদস্য মুছে ফেলুন"
                        className="p-1.5 rounded-xl bg-rose-950/70 hover:bg-rose-900 text-rose-400 border border-rose-800 transition-colors cursor-pointer"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Tab: New Account Registrations Pending Approval (Requirement 17) */}
      {activeTab === 'PENDING_ACCOUNTS' && (
        <div className="space-y-4 text-xs">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-bold text-ink text-base flex items-center gap-2">
                  <UserPlus className="w-5 h-5 text-amber-400" />
                  <span>নতুন সদস্য অ্যাকাউন্ট অনুমোদন ড্যাশবোর্ড (Pending Registrations)</span>
                </h3>
                <p className="text-slate-400 mt-0.5">
                  সদস্যদের নতুন রেজিস্ট্রেশন আবেদন যাচাই করে অনুমোদন (Approve) বা বাতিল (Reject) করুন। অনুমোদন পেলে সদস্য লগইন করতে পারবেন।
                </p>
              </div>
              <span className="text-xs font-bold px-3 py-1 rounded-xl bg-amber-500/20 text-amber-300 border border-amber-500/30">
                অপেক্ষমান: {toBengaliNumerals(users.filter((u) => u.status === 'PENDING').length)} জন
              </span>
            </div>

            <div className="space-y-3 pt-2">
              {users.filter((u) => u.status === 'PENDING').length === 0 ? (
                <div className="p-8 text-center bg-slate-950/60 rounded-2xl border border-slate-800 space-y-2">
                  <CheckCircle2 className="w-10 h-10 text-emerald-400 mx-auto" />
                  <h4 className="font-bold text-ink text-sm">কোনো নতুন অ্যাকাউন্ট রেজিস্ট্রেশন অপেক্ষমান নেই</h4>
                  <p className="text-slate-400 text-xs">
                    নতুন কেউ "অ্যাকাউন্ট তৈরি করুন" অপশন দিয়ে রেজিস্ট্রেশন করলে এখানে তাৎক্ষণিক প্রদর্শিত হবে।
                  </p>
                </div>
              ) : (
                users
                  .filter((u) => u.status === 'PENDING')
                  .map((pendingUser) => (
                    <div
                      key={pendingUser.id}
                      className="p-4 rounded-2xl bg-slate-950 border border-amber-600/40 flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-md"
                    >
                      <div className="flex items-start sm:items-center gap-3.5">
                        <Avatar
                          src={pendingUser.avatarUrl}
                          name={pendingUser.name}
                          size="lg"
                          ringColor="ring-amber-500"
                        />
                        <div className="space-y-1">
                          <div className="flex items-center gap-2 flex-wrap">
                            <h4 className="font-bold text-ink text-base">{pendingUser.name}</h4>
                            <span className="font-mono text-[11px] px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30 font-bold">
                              {pendingUser.memberId}
                            </span>
                            <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-slate-800 text-slate-300">
                              {pendingUser.gender === 'MALE' ? 'পুরুষ' : pendingUser.gender === 'FEMALE' ? 'নারী' : 'অন্যান্য'}
                            </span>
                          </div>
                          <div className="flex items-center gap-2 text-slate-400 text-xs flex-wrap">
                            <span>📞 {pendingUser.phone}</span>
                            <span>•</span>
                            <span>✉️ {pendingUser.email || 'মেইল নেই'}</span>
                            <span>•</span>
                            <span>আবেদনের তারিখ: {pendingUser.joinDate}</span>
                          </div>
                          {pendingUser.nomineeName && (
                            <div className="text-[11px] text-slate-400 bg-slate-900/80 p-2 rounded-xl border border-slate-800">
                              নমিনী: <strong className="text-slate-200">{pendingUser.nomineeName}</strong> ({pendingUser.nomineeRelation}) • ফোন: {pendingUser.nomineePhone}
                            </div>
                          )}
                        </div>
                      </div>

                      <div className="flex items-center gap-2 shrink-0 self-end sm:self-center">
                        <button
                          type="button"
                          onClick={() => approveUserAccount(pendingUser.id)}
                          className="py-2 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs transition-all flex items-center gap-1.5 cursor-pointer"
                        >
                          <Check className="w-4 h-4" />
                          <span>অনুমোদন করুন (Approve)</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => {
                            if (confirm(`আপনি কি ${pendingUser.name} এর আবেদনটি প্রত্যাখ্যান করতে চান?`)) {
                              rejectUserAccount(pendingUser.id);
                            }
                          }}
                          className="py-2 px-3 rounded-xl bg-rose-950 hover:bg-rose-900 text-rose-300 font-bold text-xs border border-rose-800 transition-all flex items-center gap-1 cursor-pointer"
                        >
                          <X className="w-4 h-4" />
                          <span>প্রত্যাখ্যান</span>
                        </button>
                      </div>
                    </div>
                  ))
              )}
            </div>
          </div>
        </div>
      )}

      {/* Tab: Font Selection & Weight Rules (Requirement 5) */}
      {activeTab === 'FONTS' && (
        <div className="space-y-4 text-xs">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4">
            <div>
              <h3 className="font-bold text-ink text-base flex items-center gap-2">
                <Type className="w-5 h-5 text-amber-400" />
                <span>ফন্ট নির্বাচন ও টাইপোগ্রাফি ওয়েট কনফিগারেশন</span>
              </h3>
              <p className="text-slate-400 mt-0.5">
                ফন্টের লাইট (৩০০) ভার্সন বন্ধ রাখা হয়েছে। সংখ্যা ও টাকার অংক Hind Siliguri ফন্টে যাতে না ভাঙে সেজন্য সর্বদা বোল্ড ওয়েট প্রযুক্ত থাকবে।
              </p>
            </div>

            {/* Font Family Quick Presets */}
            <div className="space-y-2 bg-slate-950 p-4 rounded-2xl border border-slate-800">
              <label className="font-bold text-slate-200 block text-xs">জনপ্রিয় বাংলা ফন্ট প্রিসেটসমূহ:</label>
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-2.5">
                {[
                  {
                    name: 'Hind Siliguri (ডিফল্ট ফিক্সড)',
                    family: 'Hind Siliguri',
                    url: 'https://fonts.googleapis.com/css2?family=Hind+Siliguri:wght@400;500;600;700;800&display=swap',
                    desc: 'সবচেয়ে স্পষ্ট বাংলা সংখ্যা ও রসিদ টাইপোগ্রাফি',
                  },
                  {
                    name: 'Noto Sans Bengali',
                    family: 'Noto Sans Bengali',
                    url: 'https://fonts.googleapis.com/css2?family=Noto+Sans+Bengali:wght@400;500;600;700;800&display=swap',
                    desc: 'গুগলের সার্বজনীন স্ট্যান্ডার্ড বাংলা ফন্ট',
                  },
                  {
                    name: 'Tiro Bangla',
                    family: 'Tiro Bangla',
                    url: 'https://fonts.googleapis.com/css2?family=Tiro+Bangla:ital@0;1&display=swap',
                    desc: 'ঐতিহ্যবাহী ক্ল্যাসিক্যাল বুক স্টাইল বাংলা ফন্ট',
                  },
                  {
                    name: 'Anek Bangla',
                    family: 'Anek Bangla',
                    url: 'https://fonts.googleapis.com/css2?family=Anek+Bangla:wght@400;500;600;700;800&display=swap',
                    desc: 'আধুনিক জ্যামিতিক টেক্সটাইল ফন্ট',
                  },
                ].map((preset) => (
                  <button
                    key={preset.family}
                    type="button"
                    onClick={() => {
                      setCustomFontFamily(preset.family);
                      setCustomFontUrl(preset.url);
                      updateConfig({
                        customFontFamily: preset.family,
                        customFontUrl: preset.url,
                      });
                      triggerSuccess(`ফন্ট সফলভাবে "${preset.family}" এ পরিবর্তিত হয়েছে!`);
                    }}
                    className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                      customFontFamily === preset.family
                        ? 'bg-amber-600/20 border-amber-500 text-ink shadow-sm'
                        : 'bg-slate-900 border-slate-800 text-slate-300 hover:border-slate-700'
                    }`}
                  >
                    <div className="font-bold text-xs text-ink">{preset.name}</div>
                    <p className="text-[10px] text-slate-400 mt-1 leading-tight">{preset.desc}</p>
                  </button>
                ))}
              </div>
            </div>

            {/* Typography Weight Strategy Options */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 bg-slate-950 p-4 rounded-2xl border border-slate-800">
              <div className="space-y-1">
                <span className="font-bold text-slate-300 block">১. সংখ্যা ও টাকার পরিমাণ:</span>
                <div className="p-2.5 rounded-xl bg-slate-900 border border-emerald-500/40 text-emerald-400 font-bold text-xs">
                  সর্বদা Bold (৭০০/৮০০) — ফিক্সড
                </div>
                <p className="text-[10px] text-slate-400">১ ও বাংলা সংখ্যা কখনোই ভাঙবে না</p>
              </div>

              <div className="space-y-1">
                <span className="font-bold text-slate-300 block">২. সাধারণ টেক্সট ও বিবরণ:</span>
                <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 text-ink font-bold text-xs">
                  Regular (৪০০) ও Medium (৫০০)
                </div>
                <p className="text-[10px] text-slate-400">লাইট ভার্সন (৩০০) চিরতরে নিষিদ্ধ</p>
              </div>

              <div className="space-y-1">
                <span className="font-bold text-slate-300 block">৩. হেডিং, টাইটেল ও বাটন:</span>
                <div className="p-2.5 rounded-xl bg-slate-900 border border-amber-500/40 text-amber-300 font-bold text-xs">
                  Bold (৭০০) ও Black (৮০০)
                </div>
                <p className="text-[10px] text-slate-400">উচ্চ কনট্রাস্ট ও আধুনিক লুক</p>
              </div>
            </div>

            {/* Requirement 9: Manual Font File Upload (.ttf, .woff, .woff2, .otf) */}
            <div className="p-4 rounded-2xl bg-slate-950 border border-amber-500/30 space-y-3">
              <div className="flex items-center justify-between">
                <label className="font-bold text-amber-300 block text-xs flex items-center gap-1.5">
                  <Upload className="w-4 h-4 text-amber-400" />
                  <span>ম্যানুয়াল ফন্ট ফাইল আপলোড (.ttf, .woff, .woff2, .otf):</span>
                </label>
                <span className="text-[10px] text-amber-400 font-bold px-2 py-0.5 rounded bg-amber-500/10 border border-amber-500/20">
                  ইনস্ট্যান্ট অ্যাপ্লাই
                </span>
              </div>
              <p className="text-slate-400 text-xs leading-relaxed">
                আপনার ডিভাইস থেকে যেকোনো কাস্টম বাংলা ফন্ট ফাইল (.ttf / .woff / .otf) সরাসরি নির্বাচন করুন। ফাইলটি নির্বাচন করার সাথে সাথে পুরো অ্যাপের ইন্টারফেসে স্বয়ংক্রিয়ভাবে কার্যকর (Apply) হবে।
              </p>

              <input
                type="file"
                accept=".ttf,.woff,.woff2,.otf"
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (!file) return;
                  const reader = new FileReader();
                  reader.onload = (event) => {
                    const dataUrl = event.target?.result as string;
                    const fontName = file.name.replace(/\.[^/.]+$/, '').replace(/[^a-zA-Z0-9]/g, '');
                    updateConfig({
                      uploadedFontDataUrl: dataUrl,
                      uploadedFontName: fontName,
                      customFontFamily: fontName,
                    });
                    triggerSuccess(`ফন্ট "${file.name}" সফলভাবে আপলোড ও অ্যাপে প্রয়োগ করা হয়েছে!`);
                  };
                  reader.readAsDataURL(file);
                }}
                className="block w-full text-xs text-slate-300 file:mr-3 file:py-2 file:px-4 file:rounded-xl file:border-0 file:text-xs file:font-bold file:bg-amber-600 file:text-white hover:file:bg-amber-500 cursor-pointer"
              />

              {config.uploadedFontDataUrl && (
                <div className="flex items-center justify-between text-xs p-3 rounded-xl bg-emerald-950/40 border border-emerald-500/40 text-emerald-300">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                    <span className="font-bold">সক্রিয় আপলোডকৃত ফন্ট: {config.uploadedFontName || 'CustomFont'}</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      updateConfig({
                        uploadedFontDataUrl: undefined,
                        uploadedFontName: undefined,
                        customFontFamily: 'Hind Siliguri',
                      });
                      triggerSuccess('আপলোডকৃত ফন্ট বাতিল করে ডিফল্ট Hind Siliguri ফন্টে ফিরিয়ে আনা হয়েছে।');
                    }}
                    className="text-rose-400 hover:text-rose-300 font-bold underline cursor-pointer text-xs"
                  >
                    ডিফল্ট ফন্টে ফিরুন
                  </button>
                </div>
              )}
            </div>

            {/* Live Font Testing & Rendering Preview */}
            <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <span className="font-bold text-emerald-400 text-xs">লাইভ ফন্ট ও সংখ্যা প্রিভিউ:</span>
                <span className="font-mono text-[11px] text-slate-400 font-bold">
                  ফন্ট ফ্যামিলি: {customFontFamily || 'Hind Siliguri'}
                </span>
              </div>
              <div className="space-y-1 text-ink">
                <p className="text-base font-bold text-ink">
                  বেসিস ফাউন্ডেশন সমবায় সঞ্চয় ও ব্যবস্থাপনা প্ল্যাটফর্ম
                </p>
                <p className="text-xs text-slate-300 font-medium">
                  ক খ গ ঘ ঙ চ ছ জ ঝ ঞ ট ঠ ড ঢ ণ ত থ দ ধ ন প ফ ব ভ ম য র ল শ ষ স হ ড় ঢ় য় ৎ ং ঃ ঁ
                </p>
                <div className="flex items-center gap-4 text-emerald-400 font-bold text-sm pt-1">
                  <span>বাংলা সংখ্যা: ১ ২ ৩ ৪ ৫ ৬ ৭ ৮ ৯ ০</span>
                  <span>•</span>
                  <span>নমুনা কিস্তি: ৳১,৫০০.০০</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tab: Tab Re-ordering & Custom Titles (Requirement 16) */}
      {activeTab === 'TABS_ORDER' && (
        <div className="space-y-4 text-xs">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
              <div>
                <h3 className="font-bold text-ink text-base flex items-center gap-2">
                  <ListOrdered className="w-5 h-5 text-amber-400" />
                  <span>ট্যাব রি-অর্ডার ও কাস্টম শিরোনাম ব্যবস্থাপনা</span>
                </h3>
                <p className="text-slate-400 mt-0.5">
                  মেনু এবং স্ক্রিনের ট্যাবের অবস্থান উপরে/নিচে স্থানান্তর করুন এবং পছন্দমতো বাংলা শিরোনাম লিখুন।
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    const defaultOrder = DEFAULT_APP_TABS.map((t) => t.id);
                    setTabsOrder(defaultOrder);
                    setCustomTitles({});
                    updateConfig({
                      navTabsOrder: defaultOrder,
                      customTabTitles: {},
                    });
                    triggerSuccess('ট্যাবের বিন্যাস ডিফল্ট অবস্থায় ফিরিয়ে আনা হয়েছে!');
                  }}
                  className="py-1.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold transition-colors cursor-pointer"
                >
                  ডিফল্ট অর্ডার
                </button>

                <button
                  type="button"
                  onClick={() => {
                    updateConfig({
                      navTabsOrder: tabsOrder,
                      customTabTitles: customTitles,
                    });
                    triggerSuccess('ট্যাবের নতুন ক্রম ও কাস্টম শিরোনাম সফলভাবে সংরক্ষিত হয়েছে!');
                  }}
                  className="py-1.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold transition-all cursor-pointer flex items-center gap-1.5"
                >
                  <Save className="w-4 h-4" />
                  <span>সংরক্ষণ করুন</span>
                </button>
              </div>
            </div>

            {/* List of tabs with up/down arrows and title editing */}
            <div className="space-y-2">
              {tabsOrder.map((tabId, index) => {
                const defaultTab = DEFAULT_APP_TABS.find((t) => t.id === tabId) || {
                  id: tabId,
                  label: tabId,
                };
                const currentLabel = customTitles[tabId] !== undefined ? customTitles[tabId] : defaultTab.label;

                return (
                  <div
                    key={tabId}
                    className="p-3 rounded-2xl bg-slate-950 border border-slate-800 hover:border-slate-700 flex items-center justify-between gap-3 transition-colors"
                  >
                    <div className="flex items-center gap-3 min-w-0 flex-1">
                      <span className="w-6 h-6 rounded-lg bg-slate-900 text-amber-400 font-bold flex items-center justify-center text-xs shrink-0">
                        {toBengaliNumerals(index + 1)}
                      </span>

                      <div className="min-w-0 flex-1">
                        <input
                          type="text"
                          value={currentLabel}
                          onChange={(e) => {
                            const val = e.target.value;
                            setCustomTitles((prev) => ({ ...prev, [tabId]: val }));
                          }}
                          placeholder={defaultTab.label}
                          className="bg-slate-900 border border-slate-800 rounded-xl px-3 py-1.5 text-xs text-ink font-bold w-full max-w-sm focus:ring-1 focus:ring-amber-500"
                        />
                        <span className="text-[10px] text-slate-500 font-mono ml-1">
                          কী: {tabId} (ডিফল্ট: {defaultTab.label})
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center gap-1 shrink-0">
                      <button
                        type="button"
                        disabled={index === 0}
                        onClick={() => {
                          if (index === 0) return;
                          const next = [...tabsOrder];
                          const tmp = next[index - 1];
                          next[index - 1] = next[index];
                          next[index] = tmp;
                          setTabsOrder(next);
                        }}
                        title="উপরে নিন"
                        className="p-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 disabled:opacity-30 text-slate-300 hover:text-ink transition-colors cursor-pointer"
                      >
                        <ArrowUp className="w-4 h-4" />
                      </button>

                      <button
                        type="button"
                        disabled={index === tabsOrder.length - 1}
                        onClick={() => {
                          if (index === tabsOrder.length - 1) return;
                          const next = [...tabsOrder];
                          const tmp = next[index + 1];
                          next[index + 1] = next[index];
                          next[index] = tmp;
                          setTabsOrder(next);
                        }}
                        title="নিচে নিন"
                        className="p-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 disabled:opacity-30 text-slate-300 hover:text-ink transition-colors cursor-pointer"
                      >
                        <ArrowDown className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* Tab: Native Android Architecture Spec & APK Export */}
      {activeTab === 'ANDROID_SPEC' && (
        <div className="space-y-4">
          <NativeAndroidSpecView />
        </div>
      )}
    </div>
  );
};
