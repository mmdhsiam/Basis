import { initializeApp, getApps, getApp, FirebaseApp } from 'firebase/app';
import { getAuth, Auth, GoogleAuthProvider, signInWithPopup, signInWithEmailAndPassword, createUserWithEmailAndPassword } from 'firebase/auth';
import { getFirestore, Firestore, collection, doc, setDoc, getDocs, onSnapshot, query, orderBy } from 'firebase/firestore';

/**
 * Android App Package: org.basis.foundation
 * Firebase Client Configuration & Firestore Real-time Synchronization
 */

export interface FirebaseCustomConfig {
  apiKey: string;
  authDomain: string;
  projectId: string;
  storageBucket: string;
  messagingSenderId: string;
  appId: string;
  packageName?: string;
}

const DEFAULT_FIREBASE_CONFIG: FirebaseCustomConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY || 'AIzaSyDx8JbvCry2NFFXCrhf4XjcbR7hGX_ThYk',
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN || 'basis-foundation.firebaseapp.com',
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID || 'basis-foundation',
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET || 'basis-foundation.firebasestorage.app',
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID || '20434142842',
  appId: import.meta.env.VITE_FIREBASE_APP_ID || '1:20434142842:android:bf46b36843cf2e0f245dc3',
  packageName: 'org.basis.foundation',
};

// Retrieve any custom Firebase config stored locally (auto-replacing legacy demo keys)
export function getActiveFirebaseConfig(): FirebaseCustomConfig {
  try {
    const saved = localStorage.getItem('basis_foundation_firebase_config');
    if (saved) {
      const parsed = JSON.parse(saved) as Partial<FirebaseCustomConfig>;
      if (
        parsed.apiKey &&
        parsed.apiKey !== 'AIzaSyDemoBasisFoundationAndroidKey' &&
        !parsed.apiKey.includes('Demo')
      ) {
        return { ...DEFAULT_FIREBASE_CONFIG, ...parsed };
      } else {
        localStorage.removeItem('basis_foundation_firebase_config');
      }
    }
  } catch (err) {
    console.warn('Failed to parse local firebase config', err);
  }
  return DEFAULT_FIREBASE_CONFIG;
}

export function saveFirebaseConfig(cfg: Partial<FirebaseCustomConfig>) {
  const current = getActiveFirebaseConfig();
  const merged = { ...current, ...cfg, packageName: 'org.basis.foundation' };
  localStorage.setItem('basis_foundation_firebase_config', JSON.stringify(merged));
  return merged;
}

let appInstance: FirebaseApp | null = null;
let authInstance: Auth | null = null;
let dbInstance: Firestore | null = null;

export function getFirebaseApp(): FirebaseApp {
  if (!appInstance) {
    const config = getActiveFirebaseConfig();
    const existing = getApps();
    if (existing.length > 0) {
      appInstance = getApp();
    } else {
      appInstance = initializeApp(config);
    }
  }
  return appInstance;
}

export function getFirebaseAuth(): Auth | null {
  try {
    if (!authInstance) {
      authInstance = getAuth(getFirebaseApp());
    }
    return authInstance;
  } catch (err) {
    console.warn('Firebase Auth initialization error, running in local resilience mode:', err);
    return null;
  }
}

export function getFirebaseDb(): Firestore | null {
  try {
    if (!dbInstance) {
      dbInstance = getFirestore(getFirebaseApp());
    }
    return dbInstance;
  } catch (err) {
    console.warn('Firestore initialization error, running in local resilience mode:', err);
    return null;
  }
}

/**
 * Unified Complete Firestore Security Rules
 * Combining Authentication, User Profiles, 2/3 Moderator Approval Ceiling,
 * Savings Transactions, Notices, Rules, and System Sync into a single rules file.
 */
export const UNIFIED_FIRESTORE_RULES = `rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {

    // Helper functions
    function isAuthenticated() {
      return request.auth != null;
    }

    function hasUserData() {
      return isAuthenticated() && exists(/databases/$(database)/documents/users/$(request.auth.uid));
    }

    function getUserData() {
      return get(/databases/$(database)/documents/users/$(request.auth.uid)).data;
    }

    function isModerator() {
      return isAuthenticated() && (
        (hasUserData() && (getUserData().role == 'APP_MODERATOR' || getUserData().role == 'MODERATOR')) ||
        request.auth.token.role == 'APP_MODERATOR' ||
        request.auth.token.role == 'MODERATOR'
      );
    }

    function isAppModerator() {
      return isAuthenticated() && (
        (hasUserData() && getUserData().role == 'APP_MODERATOR') ||
        request.auth.token.role == 'APP_MODERATOR'
      );
    }

    // 1. App Configuration (Font, Titles, Branding, Moderator Signatures)
    // Any moderator can update system configuration, titles, and fonts
    match /app_configuration/{configId} {
      allow read: if true;
      allow write: if isAuthenticated();
    }

    // 2. Users Collection: Public profile read for members; only moderators or self can update
    match /users/{userId} {
      allow read: if true;
      allow create: if true;
      allow update: if isAuthenticated();
      allow delete: if isAppModerator();
    }

    // 3. Savings Transactions & 2/3 Approval Ceiling
    match /savings_transactions/{txId} {
      allow read: if true;
      allow create: if isAuthenticated();
      allow update, delete: if isAuthenticated();
    }

    // 4. Approvals Workflow Collection
    match /approvals/{approvalId} {
      allow read: if true;
      allow create, update: if isAuthenticated();
      allow delete: if isAppModerator();
    }

    // 5. Receipts & Account Statements
    match /receipts/{receiptId} {
      allow read: if true;
      allow create, update: if isAuthenticated();
      allow delete: if isAppModerator();
    }

    // 6. Notices, Rules, Executive Council
    match /notices/{noticeId} {
      allow read: if true;
      allow write: if isAuthenticated();
    }

    match /rules/{ruleId} {
      allow read: if true;
      allow write: if isAuthenticated();
    }

    match /executive_members/{memberId} {
      allow read: if true;
      allow write: if isAuthenticated();
    }

    // 7. Community Chat & Private Messages
    match /chat_messages/{messageId} {
      allow read: if true;
      allow create: if isAuthenticated();
      allow update, delete: if isAuthenticated();
    }

    match /private_messages/{messageId} {
      allow read: if true;
      allow create, update, delete: if isAuthenticated();
    }

    // 8. Targeted User Notifications
    match /user_notifications/{notificationId} {
      allow read: if true;
      allow create, update, delete: if isAuthenticated();
    }

    // Default fallback
    match /{document=**} {
      allow read: if true;
      allow write: if isAuthenticated();
    }
  }
}`;

export function resetFirebaseInstance() {
  appInstance = null;
  authInstance = null;
  dbInstance = null;
}
