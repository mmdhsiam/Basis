import {
  doc,
  setDoc,
  deleteDoc,
  collection,
  onSnapshot,
  getDocs,
  getDoc,
} from 'firebase/firestore';
import { getFirebaseDb } from './firebase';
import {
  AppConfiguration,
  NoticeItem,
  FoundationRule,
  ExecutiveMember,
  SavingsTransaction,
  UserProfile,
  ApprovalRequest,
  ChatMessage,
  ChatPoll,
  PrivateMessage,
  ElectronicReceipt,
  FoundationExpense,
  ComplaintItem,
  FeatureRequestItem,
  UserNotification,
} from '../types';

/**
 * Recursively strips undefined values from objects and arrays so Firestore setDoc never fails.
 */
function cleanValue(val: any): any {
  if (val === undefined) return undefined;
  if (val === null || val instanceof Date || typeof val !== 'object') return val;
  if (Array.isArray(val)) {
    return val
      .map((item) => cleanValue(item))
      .filter((item) => item !== undefined);
  }
  const cleanedObj: Record<string, any> = {};
  for (const key of Object.keys(val)) {
    const cleanedProp = cleanValue(val[key]);
    if (cleanedProp !== undefined) {
      cleanedObj[key] = cleanedProp;
    }
  }
  return cleanedObj;
}

function cleanForFirestore<T extends Record<string, any>>(obj: T): Record<string, any> {
  return cleanValue(obj) as Record<string, any>;
}

export type SyncStatus = 'SYNCED' | 'SYNCING' | 'OFFLINE' | 'LOCAL';

export interface RealtimeSyncCallbacks {
  onConfigChange?: (config: AppConfiguration) => void;
  onNoticesChange?: (notices: NoticeItem[]) => void;
  onRulesChange?: (rules: FoundationRule[]) => void;
  onExecutiveMembersChange?: (members: ExecutiveMember[]) => void;
  onSavingsChange?: (savings: SavingsTransaction[]) => void;
  onUsersChange?: (users: UserProfile[]) => void;
  onApprovalsChange?: (approvals: ApprovalRequest[]) => void;
  onChatChange?: (messages: ChatMessage[]) => void;
  onPollsChange?: (polls: ChatPoll[]) => void;
  onPrivateMessagesChange?: (messages: PrivateMessage[]) => void;
  onReceiptsChange?: (receipts: ElectronicReceipt[]) => void;
  onExpensesChange?: (expenses: FoundationExpense[]) => void;
  onComplaintsChange?: (complaints: ComplaintItem[]) => void;
  onFeaturesChange?: (features: FeatureRequestItem[]) => void;
  onNotificationsChange?: (notifications: UserNotification[]) => void;
  onStatusChange?: (status: SyncStatus, lastSyncedAt: string) => void;
}

export async function syncConfigToFirestore(config: AppConfiguration): Promise<boolean> {
  try {
    const db = getFirebaseDb();
    if (!db) return false;
    const ref = doc(db, 'app_configuration', 'main');
    await setDoc(ref, cleanForFirestore({ ...config, updatedAt: new Date().toISOString() }), { merge: true });
    return true;
  } catch (err) {
    console.warn('Firestore config write warning:', err);
    return false;
  }
}

export async function syncNoticeToFirestore(notice: NoticeItem): Promise<boolean> {
  try {
    const db = getFirebaseDb();
    if (!db) return false;
    const ref = doc(db, 'notices', notice.id);
    await setDoc(ref, cleanForFirestore(notice), { merge: true });
    return true;
  } catch (err) {
    console.warn('Firestore notice write warning:', err);
    return false;
  }
}

export async function deleteNoticeFromFirestore(noticeId: string): Promise<boolean> {
  try {
    const db = getFirebaseDb();
    if (!db) return false;
    await deleteDoc(doc(db, 'notices', noticeId));
    return true;
  } catch (err) {
    console.warn('Firestore notice delete warning:', err);
    return false;
  }
}

export async function syncRuleToFirestore(rule: FoundationRule): Promise<boolean> {
  try {
    const db = getFirebaseDb();
    if (!db) return false;
    const ref = doc(db, 'rules', rule.id);
    await setDoc(ref, cleanForFirestore(rule), { merge: true });
    return true;
  } catch (err) {
    console.warn('Firestore rule write warning:', err);
    return false;
  }
}

export async function deleteRuleFromFirestore(ruleId: string): Promise<boolean> {
  try {
    const db = getFirebaseDb();
    if (!db) return false;
    await deleteDoc(doc(db, 'rules', ruleId));
    return true;
  } catch (err) {
    console.warn('Firestore rule delete warning:', err);
    return false;
  }
}

export async function syncExecutiveMemberToFirestore(member: ExecutiveMember): Promise<boolean> {
  try {
    const db = getFirebaseDb();
    if (!db) return false;
    const ref = doc(db, 'executive_members', member.id);
    await setDoc(ref, cleanForFirestore(member), { merge: true });
    return true;
  } catch (err) {
    console.warn('Firestore executive member write warning:', err);
    return false;
  }
}

export async function deleteExecutiveMemberFromFirestore(memberId: string): Promise<boolean> {
  try {
    const db = getFirebaseDb();
    if (!db) return false;
    await deleteDoc(doc(db, 'executive_members', memberId));
    return true;
  } catch (err) {
    console.warn('Firestore executive member delete warning:', err);
    return false;
  }
}

export async function syncSavingsTransactionToFirestore(tx: SavingsTransaction): Promise<boolean> {
  try {
    const db = getFirebaseDb();
    if (!db) return false;
    const ref = doc(db, 'savings_transactions', tx.id);
    await setDoc(ref, cleanForFirestore(tx), { merge: true });
    return true;
  } catch (err) {
    console.warn('Firestore savings write warning:', err);
    return false;
  }
}

export async function syncReceiptToFirestore(receipt: ElectronicReceipt): Promise<boolean> {
  try {
    const db = getFirebaseDb();
    if (!db) return false;
    const ref = doc(db, 'receipts', receipt.receiptNumber);
    await setDoc(ref, cleanForFirestore(receipt), { merge: true });
    return true;
  } catch (err) {
    console.warn('Firestore receipt write warning:', err);
    return false;
  }
}

export async function syncApprovalToFirestore(appr: ApprovalRequest): Promise<boolean> {
  try {
    const db = getFirebaseDb();
    if (!db) return false;
    const ref = doc(db, 'approvals', appr.id);
    await setDoc(ref, cleanForFirestore(appr), { merge: true });
    return true;
  } catch (err) {
    console.warn('Firestore approval write warning:', err);
    return false;
  }
}

export async function syncUserToFirestore(user: UserProfile): Promise<boolean> {
  try {
    const db = getFirebaseDb();
    if (!db || user.id === '__guest__') return false;
    const ref = doc(db, 'users', user.id);
    await setDoc(ref, cleanForFirestore(user), { merge: true });
    return true;
  } catch (err) {
    console.warn('Firestore user write warning:', err);
    return false;
  }
}

export async function deleteUserFromFirestore(userId: string): Promise<boolean> {
  try {
    const db = getFirebaseDb();
    if (!db) return false;
    await deleteDoc(doc(db, 'users', userId));
    return true;
  } catch (err) {
    console.warn('Firestore user delete warning:', err);
    return false;
  }
}

export async function fetchUsersFromFirestore(): Promise<UserProfile[]> {
  try {
    const db = getFirebaseDb();
    if (!db) return [];
    const snap = await getDocs(collection(db, 'users'));
    const list: UserProfile[] = [];
    snap.forEach((docSnap) => {
      const data = docSnap.data() as UserProfile;
      if (data && data.id && data.id !== '__guest__') {
        list.push(data);
      }
    });
    return list;
  } catch (err) {
    console.warn('Firestore fetch users warning:', err);
    return [];
  }
}

export async function syncChatMessageToFirestore(msg: ChatMessage): Promise<boolean> {
  try {
    const db = getFirebaseDb();
    if (!db) return false;
    const ref = doc(db, 'chat_messages', msg.id);
    await setDoc(ref, cleanForFirestore(msg), { merge: true });
    return true;
  } catch (err) {
    console.warn('Firestore chat write warning:', err);
    return false;
  }
}

export async function syncPollToFirestore(poll: ChatPoll): Promise<boolean> {
  try {
    const db = getFirebaseDb();
    if (!db) return false;
    const ref = doc(db, 'chat_polls', poll.id);
    await setDoc(ref, cleanForFirestore(poll), { merge: true });
    return true;
  } catch (err) {
    console.warn('Firestore poll write warning:', err);
    return false;
  }
}

export async function syncPrivateMessageToFirestore(pm: PrivateMessage): Promise<boolean> {
  try {
    const db = getFirebaseDb();
    if (!db) return false;
    const ref = doc(db, 'private_messages', pm.id);
    await setDoc(ref, cleanForFirestore(pm), { merge: true });
    return true;
  } catch (err) {
    console.warn('Firestore private message write warning:', err);
    return false;
  }
}

export async function syncExpenseToFirestore(expense: FoundationExpense): Promise<boolean> {
  try {
    const db = getFirebaseDb();
    if (!db) return false;
    const ref = doc(db, 'expenses', expense.id);
    await setDoc(ref, cleanForFirestore(expense), { merge: true });
    return true;
  } catch (err) {
    console.warn('Firestore expense write warning:', err);
    return false;
  }
}

export async function deleteExpenseFromFirestore(expenseId: string): Promise<boolean> {
  try {
    const db = getFirebaseDb();
    if (!db) return false;
    await deleteDoc(doc(db, 'expenses', expenseId));
    return true;
  } catch (err) {
    console.warn('Firestore expense delete warning:', err);
    return false;
  }
}

export async function syncComplaintToFirestore(complaint: ComplaintItem): Promise<boolean> {
  try {
    const db = getFirebaseDb();
    if (!db) return false;
    const ref = doc(db, 'complaints', complaint.id);
    await setDoc(ref, cleanForFirestore(complaint), { merge: true });
    return true;
  } catch (err) {
    console.warn('Firestore complaint write warning:', err);
    return false;
  }
}

export async function syncFeatureRequestToFirestore(feature: FeatureRequestItem): Promise<boolean> {
  try {
    const db = getFirebaseDb();
    if (!db) return false;
    const ref = doc(db, 'feature_requests', feature.id);
    await setDoc(ref, cleanForFirestore(feature), { merge: true });
    return true;
  } catch (err) {
    console.warn('Firestore feature request write warning:', err);
    return false;
  }
}

export async function syncUserNotificationToFirestore(notif: UserNotification): Promise<boolean> {
  try {
    const db = getFirebaseDb();
    if (!db) return false;
    const ref = doc(db, 'user_notifications', notif.id);
    await setDoc(ref, cleanForFirestore(notif), { merge: true });
    return true;
  } catch (err) {
    console.warn('Firestore notification write warning:', err);
    return false;
  }
}

/**
 * Performs an active bidirectional pull/push sync with Firestore for Moderator Sync.
 */
export async function performFullFirestoreSync(
  localPayload: {
    config: AppConfiguration;
    users: UserProfile[];
    savings: SavingsTransaction[];
    receipts: ElectronicReceipt[];
    approvals: ApprovalRequest[];
    notices: NoticeItem[];
    rules: FoundationRule[];
    expenses: FoundationExpense[];
    complaints: ComplaintItem[];
    featureRequests: FeatureRequestItem[];
  },
  callbacks: RealtimeSyncCallbacks
): Promise<boolean> {
  if (typeof navigator !== 'undefined' && !navigator.onLine) {
    return false;
  }
  const db = getFirebaseDb();
  if (!db) return false;

  try {
    callbacks.onStatusChange?.('SYNCING', new Date().toLocaleTimeString('bn-BD'));

    // Pull config first; if remote doesn't exist yet, push local config
    const cfgSnap = await getDoc(doc(db, 'app_configuration', 'main'));
    if (cfgSnap.exists()) {
      callbacks.onConfigChange?.(cfgSnap.data() as AppConfiguration);
    } else {
      await syncConfigToFirestore(localPayload.config);
    }

    // Pull users; merge any local approved/moderator users that are missing remotely
    const usersSnap = await getDocs(collection(db, 'users'));
    if (!usersSnap.empty) {
      const remoteUsers: UserProfile[] = [];
      usersSnap.forEach((d) => {
        const u = d.data() as UserProfile;
        if (u && u.id !== '__guest__') remoteUsers.push(u);
      });
      callbacks.onUsersChange?.(remoteUsers);
    } else {
      await Promise.all(
        localPayload.users
          .filter((u) => u.id !== '__guest__')
          .map((u) => syncUserToFirestore(u))
      );
    }

    // Pull savings
    const txSnap = await getDocs(collection(db, 'savings_transactions'));
    if (!txSnap.empty) {
      const remoteTx: SavingsTransaction[] = [];
      txSnap.forEach((d) => remoteTx.push(d.data() as SavingsTransaction));
      remoteTx.sort((a, b) => new Date(b.transactionDate).getTime() - new Date(a.transactionDate).getTime());
      callbacks.onSavingsChange?.(remoteTx);
    } else {
      await Promise.all(localPayload.savings.map((tx) => syncSavingsTransactionToFirestore(tx)));
    }

    // Pull notices
    const noticesSnap = await getDocs(collection(db, 'notices'));
    if (!noticesSnap.empty) {
      const remoteNotices: NoticeItem[] = [];
      noticesSnap.forEach((d) => remoteNotices.push(d.data() as NoticeItem));
      remoteNotices.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
      callbacks.onNoticesChange?.(remoteNotices);
    } else {
      await Promise.all(localPayload.notices.map((n) => syncNoticeToFirestore(n)));
    }

    // Pull approvals
    const apprSnap = await getDocs(collection(db, 'approvals'));
    if (!apprSnap.empty) {
      const remoteAppr: ApprovalRequest[] = [];
      apprSnap.forEach((d) => remoteAppr.push(d.data() as ApprovalRequest));
      callbacks.onApprovalsChange?.(remoteAppr);
    } else {
      await Promise.all(localPayload.approvals.map((a) => syncApprovalToFirestore(a)));
    }

    // Pull rules
    const rulesSnap = await getDocs(collection(db, 'rules'));
    if (!rulesSnap.empty) {
      const remoteRules: FoundationRule[] = [];
      rulesSnap.forEach((d) => remoteRules.push(d.data() as FoundationRule));
      remoteRules.sort((a, b) => (a.ruleNumber ?? 0) - (b.ruleNumber ?? 0));
      callbacks.onRulesChange?.(remoteRules);
    } else {
      await Promise.all(localPayload.rules.map((r) => syncRuleToFirestore(r)));
    }

    callbacks.onStatusChange?.('SYNCED', new Date().toLocaleTimeString('bn-BD'));
    return true;
  } catch (err) {
    console.warn('Full Firestore sync error:', err);
    callbacks.onStatusChange?.('LOCAL', new Date().toLocaleTimeString('bn-BD'));
    return false;
  }
}

/**
 * Establishes real-time listeners on all Firestore collections.
 */
export function initRealtimeSync(callbacks: RealtimeSyncCallbacks): () => void {
  const unsubscribers: (() => void)[] = [];

  try {
    const db = getFirebaseDb();
    if (!db) {
      callbacks.onStatusChange?.('LOCAL', new Date().toLocaleTimeString('bn-BD'));
      return () => {};
    }

    callbacks.onStatusChange?.('SYNCING', new Date().toLocaleTimeString('bn-BD'));

    // 1. App Configuration
    unsubscribers.push(
      onSnapshot(
        doc(db, 'app_configuration', 'main'),
        (snapshot) => {
          if (snapshot.exists()) {
            callbacks.onConfigChange?.(snapshot.data() as AppConfiguration);
            callbacks.onStatusChange?.('SYNCED', new Date().toLocaleTimeString('bn-BD'));
          }
        },
        (err) => {
          console.warn('Config snapshot listener warning:', err);
          callbacks.onStatusChange?.('LOCAL', new Date().toLocaleTimeString('bn-BD'));
        }
      )
    );

    // 2. Notices
    unsubscribers.push(
      onSnapshot(
        collection(db, 'notices'),
        (snapshot) => {
          if (!snapshot.empty) {
            const list: NoticeItem[] = [];
            snapshot.forEach((docSnap) => list.push(docSnap.data() as NoticeItem));
            list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
            callbacks.onNoticesChange?.(list);
            callbacks.onStatusChange?.('SYNCED', new Date().toLocaleTimeString('bn-BD'));
          }
        },
        (err) => console.warn('Notices listener warning:', err)
      )
    );

    // 3. Rules
    unsubscribers.push(
      onSnapshot(
        collection(db, 'rules'),
        (snapshot) => {
          if (!snapshot.empty) {
            const list: FoundationRule[] = [];
            snapshot.forEach((docSnap) => list.push(docSnap.data() as FoundationRule));
            list.sort((a, b) => (a.ruleNumber ?? 0) - (b.ruleNumber ?? 0));
            callbacks.onRulesChange?.(list);
          }
        },
        (err) => console.warn('Rules listener warning:', err)
      )
    );

    // 4. Executive Members
    unsubscribers.push(
      onSnapshot(
        collection(db, 'executive_members'),
        (snapshot) => {
          if (!snapshot.empty) {
            const list: ExecutiveMember[] = [];
            snapshot.forEach((docSnap) => list.push(docSnap.data() as ExecutiveMember));
            list.sort((a, b) => a.order - b.order);
            callbacks.onExecutiveMembersChange?.(list);
          }
        },
        (err) => console.warn('Executive members listener warning:', err)
      )
    );

    // 5. Savings Transactions
    unsubscribers.push(
      onSnapshot(
        collection(db, 'savings_transactions'),
        (snapshot) => {
          if (!snapshot.empty) {
            const list: SavingsTransaction[] = [];
            snapshot.forEach((docSnap) => list.push(docSnap.data() as SavingsTransaction));
            list.sort((a, b) => new Date(b.transactionDate).getTime() - new Date(a.transactionDate).getTime());
            callbacks.onSavingsChange?.(list);
            callbacks.onStatusChange?.('SYNCED', new Date().toLocaleTimeString('bn-BD'));
          }
        },
        (err) => console.warn('Savings listener warning:', err)
      )
    );

    // 6. Users
    unsubscribers.push(
      onSnapshot(
        collection(db, 'users'),
        (snapshot) => {
          if (!snapshot.empty) {
            const list: UserProfile[] = [];
            snapshot.forEach((docSnap) => {
              const u = docSnap.data() as UserProfile;
              if (u && u.id !== '__guest__') list.push(u);
            });
            callbacks.onUsersChange?.(list);
          }
        },
        (err) => console.warn('Users listener warning:', err)
      )
    );

    // 7. Approvals
    unsubscribers.push(
      onSnapshot(
        collection(db, 'approvals'),
        (snapshot) => {
          if (!snapshot.empty) {
            const list: ApprovalRequest[] = [];
            snapshot.forEach((docSnap) => list.push(docSnap.data() as ApprovalRequest));
            list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
            callbacks.onApprovalsChange?.(list);
          }
        },
        (err) => console.warn('Approvals listener warning:', err)
      )
    );

    // 8. Chat Messages
    unsubscribers.push(
      onSnapshot(
        collection(db, 'chat_messages'),
        (snapshot) => {
          if (!snapshot.empty) {
            const list: ChatMessage[] = [];
            snapshot.forEach((docSnap) => list.push(docSnap.data() as ChatMessage));
            list.sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
            callbacks.onChatChange?.(list);
          }
        },
        (err) => console.warn('Chat listener warning:', err)
      )
    );

    // 9. Chat Polls
    unsubscribers.push(
      onSnapshot(
        collection(db, 'chat_polls'),
        (snapshot) => {
          if (!snapshot.empty) {
            const list: ChatPoll[] = [];
            snapshot.forEach((docSnap) => list.push(docSnap.data() as ChatPoll));
            callbacks.onPollsChange?.(list);
          }
        },
        (err) => console.warn('Polls listener warning:', err)
      )
    );

    // 10. Private Messages
    unsubscribers.push(
      onSnapshot(
        collection(db, 'private_messages'),
        (snapshot) => {
          if (!snapshot.empty) {
            const list: PrivateMessage[] = [];
            snapshot.forEach((docSnap) => list.push(docSnap.data() as PrivateMessage));
            list.sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
            callbacks.onPrivateMessagesChange?.(list);
          }
        },
        (err) => console.warn('Private messages listener warning:', err)
      )
    );

    // 11. Receipts
    unsubscribers.push(
      onSnapshot(
        collection(db, 'receipts'),
        (snapshot) => {
          if (!snapshot.empty) {
            const list: ElectronicReceipt[] = [];
            snapshot.forEach((docSnap) => list.push(docSnap.data() as ElectronicReceipt));
            callbacks.onReceiptsChange?.(list);
          }
        },
        (err) => console.warn('Receipts listener warning:', err)
      )
    );

    // 12. Expenses
    unsubscribers.push(
      onSnapshot(
        collection(db, 'expenses'),
        (snapshot) => {
          if (!snapshot.empty) {
            const list: FoundationExpense[] = [];
            snapshot.forEach((docSnap) => list.push(docSnap.data() as FoundationExpense));
            callbacks.onExpensesChange?.(list);
          }
        },
        (err) => console.warn('Expenses listener warning:', err)
      )
    );

    // 13. Complaints
    unsubscribers.push(
      onSnapshot(
        collection(db, 'complaints'),
        (snapshot) => {
          if (!snapshot.empty) {
            const list: ComplaintItem[] = [];
            snapshot.forEach((docSnap) => list.push(docSnap.data() as ComplaintItem));
            list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
            callbacks.onComplaintsChange?.(list);
          }
        },
        (err) => console.warn('Complaints listener warning:', err)
      )
    );

    // 14. Feature Requests
    unsubscribers.push(
      onSnapshot(
        collection(db, 'feature_requests'),
        (snapshot) => {
          if (!snapshot.empty) {
            const list: FeatureRequestItem[] = [];
            snapshot.forEach((docSnap) => list.push(docSnap.data() as FeatureRequestItem));
            callbacks.onFeaturesChange?.(list);
          }
        },
        (err) => console.warn('Feature requests listener warning:', err)
      )
    );

    // 15. Targeted User Notifications
    unsubscribers.push(
      onSnapshot(
        collection(db, 'user_notifications'),
        (snapshot) => {
          if (!snapshot.empty) {
            const list: UserNotification[] = [];
            snapshot.forEach((docSnap) => list.push(docSnap.data() as UserNotification));
            list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
            callbacks.onNotificationsChange?.(list);
          }
        },
        (err) => console.warn('Notifications listener warning:', err)
      )
    );

    callbacks.onStatusChange?.('SYNCED', new Date().toLocaleTimeString('bn-BD'));
  } catch (err) {
    console.warn('Realtime sync setup error (using local resilience):', err);
    callbacks.onStatusChange?.('LOCAL', new Date().toLocaleTimeString('bn-BD'));
  }

  return () => {
    unsubscribers.forEach((unsub) => {
      try {
        unsub();
      } catch (e) {
        // ignore
      }
    });
  };
}
