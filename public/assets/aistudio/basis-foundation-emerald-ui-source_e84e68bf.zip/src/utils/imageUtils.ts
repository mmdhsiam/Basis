/**
 * Utility to parse, extract, and clean image URLs from:
 * - Direct image links (https://...jpg/png/webp/svg/gif)
 * - ImgBB HTML / BBCode embed snippets
 * - PostImages HTML / BBCode embed snippets
 * - Imgur, Cloudinary, Google Drive preview links
 * - Base64 Data URLs
 */
export function extractDirectImageUrl(rawInput?: string): string {
  if (!rawInput) return '';
  let str = rawInput.trim();
  if (!str) return '';

  // 1. Check BBCode snippets: [url=...][img]URL[/img][/url] or [img]URL[/img]
  const bbMatch = str.match(/\[img\](.*?)\[\/img\]/i);
  if (bbMatch && bbMatch[1]) {
    str = bbMatch[1].trim();
  }

  // 2. Check HTML snippets: <a href="..."><img src="URL" .../></a> or <img src="URL" ...>
  const htmlMatch = str.match(/<img[^>]+src=["']([^"']+)["']/i);
  if (htmlMatch && htmlMatch[1]) {
    str = htmlMatch[1].trim();
  }

  // 3. Remove leading/trailing quotes or markdown
  str = str.replace(/^["'`]|["'`]$/g, '').trim();

  // 4. If URL wrapped in markdown format ![alt](url)
  const mdMatch = str.match(/!\[.*?\]\((.*?)\)/);
  if (mdMatch && mdMatch[1]) {
    str = mdMatch[1].trim();
  }

  // 5. ImgBB viewer link fallback:
  // e.g. https://ibb.co/xyz or https://ibb.co.com/xyz
  // Often ImgBB direct images are hosted on i.ibb.co. If user only pasted ibb.co viewer link,
  // we keep it clean or format if matching known patterns.
  if (str.includes('postimg.cc/') && !str.includes('i.postimg.cc/')) {
    // If it's a postimg viewer page, keep it clean
  }

  return str;
}

/**
 * Checks whether a given string is a plausible image source
 */
export function isValidImageSource(src?: string): boolean {
  if (!src) return false;
  const cleaned = extractDirectImageUrl(src);
  if (!cleaned) return false;
  return (
    cleaned.startsWith('http://') ||
    cleaned.startsWith('https://') ||
    cleaned.startsWith('data:image/') ||
    cleaned.startsWith('/') ||
    cleaned.startsWith('./')
  );
}
