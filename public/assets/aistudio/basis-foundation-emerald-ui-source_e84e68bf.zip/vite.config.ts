import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import fs from 'fs';
import path from 'path';
import { defineConfig } from 'vite';

const apkDownloadPlugin = () => ({
  name: 'apk-download-plugin',
  configureServer(server: any) {
    server.middlewares.use((req: any, res: any, next: any) => {
      const url = req.url || '';
      if ((url.startsWith('/downloads/') && url.endsWith('.apk')) || url.startsWith('/api/download-apk')) {
        let requestedFile = 'basis-foundation-v2.3.0-release.apk';
        if (url.includes('v2.2.0')) {
          requestedFile = 'basis-foundation-v2.2.0.apk';
        }
        const targetPath = path.resolve(process.cwd(), 'public/downloads', requestedFile);
        if (fs.existsSync(targetPath)) {
          const stat = fs.statSync(targetPath);
          res.writeHead(200, {
            'Content-Type': 'application/vnd.android.package-archive',
            'Content-Disposition': `attachment; filename="${requestedFile}"`,
            'Content-Length': stat.size,
            'Cache-Control': 'public, max-age=3600',
            'Access-Control-Allow-Origin': '*',
          });
          const stream = fs.createReadStream(targetPath);
          return stream.pipe(res);
        }
      }
      next();
    });
  },
});

export default defineConfig(() => {
  return {
    base: './',
    plugins: [react(), tailwindcss(), apkDownloadPlugin()],
    resolve: {
      alias: {
        '@': path.resolve(__dirname, '.'),
      },
    },
    server: {
      // HMR is disabled in AI Studio via DISABLE_HMR env var.
      // Do not modify—file watching is disabled to prevent flickering during agent edits.
      hmr: process.env.DISABLE_HMR !== 'true',
      // Disable file watching when DISABLE_HMR is true to save CPU during agent edits.
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});
