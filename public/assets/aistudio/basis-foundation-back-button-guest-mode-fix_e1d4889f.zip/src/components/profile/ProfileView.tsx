import React, { useState } from 'react';
import {
  User,
  Wallet,
  Phone,
  Mail,
  MapPin,
  Calendar,
  CheckCircle2,
  Clock,
  Receipt,
  FileSpreadsheet,
  AlertCircle,
  ShieldCheck,
  ShieldAlert,
  Edit3,
  Save,
  Image as ImageIcon,
  Printer,
  Sparkles,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { formatCurrencyBengali, toBengaliNumerals } from '../../utils/calculations';
import { extractDirectImageUrl } from '../../utils/imageUtils';
import { Avatar } from '../common/Avatar';
import { StatementPrintModal } from '../modals/StatementPrintModal';

interface ProfileViewProps {
  onOpenReceipt?: (txId: string) => void;
}

export const ProfileView: React.FC<ProfileViewProps> = ({ onOpenReceipt }) => {
  const {
    currentUser,
    updateUserProfile,
    savings,
    overdueReminders,
    config,
    triggerSuccess,
    setActivePrintReceipt,
    getReceiptForTransaction,
  } = useApp();

  const isModerator = currentUser.role === 'APP_MODERATOR' || currentUser.role === 'MODERATOR';

  // Personal edit states
  const [isEditing, setIsEditing] = useState(false);
  const [name, setName] = useState(currentUser.name);
  const [phone, setPhone] = useState(currentUser.phone);
  const [email, setEmail] = useState(currentUser.email);
  const [address, setAddress] = useState(currentUser.address || '');
  const [avatarUrl, setAvatarUrl] = useState(currentUser.avatarUrl || '');
  const [nomineeName, setNomineeName] = useState(currentUser.nomineeName || '');
  const [nomineeRelation, setNomineeRelation] = useState(currentUser.nomineeRelation || '');
  const [nomineePhone, setNomineePhone] = useState(currentUser.nomineePhone || '');
  const [signatureType, setSignatureType] = useState<'NAME' | 'IMAGE'>(currentUser.signatureType || 'NAME');
  const [signatureImageUrl, setSignatureImageUrl] = useState(currentUser.signatureImageUrl || '');
  const [nidFrontImageUrl, setNidFrontImageUrl] = useState(currentUser.nidFrontImageUrl || '');
  const [nidBackImageUrl, setNidBackImageUrl] = useState(currentUser.nidBackImageUrl || '');

  // Statement modal state
  const [isStatementModalOpen, setIsStatementModalOpen] = useState(false);

  // User's own savings transactions
  const userSavings = savings
    .filter((s) => s.memberId === currentUser.id || s.memberId === currentUser.memberId)
    .sort((a, b) => new Date(b.transactionDate).getTime() - new Date(a.transactionDate).getTime());

  const approvedSavings = userSavings.filter((s) => s.status === 'APPROVED');
  const pendingSavings = userSavings.filter((s) => s.status === 'PENDING');

  const totalApprovedAmount = approvedSavings.reduce((acc, s) => acc + s.amount, 0);
  const totalPendingAmount = pendingSavings.reduce((acc, s) => acc + s.amount, 0);

  const isOverdue = overdueReminders.includes(currentUser.memberId);

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanAvatar = extractDirectImageUrl(avatarUrl);
    const cleanSignature = extractDirectImageUrl(signatureImageUrl);
    const cleanNidFront = extractDirectImageUrl(nidFrontImageUrl);
    const cleanNidBack = extractDirectImageUrl(nidBackImageUrl);

    updateUserProfile(currentUser.id, {
      name: name.trim(),
      phone: phone.trim(),
      email: email.trim(),
      address: address.trim() || undefined,
      avatarUrl: cleanAvatar || undefined,
      nomineeName: nomineeName.trim() || undefined,
      nomineeRelation: nomineeRelation.trim() || undefined,
      nomineePhone: nomineePhone.trim() || undefined,
      signatureType,
      signatureImageUrl: cleanSignature || undefined,
      nidFrontImageUrl: cleanNidFront || undefined,
      nidBackImageUrl: cleanNidBack || undefined,
    });
    setIsEditing(false);
    triggerSuccess('আপনার ব্যক্তিগত প্রোফাইল তথ্য, সিগনেচার ও এনআইডি সফলভাবে সংরক্ষিত হয়েছে!');
  };

  return (
    <div className="space-y-6 pb-20 max-w-4xl mx-auto">
      {/* Overdue Alert banner if targeted */}
      {isOverdue && (
        <div className="bg-gradient-to-r from-rose-900 via-rose-950 to-rose-900 border-2 border-rose-500 text-rose-100 p-4 rounded-3xl shadow-xl flex items-start gap-3.5 animate-pulse">
          <AlertCircle className="w-6 h-6 text-rose-400 shrink-0 mt-0.5" />
          <div className="space-y-1">
            <h4 className="font-black text-white text-sm">সঞ্চয় বকেয়া তাগিদ বার্তা:</h4>
            <p className="text-xs leading-relaxed font-bold">
              আপনি এই মাসের টাকা এখনো জমা দেননি। যথাসময়ে টাকা জমা করার জন্য অনুরোধ করা হলো।
            </p>
          </div>
        </div>
      )}

      {/* Main Profile Header Card */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 sm:p-7 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-emerald-500/5 rounded-full blur-3xl pointer-events-none" />

        <div className="flex flex-col sm:flex-row items-center sm:items-start justify-between gap-5 relative z-10 text-center sm:text-left">
          <div className="flex flex-col sm:flex-row items-center gap-4 sm:gap-5">
            <Avatar
              src={currentUser.avatarUrl}
              name={currentUser.name}
              size="xl"
              ringColor={
                currentUser.role === 'APP_MODERATOR'
                  ? 'ring-amber-500'
                  : currentUser.role === 'MODERATOR'
                  ? 'ring-blue-500'
                  : 'ring-emerald-500'
              }
            />

            <div className="space-y-1.5">
              <div className="flex items-center justify-center sm:justify-start gap-2 flex-wrap">
                <h2 className="text-xl sm:text-2xl font-black text-white">{currentUser.name}</h2>
                {isModerator && (
                  <span title="ভেরিফাইড মডারেটর" className="inline-flex items-center">
                    <CheckCircle2 className="w-4 h-4 text-blue-400 fill-blue-500 text-white" />
                  </span>
                )}
                {currentUser.moderatorTitle && (
                  <span className="text-xs font-bold px-2.5 py-0.5 rounded-full bg-blue-500/20 text-blue-300 border border-blue-500/30">
                    {currentUser.moderatorTitle}
                  </span>
                )}
              </div>

              <div className="flex items-center justify-center sm:justify-start gap-2 text-xs text-slate-400 font-medium flex-wrap">
                <span className="font-mono bg-slate-950 px-2 py-0.5 rounded-md border border-slate-800 text-emerald-400 font-bold">
                  {currentUser.memberId}
                </span>
                <span>•</span>
                <span>
                  {currentUser.role === 'APP_MODERATOR'
                    ? 'প্রধান অ্যাপ মডারেটর'
                    : currentUser.role === 'MODERATOR'
                    ? 'মডারেটর'
                    : 'সাধারণ সদস্য'}
                </span>
                <span>•</span>
                <span>
                  লিঙ্গ: {currentUser.gender === 'FEMALE' ? 'নারী' : currentUser.gender === 'MALE' ? 'পুরুষ' : 'অন্যান্য'}
                </span>
                <span>•</span>
                <span>যোগদান: {currentUser.joinDate || '২০২৫-০১-১০'}</span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsEditing(!isEditing)}
              className="py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold transition-all flex items-center gap-1.5 border border-slate-700 cursor-pointer shadow-sm"
            >
              <Edit3 className="w-4 h-4 text-emerald-400" />
              <span>{isEditing ? 'সম্পাদনা বাতিল' : 'প্রোফাইল এডিট'}</span>
            </button>

            <button
              onClick={() => setIsStatementModalOpen(true)}
              className="py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-black transition-all flex items-center gap-1.5 shadow-lg shadow-emerald-600/30 cursor-pointer"
            >
              <FileSpreadsheet className="w-4 h-4" />
              <span>স্টেটমেন্ট ডাউনলোড</span>
            </button>
          </div>
        </div>
      </div>

      {/* Edit Form Modal/Drawer if editing */}
      {isEditing && (
        <form
          onSubmit={handleSaveProfile}
          className="bg-slate-900 border border-emerald-500/50 rounded-3xl p-5 sm:p-6 shadow-2xl space-y-4 animate-in fade-in text-xs"
        >
          <h3 className="font-black text-white text-sm flex items-center gap-2">
            <Edit3 className="w-4 h-4 text-emerald-400" />
            <span>ব্যক্তিগত তথ্য ও প্রোফাইল ছবি হালনাগাদ</span>
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1">
              <label className="font-bold text-slate-300">পূর্ণ নাম:</label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white font-bold"
                required
              />
            </div>

            <div className="space-y-1">
              <label className="font-bold text-slate-300">মোবাইল নম্বর:</label>
              <input
                type="text"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white font-mono"
                required
              />
            </div>

            <div className="space-y-1">
              <label className="font-bold text-slate-300">ইমেইল ঠিকানা:</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white font-mono"
              />
            </div>

            <div className="space-y-1">
              <label className="font-bold text-slate-300">স্থায়ী ঠিকানা:</label>
              <input
                type="text"
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white"
                placeholder="গ্রাম/শহর, থানা, জেলা"
              />
            </div>

            {/* Profile Hosted Image Link with Auto Live Preview (Requirement 7) */}
            <div className="col-span-full space-y-2 bg-slate-950 p-3.5 rounded-2xl border border-slate-800">
              <label className="font-bold text-slate-300 flex items-center gap-1.5">
                <ImageIcon className="w-4 h-4 text-emerald-400" />
                <span>প্রোফাইল ছবি হোস্টেড লিংক (Viewer Link / Direct / HTML / BBCode সাপোর্ট):</span>
              </label>
              <div className="flex items-center gap-3">
                <Avatar src={avatarUrl} name={name} size="lg" ringColor="ring-emerald-500" />
                <input
                  type="text"
                  placeholder="https://i.ibb.co/... অথবা [img]...[/img] বা <img src=...>"
                  value={avatarUrl}
                  onChange={(e) => setAvatarUrl(e.target.value)}
                  className="flex-1 bg-slate-900 border border-slate-800 rounded-xl p-2.5 text-xs text-slate-200 font-mono"
                />
              </div>
              <p className="text-[11px] text-slate-400">
                * হোস্টেড ছবির ডিরেক্ট বা ভিউয়ার লিংক দিলেই নামের পাশে সর্বত্র ছবি শো করবে।
              </p>
            </div>

            <div className="space-y-1">
              <label className="font-bold text-slate-300">নমিনীর নাম:</label>
              <input
                type="text"
                value={nomineeName}
                onChange={(e) => setNomineeName(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white"
              />
            </div>

            <div className="space-y-1">
              <label className="font-bold text-slate-300">নমিনীর সাথে সম্পর্ক:</label>
              <input
                type="text"
                value={nomineeRelation}
                onChange={(e) => setNomineeRelation(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white"
              />
            </div>

            <div className="col-span-full space-y-1">
              <label className="font-bold text-slate-300">নমিনীর মোবাইল নম্বর:</label>
              <input
                type="text"
                value={nomineePhone}
                onChange={(e) => setNomineePhone(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white font-mono"
              />
            </div>

            {/* Requirement 10: Signature Setting (Image or Name selection) */}
            <div className="col-span-full p-4 rounded-2xl bg-slate-950 border border-emerald-900/40 space-y-3">
              <label className="font-bold text-white flex items-center gap-1.5 text-xs">
                <span className="w-2 h-2 rounded-full bg-emerald-400" />
                <span>অফিসিয়াল স্বাক্ষর সেটিংস (রসিদ ও স্টেটমেন্টের জন্য - Requirement 10):</span>
              </label>

              <div className="flex items-center gap-6 text-xs text-slate-300">
                <label className="flex items-center gap-2 cursor-pointer font-bold">
                  <input
                    type="radio"
                    name="signatureType"
                    value="NAME"
                    checked={signatureType === 'NAME'}
                    onChange={() => setSignatureType('NAME')}
                    className="accent-emerald-500 w-4 h-4"
                  />
                  <span>আমার নাম ইনপুট হবে (টাইপোগ্রাফি)</span>
                </label>

                <label className="flex items-center gap-2 cursor-pointer font-bold">
                  <input
                    type="radio"
                    name="signatureType"
                    value="IMAGE"
                    checked={signatureType === 'IMAGE'}
                    onChange={() => setSignatureType('IMAGE')}
                    className="accent-emerald-500 w-4 h-4"
                  />
                  <span>সিগনেচার ইমেজ হিসেবে সেট হবে</span>
                </label>
              </div>

              {signatureType === 'IMAGE' && (
                <div className="space-y-1.5 pt-2 border-t border-slate-800/80">
                  <label className="font-medium text-slate-300 text-xs">সিগনেচার হোস্টেড ইমেজ লিংক:</label>
                  <div className="flex items-center gap-3">
                    <input
                      type="url"
                      placeholder="https://i.ibb.co/.../my-signature.png"
                      value={signatureImageUrl}
                      onChange={(e) => setSignatureImageUrl(e.target.value)}
                      className="flex-1 bg-slate-900 border border-slate-800 rounded-xl p-2.5 text-xs text-white font-mono"
                    />
                    {signatureImageUrl && (
                      <div className="w-24 h-10 bg-white rounded-lg p-1 border border-slate-700 flex items-center justify-center shrink-0">
                        <img
                          src={extractDirectImageUrl(signatureImageUrl)}
                          alt="Signature Preview"
                          className="max-h-full object-contain"
                        />
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>

            {/* Requirement 15: NID Card Front & Back Hosted Images with Live Preview */}
            <div className="col-span-full p-4 rounded-2xl bg-slate-950 border border-blue-900/40 space-y-3">
              <label className="font-bold text-white flex items-center gap-1.5 text-xs">
                <span className="w-2 h-2 rounded-full bg-blue-400" />
                <span>জাতীয় পরিচয়পত্র (NID) কার্ডের ছবি ও লিংক (Requirement 15):</span>
              </label>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {/* NID Front */}
                <div className="space-y-1.5">
                  <span className="text-[11px] font-bold text-slate-300">এনআইডি ফ্রন্ট সাইড (Front) লিংক:</span>
                  <input
                    type="url"
                    placeholder="https://i.ibb.co/.../nid-front.jpg"
                    value={nidFrontImageUrl}
                    onChange={(e) => setNidFrontImageUrl(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-xl p-2.5 text-xs text-white font-mono"
                  />
                  {nidFrontImageUrl ? (
                    <div className="mt-2 h-28 rounded-xl overflow-hidden border border-slate-700 bg-slate-900 flex items-center justify-center">
                      <img
                        src={extractDirectImageUrl(nidFrontImageUrl)}
                        alt="NID Front Preview"
                        className="w-full h-full object-cover"
                      />
                    </div>
                  ) : (
                    <div className="h-14 rounded-xl border border-dashed border-slate-800 flex items-center justify-center text-[10px] text-slate-500">
                      ফ্রন্ট প্রিভিউ নেই
                    </div>
                  )}
                </div>

                {/* NID Back */}
                <div className="space-y-1.5">
                  <span className="text-[11px] font-bold text-slate-300">এনআইডি ব্যাক সাইড (Back) লিংক:</span>
                  <input
                    type="url"
                    placeholder="https://i.ibb.co/.../nid-back.jpg"
                    value={nidBackImageUrl}
                    onChange={(e) => setNidBackImageUrl(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-xl p-2.5 text-xs text-white font-mono"
                  />
                  {nidBackImageUrl ? (
                    <div className="mt-2 h-28 rounded-xl overflow-hidden border border-slate-700 bg-slate-900 flex items-center justify-center">
                      <img
                        src={extractDirectImageUrl(nidBackImageUrl)}
                        alt="NID Back Preview"
                        className="w-full h-full object-cover"
                      />
                    </div>
                  ) : (
                    <div className="h-14 rounded-xl border border-dashed border-slate-800 flex items-center justify-center text-[10px] text-slate-500">
                      ব্যাক প্রিভিউ নেই
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-2 border-t border-slate-800">
            <button
              type="button"
              onClick={() => setIsEditing(false)}
              className="py-2 px-4 rounded-xl bg-slate-800 text-slate-300 font-bold"
            >
              বাতিল
            </button>
            <button
              type="submit"
              className="py-2 px-5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-black flex items-center gap-1.5 cursor-pointer"
            >
              <Save className="w-4 h-4" />
              <span>সংরক্ষণ করুন</span>
            </button>
          </div>
        </form>
      )}

      {/* Requirement 5: Personal Financial & Savings Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-sm space-y-1 relative overflow-hidden">
          <div className="flex items-center justify-between text-xs text-slate-400 font-bold">
            <span>মোট অনুমোদিত সঞ্চয় জমা</span>
            <Wallet className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-black text-emerald-400">
            {formatCurrencyBengali(totalApprovedAmount)}
          </div>
          <p className="text-[11px] text-slate-400 font-medium">
            সর্বমোট {toBengaliNumerals(approvedSavings.length)} টি কিস্তি সফলভাবে অনুমোদিত।
          </p>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-sm space-y-1">
          <div className="flex items-center justify-between text-xs text-slate-400 font-bold">
            <span>অনুমোদনাধীন জমা (Pending)</span>
            <Clock className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-2xl font-black text-amber-400">
            {formatCurrencyBengali(totalPendingAmount)}
          </div>
          <p className="text-[11px] text-slate-400 font-medium">
            {toBengaliNumerals(pendingSavings.length)} টি কিস্তি মডারেটরদের ভোটের অপেক্ষায়।
          </p>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-sm space-y-1">
          <div className="flex items-center justify-between text-xs text-slate-400 font-bold">
            <span>বকেয়া ও পরবর্তী জমাদান</span>
            <Calendar className="w-4 h-4 text-blue-400" />
          </div>
          <div className="text-lg font-black text-white">
            প্রতি মাসের {toBengaliNumerals(config.monthlyDueDay)} তারিখ
          </div>
          <span
            className={`inline-block px-2 py-0.5 rounded-full text-[10px] font-black ${
              isOverdue
                ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
            }`}
          >
            {isOverdue ? 'চলতি মাসের কিস্তি বকেয়া রয়েছে' : 'হিসাব সম্পূর্ণ নিয়মিত ও পরিশোধিত'}
          </span>
        </div>
      </div>

      {/* Personal Info Grid Display */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 sm:p-6 shadow-sm space-y-4">
        <h3 className="text-sm font-black text-white flex items-center gap-2">
          <User className="w-4 h-4 text-emerald-400" />
          <span>যোগাযোগ ও পারিবারিক তথ্য</span>
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
          <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800 flex items-center justify-between">
            <span className="text-slate-400 font-bold flex items-center gap-1.5">
              <Phone className="w-3.5 h-3.5 text-emerald-400" />
              <span>মোবাইল নম্বর:</span>
            </span>
            <span className="font-mono text-emerald-400 font-bold">{currentUser.phone}</span>
          </div>

          <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800 flex items-center justify-between">
            <span className="text-slate-400 font-bold flex items-center gap-1.5">
              <Mail className="w-3.5 h-3.5 text-blue-400" />
              <span>ইমেইল:</span>
            </span>
            <span className="font-mono text-slate-200">{currentUser.email || 'N/A'}</span>
          </div>

          <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800 flex items-center justify-between">
            <span className="text-slate-400 font-bold flex items-center gap-1.5">
              <MapPin className="w-3.5 h-3.5 text-rose-400" />
              <span>ঠিকানা:</span>
            </span>
            <span className="text-slate-200 truncate max-w-[200px]">{currentUser.address || 'তথ্য নেই'}</span>
          </div>

          <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800 flex items-center justify-between">
            <span className="text-slate-400 font-bold flex items-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
              <span>মনোনীত নমিনী:</span>
            </span>
            <span className="text-slate-200 font-bold">
              {currentUser.nomineeName || 'নির্ধারিত হয়নি'}{' '}
              {currentUser.nomineeRelation ? `(${currentUser.nomineeRelation})` : ''}
            </span>
          </div>
        </div>
      </div>

      {/* User's Savings Ledger History with Receipt Print */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 sm:p-6 shadow-sm space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-black text-white flex items-center gap-2">
            <Receipt className="w-4 h-4 text-emerald-400" />
            <span>আমার ব্যক্তিগত জমা ও রসিদ খাতা ({toBengaliNumerals(userSavings.length)} টি)</span>
          </h3>
          <span className="text-[11px] text-slate-400 font-medium">রসিদ দেখতে ক্লিক করুন</span>
        </div>

        {userSavings.length === 0 ? (
          <div className="text-center py-10 text-slate-400 text-xs">
            আপনার অ্যাকাউন্টে এখনও কোনো জমার এন্ট্রি পাওয়া যায়নি।
          </div>
        ) : (
          <div className="space-y-2.5">
            {userSavings.map((tx) => (
              <div
                key={tx.id}
                className="bg-slate-950 border border-slate-800/80 hover:border-slate-700 p-3.5 rounded-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs transition-colors"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-black text-white text-sm">{tx.savingsMonth}</span>
                    <span
                      className={`px-2 py-0.5 rounded-full text-[10px] font-black ${
                        tx.status === 'APPROVED'
                          ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                          : tx.status === 'PENDING'
                          ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                          : 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                      }`}
                    >
                      {tx.status === 'APPROVED' ? 'অনুমোদিত' : tx.status === 'PENDING' ? 'অপেক্ষমান' : 'প্রত্যাখ্যাত'}
                    </span>
                    <span className="text-[11px] text-slate-400 font-mono">
                      {new Date(tx.transactionDate).toLocaleDateString('en-GB')}
                    </span>
                  </div>

                  <p className="text-[11px] text-slate-400">
                    মাধ্যম: <strong className="text-slate-300">{tx.paymentMethod}</strong> • রেফারেন্স:{' '}
                    <span className="font-mono text-slate-300">{tx.transactionRef || 'N/A'}</span>
                  </p>
                </div>

                <div className="flex items-center justify-between sm:justify-end gap-3 self-end sm:self-center">
                  <div className="text-right">
                    <div className="font-black text-emerald-400 text-sm">
                      {formatCurrencyBengali(tx.amount)}
                    </div>
                  </div>

                  {tx.status === 'APPROVED' && (
                    <button
                      onClick={() => {
                        if (onOpenReceipt) {
                          onOpenReceipt(tx.id);
                        } else {
                          const rec = getReceiptForTransaction(tx.id);
                          if (rec) setActivePrintReceipt(rec);
                        }
                      }}
                      className="py-1.5 px-3 rounded-xl bg-slate-800 hover:bg-emerald-600 text-slate-200 hover:text-white transition-all font-bold text-[11px] flex items-center gap-1 cursor-pointer"
                      title="অফিসিয়াল ডিজিটাল রসিদ দেখুন ও প্রিন্ট করুন"
                    >
                      <Printer className="w-3.5 h-3.5" />
                      <span>রসিদ</span>
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Statement Modal for Current User */}
      <StatementPrintModal
        isOpen={isStatementModalOpen}
        member={currentUser}
        transactions={savings.filter((s) => s.memberId === currentUser.id || s.memberId === currentUser.memberId)}
        periodLabel="ALL"
        config={config}
        onClose={() => setIsStatementModalOpen(false)}
      />
    </div>
  );
};
