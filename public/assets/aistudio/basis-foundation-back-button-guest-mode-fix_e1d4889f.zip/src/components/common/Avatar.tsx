import React, { useState, useEffect } from 'react';
import { extractDirectImageUrl } from '../../utils/imageUtils';

interface AvatarProps {
  src?: string;
  name: string;
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl' | '2xl';
  className?: string;
  ringColor?: string;
}

export const Avatar: React.FC<AvatarProps> = ({
  src,
  name,
  size = 'md',
  className = '',
  ringColor,
}) => {
  const [hasError, setHasError] = useState(false);
  const cleanSrc = extractDirectImageUrl(src);

  // Reset error when src changes so new hosted URL immediately re-attempts loading
  useEffect(() => {
    setHasError(false);
  }, [cleanSrc]);

  const sizeClasses = {
    xs: 'w-6 h-6 text-[10px]',
    sm: 'w-8 h-8 text-xs',
    md: 'w-10 h-10 text-sm font-bold',
    lg: 'w-12 h-12 text-base font-bold',
    xl: 'w-16 h-16 text-xl font-bold',
    '2xl': 'w-24 h-24 text-2xl font-black',
  };

  const initial = (name || 'স').trim().charAt(0);

  // If valid cleanSrc and not errored
  if (cleanSrc && !hasError && cleanSrc.trim() !== '') {
    return (
      <div
        className={`relative inline-block shrink-0 rounded-full overflow-hidden shadow-sm ${sizeClasses[size]} ${
          ringColor ? `ring-2 ${ringColor}` : 'ring-1 ring-slate-700/60 dark:ring-slate-700'
        } ${className}`}
      >
        <img
          src={cleanSrc}
          alt={name}
          onError={() => setHasError(true)}
          className="w-full h-full object-cover rounded-full"
          loading="lazy"
        />
      </div>
    );
  }

  // Graceful fallback to vibrant colored initial circle
  return (
    <div
      className={`relative inline-flex items-center justify-center shrink-0 rounded-full font-bold select-none ${
        sizeClasses[size]
      } bg-gradient-to-tr from-emerald-800 to-teal-600 text-white shadow-sm ${
        ringColor ? `ring-2 ${ringColor}` : 'ring-1 ring-emerald-500/30'
      } ${className}`}
    >
      <span>{initial}</span>
    </div>
  );
};
