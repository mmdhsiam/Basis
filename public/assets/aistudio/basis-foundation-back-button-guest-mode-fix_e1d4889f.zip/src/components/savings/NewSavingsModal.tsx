import React, { useState } from 'react';
import { X, PlusCircle, AlertCircle, ShieldCheck, Building2, CreditCard, Calendar } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { PaymentMethod } from '../../types';
import { toBengaliNumerals, formatCurrencyBengali } from '../../utils/calculations';

interface NewSavingsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const NewSavingsModal: React.FC<NewSavingsModalProps> = ({ isOpen, onClose }) => {
  const { users, createSavingsEntry, currentUser, config, checkUserHasPendingDeposit } = useApp();

  const [memberId, setMemberId] = useState<string>(
    currentUser.role === 'MEMBER' ? currentUser.memberId : (users[0]?.memberId || 'BF-001')
  );
  const [showPendingPopup, setShowPendingPopup] = useState<boolean>(false);
  const [amount, setAmount] = useState<number>(config.defaultMonthlyAmount || 1500);
  const [transactionDate, setTransactionDate] = useState<string>(
    new Date().toISOString().split('T')[0]
  );
  const [savingsMonth, setSavingsMonth] = useState<string>('2026-10');

  // Requirement 14: Dynamic month options that expand when last month is selected
  const [monthOptions, setMonthOptions] = useState([
    { id: '2026-08', label: 'আগস্ট ২০২৬' },
    { id: '2026-09', label: 'সেপ্টেম্বর ২০২৬' },
    { id: '2026-10', label: 'অক্টোবর ২০২৬ (চলতি মাস)' },
    { id: '2026-11', label: 'নভেম্বর ২০২৬ (অগ্রিম)' },
  ]);

  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('BKASH');
  const [transactionRef, setTransactionRef] = useState<string>('');
  const [bankName, setBankName] = useState<string>('ইসলামী ব্যাংক বাংলাদেশ পিএলসি');
  const [bankBranch, setBankBranch] = useState<string>('ধানমন্ডি শাখা');
  const [notes, setNotes] = useState<string>('');

  if (!isOpen) return null;

  const handleMonthChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const chosenVal = e.target.value;
    setSavingsMonth(chosenVal);

    // Requirement 14: When last month is chosen, dynamically generate next month
    const lastItem = monthOptions[monthOptions.length - 1];
    if (lastItem && lastItem.id === chosenVal) {
      const [yStr, mStr] = chosenVal.split('-');
      let year = parseInt(yStr, 10);
      let month = parseInt(mStr, 10) + 1;
      if (month > 12) {
        month = 1;
        year += 1;
      }
      const nextMonthId = `${year}-${String(month).padStart(2, '0')}`;
      const bengaliMonths = [
        'জানুয়ারি', 'ফেব্রুয়ারি', 'মার্চ', 'এপ্রিল', 'মে', 'জুন',
        'জুলাই', 'আগস্ট', 'সেপ্টেম্বর', 'অক্টোবর', 'নভেম্বর', 'ডিসেম্বর'
      ];
      const nextMonthLabel = `${bengaliMonths[month - 1]} ${toBengaliNumerals(year)} (স্বয়ংক্রিয় যুক্ত)`;

      setMonthOptions((prev) => [...prev, { id: nextMonthId, label: nextMonthLabel }]);
      alert(`পরবর্তী মাস "${nextMonthLabel}" সফলভাবে ড্রপডাউনে তৈরি ও যুক্ত করা হয়েছে!`);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (amount <= 0) {
      alert('সঞ্চয়ের পরিমাণ অবশ্যই ধনাত্মক হতে হবে।');
      return;
    }

    // Point 3: Duplicate submission check for pending deposit
    if (checkUserHasPendingDeposit(memberId)) {
      setShowPendingPopup(true);
      return;
    }

    let finalRef = transactionRef.trim();
    if (paymentMethod === 'BANK' || paymentMethod === 'BANK_TRANSFER') {
      const bankDetails = `${bankName} (${bankBranch})`;
      finalRef = finalRef ? `${bankDetails} - ভাউচার: ${finalRef}` : bankDetails;
    }

    createSavingsEntry({
      memberId,
      amount: Number(amount),
      savingsMonth,
      savingsYear: Number(savingsMonth.split('-')[0]),
      paymentMethod,
      transactionRef: finalRef || undefined,
      notes: notes.trim() || undefined,
    });

    onClose();
  };

  const selectedMember = users.find((u) => u.memberId === memberId);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-lg w-full p-5 sm:p-6 shadow-2xl space-y-4 max-h-[92vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center">
              <PlusCircle className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-black text-white">নতুন সঞ্চয় জমা এন্ট্রি</h3>
              <p className="text-xs text-slate-400">২/৩ মডারেটর সিলিং অনুমোদন প্রক্রিয়ার আওতাধীন</p>
            </div>
          </div>

          <button
            onClick={onClose}
            aria-label="বন্ধ করুন"
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-3.5 text-xs">
          {/* Member Selection */}
          <div className="space-y-1">
            <label className="font-extrabold text-slate-300">সদস্য নির্বাচন করুন:</label>
            <select
              value={memberId}
              onChange={(e) => setMemberId(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5 text-xs text-white font-bold focus:outline-none focus:ring-1 focus:ring-emerald-500 cursor-pointer"
            >
              {users.map((u) => (
                <option key={u.id} value={u.memberId}>
                  {u.memberId} — {u.name} ({u.phone})
                </option>
              ))}
            </select>
          </div>

          {/* Amount & Month Grid */}
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1">
              <label className="font-extrabold text-slate-300">সঞ্চয়ের পরিমাণ (টাকা):</label>
              <input
                type="number"
                min="100"
                step="50"
                value={amount}
                onChange={(e) => setAmount(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-emerald-400 focus:outline-none focus:ring-1 focus:ring-emerald-500 font-black text-base"
                required
              />
              <span className="text-[10px] text-emerald-400 font-bold block">
                কথায়: {formatCurrencyBengali(amount)}
              </span>
            </div>

            {/* Requirement 14: Month Dropdown with dynamic next-month expansion */}
            <div className="space-y-1">
              <label className="font-extrabold text-slate-300">সঞ্চয়ের মাস:</label>
              <select
                value={savingsMonth}
                onChange={handleMonthChange}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white font-bold focus:outline-none focus:ring-1 focus:ring-emerald-500 cursor-pointer"
              >
                {monthOptions.map((opt) => (
                  <option key={opt.id} value={opt.id}>
                    {opt.label}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Requirement 14: Calendar Date Picker (Year, Month, Day) */}
          <div className="space-y-1 bg-slate-950 p-2.5 rounded-xl border border-slate-800">
            <label className="font-extrabold text-slate-300 flex items-center gap-1.5">
              <Calendar className="w-3.5 h-3.5 text-emerald-400" />
              <span>জমার তারিখ নির্বাচন (বছর, মাস, দিন ক্যালেন্ডার):</span>
            </label>
            <input
              type="date"
              value={transactionDate}
              onChange={(e) => setTransactionDate(e.target.value)}
              className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-xs text-emerald-300 font-mono font-bold focus:outline-none focus:ring-1 focus:ring-emerald-500"
              required
            />
            <p className="text-[10px] text-slate-400">
              নির্বাচিত তারিখ: {new Date(transactionDate).toLocaleDateString('bn-BD', { day: 'numeric', month: 'long', year: 'numeric' })}
            </p>
          </div>

          {/* Payment Method Selection - Bank Option Added Prominently */}
          <div className="space-y-1.5">
            <label className="font-extrabold text-slate-300">পরিশোধের মাধ্যম নির্বাচন করুন:</label>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {[
                { id: 'BKASH', label: 'বিকাশ (bKash)', icon: '📱' },
                { id: 'BANK', label: 'ব্যাংক ট্রান্সফার / ডিপোজিট', icon: '🏦' },
                { id: 'NAGAD', label: 'নগদ (Nagad)', icon: '💳' },
                { id: 'ROCKET', label: 'রকেট (Rocket)', icon: '🚀' },
                { id: 'CASH', label: 'ক্যাশ / সরাসরি নগদ', icon: '💵' },
              ].map((m) => (
                <button
                  type="button"
                  key={m.id}
                  onClick={() => setPaymentMethod(m.id as PaymentMethod)}
                  className={`p-2 rounded-xl text-left border transition-all text-xs font-black flex items-center gap-2 ${
                    paymentMethod === m.id
                      ? 'bg-emerald-600/20 border-emerald-500 text-white shadow-sm'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  <span className="text-base">{m.icon}</span>
                  <span className="truncate">{m.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Conditional Bank Details Input */}
          {(paymentMethod === 'BANK' || paymentMethod === 'BANK_TRANSFER') && (
            <div className="p-3.5 rounded-2xl bg-slate-950 border border-emerald-900/50 space-y-2.5">
              <div className="flex items-center gap-1.5 text-emerald-400 font-black text-xs">
                <Building2 className="w-4 h-4" />
                <span>ব্যাংক ডিপোজিট বা ট্রান্সফার তথ্য</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                <div>
                  <label className="text-[11px] text-slate-400 block mb-1">ব্যাংকের নাম:</label>
                  <input
                    type="text"
                    value={bankName}
                    onChange={(e) => setBankName(e.target.value)}
                    placeholder="যেমন: ইসলামী ব্যাংক / ব্র্যাক ব্যাংক"
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-white"
                  />
                </div>
                <div>
                  <label className="text-[11px] text-slate-400 block mb-1">শাখা (Branch):</label>
                  <input
                    type="text"
                    value={bankBranch}
                    onChange={(e) => setBankBranch(e.target.value)}
                    placeholder="যেমন: ধানমন্ডি শাখা"
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-white"
                  />
                </div>
              </div>
            </div>
          )}

          {/* Transaction Ref */}
          <div className="space-y-1">
            <label className="font-extrabold text-slate-300">
              {paymentMethod === 'BANK' ? 'ভাউচার / ডিপোজিট স্লিপ নং:' : 'ট্রানজেকশন আইডি / রেফারেন্স:'}
            </label>
            <input
              type="text"
              placeholder={paymentMethod === 'BANK' ? 'যেমন: DEP-20261016-092' : 'যেমন: BK-88129384'}
              value={transactionRef}
              onChange={(e) => setTransactionRef(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:ring-1 focus:ring-emerald-500 font-mono"
            />
          </div>

          {/* Notes */}
          <div className="space-y-1">
            <label className="font-extrabold text-slate-300">মন্তব্য বা বিবরণ (ঐচ্ছিক):</label>
            <input
              type="text"
              placeholder="জমার বিবরণ লিখুন..."
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:ring-1 focus:ring-emerald-500"
            />
          </div>

          {/* Approval Policy Note */}
          <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800 flex items-start gap-2 text-[11px] text-slate-400">
            <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
            <span>
              নীতিমালা অনুচ্ছেদ ৫: এই এন্ট্রিটি দাখিলের পর অবিলম্বে পেন্ডিং থাকবে। যোগ্য মডারেটরদের ২/৩ অংশ (Ceiling) ভোট প্রদানের পর রসিদ প্রস্তুত হবে এবং মূল তহবিলে যোগ হবে।
            </span>
          </div>

          {/* Action Buttons */}
          <div className="pt-2 flex items-center justify-end gap-2.5">
            <button
              type="button"
              onClick={onClose}
              className="py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs transition-colors"
            >
              বাতিল
            </button>
            <button
              type="submit"
              className="py-2.5 px-5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs shadow-lg shadow-emerald-600/30 transition-colors flex items-center gap-1.5"
            >
              <PlusCircle className="w-4 h-4" />
              <span>জমা এন্ট্রি দাখিল করুন</span>
            </button>
          </div>
        </form>
      </div>

      {/* Point 3: Duplicate Submission Warning Popup */}
      {showPendingPopup && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-slate-950/90 backdrop-blur-md animate-in fade-in duration-200">
          <div className="bg-slate-900 border border-amber-500/50 rounded-3xl max-w-sm w-full p-6 text-center space-y-4 shadow-2xl">
            <div className="w-14 h-14 rounded-3xl bg-amber-500/20 text-amber-400 border border-amber-500/30 flex items-center justify-center mx-auto shadow-lg shadow-amber-500/20">
              <AlertCircle className="w-8 h-8" />
            </div>

            <div className="space-y-1.5">
              <h4 className="text-base font-extrabold text-white">
                অনুমোদনের অপেক্ষায় রয়েছে!
              </h4>
              <p className="text-xs text-amber-200/90 font-medium leading-relaxed">
                আপনি একবার টাকা জমার তথ্য সাবমিট করেছেন, অনুগ্রহ করে মডারেটর প্যানেলের অনুমোদনের জন্য অপেক্ষা করুন।
              </p>
            </div>

            <div className="pt-2">
              <button
                type="button"
                onClick={() => {
                  setShowPendingPopup(false);
                  onClose();
                }}
                className="w-full py-2.5 px-5 rounded-2xl bg-gradient-to-r from-amber-600 to-amber-500 hover:from-amber-500 hover:to-amber-400 text-white font-black text-xs shadow-lg shadow-amber-600/30 transition-all cursor-pointer"
              >
                ঠিক আছে, বুঝেছি
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
