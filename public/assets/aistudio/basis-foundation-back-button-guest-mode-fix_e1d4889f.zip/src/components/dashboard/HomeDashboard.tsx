import React, { useState } from 'react';
import {
  Wallet,
  TrendingUp,
  Users,
  CheckCircle2,
  Bell,
  Search,
  Phone,
  PlusCircle,
  FileSpreadsheet,
  Shield,
  ShieldCheck,
  AlertCircle,
  ArrowRight,
  ExternalLink,
  ChevronRight,
  Lightbulb,
  Receipt,
  Sparkles,
  BarChart3,
  Clock,
  Send,
  Building,
  Building2,
  MessageSquare,
  BookOpen,
  FileText,
  HelpCircle,
  CreditCard,
  Lock,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import {
  formatCurrencyBengali,
  toBengaliNumerals,
} from '../../utils/calculations';
import { Avatar } from '../common/Avatar';

interface HomeDashboardProps {
  setActiveTab: (tab: string) => void;
  onOpenNewSavingsModal: () => void;
}

export const HomeDashboard: React.FC<HomeDashboardProps> = ({
  setActiveTab,
  onOpenNewSavingsModal,
}) => {
  const {
    currentUser,
    users,
    savings,
    financialTotals,
    growthRate,
    monthlyAggregates,
    notices,
    rules,
    complaints,
    featureRequests,
    chatMessages,
    receipts,
    config,
    overdueReminders,
    sendOverdueReminder,
    totalExpenses,
    netReserveBalance,
  } = useApp();

  const [selectedMonth, setSelectedMonth] = useState('2026-10');
  const [isOverdueExpanded, setIsOverdueExpanded] = useState(false);

  const [isAlertDismissed, setIsAlertDismissed] = useState(false);

  const isModeratorOrAppMod =
    currentUser?.role === 'APP_MODERATOR' || currentUser?.role === 'MODERATOR';

  // Current Month deposits ordered by deposit date/time
  const monthDeposits = savings
    .filter((t) => t.savingsMonth === selectedMonth && t.status === 'APPROVED')
    .sort((a, b) => new Date(b.transactionDate).getTime() - new Date(a.transactionDate).getTime());

  const currentMonthTotalAmount = monthDeposits.reduce((sum, t) => sum + t.amount, 0);
  const depositedMemberIds = new Set(monthDeposits.map((t) => t.memberId));

  // Overdue members for current month (excluding members who deposited or have pending deposit)
  const overdueMembers = users.filter(
    (u) =>
      u.status === 'APPROVED' &&
      !savings.some(
        (t) =>
          t.memberId === u.memberId &&
          t.savingsMonth === selectedMonth &&
          (t.status === 'APPROVED' || t.status === 'PENDING')
      )
  );

  // Check if current user has an approved or pending deposit this month
  const hasUserDepositedOrPending = currentUser
    ? savings.some(
        (t) =>
          t.memberId === currentUser.memberId &&
          t.savingsMonth === selectedMonth &&
          (t.status === 'APPROVED' || t.status === 'PENDING')
      )
    : false;

  const isCurrentUserReminded =
    currentUser &&
    currentUser.role === 'MEMBER' &&
    !hasUserDepositedOrPending &&
    !isAlertDismissed &&
    (overdueReminders.includes(currentUser.memberId) || !hasUserDepositedOrPending);

  const handleSendReminder = (memberId: string) => {
    sendOverdueReminder(memberId);
  };

  const pinnedNotice = notices.find((n) => n.isPinned) || notices[0];

  return (
    <div className="space-y-5 pb-16">
      {/* Red Alert Box Popup when Member has Overdue Reminder */}
      {isCurrentUserReminded && (
        <div className="bg-gradient-to-r from-rose-950 via-rose-900/90 to-slate-900 border-2 border-rose-600 rounded-3xl p-4 sm:p-5 shadow-2xl flex flex-col sm:flex-row items-center justify-between gap-4 animate-in fade-in zoom-in-95 duration-200 relative">
          <button
            onClick={() => setIsAlertDismissed(true)}
            aria-label="নোটিশ বন্ধ করুন"
            className="absolute right-3 top-3 p-1 rounded-lg text-rose-300 hover:text-white hover:bg-rose-800/50 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
          <div className="flex items-center gap-3.5 text-center sm:text-left pr-6 sm:pr-0">
            <div className="w-12 h-12 rounded-2xl bg-rose-600 text-white flex items-center justify-center shrink-0 shadow-lg shadow-rose-600/40 animate-pulse">
              <AlertCircle className="w-7 h-7" />
            </div>
            <div>
              <div className="flex items-center justify-center sm:justify-start gap-2">
                <span className="text-[11px] font-black uppercase tracking-wider px-2 py-0.5 rounded bg-rose-500/20 text-rose-300 border border-rose-500/30">
                  জরুরি বকেয়া নোটিশ
                </span>
                <span className="text-xs text-rose-300 font-bold">
                  {currentUser.name} ({currentUser.memberId})
                </span>
              </div>
              <p className="text-white font-black text-sm sm:text-base mt-1 leading-snug">
                "আপনি এই মাসের টাকা এখনো জমা দেননি। যথা সময়ে টাকা জমা করার জন্য অনুরোধ করা হলো।"
              </p>
              <p className="text-xs text-rose-200 font-bold mt-0.5">
                নির্ধারিত জমা: ৳{toBengaliNumerals(config.defaultMonthlyAmount || 1500)} • শেষ তারিখ: প্রতি মাসের {toBengaliNumerals(config.monthlyDueDay || 10)} তারিখ
              </p>
            </div>
          </div>

          <button
            onClick={onOpenNewSavingsModal}
            className="w-full sm:w-auto py-3 px-6 rounded-2xl bg-rose-600 hover:bg-rose-500 text-white font-black text-xs sm:text-sm shadow-xl shadow-rose-600/40 transition-all flex items-center justify-center gap-2 shrink-0 cursor-pointer"
          >
            <PlusCircle className="w-4 h-4" />
            <span>এখনই টাকা জমা দিন</span>
          </button>
        </div>
      )}

      {/* 1. Quick Horizontal Sub-Nav Pills */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs font-black scrollbar-none">
        <button
          onClick={() => setActiveTab('home')}
          className="py-2 px-4 rounded-2xl bg-emerald-600 text-white shadow-md shadow-emerald-600/30 shrink-0"
        >
          হোম ড্যাশবোর্ড
        </button>
        <button
          onClick={() => setActiveTab('savings')}
          className="py-2 px-4 rounded-2xl bg-slate-900 border border-slate-800 text-slate-300 hover:text-white hover:bg-slate-800 transition-colors shrink-0"
        >
          মাসিক সঞ্চয় খাতা
        </button>
        <button
          onClick={() => setActiveTab('analytics')}
          className="py-2 px-4 rounded-2xl bg-slate-900 border border-slate-800 text-slate-300 hover:text-white hover:bg-slate-800 transition-colors shrink-0"
        >
          হিসাব বিশ্লেষণ ও গ্রাফ
        </button>
        <button
          onClick={() => setActiveTab('receipts')}
          className="py-2 px-4 rounded-2xl bg-slate-900 border border-slate-800 text-slate-300 hover:text-white hover:bg-slate-800 transition-colors shrink-0"
        >
          রসিদ ও বিবরণী
        </button>
        <button
          onClick={() => setActiveTab('about-us')}
          className="py-2 px-4 rounded-2xl bg-slate-900 border border-slate-800 text-emerald-400 hover:bg-slate-800 transition-colors shrink-0 flex items-center gap-1"
        >
          <Sparkles className="w-3.5 h-3.5" />
          <span>আমাদের সম্পর্কে</span>
        </button>
      </div>

      {/* 2. Urgent Notice Card */}
      {pinnedNotice && (
        <div className="bg-gradient-to-r from-amber-950/40 via-slate-900 to-slate-900 border border-amber-600/40 rounded-3xl p-4 sm:p-5 shadow-lg flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="p-1 rounded-lg bg-amber-500/20 text-amber-400">
                <Bell className="w-3.5 h-3.5" />
              </span>
              <span className="text-xs font-black text-amber-400">
                জরুরি বিজ্ঞপ্তি • {pinnedNotice.authorName}
              </span>
              <CheckCircle2 className="w-3.5 h-3.5 text-blue-400" />
            </div>
            <h3 className="font-black text-white text-base">
              {pinnedNotice.title}
            </h3>
            <p className="text-xs text-slate-300 line-clamp-1 max-w-2xl leading-relaxed">
              {pinnedNotice.content}
            </p>
          </div>

          <button
            onClick={() => setActiveTab('notices')}
            className="py-2 px-4 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 border border-amber-500/40 text-amber-300 font-black text-xs transition-colors flex items-center gap-1.5 self-start sm:self-auto shrink-0 cursor-pointer"
          >
            <span>সম্পূর্ণ পড়ুন</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Requirement 18: জরুরি বিজ্ঞপ্তির পরেই চলতি মাসের আদায়ের সংক্ষিপ্ত চিত্র ও ইউজারদের সর্বশেষ ৫ জনের তালিকা */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-4 sm:p-5 shadow-sm space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-slate-800 pb-3 gap-2">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0">
              <Clock className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-black text-white text-sm sm:text-base">
                চলতি মাসের আদায়ের সংক্ষিপ্ত চিত্র ও সর্বশেষ ৫ জন জমাকারী
              </h3>
              <p className="text-[11px] text-slate-400">
                চলতি মাসে মোট আদায়: <strong className="text-emerald-400 font-black">{formatCurrencyBengali(currentMonthTotalAmount)}</strong> • জমাদানকারী: <strong className="text-white font-black">{toBengaliNumerals(monthDeposits.length)} জন</strong>
              </p>
            </div>
          </div>

          <button
            onClick={() => setActiveTab('savings')}
            className="text-xs font-black text-emerald-400 hover:underline flex items-center gap-1 self-start sm:self-auto shrink-0 cursor-pointer"
          >
            <span>সম্পূর্ণ সঞ্চয় খাতা</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Latest 5 Approved Deposits in Clean Compact Cards (Horizontal Scrollable) */}
<div className="flex gap-2.5 pt-1 overflow-x-auto pb-2 scroll-smooth">
  {monthDeposits.slice(0, 5).map((tx) => (
    <div
      key={tx.id}
      className="min-w-[180px] sm:min-w-[200px] flex-1 shrink-0 p-3 rounded-2xl bg-slate-950/80 border border-slate-800/80 hover:border-slate-700 flex flex-col justify-between transition-colors space-y-2 shadow-sm"
    >
      <div className="flex items-center gap-2">
        <Avatar
          src={users.find((u) => u.memberId === tx.memberId)?.avatarUrl}
          name={tx.memberName}
          size="sm"
        />
        <div className="truncate min-w-0">
          <h4 className="font-extrabold text-xs text-white truncate">{tx.memberName}</h4>
          <span className="font-mono text-emerald-400 font-bold text-[10px] block">
            {tx.memberId}
          </span>
        </div>
      </div>

      <div className="pt-2 border-t border-slate-800/60 flex items-center justify-between text-xs">
        <span className="text-[10px] text-slate-400 font-medium">{tx.paymentMethod}</span>
        <span className="font-black text-emerald-400 text-xs">
          {formatCurrencyBengali(tx.amount)}
        </span>
      </div>
    </div>
  ))}
  {monthDeposits.length === 0 && (
    <div className="w-full py-4 text-center text-xs text-slate-500">
      চলতি মাসে এখনও কোনো সঞ্চয় জমা অনুমোদিত হয়নি।
    </div>
  )}
</div>

        {/* Overdue Alert Banner with Expand Option */}
        {overdueMembers.length > 0 && (
          <div className="pt-2">
            <div className="p-3 rounded-2xl bg-rose-950/30 border border-rose-900/40 flex items-center justify-between text-xs">
              <div className="flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
                <span className="text-rose-200 font-bold">
                  বকেয়া সদস্য: <strong className="text-rose-300 font-black">{toBengaliNumerals(overdueMembers.length)} জন</strong> এখনো চলতি মাসের জমা দেননি।
                </span>
              </div>

              <button
                onClick={() => setIsOverdueExpanded(!isOverdueExpanded)}
                className="py-1 px-3 rounded-xl bg-rose-900/50 hover:bg-rose-900 text-rose-200 text-xs font-black transition-colors cursor-pointer"
              >
                {isOverdueExpanded ? 'সংক্ষিপ্ত করুন' : 'তালিকা দেখুন'}
              </button>
            </div>

            {/* Expanded Overdue List */}
            {isOverdueExpanded && (
              <div className="mt-2 space-y-1.5 p-3 rounded-2xl bg-slate-950 border border-rose-900/30 max-h-56 overflow-y-auto">
                {overdueMembers.map((m) => {
                  const isReminded = overdueReminders.includes(m.memberId);
                  return (
                    <div
                      key={m.id}
                      className="flex items-center justify-between p-2 rounded-xl bg-slate-900/60 text-xs"
                    >
                      <div className="flex items-center gap-2">
                        <Avatar src={m.avatarUrl} name={m.name} size="xs" />
                        <span className="text-white font-bold">{m.name}</span>
                        <span className="text-slate-400 font-mono text-[11px] font-bold">({m.memberId})</span>
                      </div>

                      <button
                        onClick={() => handleSendReminder(m.memberId)}
                        disabled={isReminded}
                        className={`py-1 px-2.5 rounded-lg text-[10px] font-black transition-all flex items-center gap-1 cursor-pointer ${
                          isReminded
                            ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                            : 'bg-rose-600 hover:bg-rose-500 text-white'
                        }`}
                      >
                        <Send className="w-3 h-3" />
                        <span>{isReminded ? 'তাগিদ পাঠানো হয়েছে' : 'তাগিদ পাঠান'}</span>
                      </button>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}
      </div>

      {/* Top Executive KPI Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
        {/* সর্বমোট সঞ্চিত তহবিল */}
        <div
          onClick={() => setActiveTab('bank')}
          className="bg-slate-900 border border-slate-800 hover:border-emerald-500/50 rounded-3xl p-4 sm:p-5 shadow-md transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-black text-slate-400">
              {config.dashboardBalanceDisplay === 'NET_AFTER_EXPENSE'
                ? 'প্রকৃত অবশিষ্ট সঞ্চিত তহবিল (খরচ বাদে)'
                : 'সর্বমোট সঞ্চিত তহবিল (গ্রস জমা)'}
            </span>
            <div className="w-10 h-10 rounded-2xl bg-emerald-500/20 border border-emerald-500/30 text-emerald-400 flex items-center justify-center shadow-inner">
              <Wallet className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-2.5">
            <h3 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
              {formatCurrencyBengali(
                config.dashboardBalanceDisplay === 'NET_AFTER_EXPENSE'
                  ? netReserveBalance
                  : financialTotals.totalApproved
              )}
            </h3>
            <div className="mt-1 flex items-center gap-1 text-xs text-emerald-400 font-bold">
              <TrendingUp className="w-3.5 h-3.5" />
              <span>
                {config.dashboardBalanceDisplay === 'NET_AFTER_EXPENSE'
                  ? `মোট খরচ বাদ দেওয়া হয়েছে (খরচ: ${formatCurrencyBengali(totalExpenses)}) • ব্যাংক হিসাব →`
                  : `${growthRate.formatted} প্রবৃদ্ধি • ব্যাংক ও খরচ হিসাব →`}
              </span>
            </div>
          </div>
        </div>

        {/* চলতি মাসের জমা */}
        <div
          onClick={() => setActiveTab('savings')}
          className="bg-slate-900 border border-slate-800 hover:border-teal-500/50 rounded-3xl p-4 sm:p-5 shadow-md transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-black text-slate-400">চলতি মাসের আদায়</span>
            <div className="w-10 h-10 rounded-2xl bg-teal-500/20 border border-teal-500/30 text-teal-400 flex items-center justify-center shadow-inner">
              <TrendingUp className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-2.5">
            <h3 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
              {formatCurrencyBengali(currentMonthTotalAmount)}
            </h3>
            <div className="mt-1 flex items-center gap-1 text-xs text-slate-400 font-bold">
              <span>{toBengaliNumerals(monthDeposits.length)} জন প্রদান করেছেন →</span>
            </div>
          </div>
        </div>

        {/* সক্রিয় সদস্য সংখ্যা */}
        <div
          onClick={() => setActiveTab('members')}
          className="bg-slate-900 border border-slate-800 hover:border-blue-500/50 rounded-3xl p-4 sm:p-5 shadow-md transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-black text-slate-400">সক্রিয় সদস্য সংখ্যা</span>
            <div className="w-10 h-10 rounded-2xl bg-blue-500/20 border border-blue-500/30 text-blue-400 flex items-center justify-center shadow-inner">
              <Users className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-2.5">
            <h3 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
              {toBengaliNumerals(users.filter((u) => u.status === 'APPROVED').length)} জন
            </h3>
            <div className="mt-1 flex items-center gap-1 text-xs text-blue-400 font-bold">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>অনুমোদিত সদস্য তালিকা →</span>
            </div>
          </div>
        </div>

        {/* ২/৩ মডারেটর অনুমোদন */}
        <div
          onClick={() => setActiveTab('rules')}
          className="bg-slate-900 border border-slate-800 hover:border-purple-500/50 rounded-3xl p-4 sm:p-5 shadow-md transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-black text-slate-400">২/৩ মডারেটর অনুমোদন</span>
            <div className="w-10 h-10 rounded-2xl bg-purple-500/20 border border-purple-500/30 text-purple-400 flex items-center justify-center shadow-inner">
              <ShieldCheck className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-2.5">
            <h3 className="text-2xl sm:text-3xl font-black text-emerald-400 tracking-tight flex items-center gap-1.5">
              <span>সুরক্ষিত</span>
              <CheckCircle2 className="w-6 h-6 text-blue-400 inline" />
            </h3>
            <div className="mt-1 flex items-center gap-1 text-xs text-slate-400 font-bold">
              <span>গঠনতন্ত্র ও ডিজিটাল লেজার সংরক্ষিত</span>
            </div>
          </div>
        </div>
      </div>

      {/* Requirement 19: All Tabs Summary Cards with Live Data Preview */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-base font-black text-white flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-emerald-400" />
            <span>সকল সেকশনের লাইভ সারসংক্ষেপ কার্ড (Overview with Live Data)</span>
          </h3>
          <span className="text-xs text-slate-400 font-bold">
            সরাসরি সেকশনে প্রবেশ করতে ক্লিক করুন
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
          {/* Card 1: সদস্যবৃন্দ - Live Preview with 4 Avatars (Requirement 19) */}
          <div
            onClick={() => setActiveTab('members')}
            className="p-4 rounded-3xl bg-slate-900 border border-slate-800 hover:border-blue-500/50 transition-all cursor-pointer space-y-3 group shadow-sm flex flex-col justify-between"
          >
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <div className="w-10 h-10 rounded-2xl bg-blue-500/20 text-blue-400 flex items-center justify-center font-black">
                  <Users className="w-5 h-5" />
                </div>
                <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-blue-500/20 text-blue-400 border border-blue-500/30">
                  সদস্য ও পদবী
                </span>
              </div>
              <h4 className="font-black text-white text-base group-hover:text-blue-400 transition-colors">
                সদস্যবৃন্দ ও প্রোফাইল
              </h4>
              <p className="text-xs text-slate-400 leading-relaxed">
                মোট <strong className="text-white font-black">{toBengaliNumerals(users.length)}</strong> জন নিবন্ধিত সদস্য ও মডারেটর।
              </p>

              {/* Requirement 19: Live Avatars preview */}
              <div className="flex items-center gap-1.5 pt-1">
                {users.slice(0, 4).map((u) => (
                  <Avatar key={u.id} src={u.avatarUrl} name={u.name} size="xs" />
                ))}
                {users.length > 4 && (
                  <span className="text-[10px] text-slate-400 font-bold ml-1">
                    +{toBengaliNumerals(users.length - 4)} জন
                  </span>
                )}
              </div>
            </div>
            <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-xs text-blue-400 font-black">
              <span>সদস্য তালিকা দেখুন</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </div>
          </div>

          {/* Card 2: হিসাব বিশ্লেষণ ও গ্রাফ - Live Mini Graph (Requirement 19) */}
          <div
            onClick={() => setActiveTab('analytics')}
            className="p-4 rounded-3xl bg-slate-900 border border-slate-800 hover:border-purple-500/50 transition-all cursor-pointer space-y-3 group shadow-sm flex flex-col justify-between"
          >
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <div className="w-10 h-10 rounded-2xl bg-purple-500/20 text-purple-400 flex items-center justify-center font-black">
                  <BarChart3 className="w-5 h-5" />
                </div>
                <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-400 border border-purple-500/30">
                  গ্রাফ ও অ্যানালিটিক্স
                </span>
              </div>
              <h4 className="font-black text-white text-base group-hover:text-purple-400 transition-colors">
                হিসাব বিশ্লেষণ ও গ্রাফ
              </h4>

              {/* Requirement 19: Mini Visual Trend Bar Chart */}
              <div className="flex items-end gap-1.5 h-10 pt-1 px-1 bg-slate-950/60 rounded-xl">
                {Object.entries(monthlyAggregates)
                  .slice(-5)
                  .map(([mon, amt]) => {
                    const maxVal = Math.max(...Object.values(monthlyAggregates), 1);
                    const heightPct = Math.max(20, Math.round((amt / maxVal) * 100));
                    return (
                      <div key={mon} className="flex-1 flex flex-col items-center gap-0.5 h-full justify-end">
                        <div
                          className="w-full bg-gradient-to-t from-purple-600 to-indigo-400 rounded-t transition-all"
                          style={{ height: `${heightPct}%` }}
                          title={`${mon}: ৳${amt}`}
                        />
                        <span className="text-[8px] text-slate-500 font-mono leading-none">
                          {mon.slice(5)}
                        </span>
                      </div>
                    );
                  })}
              </div>
            </div>
            <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-xs text-purple-400 font-black">
              <span>চার্ট ও অ্যানালিটিক্স</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </div>
          </div>

          {/* Card 3: মডারেটর অনুমোদন প্যানেল - Live Moderator List (Requirement 15: Only for Moderators) */}
          {(currentUser.role === 'APP_MODERATOR' || currentUser.role === 'MODERATOR') && (
            <div
              onClick={() => setActiveTab('moderator')}
              className="p-4 rounded-3xl bg-slate-900 border border-slate-800 hover:border-amber-500/50 transition-all cursor-pointer space-y-3 group shadow-sm flex flex-col justify-between"
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="w-10 h-10 rounded-2xl bg-amber-500/20 text-amber-400 flex items-center justify-center font-black">
                    <ShieldCheck className="w-5 h-5" />
                  </div>
                  <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-400 border border-amber-500/30">
                    ২/৩ সিলিং ভোট
                  </span>
                </div>
                <h4 className="font-black text-white text-base group-hover:text-amber-400 transition-colors">
                  মডারেটর অনুমোদন প্যানেল
                </h4>

                {/* Requirement 19: Live active moderators badges */}
                <div className="flex items-center gap-1.5 pt-1 flex-wrap">
                  {users
                    .filter((u) => u.role !== 'MEMBER')
                    .slice(0, 3)
                    .map((m) => (
                      <span
                        key={m.id}
                        className="text-[10px] bg-amber-500/10 border border-amber-500/20 text-amber-300 px-2 py-0.5 rounded-full flex items-center gap-1 font-bold"
                      >
                        <CheckCircle2 className="w-2.5 h-2.5 text-blue-400 inline" />
                        <span>{m.name.split(' ')[0]}</span>
                      </span>
                    ))}
                </div>
              </div>
              <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-xs text-amber-400 font-black">
                <span>অনুমোদন ড্যাশবোর্ড</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </div>
            </div>
          )}

          {/* Card 4: মাসিক সঞ্চয় খাতা */}
          <div
            onClick={() => setActiveTab('savings')}
            className="p-4 rounded-3xl bg-slate-900 border border-slate-800 hover:border-emerald-500/50 transition-all cursor-pointer space-y-3 group shadow-sm flex flex-col justify-between"
          >
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <div className="w-10 h-10 rounded-2xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-black">
                  <Wallet className="w-5 h-5" />
                </div>
                <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                  সঞ্চয় লেজার
                </span>
              </div>
              <h4 className="font-black text-white text-base group-hover:text-emerald-400 transition-colors">
                মাসিক সঞ্চয় ও জমা
              </h4>
              <div className="bg-slate-950/70 p-2 rounded-xl text-[11px] text-emerald-300 font-bold flex items-center justify-between">
                <span>চলতি মাসে আদায়:</span>
                <span className="text-white font-black">{formatCurrencyBengali(currentMonthTotalAmount)}</span>
              </div>
            </div>
            <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-xs text-emerald-400 font-black">
              <span>সঞ্চয় খাতা খুলুন</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </div>
          </div>

          {/* Card 5: ডিজিটাল রসিদ ও স্টেটমেন্ট */}
          <div
            onClick={() => setActiveTab('receipts')}
            className="p-4 rounded-3xl bg-slate-900 border border-slate-800 hover:border-teal-500/50 transition-all cursor-pointer space-y-3 group shadow-sm flex flex-col justify-between"
          >
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <div className="w-10 h-10 rounded-2xl bg-teal-500/20 text-teal-400 flex items-center justify-center font-black">
                  <Receipt className="w-5 h-5" />
                </div>
                <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-teal-500/20 text-teal-400 border border-teal-500/30">
                  ই-রসিদ ও প্রিন্ট
                </span>
              </div>
              <h4 className="font-black text-white text-base group-hover:text-teal-400 transition-colors">
                ডিজিটাল রসিদ ও স্টেটমেন্ট
              </h4>
              <div className="bg-slate-950/70 p-2 rounded-xl text-[10px] text-teal-300 font-mono flex items-center justify-between">
                <span>সর্বশেষ প্রস্তুত রসিদ:</span>
                <span className="text-white font-bold">{receipts[0]?.receiptNumber || 'BF-2026-REC-01'}</span>
              </div>
            </div>
            <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-xs text-teal-400 font-black">
              <span>রসিদ প্রিভিউ ও প্রিন্ট</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </div>
          </div>

          {/* Card 6: ব্যাংক ইনফরমেশন ও খরচের হিসাব */}
          <div
            onClick={() => setActiveTab('bank')}
            className="p-4 rounded-3xl bg-slate-900 border border-slate-800 hover:border-indigo-500/50 transition-all cursor-pointer space-y-3 group shadow-sm flex flex-col justify-between"
          >
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <div className="w-10 h-10 rounded-2xl bg-indigo-500/20 text-indigo-400 flex items-center justify-center font-black">
                  <Building2 className="w-5 h-5" />
                </div>
                <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-400 border border-indigo-500/30">
                  ব্যাংক ও QR
                </span>
              </div>
              <h4 className="font-black text-white text-base group-hover:text-indigo-400 transition-colors">
                ব্যাংক ইনফরমেশন ও অফিসিয়াল হিসাব
              </h4>
              <div className="bg-slate-950/70 p-2 rounded-xl text-[11px] text-indigo-300 font-bold flex items-center justify-between">
                <span className="font-mono truncate">{config.bankDetails?.bankName || 'ইসলামী ব্যাংক বাংলাদেশ'}</span>
                <span className="text-emerald-400 font-black shrink-0">{formatCurrencyBengali(netReserveBalance)}</span>
              </div>
            </div>
            <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-xs text-indigo-400 font-black">
              <span>ব্যাংক বিবরণ ও হিসাব দেখুন</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </div>
          </div>

          {/* Card 7: কমিউনিটি চ্যাট ও ইনবক্স */}
          <div
            onClick={() => setActiveTab('chat')}
            className="p-4 rounded-3xl bg-slate-900 border border-slate-800 hover:border-indigo-500/50 transition-all cursor-pointer space-y-3 group shadow-sm flex flex-col justify-between"
          >
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <div className="w-10 h-10 rounded-2xl bg-indigo-500/20 text-indigo-400 flex items-center justify-center font-black">
                  <MessageSquare className="w-5 h-5" />
                </div>
                <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-400 border border-indigo-500/30">
                  বার্তালাপ
                </span>
              </div>
              <h4 className="font-black text-white text-base group-hover:text-indigo-400 transition-colors">
                কমিউনিটি চ্যাট ও ইনবক্স
              </h4>
              <div className="bg-slate-950/70 p-2 rounded-xl text-[10px] text-slate-300 truncate">
                <strong className="text-indigo-400">
                  {chatMessages[chatMessages.length - 1]?.senderName}:{' '}
                </strong>
                {chatMessages[chatMessages.length - 1]?.text || 'কোনো বার্তা নেই'}
              </div>
            </div>
            <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-xs text-indigo-400 font-black">
              <span>চ্যাট বক্সে প্রবেশ করুন</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </div>
          </div>

          {/* Card 8: নোটিশ ও ঘোষণা */}
          <div
            onClick={() => setActiveTab('notices')}
            className="p-4 rounded-3xl bg-slate-900 border border-slate-800 hover:border-amber-500/50 transition-all cursor-pointer space-y-3 group shadow-sm flex flex-col justify-between"
          >
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <div className="w-10 h-10 rounded-2xl bg-amber-500/20 text-amber-400 flex items-center justify-center font-black">
                  <Bell className="w-5 h-5" />
                </div>
                <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-400 border border-amber-500/30">
                  ঘোষণা বোর্ড
                </span>
              </div>
              <h4 className="font-black text-white text-base group-hover:text-amber-400 transition-colors">
                নোটিশ ও ঘোষণা
              </h4>
              <p className="text-xs text-slate-400 line-clamp-2 leading-relaxed">
                জরুরি সার্কুলার, সাধারণ নোটিশ ও সময়োপযোগী প্রশাসনিক নির্দেশনা সমূহ।
              </p>
            </div>
            <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-xs text-amber-400 font-black">
              <span>সকল নোটিশ দেখুন</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </div>
          </div>

          {/* Card 9: নিয়মাবলী ও গঠনতন্ত্র */}
          <div
            onClick={() => setActiveTab('rules')}
            className="p-4 rounded-3xl bg-slate-900 border border-slate-800 hover:border-rose-500/50 transition-all cursor-pointer space-y-3 group shadow-sm flex flex-col justify-between"
          >
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <div className="w-10 h-10 rounded-2xl bg-rose-500/20 text-rose-400 flex items-center justify-center font-black">
                  <FileText className="w-5 h-5" />
                </div>
                <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-400 border border-rose-500/30">
                  গঠনতন্ত্র ও বিধি
                </span>
              </div>
              <h4 className="font-black text-white text-base group-hover:text-rose-400 transition-colors">
                নিয়মাবলী ও গঠনতন্ত্র
              </h4>
              <p className="text-xs text-slate-400 line-clamp-2 leading-relaxed">
                ফাউন্ডেশনের অনুমোদিত গঠনতন্ত্র, ধারা-উপধারা ও নিয়মাবলীর সর্বশেষ সংশোধিত সংস্করণ।
              </p>
            </div>
            <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-xs text-rose-400 font-black">
              <span>গঠনতন্ত্র পাঠ করুন</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </div>
          </div>

          {/* Card 10: অভিযোগ ও পরামর্শ */}
          <div
            onClick={() => setActiveTab('complaints')}
            className="p-4 rounded-3xl bg-slate-900 border border-slate-800 hover:border-teal-500/50 transition-all cursor-pointer space-y-3 group shadow-sm flex flex-col justify-between"
          >
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <div className="w-10 h-10 rounded-2xl bg-teal-500/20 text-teal-400 flex items-center justify-center font-black">
                  <HelpCircle className="w-5 h-5" />
                </div>
                <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-teal-500/20 text-teal-400 border border-teal-500/30">
                  অভিযোগ সেল
                </span>
              </div>
              <h4 className="font-black text-white text-base group-hover:text-teal-400 transition-colors">
                অভিযোগ ও পরামর্শ বক্স
              </h4>
              <p className="text-xs text-slate-400 leading-relaxed">
                মোট <strong className="text-white font-black">{toBengaliNumerals(complaints.length)}</strong> টি অভিযোগ ও পরামর্শ দাখিল ও নিষ্পত্তির ট্র্যাকিং।
              </p>
            </div>
            <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-xs text-teal-400 font-black">
              <span>অভিযোগ বক্স খুলুন</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </div>
          </div>

          {/* Card 11: নতুন ফিচার রিকোয়েস্ট */}
          <div
            onClick={() => setActiveTab('features')}
            className="p-4 rounded-3xl bg-slate-900 border border-slate-800 hover:border-yellow-500/50 transition-all cursor-pointer space-y-3 group shadow-sm flex flex-col justify-between"
          >
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <div className="w-10 h-10 rounded-2xl bg-yellow-500/20 text-yellow-400 flex items-center justify-center font-black">
                  <Lightbulb className="w-5 h-5" />
                </div>
                <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-yellow-500/20 text-yellow-400 border border-yellow-500/30">
                  আইডিয়া ও ভোট
                </span>
              </div>
              <h4 className="font-black text-white text-base group-hover:text-yellow-400 transition-colors">
                নতুন ফিচার রিকোয়েস্ট
              </h4>
              <p className="text-xs text-slate-400 leading-relaxed">
                অ্যাপের নতুন ফিচারের প্রস্তাবনা প্রদান ও সদস্যদের প্রত্যক্ষ ভোটাভুটির ফলাফল।
              </p>
            </div>
            <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-xs text-yellow-400 font-black">
              <span>ফিচার ভোট দিন</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </div>
          </div>

          {/* Card 12: গুগল শীট লাইভ সিঙ্ক */}
          <div
            onClick={() => setActiveTab('sheets')}
            className="p-4 rounded-3xl bg-slate-900 border border-slate-800 hover:border-emerald-500/50 transition-all cursor-pointer space-y-3 group shadow-sm flex flex-col justify-between"
          >
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <div className="w-10 h-10 rounded-2xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-black">
                  <FileSpreadsheet className="w-5 h-5" />
                </div>
                <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                  ক্লাউড স্প্রেডশীট
                </span>
              </div>
              <h4 className="font-black text-white text-base group-hover:text-emerald-400 transition-colors">
                গুগল শীট লাইভ ম্যানেজমেন্ট
              </h4>
              <p className="text-xs text-slate-400 leading-relaxed">
                অ্যাপ থেকেই সরাসরি লাইভ গুগল শীট পরিচালনা, সম্পাদনা ও পূর্ণাঙ্গ ইন্টিগ্রেশন।
              </p>
            </div>
            <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-xs text-emerald-400 font-black">
              <span>গুগল শীট ওপেন করুন</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
