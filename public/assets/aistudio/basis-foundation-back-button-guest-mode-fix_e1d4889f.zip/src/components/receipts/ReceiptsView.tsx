import React, { useState } from 'react';
import {
  Receipt,
  Download,
  Search,
  CheckCircle2,
  FileSpreadsheet,
  ShieldCheck,
  Calendar,
  User,
  ExternalLink,
  Printer,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { ElectronicReceipt, UserProfile } from '../../types';
import {
  formatCurrencyBengali,
  toBengaliNumerals,
} from '../../utils/calculations';
import { generateReceiptPdf, generateStatementPdf } from '../../utils/pdfGenerator';
import { StatementPrintModal } from '../modals/StatementPrintModal';

interface ReceiptsViewProps {
  selectedReceiptTxId?: string;
}

export const ReceiptsView: React.FC<ReceiptsViewProps> = ({ selectedReceiptTxId }) => {
  const { receipts, currentUser, users, savings, config, setActivePrintReceipt } = useApp();

  const isModerator = currentUser?.role === 'APP_MODERATOR' || currentUser?.role === 'MODERATOR';

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedStatementMemberId, setSelectedStatementMemberId] = useState<string>(
    currentUser?.memberId || (users[0]?.memberId ?? 'BF-001')
  );
  const [statementPeriod, setStatementPeriod] = useState<string>('ALL');
  const [isStatementModalOpen, setIsStatementModalOpen] = useState<boolean>(false);

  // Filter receipts: Moderators can view all, ordinary members only their own
  const filteredReceipts = receipts.filter((r) => {
    if (!currentUser) return false;
    if (!isModerator && r.memberId !== currentUser.memberId) {
      return false;
    }
    const q = searchQuery.toLowerCase().trim();
    return (
      r.receiptNumber.toLowerCase().includes(q) ||
      r.memberName.toLowerCase().includes(q) ||
      r.memberId.toLowerCase().includes(q) ||
      r.savingsMonth.includes(q)
    );
  });

  const handleDownloadReceipt = (receipt: ElectronicReceipt) => {
    generateReceiptPdf(receipt, config);
  };

  const currentStatementMember: UserProfile =
    users.find((u) => u.memberId === selectedStatementMemberId) ||
    currentUser ||
    users[0];

  const currentStatementTxs = savings.filter(
    (t) => t.memberId === currentStatementMember?.memberId
  );

  const handleOpenStatementModal = () => {
    setIsStatementModalOpen(true);
  };

  const handleDownloadDirectPdf = () => {
    if (!currentStatementMember) return;
    generateStatementPdf(currentStatementMember, currentStatementTxs, statementPeriod, config);
  };

  return (
    <div className="space-y-5 pb-16">
      {/* Top Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-sm space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h2 className="text-xl font-bold text-white flex items-center gap-2">
              <Receipt className="w-5 h-5 text-emerald-400" />
              <span>ডিজিটাল রসিদ ও ব্যাংক-স্টাইল স্টেটমেন্ট</span>
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              অনুমোদিত প্রতিটি জমার স্বয়ংক্রিয় ভেরিফাইড রসিদ ও সমগ্র সঞ্চয় হিসাবের অফিসিয়াল পিডিএফ স্টেটমেন্ট।
            </p>
          </div>
        </div>

        {/* PDF Statement Generator Card (Section 10.2) */}
        <div className="bg-slate-950 border border-emerald-900/40 rounded-2xl p-4 sm:p-5 space-y-3">
          <div className="flex items-center gap-2">
            <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
            <h3 className="font-bold text-white text-sm">
              অফিসিয়াল একাউন্ট স্টেটমেন্ট জেনারেটর (Official Statement Generator)
            </h3>
          </div>
          <p className="text-xs text-slate-400">
            ব্যাংক স্ট্যান্ডার্ড ফরম্যাটে লেনদেন বিবরণী তৈরি হবে (ফাইল নাম:{' '}
            <code className="text-emerald-300 font-mono">BF_MEMBER_ID_Statement.pdf</code>)।
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-12 gap-3 pt-2">
            {/* Member Selector (for moderators) */}
            <div className="sm:col-span-5 space-y-1">
              <label className="text-[11px] font-semibold text-slate-300">সদস্য হিসাব:</label>
              <select
                aria-label="সদস্য হিসাব নির্বাচন করুন"
                disabled={currentUser.role === 'MEMBER'}
                value={selectedStatementMemberId}
                onChange={(e) => setSelectedStatementMemberId(e.target.value)}
                className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-200 focus:outline-none focus:ring-1 focus:ring-emerald-500 disabled:opacity-60"
              >
                {users.map((u) => (
                  <option key={u.id} value={u.memberId}>
                    {u.memberId} — {u.name}
                  </option>
                ))}
              </select>
            </div>

            {/* Period Selector */}
            <div className="sm:col-span-4 space-y-1">
              <label className="text-[11px] font-semibold text-slate-300">স্টেটমেন্ট সময়কাল:</label>
              <select
                aria-label="স্টেটমেন্ট সময়কাল নির্বাচন করুন"
                value={statementPeriod}
                onChange={(e) => setStatementPeriod(e.target.value)}
                className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-200 focus:outline-none focus:ring-1 focus:ring-emerald-500"
              >
                <option value="ALL">সমগ্র সময়কাল (All Time Records)</option>
                <option value="2026-10">অক্টোবর ২০২৬</option>
                <option value="2026-09">সেপ্টেম্বর ২০২৬</option>
                <option value="2026-08">আগস্ট ২০২৬</option>
                <option value="2026">সম্পূর্ণ ২০২৬ সাল</option>
              </select>
            </div>

            {/* Generate Buttons: Vector Print Modal + Direct PDF Download (Requirement 3) */}
            <div className="sm:col-span-3 flex items-end gap-2">
              <button
                onClick={handleOpenStatementModal}
                className="flex-1 py-2.5 px-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-100 font-bold text-xs border border-slate-700 transition-all flex items-center justify-center gap-1 cursor-pointer"
                title="স্টেটমেন্ট প্রিভিউ ও প্রিন্ট"
              >
                <Printer className="w-4 h-4 text-emerald-400" />
                <span className="hidden sm:inline">ভিউ / </span>প্রিন্ট
              </button>

              <button
                onClick={handleDownloadDirectPdf}
                className="flex-1 py-2.5 px-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs shadow-lg shadow-emerald-600/30 transition-all flex items-center justify-center gap-1 cursor-pointer"
                title="সরাসরি A4 পিডিএফ ডাউনলোড"
              >
                <Download className="w-4 h-4" />
                <span>ডাউনলোড</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Receipts Search & Grid */}
      <div className="space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <h3 className="font-bold text-white text-base flex items-center gap-2">
            <span>ভেরিফাইড রসিদসমূহ</span>
            <span className="text-xs px-2 py-0.5 rounded-full bg-slate-800 text-slate-300">
              {toBengaliNumerals(filteredReceipts.length)} টি
            </span>
          </h3>

          <div className="relative max-w-xs w-full">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="রসিদ নং, সদস্যের নাম বা মাস..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-slate-900 border border-slate-800 rounded-xl pl-9 pr-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-emerald-500"
            />
          </div>
        </div>

        {/* Receipts Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredReceipts.map((receipt) => (
            <div
              key={receipt.receiptNumber}
              className="bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-2xl p-4 shadow-sm transition-all flex flex-col justify-between space-y-3 group relative overflow-hidden"
            >
              {/* Hosted Watermark Image Overlay if provided */}
              {config.receiptWatermarkImageUrl && (
                <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-[0.08] p-6 z-0">
                  <img
                    src={config.receiptWatermarkImageUrl}
                    alt="Watermark"
                    className="max-w-[160px] max-h-[160px] object-contain"
                  />
                </div>
              )}
              <div className="relative z-10">
                {/* Receipt Header Badge */}
                <div className="flex items-center justify-between border-b border-slate-800 pb-2.5">
                  <span className="font-mono text-xs font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                    {receipt.receiptNumber}
                  </span>
                  <span className="text-[10px] text-slate-400">
                    {new Date(receipt.generatedAt).toLocaleDateString('en-GB')}
                  </span>
                </div>

                {/* Details */}
                <div className="mt-2.5 space-y-1.5 text-xs">
                  <div className="flex justify-between items-baseline">
                    <span className="text-slate-400">সদস্যের নাম:</span>
                    <strong className="text-emerald-400 font-extrabold flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-full bg-emerald-500 shrink-0 inline-block" title="সক্রিয় সদস্য" />
                      <span>{receipt.memberName}</span>
                    </strong>
                  </div>
                  <div className="flex justify-between items-baseline">
                    <span className="text-slate-400">সদস্য আইডি:</span>
                    <span className="font-mono text-slate-300 font-semibold">{receipt.memberId}</span>
                  </div>
                  <div className="flex justify-between items-baseline">
                    <span className="text-slate-400">সঞ্চয়ের মাস:</span>
                    <span className="text-slate-200 font-medium">{receipt.savingsMonth}</span>
                  </div>
                  <div className="flex justify-between items-baseline">
                    <span className="text-slate-400">পেমেন্ট মাধ্যম:</span>
                    <span className="text-slate-300">{receipt.paymentMethod}</span>
                  </div>
                  {receipt.transactionRef && (
                    <div className="flex justify-between items-baseline">
                      <span className="text-slate-400">ট্রানজেকশন রেফ:</span>
                      <span className="font-mono text-slate-300">{receipt.transactionRef}</span>
                    </div>
                  )}

                  {/* Amount Pill */}
                  <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800/80 flex items-center justify-between mt-2">
                    <span className="text-[11px] text-slate-400 font-semibold">প্রাপ্ত পরিমাণ:</span>
                    <span className="text-base font-black text-emerald-400">
                      {formatCurrencyBengali(receipt.amount)}
                    </span>
                  </div>

                  {/* Verification Note */}
                  <div className="flex items-center gap-1.5 text-[10px] text-slate-500 pt-1 font-mono truncate">
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                    <span>ভেরিফাইড হ্যাশ: {receipt.verificationHash.slice(0, 20)}...</span>
                  </div>
                </div>
              </div>

              {/* Action Buttons: Preview & Print + Download PDF */}
              <div className="grid grid-cols-2 gap-2 pt-1">
                <button
                  onClick={() => setActivePrintReceipt(receipt)}
                  className="py-2 px-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs transition-all flex items-center justify-center gap-1 border border-slate-700/80 cursor-pointer"
                  title="রসিদ প্রিভিউ ও স্পষ্ট প্রিন্ট করুন"
                >
                  <ExternalLink className="w-3.5 h-3.5 text-emerald-400" />
                  <span>প্রিভিউ ও প্রিন্ট</span>
                </button>

                <button
                  onClick={() => handleDownloadReceipt(receipt)}
                  className="py-2 px-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs transition-all flex items-center justify-center gap-1 shadow-md shadow-emerald-600/30 cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>ডাউনলোড</span>
                </button>
              </div>
            </div>
          ))}
        </div>

        {filteredReceipts.length === 0 && (
          <div className="text-center py-12 bg-slate-900 border border-slate-800 rounded-2xl">
            <p className="text-xs text-slate-400">কোনো রসিদ পাওয়া যায়নি।</p>
          </div>
        )}
      </div>

      {/* Official Unbreakable Statement Print Modal */}
      <StatementPrintModal
        isOpen={isStatementModalOpen}
        member={currentStatementMember}
        transactions={currentStatementTxs}
        periodLabel={statementPeriod}
        config={config}
        onClose={() => setIsStatementModalOpen(false)}
      />
    </div>
  );
};
