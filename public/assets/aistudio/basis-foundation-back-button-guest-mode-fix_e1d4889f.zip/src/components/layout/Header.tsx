import React, { useState, useEffect, useRef } from 'react';
import {
  Menu,
  Moon,
  Sun,
  MessageSquare,
  Bell,
  Wifi,
  WifiOff,
  PhoneCall,
  Search,
  LogOut,
  LogIn,
  CheckCircle2,
  Calendar,
  Sparkles,
  Edit3,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import {
  getBengaliDateParts,
  toBengaliNumerals,
  formatCurrencyBengali,
  formatDateTimeBengali,
  getMonthNameBengali,
} from '../../utils/calculations';
import { Avatar } from '../common/Avatar';

interface HeaderProps {
  onOpenDrawer: () => void;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onInitiateCall: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  onOpenDrawer,
  activeTab,
  setActiveTab,
  onInitiateCall,
}) => {
  const {
    config,
    currentUser,
    isGuestMode,
    logoutUser,
    theme,
    setTheme,
    isOnline,
    setIsOnline,
    unreadCount,
    chatUnreadCount,
    markChatSeen,
    hasUnreadNotices,
    markNoticesSeen,
    savings,
    setIsAuthModalOpen,
    setIsSearchModalOpen,
  } = useApp();

  const [currentTime, setCurrentTime] = useState<Date>(new Date());
  const [isProfileDropdownOpen, setIsProfileDropdownOpen] = useState(false);
  const profileDropdownRef = useRef<HTMLDivElement>(null);

  // Close dropdown on outside click
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        profileDropdownRef.current &&
        !profileDropdownRef.current.contains(event.target as Node)
      ) {
        setIsProfileDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Update clock/date every 30 seconds
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 30000);
    return () => clearInterval(timer);
  }, []);

  const bengaliDate = getBengaliDateParts(currentTime);
  const englishDate = currentTime.toLocaleDateString('en-GB', {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  });

  const toggleTheme = () => {
    const newTheme = theme === 'dark' ? 'light' : 'dark';
    setTheme(newTheme);
    if (newTheme === 'dark') {
      document.documentElement.classList.add('dark');
      document.documentElement.classList.remove('light');
    } else {
      document.documentElement.classList.remove('dark');
      document.documentElement.classList.add('light');
    }
  };

  const isModerator =
    currentUser && (currentUser.role === 'APP_MODERATOR' || currentUser.role === 'MODERATOR');

  // Last 5 approved deposits for live ticker (Point 2 & 3)
  const last5Approved = savings
    .filter((s) => s.status === 'APPROVED')
    .sort((a, b) => new Date(b.transactionDate).getTime() - new Date(a.transactionDate).getTime())
    .slice(0, 5);

  // Ticker marquee speed configuration (Point 4)
  const tickerSpeed = config.tickerSpeed || 'normal';
  const marqueeDuration =
    tickerSpeed === 'slow' ? '65s' : tickerSpeed === 'fast' ? '22s' : '38s';

  // Scales from App Moderator config (Point 6)
  const headerDateScale = config.headerDateScale || 100;
  const headerLogoSize = config.headerLogoSize || 44;
  const headerTitleScale = config.headerTitleScale || 100;

  // Render announcement text with [জরুরি বিজ্ঞপ্তি] in bold red (Point 1)
  const announcementText =
    config.scrollingAnnouncement ||
    '[জরুরি বিজ্ঞপ্তি] বেসিস ফাউন্ডেশন ডিজিটাল সঞ্চয় প্ল্যাটফর্মে স্বাগতম। প্রতি মাসের ১০ তারিখের মধ্যে আপনার নিয়মিত সঞ্চয় জমা সম্পন্ন করুন।';

  const renderAnnouncementContent = (text: string) => {
    const urgentTag = '[জরুরি বিজ্ঞপ্তি]';
    if (text.includes(urgentTag)) {
      const parts = text.split(urgentTag);
      return (
        <span className="flex items-center gap-1.5">
          <span className="bg-rose-500/20 text-rose-400 border border-rose-500/40 px-2 py-0.5 rounded text-[11px] font-black uppercase tracking-wider animate-pulse">
            🚨 জরুরি বিজ্ঞপ্তি
          </span>
          <span className="text-white font-normal">{parts.join('')}</span>
        </span>
      );
    }
    return <span className="text-slate-200 font-normal">{text}</span>;
  };
const renderDepositContent = () => (
  <span className="inline-flex items-center gap-6 shrink-0 mr-6">
    {last5Approved.length > 0 ? (
      last5Approved.map((tx, idx) => (
        <span key={`${tx.id}-${idx}`} className="inline-flex items-center gap-1.5 whitespace-nowrap shrink-0">
          <span className="text-emerald-400 font-bold">
            {toBengaliNumerals(idx + 1)}.
          </span>
          <strong className="text-white font-bold">{tx.memberName}</strong>
          <span className="text-slate-400">-</span>
          <span className="text-emerald-300 font-bold">
            {formatCurrencyBengali(tx.amount)}
          </span>
          <span className="text-amber-300 font-normal">
            ({getMonthNameBengali(tx.savingsMonth)})
          </span>
          <span className="text-[10px] text-emerald-400/80 font-normal">
            [{formatDateTimeBengali(tx.transactionDate)}]
          </span>
          <span className="text-emerald-700 ml-4 font-bold">•</span>
        </span>
      ))
    ) : (
      <span className="text-emerald-200 whitespace-nowrap">
        ১. মাহমুদুল হাসান - ৳১,৫০০ (অক্টোবর ২০২৬) [২২/১০/২০২৬, ০২:৩০ অপরাহ্ন] •
      </span>
    )}
  </span>
);

  return (
    <header className="sticky top-0 z-40 bg-slate-900/95 dark:bg-slate-950/95 backdrop-blur-md border-b border-slate-800 shadow-lg transition-colors">
      {/* Main Responsive App Bar */}
      <div className="max-w-7xl mx-auto px-2 sm:px-4 py-1.5 sm:py-2 flex items-center justify-between gap-1.5 sm:gap-3 overflow-x-clip">
        {/* Left Section: Drawer Menu + Universal Search + Call */}
        <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
          <button
            onClick={onOpenDrawer}
            aria-label="মেনু খুলুন"
            className="p-1.5 sm:p-2 rounded-xl bg-slate-800/90 hover:bg-slate-700 text-slate-100 transition-colors focus:ring-2 focus:ring-emerald-500/50 shadow-sm cursor-pointer"
          >
            <Menu className="w-4 h-4 sm:w-5 sm:h-5 transition-transform hover:scale-110" />
          </button>

          {/* Universal Search Button */}
          <button
            onClick={() => setIsSearchModalOpen(true)}
            title="আইডি, নাম, রসিদ বা লেনদেন সার্চ করুন"
            className="p-1.5 sm:px-2.5 sm:py-1.5 rounded-xl bg-slate-800/90 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors shadow-sm cursor-pointer flex items-center gap-1.5 border border-slate-700/60"
          >
            <Search className="w-3.5 h-3.5 text-emerald-400" />
            <span className="hidden md:inline text-[11px] font-bold">সার্চ...</span>
          </button>

          {/* Quick Call Button */}
          <button
            onClick={onInitiateCall}
            title="গ্রুপ কল শুরু করুন"
            className="p-1.5 sm:p-2 rounded-xl bg-slate-800/90 hover:bg-slate-700 text-emerald-400 transition-colors hidden sm:flex items-center gap-1 text-xs font-bold shadow-sm cursor-pointer"
          >
            <PhoneCall className="w-3.5 h-3.5 transition-transform hover:scale-110" />
          </button>
        </div>

        {/* Center: Brand Title and Logo (scalable via App Moderator config) */}
        <div className="flex items-center justify-center min-w-0 flex-1 px-1">
          <div
            className="flex items-center gap-2 cursor-pointer select-none group min-w-0"
            onClick={() => setActiveTab('home')}
          >
            <div
              style={{ width: `${headerLogoSize}px`, height: `${headerLogoSize}px` }}
              className="rounded-xl bg-gradient-to-tr from-emerald-600 via-teal-500 to-amber-400 p-0.5 flex items-center justify-center shadow-lg shadow-emerald-500/20 group-hover:scale-105 transition-transform shrink-0"
            >
              <img
                src={config.logoUrl || '/logo.svg'}
                alt="Logo"
                onError={(e) => {
                  (e.currentTarget as HTMLImageElement).src = '/logo.svg';
                }}
                className="w-full h-full object-contain rounded-lg bg-slate-950 p-0.5"
              />
            </div>

            <div className="flex flex-col text-center sm:text-left min-w-0 truncate">
              <div className="flex items-center justify-center sm:justify-start gap-1 min-w-0">
                <h1
                  style={{ fontSize: `${(headerTitleScale / 100) * 1.05}rem` }}
                  className="font-bold tracking-tight text-white group-hover:text-emerald-300 transition-colors truncate leading-tight"
                >
                  {config.foundationName}
                </h1>
                {currentUser?.role === 'APP_MODERATOR' && (
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      setActiveTab('app-moderator');
                    }}
                    title="ফাউন্ডেশন টাইটেল ও লোগো সাইজ পরিবর্তন"
                    className="p-0.5 hover:bg-slate-800 rounded text-amber-400 hover:text-amber-300 transition-colors"
                  >
                    <Edit3 className="w-3 h-3" />
                  </button>
                )}
              </div>
              <span className="text-[9px] sm:text-[11px] font-bold text-emerald-400 tracking-wider uppercase leading-none truncate">
                BASIS FOUNDATION
              </span>
            </div>
          </div>
        </div>

        {/* Right Section: Inline Date & Day (Point 6) + Network + Theme + Notifications + User / Guest */}
        <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
          {/* Point 6: Clock removed! Inline Date & Day on the right with scalable size */}
          {/* রিমুভ করুন এই পুরো ব্লকটি */}

          {/* Network Status Icon */}
          <button
            onClick={() => setIsOnline(!isOnline)}
            title={isOnline ? 'ইন্টারনেট সক্রিয় (Online)' : 'ইন্টারনেট বিচ্ছিন্ন (Offline)'}
            className={`hidden sm:flex p-1.5 rounded-xl transition-all cursor-pointer items-center justify-center ${
              isOnline
                ? 'bg-slate-800/90 text-emerald-400 hover:bg-slate-700'
                : 'bg-rose-950/80 text-rose-400 border border-rose-800'
            }`}
          >
            <span
              className={`w-1.5 h-1.5 rounded-full mr-1 ${
                isOnline ? 'bg-emerald-400 animate-pulse' : 'bg-rose-500'
              }`}
            />
            {isOnline ? <Wifi className="w-3.5 h-3.5" /> : <WifiOff className="w-3.5 h-3.5" />}
          </button>

          {/* Theme Toggle Button */}
          <button
            onClick={toggleTheme}
            aria-label="থিম পরিবর্তন করুন"
            title={theme === 'dark' ? 'লাইট মোডে পরিবর্তন করুন' : 'ডার্ক মোডে পরিবর্তন করুন'}
            className="hidden sm:flex p-1.5 sm:p-2 rounded-xl bg-slate-800/90 hover:bg-slate-700 text-slate-200 transition-colors shadow-sm cursor-pointer"
          >
            {theme === 'dark' ? (
              <Sun className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-amber-400" />
            ) : (
              <Moon className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-indigo-400" />
            )}
          </button>

          {/* Inbox / Chat Button */}
          <button
            onClick={() => {
              markChatSeen();
              setActiveTab('chat');
            }}
            aria-label="ইনবক্স ও চ্যাট"
            className={`p-1.5 sm:p-2 rounded-xl transition-colors relative shadow-sm cursor-pointer ${
              activeTab === 'chat'
                ? 'bg-emerald-600 text-white'
                : 'bg-slate-800/90 hover:bg-slate-700 text-slate-200'
            }`}
          >
            <MessageSquare className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
            {chatUnreadCount > 0 && (
              <span className="absolute -top-1 -right-1 w-3.5 h-3.5 sm:w-4 sm:h-4 rounded-full bg-emerald-500 text-[9px] sm:text-[10px] text-white font-bold flex items-center justify-center shadow">
                {toBengaliNumerals(chatUnreadCount)}
              </span>
            )}
          </button>

          {/* Notification Bell */}
          <button
            onClick={() => {
              markNoticesSeen();
              setActiveTab('notices');
            }}
            aria-label="নোটিফিকেশন"
            className="p-1.5 sm:p-2 rounded-xl bg-slate-800/90 hover:bg-slate-700 text-slate-200 transition-colors relative shadow-sm cursor-pointer"
          >
            <Bell className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
            {hasUnreadNotices && unreadCount > 0 && (
              <span className="absolute -top-1 -right-1 w-3.5 h-3.5 sm:w-4 sm:h-4 rounded-full bg-rose-500 text-[9px] sm:text-[10px] text-white font-bold flex items-center justify-center shadow animate-pulse">
                {toBengaliNumerals(unreadCount)}
              </span>
            )}
          </button>

          {/* User Profile or Guest Login Button */}
          {!isGuestMode && currentUser ? (
            <div className="relative" ref={profileDropdownRef}>
              <button
                onClick={() => setIsProfileDropdownOpen(!isProfileDropdownOpen)}
                className="flex items-center gap-1 rounded-full p-0.5 hover:ring-2 hover:ring-emerald-400 transition-all cursor-pointer shrink-0"
                title={`${currentUser.name} - প্রোফাইল মেনু`}
              >
                <Avatar
                  src={currentUser.avatarUrl}
                  name={currentUser.name}
                  size="sm"
                  ringColor={isModerator ? 'ring-blue-500' : 'ring-emerald-500/60'}
                />
              </button>

              {/* Profile Dropdown Popover (No multi-account switcher!) */}
              {isProfileDropdownOpen && (
                <div className="absolute right-0 mt-2 w-72 bg-slate-900 border border-slate-700 rounded-3xl shadow-2xl p-4 z-50 animate-in fade-in zoom-in-95 duration-150 space-y-3 text-xs">
                  {/* Single User Info Card */}
                  <div className="flex items-center gap-3 border-b border-slate-800 pb-3">
                    <Avatar
                      src={currentUser.avatarUrl}
                      name={currentUser.name}
                      size="md"
                      ringColor="ring-emerald-500"
                    />
                    <div className="truncate">
                      <div className="flex items-center gap-1">
                        <strong className="text-white font-bold text-sm truncate block">
                          {currentUser.name}
                        </strong>
                        {isModerator && (
                          <CheckCircle2 className="w-3.5 h-3.5 text-blue-400 fill-blue-500 text-white shrink-0" />
                        )}
                      </div>
                      <span className="font-mono text-emerald-400 font-bold block text-[11px]">
                        {currentUser.memberId}
                      </span>
                      <span className="text-[10px] text-slate-400 block truncate">
                        {currentUser.moderatorTitle ||
                          (currentUser.role === 'APP_MODERATOR'
                            ? 'প্রধান অ্যাপ মডারেটর'
                            : currentUser.role === 'MODERATOR'
                            ? 'মডারেটর'
                            : 'সাধারণ সদস্য')}
                      </span>
                    </div>
                  </div>

                  {/* Profile Links */}
                  <div className="space-y-1">
                    <button
                      onClick={() => {
                        setActiveTab('profile');
                        setIsProfileDropdownOpen(false);
                      }}
                      className="w-full text-left p-2 rounded-xl hover:bg-slate-800 text-slate-200 font-normal flex items-center justify-between transition-colors cursor-pointer"
                    >
                      <span>আমার প্রোফাইল ও জমার খাতা</span>
                      <span>→</span>
                    </button>

                    <button
                      onClick={() => {
                        setActiveTab('settings');
                        setIsProfileDropdownOpen(false);
                      }}
                      className="w-full text-left p-2 rounded-xl hover:bg-slate-800 text-slate-200 font-normal flex items-center justify-between transition-colors cursor-pointer"
                    >
                      <span>অ্যাপ সেটিংস ও ব্যক্তিগত পছন্দ</span>
                      <span>⚙️</span>
                    </button>
                  </div>

                  {/* Logout Button */}
                  <div className="pt-2 border-t border-slate-800">
                    <button
                      onClick={() => {
                        setIsProfileDropdownOpen(false);
                        logoutUser();
                      }}
                      className="w-full py-2 px-3 rounded-xl bg-rose-950/60 hover:bg-rose-900 border border-rose-900 text-rose-300 font-bold text-xs transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                    >
                      <LogOut className="w-3.5 h-3.5 text-rose-400" />
                      <span>লগআউট করুন</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          ) : (
            /* Guest Login Button */
            <button
              onClick={() => setIsAuthModalOpen(true)}
              className="py-1.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs transition-all flex items-center gap-1.5 shadow-md shadow-emerald-600/30 cursor-pointer shrink-0"
            >
              <LogIn className="w-3.5 h-3.5" />
              <span>লগইন করুন</span>
            </button>
          )}
        </div>
      </div>

      {/* 1. Scrolling Main Announcement Bar with [জরুরি বিজ্ঞপ্তি] in Red (Point 1 & 4) */}
      <div className="bg-slate-950/90 border-t border-slate-800/80 px-3 py-1 flex items-center text-xs overflow-hidden">
        <span className="bg-amber-500/20 text-amber-300 border border-amber-500/40 px-2 py-0.2 rounded text-[10px] font-bold shrink-0 flex items-center gap-1 mr-2">
          📢 ঘোষণা:
        </span>
        <div className="overflow-hidden relative w-full text-slate-300 text-[11px] font-normal flex">
          <div
            className="animate-marquee inline-flex items-center gap-8 whitespace-nowrap shrink-0"
            style={{ animationDuration: marqueeDuration }}
          >
            {renderAnnouncementContent(announcementText)}
            <span className="text-slate-600 font-bold">•</span>
            {renderAnnouncementContent(announcementText)}
            <span className="text-slate-600 font-bold">•</span>
          </div>
        </div>
      </div>

      {/* 2. Scrolling Latest 5 Deposits Ticker with Month in Brackets & Exact Date/Time (Point 2, 3 & 4) */}
      <div className="bg-emerald-950/60 border-t border-emerald-900/50 px-3 py-1 flex items-center justify-between text-xs overflow-hidden">
        <div className="flex items-center gap-2 overflow-hidden w-full">
          <span className="bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 px-2 py-0.2 rounded text-[10px] font-bold shrink-0 flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
            ⚡ সর্বশেষ জমা:
          </span>

          <div className="overflow-hidden relative w-full text-[11px] text-emerald-300 font-normal flex">
            <div
              className="animate-marquee inline-flex items-center gap-6 whitespace-nowrap shrink-0"
              style={{ animationDuration: marqueeDuration }}
            >
              {renderDepositContent()}
              {renderDepositContent()}
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};
