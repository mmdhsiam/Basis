import React from 'react';
import {
  X,
  Home,
  Users,
  Wallet,
  Receipt,
  BarChart3,
  ShieldCheck,
  ShieldAlert,
  Bell,
  BookOpen,
  FileText,
  Lightbulb,
  FileSpreadsheet,
  MessageSquare,
  Settings,
  DownloadCloud,
  LogOut,
  ExternalLink,
  Flame,
  Info,
  Building2,
  User,
  Award,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { toBengaliNumerals } from '../../utils/calculations';
import { Avatar } from '../common/Avatar';

interface NavigationDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onShowExitDialog: () => void;
  onOpenFirebaseGuide?: () => void;
}

export const NavigationDrawer: React.FC<NavigationDrawerProps> = ({
  isOpen,
  onClose,
  activeTab,
  setActiveTab,
  onShowExitDialog,
  onOpenFirebaseGuide,
}) => {
  const { currentUser, config, unreadCount, isDemoMode } = useApp();

  if (!isOpen) return null;

  const navItems = [
    { id: 'home', label: 'হোম ড্যাশবোর্ড', icon: Home, badge: null, roles: ['APP_MODERATOR', 'MODERATOR', 'MEMBER'] },
    { id: 'profile', label: 'আমার প্রোফাইল ও জমার খাতা', icon: User, badge: null, roles: ['APP_MODERATOR', 'MODERATOR', 'MEMBER'] },
    { id: 'bank', label: 'ব্যাংক ইনফরমেশন ও হিসাব', icon: Building2, badge: 'New', badgeColor: 'bg-indigo-500', roles: ['APP_MODERATOR', 'MODERATOR', 'MEMBER'] },
    { id: 'about-us', label: 'আমাদের সম্পর্কে (About Us)', icon: BookOpen, badge: 'New', badgeColor: 'bg-emerald-500', roles: ['APP_MODERATOR', 'MODERATOR', 'MEMBER'] },
    { id: 'members', label: 'সদস্য তালিকা ও পদবি', icon: Users, badge: null, roles: ['APP_MODERATOR', 'MODERATOR', 'MEMBER'] },
    { id: 'savings', label: 'সঞ্চয় খাতা ও নতুন জমা', icon: Wallet, badge: null, roles: ['APP_MODERATOR', 'MODERATOR', 'MEMBER'] },
    { id: 'receipts', label: 'রসিদ ও পিডিএফ স্টেটমেন্ট', icon: Receipt, badge: null, roles: ['APP_MODERATOR', 'MODERATOR', 'MEMBER'] },
    { id: 'analytics', label: 'হিসাব বিশ্লেষণ ও গ্রাফ', icon: BarChart3, badge: null, roles: ['APP_MODERATOR', 'MODERATOR', 'MEMBER'] },
    {
      id: 'moderator',
      label: 'মডারেটর প্যানেল',
      icon: ShieldCheck,
      badge: unreadCount > 0 ? toBengaliNumerals(unreadCount) : null,
      badgeColor: 'bg-rose-500',
      roles: ['APP_MODERATOR', 'MODERATOR'],
    },
    {
      id: 'app-moderator',
      label: 'অ্যাপ মডারেটর অ্যাডমিন',
      icon: ShieldAlert,
      badge: 'Admin',
      badgeColor: 'bg-amber-500',
      roles: ['APP_MODERATOR'],
    },
    { id: 'notices', label: 'নোটিশ বোর্ড', icon: Bell, badge: null, roles: ['APP_MODERATOR', 'MODERATOR', 'MEMBER'] },
    { id: 'executive', label: 'কার্যনির্বাহী পর্ষদ', icon: Award, badge: 'New', badgeColor: 'bg-amber-500', roles: ['APP_MODERATOR', 'MODERATOR', 'MEMBER'] },
    { id: 'rules', label: 'ফাউন্ডেশন গঠনতন্ত্র ও বিধি', icon: FileText, badge: null, roles: ['APP_MODERATOR', 'MODERATOR', 'MEMBER'] },
    { id: 'complaints', label: 'অভিযোগ প্রতিকার সেল', icon: FileText, badge: null, roles: ['APP_MODERATOR', 'MODERATOR', 'MEMBER'] },
    { id: 'features', label: 'নতুন ফিচারের প্রস্তাবনা', icon: Lightbulb, badge: null, roles: ['APP_MODERATOR', 'MODERATOR', 'MEMBER'] },
    { id: 'sheets', label: 'গুগল শিটস ক্লাউড সিঙ্ক', icon: FileSpreadsheet, badge: null, roles: ['APP_MODERATOR', 'MODERATOR', 'MEMBER'] },
    { id: 'settings', label: 'অ্যাপ সেটিংস ও পছন্দসমূহ', icon: Settings, badge: null, roles: ['APP_MODERATOR', 'MODERATOR', 'MEMBER'] },
  ];

  // Dynamic Tab Ordering and Custom Titles from App Moderator Config
  const rawOrder = config.navTabsOrder || [];
  const customTitles = config.customTabTitles || {};

  const orderedNavItems = [...navItems].sort((a, b) => {
    const idxA = rawOrder.indexOf(a.id);
    const idxB = rawOrder.indexOf(b.id);
    if (idxA === -1 && idxB === -1) return 0;
    if (idxA === -1) return 1;
    if (idxB === -1) return -1;
    return idxA - idxB;
  }).map((item) => ({
    ...item,
    label: customTitles[item.id] || item.label,
  }));

  const filteredItems = orderedNavItems.filter((item) =>
    currentUser ? item.roles.includes(currentUser.role) : item.roles.includes('MEMBER')
  );

  const handleSelect = (id: string) => {
    setActiveTab(id);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex animate-in fade-in duration-200">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-slate-950/40 backdrop-blur-[1px] transition-opacity cursor-pointer"
        onClick={onClose}
      />

      {/* Drawer Panel */}
      <div className="relative w-80 max-w-[85vw] bg-slate-900 border-r border-slate-800 h-full flex flex-col shadow-2xl z-10 overflow-hidden">
        {/* User Card in Drawer */}
        <div className="p-4 bg-gradient-to-br from-slate-950 to-slate-900 border-b border-slate-800">
          <div className="flex items-start justify-between">
            {currentUser ? (
              <div className="flex items-center gap-3">
                <Avatar
                  src={currentUser.avatarUrl}
                  name={currentUser.name}
                  size="lg"
                  ringColor={currentUser.role === 'APP_MODERATOR' ? 'ring-amber-500' : 'ring-emerald-500'}
                />
                <div className="overflow-hidden">
                  <h3 className="font-extrabold text-slate-100 text-sm truncate">{currentUser.name}</h3>
                  <p className="text-xs text-slate-400 font-mono">আইডি: {currentUser.memberId}</p>
                  <div className="mt-1 flex items-center gap-1.5">
                    <span
                      className={`text-[10px] font-black px-2 py-0.5 rounded-full uppercase ${
                        currentUser.role === 'APP_MODERATOR'
                          ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                          : currentUser.role === 'MODERATOR'
                          ? 'bg-blue-500/20 text-blue-300 border border-blue-500/30'
                          : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                      }`}
                    >
                      {currentUser.role === 'APP_MODERATOR'
                        ? 'অ্যাপ মডারেটর'
                        : currentUser.role === 'MODERATOR'
                        ? 'মডারেটর'
                        : 'সাধারণ সদস্য'}
                    </span>
                  </div>
                </div>
              </div>
            ) : (
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center font-black">
                  👤
                </div>
                <div>
                  <h3 className="font-extrabold text-slate-100 text-sm">অতিথি দর্শক</h3>
                  <p className="text-[11px] text-emerald-400 font-bold">লগইন বা একাউন্ট খুলুন</p>
                </div>
              </div>
            )}

            <button
              onClick={onClose}
              className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Scrollable Nav Item List */}
        <div className="flex-1 overflow-y-auto p-3 space-y-1">
          {filteredItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;

            return (
              <button
                key={item.id}
                onClick={() => handleSelect(item.id)}
                className={`w-full flex items-center justify-between px-3 py-2.5 rounded-2xl text-xs font-black transition-all ${
                  isActive
                    ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/30 font-black'
                    : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div
                    className={`w-7 h-7 rounded-xl flex items-center justify-center ${
                      isActive
                        ? 'bg-white/20 text-white'
                        : 'bg-slate-800 text-emerald-400'
                    }`}
                  >
                    <Icon className="w-4 h-4" />
                  </div>
                  <span>{item.label}</span>
                </div>

                {item.badge && (
                  <span
                    className={`text-[10px] px-1.5 py-0.5 rounded-full text-white font-black ${
                      item.badgeColor || 'bg-slate-700'
                    }`}
                  >
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}

          {/* Firebase Guide Button in Drawer */}
          {onOpenFirebaseGuide && (
            <button
              onClick={() => {
                onClose();
                onOpenFirebaseGuide();
              }}
              className="w-full flex items-center justify-between px-3 py-2.5 rounded-2xl text-xs font-black text-amber-300 bg-amber-500/10 border border-amber-500/30 hover:bg-amber-500/20 transition-all mt-2"
            >
              <div className="flex items-center gap-3">
                <div className="w-7 h-7 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center">
                  <Flame className="w-4 h-4" />
                </div>
                <span>ফায়ারবেজ লগইন গাইড</span>
              </div>
              <span className="text-[10px] px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 font-bold">
                নির্দেশনা
              </span>
            </button>
          )}
        </div>

        {/* Drawer Footer with Foundation Logo & Exit */}
        <div className="p-3 bg-slate-950/90 border-t border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-lg bg-emerald-600 p-0.5 flex items-center justify-center">
              <img src={config.logoUrl || '/logo.svg'} alt="Logo" className="w-full h-full object-contain" />
            </div>
            <div className="text-[11px] text-slate-400">
              <span className="font-bold text-white block truncate max-w-[140px]">{config.foundationName}</span>
              <span className="text-[9px] text-emerald-400">v1.2.0 (Stable)</span>
            </div>
          </div>

          <button
            onClick={() => {
              onClose();
              onShowExitDialog();
            }}
            className="p-2 rounded-xl bg-rose-500/10 text-rose-400 hover:bg-rose-500/20 transition-colors"
            title="অ্যাপ থেকে প্রস্থান"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
