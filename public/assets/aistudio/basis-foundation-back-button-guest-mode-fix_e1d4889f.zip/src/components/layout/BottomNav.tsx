import React, { useState } from 'react';
import { Home, Users, Wallet, BarChart3, MoreHorizontal } from 'lucide-react';
import { toBengaliNumerals } from '../../utils/calculations';

interface BottomNavProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onOpenDrawer: () => void;
  unreadCount: number;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  activeTab,
  setActiveTab,
  onOpenDrawer,
  unreadCount,
}) => {
  // Point 7: Remember if the user has seen the menu drawer so the red dot stops blinking permanently
  const [hasSeenMenu, setHasSeenMenu] = useState<boolean>(() => {
    return localStorage.getItem('basis_menu_seen') === 'true';
  });

  const handleOpenMenu = () => {
    setHasSeenMenu(true);
    localStorage.setItem('basis_menu_seen', 'true');
    onOpenDrawer();
  };

  const tabs = [
    { id: 'home', label: 'হোম', icon: Home },
    { id: 'members', label: 'সদস্য', icon: Users },
    { id: 'savings', label: 'সঞ্চয়', icon: Wallet },
    { id: 'analytics', label: 'বিশ্লেষণ', icon: BarChart3 },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-30 glowing-nav-menu rounded-t-3xl px-3 py-1.5 flex items-center justify-around sm:hidden select-none">
      {tabs.map((tab) => {
        const Icon = tab.icon;
        const isActive = activeTab === tab.id;
        return (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`flex flex-col items-center justify-center py-1.5 px-3 rounded-2xl transition-all relative ${
              isActive
                ? 'glowing-nav-item-active font-black'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Icon className={`w-5 h-5 ${isActive ? 'scale-115 text-emerald-400' : 'text-slate-400'} transition-transform icon-motion`} />
            <span className="text-[10px] mt-0.5 leading-tight">{tab.label}</span>
          </button>
        );
      })}

      {/* More / Menu Button (Point 7: red dot stops blinking once opened) */}
      <button
        onClick={handleOpenMenu}
        className="flex flex-col items-center justify-center py-1.5 px-3 rounded-2xl text-slate-400 hover:text-slate-200 transition-all relative cursor-pointer"
      >
        <MoreHorizontal className="w-5 h-5 icon-motion" />
        <span className="text-[10px] mt-0.5 leading-tight">মেনু</span>
        {unreadCount > 0 && !hasSeenMenu && (
          <span className="absolute top-1 right-3 flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-rose-500"></span>
          </span>
        )}
      </button>
    </nav>
  );
};
