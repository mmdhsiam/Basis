import React, { useState, useMemo } from 'react';
import {
  BarChart3,
  TrendingUp,
  PieChart,
  Calendar,
  CheckCircle2,
  Clock,
  ArrowUpRight,
  ArrowDownRight,
  Percent,
  Wallet,
  Users,
  Building2,
  Award,
  Target,
  Sparkles,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import {
  formatCurrencyBengali,
  toBengaliNumerals,
} from '../../utils/calculations';
import { Avatar } from '../common/Avatar';

export const FinancialAnalyticsView: React.FC = () => {
  const { savings, users, financialTotals, monthlyAggregates, growthRate, expenses } = useApp();

  const [selectedYear, setSelectedYear] = useState<number>(2026);
  const [selectedMonth, setSelectedMonth] = useState<string>('2026-10');
  const [activeChartType, setActiveChartType] = useState<'BAR' | 'VS_EXPENSE' | 'CUMULATIVE' | 'DONUT'>('BAR');

  // Month list with data dynamically computed from all approved transactions across all members
  const monthsData = useMemo(() => {
    const months = [
      { month: '2026-06', label: 'জুন ২৬' },
      { month: '2026-07', label: 'জুলাই ২৬' },
      { month: '2026-08', label: 'আগস্ট ২৬' },
      { month: '2026-09', label: 'সেপ্টেম্বর ২৬' },
      { month: '2026-10', label: 'অক্টোবর ২৬' },
    ];
    let cum = 0;
    return months.map((m) => {
      // Sum all approved transactions for this specific month from any member
      const monthTxSum = savings
        .filter((t) => t.savingsMonth === m.month && t.status === 'APPROVED')
        .reduce((sum, t) => sum + t.amount, 0);

      const monthExpSum = expenses
        .filter((e) => e.expenseDate.startsWith(m.month))
        .reduce((sum, e) => sum + e.amount, 0);

      cum += monthTxSum;
      return {
        month: m.month,
        label: m.label,
        amount: monthTxSum,
        expense: monthExpSum,
        cumulative: cum,
      };
    });
  }, [savings, expenses]);

  const maxMonthAmount = Math.max(...monthsData.map((m) => Math.max(m.amount, m.expense || 0)), 10000);
  const maxCumulative = Math.max(...monthsData.map((m) => m.cumulative), 30000);

  // Payment method breakdown for selected month (including BANK)
  const paymentBreakdown = useMemo(() => {
    const monthTxs = savings.filter(
      (t) => t.savingsMonth === selectedMonth && t.status === 'APPROVED'
    );
    const breakdown: Record<string, number> = {
      BKASH: 0,
      BANK: 0,
      BANK_TRANSFER: 0,
      NAGAD: 0,
      ROCKET: 0,
      CASH: 0,
      OTHER: 0,
    };
    for (const tx of monthTxs) {
      if (tx.paymentMethod === 'BANK_TRANSFER' || tx.paymentMethod === 'BANK') {
        breakdown.BANK = (breakdown.BANK || 0) + tx.amount;
      } else {
        breakdown[tx.paymentMethod] = (breakdown[tx.paymentMethod] || 0) + tx.amount;
      }
    }
    const total = Object.values(breakdown).reduce((a, b) => a + b, 0);
    return { breakdown, total };
  }, [savings, selectedMonth]);

  // Member savings ranking (Top savers)
  const memberRankings = useMemo(() => {
    const totals: Record<string, { memberId: string; name: string; total: number; count: number; avatar?: string }> = {};
    for (const tx of savings.filter((s) => s.status === 'APPROVED')) {
      if (!totals[tx.memberId]) {
        const u = users.find((user) => user.memberId === tx.memberId);
        totals[tx.memberId] = {
          memberId: tx.memberId,
          name: tx.memberName,
          total: 0,
          count: 0,
          avatar: u?.avatarUrl,
        };
      }
      totals[tx.memberId].total += tx.amount;
      totals[tx.memberId].count += 1;
    }
    return Object.values(totals).sort((a, b) => b.total - a.total);
  }, [savings, users]);

  // Participation rate for selected month
  const activeMembersCount = users.filter((u) => u.status === 'APPROVED').length;
  const depositedMembersCount = new Set(
    savings
      .filter((t) => t.savingsMonth === selectedMonth && t.status === 'APPROVED')
      .map((t) => t.memberId)
  ).size;
  const participationPct = Math.round(
    (depositedMembersCount / Math.max(1, activeMembersCount)) * 100
  );

  // Annual Target (৳ ২,০০,০০০)
  const annualTarget = 200000;
  const totalSavings = financialTotals.totalApproved;
  const targetPct = Math.min(100, Math.round((totalSavings / annualTarget) * 100));

  return (
    <div className="space-y-5 pb-16">
      {/* 1. Header with Month & Year Selectors */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-4 sm:p-6 shadow-sm space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h2 className="text-xl sm:text-2xl font-black text-white flex items-center gap-2">
              <BarChart3 className="w-6 h-6 text-emerald-400" />
              <span>হিসাব বিশ্লেষণ ও আর্থিক পরিসংখ্যান (Financial Analytics)</span>
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              অনুমোদিত লেনদেনের গতিপ্রকৃতি, বার চার্ট, ডোনাট গ্রাফ, সঞ্চয়ন কার্ভ ও বাৎসরিক লক্ষ্যমাত্রা পর্যবেক্ষণ।
            </p>
          </div>

          <div className="flex items-center gap-2">
            <select
              aria-label="মাস নির্বাচন করুন"
              value={selectedMonth}
              onChange={(e) => setSelectedMonth(e.target.value)}
              className="bg-slate-950 border border-slate-800 text-xs text-white font-extrabold rounded-xl px-3 py-2 focus:ring-1 focus:ring-emerald-500 cursor-pointer"
            >
              <option value="2026-10">অক্টোবর ২০২৬</option>
              <option value="2026-09">সেপ্টেম্বর ২০২৬</option>
              <option value="2026-08">আগস্ট ২০২৬</option>
            </select>

            <select
              aria-label="সাল নির্বাচন করুন"
              value={selectedYear}
              onChange={(e) => setSelectedYear(Number(e.target.value))}
              className="bg-slate-950 border border-slate-800 text-xs text-white font-extrabold rounded-xl px-3 py-2 focus:ring-1 focus:ring-emerald-500 cursor-pointer"
            >
              <option value={2026}>২০২৬ সাল</option>
              <option value={2025}>২০২৫ সাল</option>
            </select>
          </div>
        </div>
      </div>

      {/* 2. Primary 4 Metric Highlights */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-4 sm:p-5 shadow-sm">
          <span className="text-xs font-bold text-slate-400">নির্বাচিত মাসের সঞ্চয়</span>
          <h3 className="text-2xl font-black text-emerald-400 mt-1">
            {formatCurrencyBengali(paymentBreakdown.total)}
          </h3>
          <p className="text-[11px] text-slate-400 mt-0.5 font-bold">
            সময়কাল: {selectedMonth}
          </p>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-4 sm:p-5 shadow-sm">
          <span className="text-xs font-bold text-slate-400">মাসিক প্রবৃদ্ধি হার</span>
          <h3
            className={`text-2xl font-black mt-1 flex items-center gap-1 ${
              growthRate.isPositive ? 'text-emerald-400' : 'text-rose-400'
            }`}
          >
            {growthRate.isPositive ? <ArrowUpRight className="w-5 h-5" /> : <ArrowDownRight className="w-5 h-5" />}
            <span>{growthRate.formatted}</span>
          </h3>
          <p className="text-[11px] text-slate-400 mt-0.5 font-bold">পূর্ববর্তী মাসের তুলনায়</p>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-4 sm:p-5 shadow-sm">
          <span className="text-xs font-bold text-slate-400">সদস্য অংশগ্রহণ হার</span>
          <h3 className="text-2xl font-black text-blue-400 mt-1">
            {toBengaliNumerals(participationPct)}%
          </h3>
          <p className="text-[11px] text-slate-400 mt-0.5 font-bold">
            {toBengaliNumerals(depositedMembersCount)}/{toBengaliNumerals(activeMembersCount)} জন সদস্য
          </p>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-4 sm:p-5 shadow-sm">
          <span className="text-xs font-bold text-slate-400">বাৎসরিক লক্ষ্য অর্জন</span>
          <h3 className="text-2xl font-black text-amber-400 mt-1">
            {toBengaliNumerals(targetPct)}%
          </h3>
          <p className="text-[11px] text-slate-400 mt-0.5 font-bold">
            লক্ষ্য: {formatCurrencyBengali(annualTarget)}
          </p>
        </div>
      </div>

      {/* 3. Interactive Main Chart: Toggle Between Monthly Bar Chart & Cumulative Fund Curve */}
      {/* 3. Interactive Main Chart: Toggle Between Monthly Bar Chart, Savings vs Expenses, & Cumulative Fund Curve */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 sm:p-6 shadow-sm space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h3 className="font-black text-white text-base sm:text-lg flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-emerald-400" />
              <span>
                {activeChartType === 'BAR' && 'মাসভিত্তিক সঞ্চয় আদায় বার চার্ট'}
                {activeChartType === 'VS_EXPENSE' && 'মাসিক সঞ্চয় বনাম ফাউন্ডেশন খরচ তুলনামূলক গ্রাফ'}
                {activeChartType === 'CUMULATIVE' && 'ক্রমপুঞ্জিত মোট তহবিল সঞ্চয়ন কার্ভ'}
              </span>
            </h3>
            <p className="text-xs text-slate-400">
              {activeChartType === 'BAR' && 'প্রতি মাসের অনুমোদিত আয়ের তুলনামূলক চিত্র'}
              {activeChartType === 'VS_EXPENSE' && 'অনুমোদিত সঞ্চয় আদায় এবং সাংগঠনিক ব্যয়ের তুলনামূলক স্বাস্থ্য'}
              {activeChartType === 'CUMULATIVE' && 'তহবিলের ক্রমাগত বৃদ্ধি ও সঞ্চয়ের সার্বিক গতিপ্রকৃতি'}
            </p>
          </div>

          <div className="flex items-center gap-1.5 bg-slate-950 p-1 rounded-2xl border border-slate-800 self-start sm:self-auto flex-wrap">
            <button
              onClick={() => setActiveChartType('BAR')}
              className={`py-1.5 px-3 rounded-xl text-xs font-black transition-all cursor-pointer ${
                activeChartType === 'BAR'
                  ? 'bg-emerald-600 text-white shadow'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              বার চার্ট (Monthly)
            </button>
            <button
              onClick={() => setActiveChartType('VS_EXPENSE')}
              className={`py-1.5 px-3 rounded-xl text-xs font-black transition-all cursor-pointer ${
                activeChartType === 'VS_EXPENSE'
                  ? 'bg-emerald-600 text-white shadow'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              সঞ্চয় বনাম ব্যয় (Comparison)
            </button>
            <button
              onClick={() => setActiveChartType('CUMULATIVE')}
              className={`py-1.5 px-3 rounded-xl text-xs font-black transition-all cursor-pointer ${
                activeChartType === 'CUMULATIVE'
                  ? 'bg-emerald-600 text-white shadow'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              সঞ্চয়ন কার্ভ (Cumulative)
            </button>
          </div>
        </div>

        {/* Visual Bar Chart */}
        {activeChartType === 'BAR' && (
          <div className="pt-6 pb-2 grid grid-cols-5 gap-3 sm:gap-6 items-end h-60 border-b border-slate-800">
            {monthsData.map((item) => {
              const heightPct = Math.max(12, Math.round((item.amount / maxMonthAmount) * 100));
              const isCurrent = item.month === selectedMonth;

              return (
                <div key={item.month} className="flex flex-col items-center h-full justify-end group">
                  <span className="text-[11px] font-black text-emerald-400 mb-1 opacity-90 group-hover:scale-110 transition-transform">
                    {formatCurrencyBengali(item.amount)}
                  </span>
                  <div
                    className="w-full max-w-[64px] rounded-t-2xl transition-all duration-500 relative flex items-end justify-center shadow-lg"
                    style={{
                      height: `${heightPct}%`,
                      background: isCurrent
                        ? 'linear-gradient(to top, #047857, #10b981, #34d399)'
                        : 'linear-gradient(to top, #0f172a, #1e293b, #334155)',
                    }}
                  >
                    {isCurrent && (
                      <div className="w-2.5 h-2.5 rounded-full bg-white mb-2 shadow animate-ping" />
                    )}
                  </div>
                  <span className="text-xs font-black text-slate-200 mt-2 truncate">
                    {item.label}
                  </span>
                </div>
              );
            })}
          </div>
        )}

        {/* Savings vs Expenses Comparative Bar Chart */}
        {activeChartType === 'VS_EXPENSE' && (
          <div className="pt-4 pb-2 space-y-3">
            <div className="flex items-center justify-center gap-4 text-xs font-bold text-slate-300">
              <span className="flex items-center gap-1.5">
                <span className="w-3 h-3 rounded-md bg-emerald-500 inline-block" />
                <span>অনুমোদিত সঞ্চয় জমা (Income)</span>
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-3 h-3 rounded-md bg-rose-500 inline-block" />
                <span>ফাউন্ডেশন খরচ ও ব্যয় (Expense)</span>
              </span>
            </div>

            <div className="pt-4 grid grid-cols-5 gap-3 sm:gap-6 items-end h-60 border-b border-slate-800">
              {monthsData.map((item) => {
                const savingsHeight = Math.max(10, Math.round((item.amount / maxMonthAmount) * 100));
                const expenseHeight = Math.max(8, Math.round(((item.expense || 0) / maxMonthAmount) * 100));

                return (
                  <div key={item.month} className="flex flex-col items-center h-full justify-end">
                    <div className="flex items-end gap-1 sm:gap-2 w-full justify-center h-full pb-1">
                      {/* Savings Bar */}
                      <div className="flex flex-col items-center flex-1 max-w-[28px] h-full justify-end">
                        <span className="text-[9px] font-black text-emerald-400 mb-0.5 truncate hidden sm:block">
                          {formatCurrencyBengali(item.amount)}
                        </span>
                        <div
                          className="w-full rounded-t-xl bg-gradient-to-t from-emerald-700 to-emerald-400 transition-all duration-500 shadow-md"
                          style={{ height: `${savingsHeight}%` }}
                        />
                      </div>

                      {/* Expense Bar */}
                      <div className="flex flex-col items-center flex-1 max-w-[28px] h-full justify-end">
                        <span className="text-[9px] font-black text-rose-400 mb-0.5 truncate hidden sm:block">
                          {formatCurrencyBengali(item.expense || 0)}
                        </span>
                        <div
                          className="w-full rounded-t-xl bg-gradient-to-t from-rose-700 to-rose-400 transition-all duration-500 shadow-md"
                          style={{ height: `${expenseHeight}%` }}
                        />
                      </div>
                    </div>
                    <span className="text-xs font-black text-slate-200 mt-2 truncate">
                      {item.label}
                    </span>
                  </div>
                );
              })}
            </div>
            <p className="text-[11px] text-slate-400 text-center italic">
              * সবুজ বার নির্দেশ করে মোট সঞ্চয় জমা এবং লাল বার নির্দেশ করে ফাউন্ডেশনের দাপ্তরিক ও কল্যাণ ব্যয়
            </p>
          </div>
        )}

        {/* Cumulative Area / Curve Simulation Chart */}
        {activeChartType === 'CUMULATIVE' && (
          <div className="pt-6 pb-2 space-y-3">
            <div className="grid grid-cols-5 gap-3 sm:gap-6 items-end h-56 border-b border-slate-800">
              {monthsData.map((item) => {
                const heightPct = Math.max(15, Math.round((item.cumulative / maxCumulative) * 100));
                return (
                  <div key={item.month} className="flex flex-col items-center h-full justify-end group">
                    <span className="text-[11px] font-black text-teal-300 mb-1">
                      {formatCurrencyBengali(item.cumulative)}
                    </span>
                    <div
                      className="w-full max-w-[64px] rounded-t-2xl transition-all duration-700 bg-gradient-to-t from-teal-900 via-teal-600 to-emerald-400 relative shadow-lg"
                      style={{ height: `${heightPct}%` }}
                    >
                      <div className="w-full h-1 bg-amber-400 absolute top-0 rounded-full" />
                    </div>
                    <span className="text-xs font-black text-slate-200 mt-2 truncate">
                      {item.label}
                    </span>
                  </div>
                );
              })}
            </div>
            <p className="text-[11px] text-slate-400 text-center italic">
              * জুন থেকে অক্টোবর ২০২৬ পর্যন্ত সর্বমোট সঞ্চয়ের ক্রমবর্ধমান প্রবৃদ্ধি রেখা
            </p>
          </div>
        )}
      </div>

      {/* 4. Payment Method Distribution (Interactive SVG Donut / Pie Chart) & Annual Target Progress */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Payment Methods Breakdown with SVG Donut / Pie Chart */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 sm:p-6 shadow-sm space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 className="font-black text-white text-base flex items-center gap-2">
              <PieChart className="w-5 h-5 text-emerald-400" />
              <span>পদ্ধতিভিত্তিক পাই চার্ট ও অনুপাত ({selectedMonth})</span>
            </h3>
            <span className="text-xs font-black text-emerald-400">
              মোট: {formatCurrencyBengali(paymentBreakdown.total)}
            </span>
          </div>

          {/* Donut Chart and Legend Grid */}
          <div className="flex flex-col sm:flex-row items-center gap-4 pt-1">
            {/* SVG Interactive Donut Chart */}
            <div className="relative w-36 h-36 shrink-0 flex items-center justify-center">
              <svg className="w-full h-full -rotate-90" viewBox="0 0 100 100">
                {/* Background Track */}
                <circle
                  cx="50"
                  cy="50"
                  r="38"
                  fill="transparent"
                  stroke="#1e293b"
                  strokeWidth="12"
                />
                {(() => {
                  const circumference = 2 * Math.PI * 38;
                  const total = paymentBreakdown.total || 1;
                  const slices = [
                    { amount: paymentBreakdown.breakdown.BANK || 0, stroke: '#10b981' },
                    { amount: paymentBreakdown.breakdown.BKASH || 0, stroke: '#ec4899' },
                    { amount: paymentBreakdown.breakdown.NAGAD || 0, stroke: '#f59e0b' },
                    { amount: paymentBreakdown.breakdown.ROCKET || 0, stroke: '#a855f7' },
                    { amount: paymentBreakdown.breakdown.CASH || 0, stroke: '#3b82f6' },
                  ];

                  let accumulatedOffset = 0;
                  return slices.map((s, idx) => {
                    const sliceLen = (s.amount / total) * circumference;
                    const el = (
                      <circle
                        key={idx}
                        cx="50"
                        cy="50"
                        r="38"
                        fill="transparent"
                        stroke={s.stroke}
                        strokeWidth="12"
                        strokeDasharray={`${sliceLen} ${circumference - sliceLen}`}
                        strokeDashoffset={-accumulatedOffset}
                        strokeLinecap="butt"
                        className="transition-all duration-700"
                      />
                    );
                    accumulatedOffset += sliceLen;
                    return el;
                  });
                })()}
              </svg>

              <div className="absolute inset-0 flex flex-col items-center justify-center text-center pointer-events-none">
                <span className="text-[10px] text-slate-400 font-bold">মোট সঞ্চয়</span>
                <span className="text-xs font-black text-white leading-tight">
                  {formatCurrencyBengali(paymentBreakdown.total)}
                </span>
              </div>
            </div>

            {/* Methods Legend Bars */}
            <div className="flex-1 w-full space-y-2">
              {[
                { method: 'ব্যাংক ডিপোজিট (Bank)', amount: paymentBreakdown.breakdown.BANK || 0, color: 'bg-emerald-500', barColor: 'from-emerald-600 to-teal-400', icon: '🏦' },
                { method: 'বিকাশ (bKash)', amount: paymentBreakdown.breakdown.BKASH || 0, color: 'bg-pink-500', barColor: 'from-pink-600 to-rose-400', icon: '📱' },
                { method: 'নগদ (Nagad)', amount: paymentBreakdown.breakdown.NAGAD || 0, color: 'bg-amber-500', barColor: 'from-amber-600 to-yellow-400', icon: '💳' },
                { method: 'রকেট (Rocket)', amount: paymentBreakdown.breakdown.ROCKET || 0, color: 'bg-purple-500', barColor: 'from-purple-600 to-indigo-400', icon: '🚀' },
                { method: 'সরাসরি ক্যাশ (Cash)', amount: paymentBreakdown.breakdown.CASH || 0, color: 'bg-blue-500', barColor: 'from-blue-600 to-cyan-400', icon: '💵' },
              ].map((p) => {
                const pct = paymentBreakdown.total > 0
                  ? Math.round((p.amount / paymentBreakdown.total) * 100)
                  : 0;

                return (
                  <div key={p.method} className="space-y-0.5">
                    <div className="flex justify-between text-[11px]">
                      <span className="text-white font-bold flex items-center gap-1.5">
                        <span className={`w-2 h-2 rounded-full ${p.color}`} />
                        <span>{p.method}</span>
                      </span>
                      <span className="text-slate-300 font-black">
                        {formatCurrencyBengali(p.amount)} ({toBengaliNumerals(pct)}%)
                      </span>
                    </div>
                    <div className="w-full bg-slate-950 rounded-full h-2 overflow-hidden border border-slate-800">
                      <div
                        className={`h-2 rounded-full bg-gradient-to-r ${p.barColor} transition-all duration-500`}
                        style={{ width: `${Math.max(pct, p.amount > 0 ? 5 : 0)}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Annual Target & Savings Progress Gauge */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 sm:p-6 shadow-sm space-y-4 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="font-black text-white text-base flex items-center gap-2">
                <Target className="w-5 h-5 text-amber-400" />
                <span>বাৎসরিক সঞ্চয় লক্ষ্যমাত্রা অগ্রগতি</span>
              </h3>
              <span className="text-xs font-black text-amber-400">২০২৬ অর্থবছর</span>
            </div>

            <div className="pt-4 space-y-3">
              <div className="flex items-baseline justify-between">
                <div>
                  <span className="text-[11px] text-slate-400 font-bold block">বর্তমান সঞ্চিত তহবিল:</span>
                  <span className="text-2xl font-black text-emerald-400">
                    {formatCurrencyBengali(totalSavings)}
                  </span>
                </div>
                <div className="text-right">
                  <span className="text-[11px] text-slate-400 font-bold block">ধার্যকৃত লক্ষ্যমাত্রা:</span>
                  <span className="text-xl font-black text-white">
                    {formatCurrencyBengali(annualTarget)}
                  </span>
                </div>
              </div>

              {/* Progress Bar with Milestones */}
              <div className="space-y-1">
                <div className="w-full bg-slate-950 rounded-full h-4 overflow-hidden border border-slate-800 p-0.5">
                  <div
                    className="h-full rounded-full bg-gradient-to-r from-emerald-600 via-teal-400 to-amber-400 transition-all duration-1000"
                    style={{ width: `${targetPct}%` }}
                  />
                </div>
                <div className="flex justify-between text-[10px] text-slate-500 font-bold px-1">
                  <span>০%</span>
                  <span>২৫%</span>
                  <span>৫০%</span>
                  <span>৭৫%</span>
                  <span>১০০% ({formatCurrencyBengali(annualTarget)})</span>
                </div>
              </div>

              <div className="p-3 rounded-2xl bg-slate-950/80 border border-slate-800/80 text-xs text-slate-300 leading-relaxed">
                <p>
                  🎯 ফাউন্ডেশন নির্ধারিত বার্ষিক লক্ষ্যমাত্রার <strong className="text-emerald-400 font-black">{toBengaliNumerals(targetPct)}%</strong> অর্জিত হয়েছে। বাকি <strong className="text-amber-300 font-black">{formatCurrencyBengali(Math.max(0, annualTarget - totalSavings))}</strong> সঞ্চয় চলতি অর্থবছরে সদস্যদের নিয়মিত জমার মাধ্যমে আদায়যোগ্য।
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* 5. Member Savings Contribution Ranking (Top Savers) */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 sm:p-6 shadow-sm space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <Award className="w-5 h-5 text-amber-400" />
            <h3 className="font-black text-white text-base">
              সদস্য সঞ্চয় অবদান র‍্যাংকিং (Member Contributions)
            </h3>
          </div>
          <span className="text-xs text-slate-400 font-bold">
            শীর্ষ অবদানকারী সদস্যগণ
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {memberRankings.slice(0, 6).map((rank, index) => (
            <div
              key={rank.memberId}
              className="p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800 hover:border-slate-700 transition-all flex items-center justify-between"
            >
              <div className="flex items-center gap-3">
                <div
                  className={`w-7 h-7 rounded-xl flex items-center justify-center font-black text-xs ${
                    index === 0
                      ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                      : index === 1
                      ? 'bg-slate-300/20 text-slate-200 border border-slate-400/40'
                      : index === 2
                      ? 'bg-amber-700/20 text-amber-500 border border-amber-700/40'
                      : 'bg-slate-800 text-slate-400'
                  }`}
                >
                  #{toBengaliNumerals(index + 1)}
                </div>

                <Avatar src={rank.avatar} name={rank.name} size="sm" />

                <div>
                  <h4 className="font-black text-xs text-white">{rank.name}</h4>
                  <span className="text-[10px] text-slate-400 font-mono">{rank.memberId}</span>
                </div>
              </div>

              <div className="text-right">
                <span className="font-black text-emerald-400 text-xs block">
                  {formatCurrencyBengali(rank.total)}
                </span>
                <span className="text-[10px] text-slate-500">
                  {toBengaliNumerals(rank.count)} বার জমা
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
