import React, { useState } from 'react';
import {
  Smartphone,
  FileCode,
  DownloadCloud,
  CheckCircle2,
  Copy,
  Terminal,
  ShieldCheck,
  Cpu,
  Layers,
} from 'lucide-react';

export const NativeAndroidSpecView: React.FC = () => {
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);

  const copyToClipboard = (text: string, idx: number) => {
    navigator.clipboard.writeText(text);
    setCopiedIndex(idx);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  const kotlinComposeSnippet = `// MainActivity.kt - Jetpack Compose Entry Point
package org.basis.foundation

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.navigation.compose.*
import dagger.hilt.android.AndroidEntryPoint
import org.basis.foundation.ui.theme.BasisFoundationTheme
import org.basis.foundation.ui.navigation.BasisNavHost

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            BasisFoundationTheme(darkTheme = true) {
                Surface(color = MaterialTheme.colorScheme.background) {
                    val navController = rememberNavController()
                    BasisNavHost(navController = navController)
                }
            }
        }
    }
}`;

  const approvalWorkflowUseCaseSnippet = `// ApprovalWorkflowUseCase.kt - 2/3rds Ceiling Approval Engine
package org.basis.foundation.domain.usecase

import kotlin.math.ceil
import org.basis.foundation.domain.model.ApprovalStatus
import org.basis.foundation.domain.model.ApprovalEvaluation

class CalculateApprovalThresholdUseCase {
    fun execute(eligibleModeratorsCount: Int): Int {
        if (eligibleModeratorsCount <= 0) return 1
        return ceil(eligibleModeratorsCount * 2.0 / 3.0).toInt()
    }
}

class EvaluateApprovalUseCase(
    private val calculateThreshold: CalculateApprovalThresholdUseCase
) {
    fun execute(
        eligibleCount: Int,
        approvedVotes: List<String>,
        rejectedVotes: List<String>
    ): ApprovalEvaluation {
        val required = calculateThreshold.execute(eligibleCount)
        val approveCount = approvedVotes.size
        val rejectCount = rejectedVotes.size

        return when {
            approveCount >= required -> ApprovalEvaluation(
                isFinalized = true,
                status = ApprovalStatus.APPROVED,
                requiredVotes = required
            )
            eligibleCount - rejectCount < required -> ApprovalEvaluation(
                isFinalized = true,
                status = ApprovalStatus.REJECTED,
                requiredVotes = required
            )
            else -> ApprovalEvaluation(
                isFinalized = false,
                status = ApprovalStatus.PENDING,
                requiredVotes = required
            )
        }
    }
}`;

  const gradleSnippet = `// build.gradle.kts (:app module)
plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
    alias(libs.plugins.hilt.android)
    alias(libs.plugins.google.gms.google.services)
}

android {
    namespace = "org.basis.foundation"
    compileSdk = 35

    defaultConfig {
        applicationId = "org.basis.foundation"
        minSdk = 26
        targetSdk = 35
        versionCode = 110
        versionName = "1.1.0"
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildFeatures {
        compose = true
    }
}

dependencies {
    implementation(platform(libs.firebase.bom))
    implementation(libs.firebase.firestore.ktx)
    implementation(libs.firebase.auth.ktx)
    implementation(libs.firebase.messaging.ktx)
    implementation(libs.hilt.android)
    implementation(libs.navigation.compose)
    implementation(libs.material3)
}`;

  const firestoreRulesSnippet = `// firestore.rules - Restrictive Security Rules
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    function isAuthenticated() {
      return request.auth != null;
    }
    function isApprovedMember() {
      return isAuthenticated() &&
        get(/databases/$(database)/documents/users/$(request.auth.uid)).data.status == 'APPROVED';
    }
    function isModerator() {
      let role = get(/databases/$(database)/documents/users/$(request.auth.uid)).data.role;
      return isAuthenticated() && (role == 'MODERATOR' || role == 'APP_MODERATOR');
    }
    function isAppModerator() {
      return isAuthenticated() &&
        get(/databases/$(database)/documents/users/$(request.auth.uid)).data.role == 'APP_MODERATOR';
    }

    // Savings records: Read authorized, Write moderator only, delete denied!
    match /savingsTransactions/{txId} {
      allow read: if isApprovedMember();
      allow create: if isModerator();
      allow update, delete: if false; // Immutability & Reversals only
    }

    // Moderator Only Chat: Deny ordinary members!
    match /moderatorChat/{msgId} {
      allow read, write: if isModerator();
    }

    // App releases & config: Only APP_MODERATOR
    match /appReleases/{releaseId} {
      allow read: if isAuthenticated();
      allow write: if isAppModerator();
    }
  }
}`;

  return (
    <div className="space-y-5 pb-16">
      {/* Header with Environment Disclosure (Section 35) */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-sm space-y-4">
        <div className="flex items-center gap-2.5">
          <Smartphone className="w-6 h-6 text-emerald-400" />
          <div>
            <h2 className="text-xl font-bold text-white">
              নেটিভ অ্যান্ড্রয়েড আর্কিটেকচার ও এপিকে বিল্ড ব্লুপ্রিন্ট (Android Spec)
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Kotlin, Jetpack Compose, Material 3, Hilt & Firebase ভিত্তিক নেটিভ অ্যান্ড্রয়েড কোডবেস।
            </p>
          </div>
        </div>

        {/* Environment Truth Disclosure as demanded by Section 35 */}
        <div className="p-4 rounded-xl bg-slate-950 border border-emerald-900/40 text-xs space-y-2">
          <div className="flex items-center gap-2 text-emerald-400 font-bold">
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            <span>পরিবেশ প্রতিবেদন ও বাস্তবায়ন নীতি (Environment Transparency Report):</span>
          </div>
          <p className="text-slate-300 leading-relaxed">
            বর্তমান ডেভেলপমেন্ট কনটেইনারটি একটি <strong>Node.js / TypeScript / React / Vite Web & Express</strong> রানটাইম।
            অনুচ্ছেদ ৩৫ এর সুস্পষ্ট নির্দেশনানুসারে—ওয়েব প্রোটোটাইপকে কোনোক্রমেই সরাসরি কম্পাইলকৃত নেটিভ এপিকে হিসেবে উপস্থাপন করা হয়নি। পরিবর্তে:
          </p>
          <ul className="list-disc list-inside space-y-1 text-slate-400 pl-2">
            <li>
              <strong>১ম অংশ (চলমান ওয়েব/পিডব্লিউএ অ্যাপ):</strong> অ্যান্ড্রয়েড মেটেরিয়াল ৩ ডিজাইন, ব্যাক বাটন ডায়ালগ, ডার্ক থিম, বাংলা ফন্ট, ২/৩ সিলিং হিসাব ইঞ্জিন এবং অফলাইন হ্যান্ডলিং সহ সম্পূর্ণ কার্যকরী ওয়েব অ্যাপ।
            </li>
            <li>
              <strong>২য় অংশ (নেটিভ অ্যান্ড্রয়েড সোর্স প্রজেক্ট স্পেক):</strong> যে কোনো অ্যান্ড্রয়েড ডেভেলপার বা প্রতিষ্ঠান সরাসরি Android Studio তে ওপেন করে <code className="text-emerald-300 font-mono">./gradlew assembleRelease</code> কমান্ডে আসল নেটিভ APK তৈরি করার জন্য নিচে সম্পূর্ণ কোড স্ট্রাকচার ও আর্কিটেকচার ব্লুপ্রিন্ট প্রস্তুত রয়েছে।
            </li>
          </ul>
        </div>
      </div>

      {/* Step-by-Step Compilation & Native APK Build Instruction Guide (Requirement 23) */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4">
        <div className="flex items-center gap-2.5 border-b border-slate-800 pb-3">
          <Terminal className="w-5 h-5 text-emerald-400" />
          <h3 className="text-base font-bold text-white">
            স্টেপ-বাই-স্টেপ এপিকে (APK) কম্পাইল ও বিল্ডিং নির্দেশিকা (Step-by-Step Build Guide)
          </h3>
        </div>

        <div className="space-y-3 text-xs">
          <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-1.5">
            <h4 className="font-bold text-emerald-300 flex items-center gap-2">
              <span className="w-5 h-5 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-mono text-[11px]">১</span>
              <span>ডিপেন্ডেন্সি ইনস্টল ও লোকাল এনভায়রনমেন্ট প্রস্তুতকরণ</span>
            </h4>
            <p className="text-slate-400 leading-relaxed pl-7">
              আপনার মেশিনে Node.js (v18+) এবং Android Studio ইনস্টল থাকতে হবে। টার্মিনালে নিচের কমান্ড রান করুন:
            </p>
            <div className="bg-slate-900 p-2 rounded-lg font-mono text-emerald-300 ml-7 text-[11px]">
              npm install
            </div>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-1.5">
            <h4 className="font-bold text-blue-300 flex items-center gap-2">
              <span className="w-5 h-5 rounded-full bg-blue-500/20 text-blue-400 flex items-center justify-center font-mono text-[11px]">২</span>
              <span>প্রোডাকশন বান্ডেল তৈরি (Build Web Assets)</span>
            </h4>
            <p className="text-slate-400 leading-relaxed pl-7">
              প্রথমে Vite দিয়ে অপ্টিমাইজড প্রোডাকশন বিল্ড তৈরি করুন যা <code className="text-emerald-400">dist</code> ফোল্ডারে সেভ হবে:
            </p>
            <div className="bg-slate-900 p-2 rounded-lg font-mono text-blue-300 ml-7 text-[11px]">
              npm run build
            </div>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-1.5">
            <h4 className="font-bold text-amber-300 flex items-center gap-2">
              <span className="w-5 h-5 rounded-full bg-amber-500/20 text-amber-400 flex items-center justify-center font-mono text-[11px]">৩</span>
              <span>ক্যাপাসিটর অ্যান্ড্রয়েড প্রজেক্ট সিঙ্ক (Capacitor Android Sync)</span>
            </h4>
            <p className="text-slate-400 leading-relaxed pl-7">
              ক্যাপাসিটরের মাধ্যমে ওয়েব বান্ডেলকে অ্যান্ড্রয়েড প্রজেক্টে ইনজেক্ট করুন:
            </p>
            <div className="bg-slate-900 p-2 rounded-lg font-mono text-amber-300 ml-7 text-[11px]">
              npx cap add android <br />
              npx cap sync
            </div>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-1.5">
            <h4 className="font-bold text-purple-300 flex items-center gap-2">
              <span className="w-5 h-5 rounded-full bg-purple-500/20 text-purple-400 flex items-center justify-center font-mono text-[11px]">৪</span>
              <span>অ্যান্ড্রয়েড স্টুডিওতে ওপেন ও APK সাইন করা</span>
            </h4>
            <p className="text-slate-400 leading-relaxed pl-7">
              অ্যান্ড্রয়েড স্টুডিওতে প্রজেক্ট ওপেন করে সরাসরি APK রান বা সাইন করুন:
            </p>
            <div className="bg-slate-900 p-2 rounded-lg font-mono text-purple-300 ml-7 text-[11px]">
              npx cap open android
            </div>
            <p className="text-[11px] text-slate-400 pl-7 pt-1">
              * Android Studio মেনু থেকে: <strong className="text-white">Build &gt; Build Bundle(s) / APK(s) &gt; Build APK(s)</strong> সিলেক্ট করলেই রিলিজ APK ফাইল প্রস্তুত হয়ে যাবে।
            </p>
          </div>
        </div>
      </div>

      {/* Code Snippets Section */}
      <div className="space-y-4">
        {/* Kotlin Compose Snippet */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-2">
          <div className="flex items-center justify-between">
            <span className="font-mono text-xs font-bold text-emerald-400 flex items-center gap-2">
              <FileCode className="w-4 h-4" />
              <span>MainActivity.kt (Jetpack Compose Entry Point)</span>
            </span>
            <button
              onClick={() => copyToClipboard(kotlinComposeSnippet, 1)}
              className="py-1 px-2.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs flex items-center gap-1 font-mono"
            >
              <Copy className="w-3 h-3" />
              <span>{copiedIndex === 1 ? 'কপি হয়েছে!' : 'কপি করুন'}</span>
            </button>
          </div>
          <pre className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-[11px] font-mono text-slate-300 overflow-x-auto leading-relaxed">
            {kotlinComposeSnippet}
          </pre>
        </div>

        {/* 2/3rds Ceiling Approval Engine Kotlin Use Case */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-2">
          <div className="flex items-center justify-between">
            <span className="font-mono text-xs font-bold text-blue-400 flex items-center gap-2">
              <Layers className="w-4 h-4" />
              <span>ApprovalWorkflowUseCase.kt (২/৩ সিলিং অনুমোদন ইঞ্জিন)</span>
            </span>
            <button
              onClick={() => copyToClipboard(approvalWorkflowUseCaseSnippet, 2)}
              className="py-1 px-2.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs flex items-center gap-1 font-mono"
            >
              <Copy className="w-3 h-3" />
              <span>{copiedIndex === 2 ? 'কপি হয়েছে!' : 'কপি করুন'}</span>
            </button>
          </div>
          <pre className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-[11px] font-mono text-slate-300 overflow-x-auto leading-relaxed">
            {approvalWorkflowUseCaseSnippet}
          </pre>
        </div>

        {/* Firestore Rules */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-2">
          <div className="flex items-center justify-between">
            <span className="font-mono text-xs font-bold text-amber-400 flex items-center gap-2">
              <ShieldCheck className="w-4 h-4" />
              <span>firestore.rules (সার্ভার-সাইড নিরাপত্তা রুলস)</span>
            </span>
            <button
              onClick={() => copyToClipboard(firestoreRulesSnippet, 3)}
              className="py-1 px-2.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs flex items-center gap-1 font-mono"
            >
              <Copy className="w-3 h-3" />
              <span>{copiedIndex === 3 ? 'কপি হয়েছে!' : 'কপি করুন'}</span>
            </button>
          </div>
          <pre className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-[11px] font-mono text-slate-300 overflow-x-auto leading-relaxed">
            {firestoreRulesSnippet}
          </pre>
        </div>

        {/* Gradle build configuration */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-2">
          <div className="flex items-center justify-between">
            <span className="font-mono text-xs font-bold text-teal-400 flex items-center gap-2">
              <Terminal className="w-4 h-4" />
              <span>app/build.gradle.kts (নির্ভরশীলতা ও কনফিগারেশন)</span>
            </span>
            <button
              onClick={() => copyToClipboard(gradleSnippet, 4)}
              className="py-1 px-2.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs flex items-center gap-1 font-mono"
            >
              <Copy className="w-3 h-3" />
              <span>{copiedIndex === 4 ? 'কপি হয়েছে!' : 'কপি করুন'}</span>
            </button>
          </div>
          <pre className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-[11px] font-mono text-slate-300 overflow-x-auto leading-relaxed">
            {gradleSnippet}
          </pre>
        </div>
      </div>
    </div>
  );
};
