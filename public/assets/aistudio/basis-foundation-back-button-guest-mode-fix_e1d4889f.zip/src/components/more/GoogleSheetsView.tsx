import React, { useState } from 'react';
import {
  FileSpreadsheet,
  ExternalLink,
  Save,
  RefreshCw,
  ShieldAlert,
  CheckCircle2,
  Copy,
  Flame,
  Info,
  Maximize2,
  Code,
  BookOpen,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const GoogleSheetsView: React.FC = () => {
  const { config, updateConfig, currentUser } = useApp();
  const [sheetUrl, setSheetUrl] = useState(
    config.googleSheetsUrl ||
      'https://docs.google.com/spreadsheets/d/1BxiMVs0XRA5nFMdKvBdBZjgmUUqptlbs74OgvE2upms/edit?usp=sharing'
  );
  const [isEditing, setIsEditing] = useState(false);
  const [mode, setMode] = useState<'edit' | 'view'>('edit');
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  const isModeratorOrAppMod =
    currentUser.role === 'APP_MODERATOR' || currentUser.role === 'MODERATOR';

  const handleSaveUrl = (e: React.FormEvent) => {
    e.preventDefault();
    updateConfig({ googleSheetsUrl: sheetUrl.trim() });
    setIsEditing(false);
    alert('গুগল শিট লিংক সফলভাবে আপডেট হয়েছে!');
  };

  const copyCode = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2500);
  };

  // Convert sharing URL to embeddable or editable minimal URL
  const getEmbedUrl = (rawUrl: string, targetMode: 'edit' | 'view') => {
    try {
      if (rawUrl.includes('spreadsheets/d/')) {
        const idMatch = rawUrl.match(/\/d\/([a-zA-Z0-9-_]+)/);
        if (idMatch && idMatch[1]) {
          const sheetId = idMatch[1];
          if (targetMode === 'edit') {
            // Allows direct interactive cell editing if logged into Google account with Editor permission
            return `https://docs.google.com/spreadsheets/d/${sheetId}/edit?rm=minimal`;
          } else {
            return `https://docs.google.com/spreadsheets/d/${sheetId}/htmlembed?widget=true&headers=false`;
          }
        }
      }
      return rawUrl;
    } catch {
      return rawUrl;
    }
  };

  const embedSrc = getEmbedUrl(sheetUrl, mode);

  const appsScriptSnippet = `// Google Apps Script (Webhook) - অটোমেটিক সঞ্চয় রো যুক্তকরণ
function doPost(e) {
  var sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
  var data = JSON.parse(e.postData.contents);
  
  // নতুন সঞ্চয় এন্ট্রি রো যোগ করুন
  sheet.appendRow([
    new Date(),
    data.receiptId || "N/A",
    data.memberId,
    data.memberName,
    data.savingsMonth,
    data.amount,
    data.paymentMethod,
    data.transactionRef || "",
    "ভেরিফাইড (২/৩ অনুমোদিত)"
  ]);
  
  return ContentService.createTextOutput(JSON.stringify({status: "success"}))
    .setMimeType(ContentService.MimeType.JSON);
}`;

  return (
    <div className="space-y-5 pb-20">
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 sm:p-6 shadow-sm space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h2 className="text-xl sm:text-2xl font-black text-white flex items-center gap-2">
              <FileSpreadsheet className="w-6 h-6 text-emerald-400" />
              <span>গুগল শিটস ক্লাউড স্প্রেডশিট (Google Sheets Integration)</span>
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              একই জিমেইল দিয়ে লগইন থাকলে সরাসরি এই অ্যাপ্লিকেশনের ভেতরেই স্প্রেডশিট সম্পাদন ও সমন্বয় করুন।
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <a
              href={sheetUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="py-2 px-3.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-black flex items-center gap-1.5 transition-colors border border-slate-700"
            >
              <span>নতুন ট্যাবে খুলুন</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>

            {isModeratorOrAppMod && (
              <button
                onClick={() => setIsEditing(!isEditing)}
                className="py-2 px-3.5 rounded-xl bg-emerald-600/20 text-emerald-400 border border-emerald-500/30 hover:bg-emerald-600/30 text-xs font-black transition-colors"
              >
                {isEditing ? 'সম্পাদনা বন্ধ' : 'শিট লিংক পরিবর্তন'}
              </button>
            )}
          </div>
        </div>

        {/* Link Edit Form */}
        {isEditing && (
          <form onSubmit={handleSaveUrl} className="pt-3 border-t border-slate-800 flex flex-col sm:flex-row gap-2">
            <input
              type="url"
              placeholder="গুগল শিট শেয়ারিং লিংক পেস্ট করুন..."
              value={sheetUrl}
              onChange={(e) => setSheetUrl(e.target.value)}
              className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:ring-1 focus:ring-emerald-500 font-mono"
              required
            />
            <button
              type="submit"
              className="py-2 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs flex items-center justify-center gap-1 shrink-0"
            >
              <Save className="w-3.5 h-3.5" />
              <span>সংরক্ষণ করুন</span>
            </button>
          </form>
        )}
      </div>

      {/* Step-by-Step Interactive Guide: How same-email access works */}
      <div className="bg-gradient-to-r from-emerald-950/40 via-slate-900 to-slate-900 border border-emerald-500/30 rounded-3xl p-5 sm:p-6 shadow-md space-y-4">
        <div className="flex items-center gap-2 text-emerald-400 font-black text-sm">
          <BookOpen className="w-5 h-5" />
          <span>একই ইমেইল দিয়ে অ্যাপ থেকে গুগল শিট সরাসরি এডিট ও ম্যানেজ করার ধাপসমূহ:</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
          {/* Step 1 */}
          <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-1.5">
            <div className="w-6 h-6 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-black text-xs">
              ১
            </div>
            <h4 className="font-black text-white text-xs">গুগল শিটে এডিটর পারমিশন দিন</h4>
            <p className="text-slate-300 text-[11px] leading-relaxed">
              আপনার গুগল স্প্রেডশিটে গিয়ে ওপরের ডানে <strong>Share</strong> বাটনে ক্লিক করে সংশ্লিষ্ট ইমেইলকে (<code className="text-emerald-400 font-mono font-bold">contact.mahmudulhasan.bd@gmail.com</code>) <strong>"Editor"</strong> পারমিশন দিন অথবা 'Anyone with link as Editor' নির্বাচন করুন।
            </p>
          </div>

          {/* Step 2 */}
          <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-1.5">
            <div className="w-6 h-6 rounded-lg bg-blue-500/20 text-blue-400 flex items-center justify-center font-black text-xs">
              ২
            </div>
            <h4 className="font-black text-white text-xs">একই ব্রাউজার গুগল একাউন্টে লগইন</h4>
            <p className="text-slate-300 text-[11px] leading-relaxed">
              যেহেতু এই ওয়েব অ্যাপ্লিকেশনটি আপনার ডিভাইসের ব্রাউজারে চালু থাকে, তাই আপনার ব্রাউজারে যদি ওই জিমেইল একাউন্ট লগইন থাকে, গুগল শিটের ফ্রেম স্বয়ংক্রিয়ভাবে আপনার অথরাইজড সেশন ব্যবহার করে।
            </p>
          </div>

          {/* Step 3 */}
          <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-1.5">
            <div className="w-6 h-6 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center font-black text-xs">
              ৩
            </div>
            <h4 className="font-black text-white text-xs">সরাসরি সেল ক্লিক করে এডিট</h4>
            <p className="text-slate-300 text-[11px] leading-relaxed">
              নিচের ফ্রেমটিতে 'এডিটর মোড' নির্বাচন করুন। ফ্রেমের যেকোনো সেলে ডাবল-ক্লিক করলেই সরাসরি টেক্সট টাইপ, ফর্মুলা লেখা এবং নতুন রো যুক্ত করা যাবে।
            </p>
          </div>
        </div>
      </div>

      {/* Frame Controls & View Toggle */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 px-1 text-xs text-slate-300">
        <div className="flex items-center gap-2">
          <span className="text-slate-400 font-bold">ভিউ মোড:</span>
          <div className="bg-slate-900 p-1 rounded-xl border border-slate-800 flex items-center gap-1">
            <button
              onClick={() => setMode('edit')}
              className={`py-1 px-3 rounded-lg text-xs font-black transition-all ${
                mode === 'edit'
                  ? 'bg-emerald-600 text-white shadow'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              ইন্টারেক্টিভ এডিটর মোড (Direct Edit)
            </button>
            <button
              onClick={() => setMode('view')}
              className={`py-1 px-3 rounded-lg text-xs font-black transition-all ${
                mode === 'view'
                  ? 'bg-emerald-600 text-white shadow'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              ক্লিন গ্রিড ভিউ (Clean Embed)
            </button>
          </div>
        </div>

        <span className="text-[11px] text-emerald-400 font-bold flex items-center gap-1">
          <CheckCircle2 className="w-3.5 h-3.5" />
          <span>সার্ভার নিরাপদ এসএসএল (SSL) এনক্রিপ্টেড সংযোগ সক্রিয়</span>
        </span>
      </div>

      {/* Embedded Google Sheet Iframe */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden shadow-2xl relative">
        <iframe
          src={embedSrc}
          title="Google Sheets Live Embed"
          className="w-full h-[650px] border-0 bg-white"
          allow="autoplay; clipboard-write; encrypted-media"
        />
      </div>

      {/* Apps Script Automation Snippet */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-sm space-y-3">
        <div className="flex items-center justify-between">
          <h4 className="font-black text-white text-sm flex items-center gap-2">
            <Code className="w-4 h-4 text-emerald-400" />
            <span>স্বয়ংক্রিয় সঞ্চয় রো সিঙ্ক কোড (Google Apps Script Webhook)</span>
          </h4>

          <button
            onClick={() => copyCode(appsScriptSnippet, 'script')}
            className="py-1 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold transition-colors flex items-center gap-1"
          >
            <Copy className="w-3.5 h-3.5" />
            <span>{copiedKey === 'script' ? 'কপি সম্পন্ন!' : 'স্ক্রিপ্ট কপি'}</span>
          </button>
        </div>

        <p className="text-xs text-slate-400">
          আপনার স্প্রেডশিটে গিয়ে <strong>Extensions &gt; Apps Script</strong>-এ এই কোডটি পেস্ট করে Deploy as Web App করলে যেকোনো অনুমোদিত সঞ্চয় অটোমেটিক নতুন সারিতে যোগ হবে।
        </p>

        <pre className="font-mono text-[11px] text-emerald-300 overflow-x-auto p-3.5 bg-slate-950 rounded-2xl border border-slate-800 leading-relaxed">
          {appsScriptSnippet}
        </pre>
      </div>
    </div>
  );
};
