import React, { useState } from 'react';
import { Bell, PlusCircle, Pin, Calendar, User, ShieldCheck, Clock, Radio, Megaphone } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { NoticeItem } from '../../types';
import { formatDateTimeBengali } from '../../utils/calculations';

export const NoticesView: React.FC = () => {
  const { notices, currentUser, addNotice } = useApp();
  const [showAddModal, setShowAddModal] = useState(false);
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [priority, setPriority] = useState<NoticeItem['priority']>('NORMAL');
  const [showInTicker, setShowInTicker] = useState<boolean>(true);

  const isModeratorOrAppMod =
    currentUser.role === 'APP_MODERATOR' || currentUser.role === 'MODERATOR';

  const handleCreateNotice = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !content.trim()) return;

    addNotice({
      title: title.trim(),
      content: content.trim(),
      priority,
      isPinned: priority === 'HIGH' || priority === 'URGENT',
      showInTicker,
    });

    setShowAddModal(false);
    setTitle('');
    setContent('');
    setShowInTicker(true);
  };

  return (
    <div className="space-y-5 pb-16">
      {/* Header */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-900 to-amber-950/20 border border-slate-800 rounded-3xl p-5 sm:p-6 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-white flex items-center gap-2.5">
            <span className="p-2 rounded-2xl bg-amber-500/20 text-amber-400 border border-amber-500/30">
              <Bell className="w-5 h-5 icon-motion" />
            </span>
            <span className="bg-gradient-to-r from-amber-300 via-white to-emerald-300 bg-clip-text text-transparent">
              অফিসিয়াল নোটিশ বোর্ড ও ঘোষণা
            </span>
          </h2>
          <p className="text-xs text-slate-400 mt-1 max-w-2xl leading-relaxed">
            বেসিস ফাউন্ডেশনের কার্যনির্বাহী পরিষদ কর্তৃক প্রকাশিত সাধারণ নোটিশ, সঞ্চয় নির্দেশনা ও জরুরি বিজ্ঞপ্তি।
          </p>
        </div>

        {isModeratorOrAppMod && (
          <button
            onClick={() => setShowAddModal(true)}
            className="py-2.5 px-5 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-500 hover:from-emerald-500 hover:to-teal-400 text-white font-black text-xs shadow-lg shadow-emerald-600/30 flex items-center gap-2 transition-all cursor-pointer shrink-0 self-start sm:self-auto"
          >
            <PlusCircle className="w-4 h-4" />
            <span>নতুন নোটিশ প্রকাশ</span>
          </button>
        )}
      </div>

      {/* Notices List */}
      <div className="space-y-4">
        {notices.map((notice) => (
          <div
            key={notice.id}
            className={`p-5 sm:p-6 rounded-3xl border transition-all duration-200 group ${
              notice.isPinned
                ? 'bg-gradient-to-br from-slate-900 via-slate-900 to-amber-950/30 border-amber-500/50 hover:border-amber-400 shadow-lg hover:shadow-amber-500/10'
                : 'bg-slate-900 border-slate-800 hover:border-emerald-500/50 hover:bg-slate-850 shadow-sm hover:shadow-emerald-500/10'
            }`}
          >
            <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3 border-b border-slate-800/80 pb-3.5">
              <div className="space-y-1.5 flex-1">
                <div className="flex flex-wrap items-center gap-2">
                  {notice.isPinned && (
                    <span className="px-2 py-0.5 rounded-lg bg-amber-500/20 text-amber-300 border border-amber-500/40 text-[10px] font-black flex items-center gap-1 shadow-sm">
                      <Pin className="w-3 h-3 text-amber-400" />
                      <span>পিনকৃত</span>
                    </span>
                  )}
                  <span
                    className={`text-[10px] font-black px-2.5 py-0.5 rounded-lg ${
                      notice.priority === 'HIGH' || notice.priority === 'URGENT'
                        ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                        : 'bg-blue-500/20 text-blue-300 border border-blue-500/30'
                    }`}
                  >
                    {notice.priority === 'HIGH' ? 'জরুরি বিজ্ঞপ্তি' : 'সাধারণ নোটিশ'}
                  </span>
                  {notice.showInTicker && (
                    <span className="px-2 py-0.5 rounded-lg bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[10px] font-black flex items-center gap-1">
                      <Megaphone className="w-3 h-3 text-emerald-400" />
                      <span>শীর্ষ ঘোষণায় প্রদর্শিত</span>
                    </span>
                  )}
                </div>

                <h3 className="font-extrabold text-white group-hover:text-amber-300 transition-colors text-base sm:text-lg">
                  {notice.title}
                </h3>
              </div>

              {/* Requirement 10: Date AND Time without seconds */}
              <div className="flex items-center gap-2 text-xs shrink-0 bg-slate-950/80 px-3 py-1.5 rounded-xl border border-slate-800">
                <Clock className="w-3.5 h-3.5 text-cyan-400" />
                <span className="text-cyan-300 font-bold">
                  {formatDateTimeBengali(notice.createdAt)}
                </span>
              </div>
            </div>

            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed pt-3.5 whitespace-pre-line group-hover:text-slate-200 transition-colors">
              {notice.content}
            </p>

            <div className="pt-3.5 mt-3.5 border-t border-slate-800/60 flex flex-wrap items-center justify-between gap-2 text-xs text-slate-400">
              <span className="flex items-center gap-2">
                <User className="w-3.5 h-3.5 text-emerald-400" />
                <span>
                  প্রকাশক:{' '}
                  <strong className="text-amber-300 font-bold">{notice.authorName}</strong>{' '}
                  <span className="text-[11px] text-slate-400 font-mono">({notice.authorRole})</span>
                </span>
              </span>
              <span className="text-[11px] text-slate-500 font-mono flex items-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                <span>ভেরিফাইড অফিসিয়াল বিজ্ঞপ্তি</span>
              </span>
            </div>
          </div>
        ))}
      </div>

      {/* Modal for adding notice */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/85 backdrop-blur-sm animate-in fade-in duration-200">
          <form
            onSubmit={handleCreateNotice}
            className="bg-slate-900 border border-slate-800 rounded-3xl max-w-lg w-full p-5 sm:p-6 space-y-4 text-xs shadow-2xl"
          >
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <div className="w-9 h-9 rounded-2xl bg-amber-500/20 text-amber-400 border border-amber-500/30 flex items-center justify-center">
                  <Bell className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-extrabold text-white">নতুন নোটিশ প্রকাশ</h3>
                  <p className="text-[11px] text-slate-400">সদস্যদের জন্য নোটিশ ও শীর্ষ ঘোষণা নির্ধারণ</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowAddModal(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            <div className="space-y-1.5">
              <label className="font-bold text-slate-200">নোটিশের শিরোনাম:</label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white font-medium focus:ring-1 focus:ring-emerald-500 focus:outline-none"
                placeholder="যেমন: চলতি মাসের সঞ্চয় জমা ও সাধারণ সভা সংক্রান্ত বিজ্ঞপ্তি..."
                required
              />
            </div>

            <div className="space-y-1.5">
              <label className="font-bold text-slate-200">গুরুত্ব (Priority):</label>
              <select
                aria-label="গুরুত্ব নির্বাচন করুন"
                value={priority}
                onChange={(e) => setPriority(e.target.value as any)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white focus:ring-1 focus:ring-emerald-500 focus:outline-none"
              >
                <option value="NORMAL">সাধারণ নোটিশ (Normal)</option>
                <option value="HIGH">জরুরি বিজ্ঞপ্তি (Urgent / Pinned)</option>
              </select>
            </div>

            {/* Point 1: Toggle scrolling announcement ticker */}
            <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800 space-y-1">
              <label className="flex items-center gap-2.5 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={showInTicker}
                  onChange={(e) => setShowInTicker(e.target.checked)}
                  className="rounded text-emerald-500 focus:ring-emerald-400 w-4 h-4 cursor-pointer"
                />
                <span className="font-bold text-slate-200 text-xs">
                  শীর্ষ ঘোষণা বারে স্ক্রলিং হিসেবে প্রদর্শন করুন (Show in Scrolling Ticker)
                </span>
              </label>
              <p className="text-[11px] text-slate-400 pl-6">
                সক্রিয় থাকলে এই নোটিশটি অ্যাপ্লিকেশনের শীর্ষ ঘোষণা বারে স্বয়ংক্রিয়ভাবে স্ক্রলিং হবে।
              </p>
            </div>

            <div className="space-y-1.5">
              <label className="font-bold text-slate-200">বিস্তারিত বিবরণ:</label>
              <textarea
                rows={4}
                value={content}
                onChange={(e) => setContent(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white font-medium focus:ring-1 focus:ring-emerald-500 focus:outline-none"
                placeholder="নোটিশের বিস্তারিত লিখুন..."
                required
              />
            </div>

            <div className="flex justify-end gap-2.5 pt-2 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setShowAddModal(false)}
                className="py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold cursor-pointer"
              >
                বাতিল
              </button>
              <button
                type="submit"
                className="py-2.5 px-5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-black shadow-lg shadow-emerald-600/30 cursor-pointer"
              >
                প্রকাশ ও সিংক করুন
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
