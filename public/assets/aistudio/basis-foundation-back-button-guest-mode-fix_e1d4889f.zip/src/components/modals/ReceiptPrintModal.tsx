import React from 'react';
import { X, Printer, Download, ShieldCheck, CheckCircle2, Award } from 'lucide-react';
import { ElectronicReceipt, AppConfiguration } from '../../types';
import { formatCurrencyBengali, toBengaliNumerals } from '../../utils/calculations';
import { generateReceiptPdf } from '../../utils/pdfGenerator';

interface ReceiptPrintModalProps {
  receipt: ElectronicReceipt | null;
  config: AppConfiguration;
  onClose: () => void;
}

export const ReceiptPrintModal: React.FC<ReceiptPrintModalProps> = ({
  receipt,
  config,
  onClose,
}) => {
  if (!receipt) return null;

  const handlePrint = () => {
    window.print();
  };

  const handleDownloadPdf = () => {
    generateReceiptPdf(receipt, config);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-slate-950/85 backdrop-blur-md overflow-y-auto animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-700 rounded-3xl max-w-2xl w-full p-4 sm:p-6 shadow-2xl space-y-4 my-auto">
        {/* Modal Controls Bar */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3 print:hidden">
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-emerald-500/20 text-emerald-400">
              <ShieldCheck className="w-5 h-5" />
            </span>
            <div>
              <h3 className="text-base font-black text-white">অফিসিয়াল ডিজিটাল রসিদ প্রিভিউ</h3>
              <p className="text-xs text-slate-400">১০০% স্পষ্ট বাংলা ফন্ট ও ভেরিফাইড নিরাপত্তা কোড</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="py-2 px-3.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs flex items-center gap-1.5 transition-colors border border-slate-700 shadow-sm"
              title="প্রিন্টার বা পিডিএফ হিসেবে প্রিন্ট করুন"
            >
              <Printer className="w-4 h-4 text-emerald-400" />
              <span className="hidden sm:inline">প্রিন্ট / সেভ পিডিএফ</span>
            </button>
            <button
              onClick={handleDownloadPdf}
              className="py-2 px-3.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center gap-1.5 transition-colors shadow-md shadow-emerald-600/30"
            >
              <Download className="w-4 h-4" />
              <span className="hidden sm:inline">সরাসরি ডাউনলোড</span>
            </button>
            <button
              onClick={onClose}
              aria-label="বন্ধ করুন"
              className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Receipt Paper Container */}
        <div
          id="printable-receipt"
          className="bg-white text-slate-900 rounded-2xl p-6 sm:p-8 border-2 border-emerald-600/40 shadow-inner relative overflow-hidden select-text font-sans"
        >
          {/* Watermark Overlay (Hosted Image or Text) */}
          {config.receiptWatermarkImageUrl ? (
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-[0.07] p-8 z-0">
              <img
                src={config.receiptWatermarkImageUrl}
                alt="Watermark"
                className="max-w-[280px] max-h-[280px] object-contain"
              />
            </div>
          ) : (
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-[0.05] z-0 rotate-[-25deg]">
              <span className="text-5xl sm:text-6xl font-black text-slate-900 tracking-widest text-center uppercase">
                {config.receiptWatermarkText || 'BASIS FOUNDATION'}
              </span>
            </div>
          )}

          <div className="relative z-10 space-y-5">
            {/* Top Official Header with Logo & Title */}
            <div className="border-b-2 border-emerald-600 pb-4 flex flex-col sm:flex-row items-center justify-between gap-4 text-center sm:text-left">
              <div className="flex items-center gap-3">
                <div className="w-14 h-14 rounded-2xl bg-slate-950 p-1 shadow shrink-0">
                  <img
                    src={config.logoUrl || '/logo.svg'}
                    alt="Logo"
                    className="w-full h-full object-contain"
                  />
                </div>
                <div>
                  <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
                    {config.foundationName}
                  </h1>
                  <p className="text-xs text-emerald-800 font-bold">{config.foundationSlogan}</p>
                  <p className="text-[11px] text-slate-500 font-semibold">
                    ডিজিটাল সমবায় সঞ্চয় ও কল্যাণ তহবিল • অফিসিয়াল রসিদ
                  </p>
                </div>
              </div>

              <div className="text-center sm:text-right space-y-1">
                <span className="inline-block px-3 py-1 rounded-full bg-emerald-100 text-emerald-900 text-xs font-black border border-emerald-300">
                  অনুমোদিত ই-রসিদ
                </span>
                <p className="text-xs font-mono font-bold text-slate-700">
                  নং: <span className="text-emerald-700">{receipt.receiptNumber}</span>
                </p>
                <p className="text-[11px] text-slate-500">
                  ইস্যু তারিখ: {new Date(receipt.generatedAt).toLocaleDateString('en-GB')}
                </p>
              </div>
            </div>

            {/* Member & Payment Information Table */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs bg-slate-50 p-4 rounded-xl border border-slate-200">
              <div className="space-y-2">
                <div className="flex items-center justify-between border-b border-slate-200 pb-1">
                  <span className="text-slate-500 font-bold">সদস্যের নাম:</span>
                  <strong className="text-emerald-700 text-sm font-black flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-emerald-500 inline-block shrink-0" />
                    <span>{receipt.memberName}</span>
                  </strong>
                </div>
                <div className="flex items-center justify-between border-b border-slate-200 pb-1">
                  <span className="text-slate-500 font-bold">সদস্য আইডি (Member ID):</span>
                  <span className="font-mono font-bold text-slate-800">{receipt.memberId}</span>
                </div>
                <div className="flex items-center justify-between border-b border-slate-200 pb-1">
                  <span className="text-slate-500 font-bold">সঞ্চয়ের মাস:</span>
                  <strong className="text-emerald-800 font-black">{receipt.savingsMonth}</strong>
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between border-b border-slate-200 pb-1">
                  <span className="text-slate-500 font-bold">পেমেন্ট মাধ্যম:</span>
                  <span className="font-bold text-slate-800">{receipt.paymentMethod}</span>
                </div>
                <div className="flex items-center justify-between border-b border-slate-200 pb-1">
                  <span className="text-slate-500 font-bold">ট্রানজেকশন রেফ:</span>
                  <span className="font-mono text-slate-700 font-semibold">{receipt.transactionRef || 'সরাসরি জমা / ক্যাশ'}</span>
                </div>
                <div className="flex items-center justify-between border-b border-slate-200 pb-1">
                  <span className="text-slate-500 font-bold">ভেরিফিকেশন স্ট্যাটাস:</span>
                  <span className="text-emerald-700 font-black flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>ভেরিফাইড ও সংরক্ষিত</span>
                  </span>
                </div>
              </div>
            </div>

            {/* Total Received Highlight Box */}
            <div className="p-4 rounded-2xl bg-gradient-to-r from-emerald-50 to-teal-50 border-2 border-emerald-500/50 flex flex-col sm:flex-row items-center justify-between gap-3 text-center sm:text-left">
              <div>
                <span className="text-xs font-bold text-emerald-900 uppercase tracking-wider block">
                  মোট গৃহীত সঞ্চয়ের পরিমাণ
                </span>
                <span className="text-xs text-slate-600 font-medium">
                  কথায়: {formatCurrencyBengali(receipt.amount)}
                </span>
              </div>
              <div className="text-2xl sm:text-3xl font-black text-emerald-700 font-mono">
                BDT {receipt.amount.toLocaleString()} /-
              </div>
            </div>

            {/* Approval Authority & Hash */}
            <div className="text-[11px] text-slate-600 space-y-1 bg-slate-100/80 p-3 rounded-xl border border-slate-200">
              <div className="flex items-center gap-1.5 font-bold text-slate-800">
                <Award className="w-4 h-4 text-emerald-600" />
                <span>অনুমোদনকারী কর্তৃপক্ষ:</span>
                <span>{receipt.approvingModeratorNames.join(', ') || 'বেসিস ফাউন্ডেশন মডারেটর প্যানেল'}</span>
              </div>
              <p className="font-mono text-[10px] text-slate-500 truncate">
                ডিজিটাল নিরাপত্তা হ্যাশ: {receipt.verificationHash}
              </p>
            </div>

            {/* Signatures */}
            <div className="pt-8 flex items-end justify-between text-xs text-slate-600">
              <div className="text-center w-36">
                <div className="h-8 flex items-end justify-center pb-1">
                  <span className="font-serif italic text-emerald-800 font-extrabold text-xs">
                    {receipt.memberName}
                  </span>
                </div>
                <div className="border-t border-slate-400 pt-1.5 font-bold">
                  জমাকারীর স্বাক্ষর
                </div>
              </div>
              <div className="text-center w-44">
                <div className="h-8 flex items-end justify-center pb-1">
                  {config.moderatorPanelSignatureImageUrl ? (
                    <img
                      src={config.moderatorPanelSignatureImageUrl}
                      alt="Authority Signature"
                      className="max-h-8 object-contain mx-auto"
                    />
                  ) : (
                    <span className="font-serif italic text-emerald-800 font-extrabold text-xs">
                      মডারেটর প্যানেল
                    </span>
                  )}
                </div>
                <div className="border-t border-slate-400 pt-1.5 font-bold">
                  কর্তৃপক্ষের স্বাক্ষর ও সিল
                </div>
              </div>
            </div>

            {/* Footer */}
            <div className="text-center text-[10px] text-slate-400 pt-3 border-t border-slate-200">
              {config.footerText} • {config.developerAttribution}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
