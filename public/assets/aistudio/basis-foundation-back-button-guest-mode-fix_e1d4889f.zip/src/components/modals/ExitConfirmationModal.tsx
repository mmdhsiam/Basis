import React from 'react';
import { AlertTriangle, LogOut, X } from 'lucide-react';

interface ExitConfirmationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirmExit: () => void;
}

export const ExitConfirmationModal: React.FC<ExitConfirmationModalProps> = ({
  isOpen,
  onClose,
  onConfirmExit,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-sm w-full p-5 shadow-2xl text-center space-y-4">
        <div className="w-12 h-12 rounded-full bg-rose-500/20 border border-rose-500/40 text-rose-400 flex items-center justify-center mx-auto">
          <AlertTriangle className="w-6 h-6" />
        </div>

        <div>
          <h3 className="text-base font-bold text-white">অ্যাপ প্রস্থান নিশ্চিতকরণ</h3>
          <p className="text-sm text-slate-300 mt-1">
            আপনি কি অ্যাপ থেকে বের হতে চান?
          </p>
        </div>

        <div className="grid grid-cols-2 gap-3 pt-2">
          {/* "বের হব না" Button */}
          <button
            onClick={onClose}
            className="w-full py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-medium text-sm transition-colors border border-slate-700"
          >
            বের হব না
          </button>

          {/* "বের হতে চাই" Button */}
          <button
            onClick={onConfirmExit}
            className="w-full py-2.5 px-4 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-sm transition-colors shadow-lg shadow-rose-600/30 flex items-center justify-center gap-1.5"
          >
            <LogOut className="w-4 h-4" />
            বের হতে চাই
          </button>
        </div>
      </div>
    </div>
  );
};
