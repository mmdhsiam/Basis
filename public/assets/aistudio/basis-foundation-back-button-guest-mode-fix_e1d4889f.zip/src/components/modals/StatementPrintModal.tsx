import React from 'react';
import { X, Printer, Download, FileSpreadsheet, ShieldCheck, CheckCircle2, Award, Building2 } from 'lucide-react';
import { UserProfile, SavingsTransaction, AppConfiguration } from '../../types';
import { formatCurrencyBengali, toBengaliNumerals } from '../../utils/calculations';
import { extractDirectImageUrl } from '../../utils/imageUtils';

interface StatementPrintModalProps {
  isOpen: boolean;
  member: UserProfile | null;
  transactions: SavingsTransaction[];
  periodLabel: string;
  config: AppConfiguration;
  onClose: () => void;
}

export const StatementPrintModal: React.FC<StatementPrintModalProps> = ({
  isOpen,
  member,
  transactions,
  periodLabel,
  config,
  onClose,
}) => {
  if (!isOpen || !member) return null;

  // Filter transactions based on period
  const filteredTxs = transactions.filter((t) => {
    if (periodLabel === 'ALL') return true;
    if (periodLabel === '2026') return t.savingsYear === 2026;
    return t.savingsMonth === periodLabel;
  }).sort((a, b) => new Date(a.transactionDate).getTime() - new Date(b.transactionDate).getTime());

  const totalDeposited = filteredTxs
    .filter((t) => t.status === 'APPROVED')
    .reduce((sum, t) => sum + t.amount, 0);

  const pendingCount = filteredTxs.filter((t) => t.status === 'PENDING').length;

  const handlePrint = () => {
    window.print();
  };

  const watermarkImg = extractDirectImageUrl(config.statementWatermarkImageUrl);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-slate-950/85 backdrop-blur-md animate-in fade-in duration-200 overflow-y-auto print:p-0 print:bg-white">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-4xl w-full max-h-[94vh] flex flex-col shadow-2xl overflow-hidden print:border-none print:shadow-none print:max-w-none print:max-h-none print:bg-white print:text-black">
        {/* Top Control Bar (Hidden during printing) */}
        <div className="p-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between print:hidden">
          <div className="flex items-center gap-2 text-white font-black text-sm">
            <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
            <span>অফিসিয়াল একাউন্ট স্টেটমেন্ট — {member.name} ({member.memberId})</span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="py-2 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs shadow-lg shadow-emerald-600/30 transition-all flex items-center gap-1.5 cursor-pointer"
            >
              <Printer className="w-4 h-4" />
              <span>প্রিন্ট ও PDF সেভ করুন</span>
            </button>
            <button
              onClick={onClose}
              className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Statement Document Content (Requirement 1: Unbreakable Unicode Bengali Typography) */}
        <div
          id="printable-statement"
          className="p-6 sm:p-8 bg-white text-slate-900 overflow-y-auto space-y-6 relative font-sans print:p-6 print:overflow-visible break-words"
          style={{
            fontFamily: "'Hind Siliguri', 'Kalpurush', 'SolaimanLipi', 'Noto Sans Bengali', system-ui, sans-serif",
            wordBreak: 'keep-all',
            overflowWrap: 'normal',
            hyphens: 'none',
            textRendering: 'optimizeLegibility',
            fontFeatureSettings: '"kern" 1, "liga" 1',
          }}
        >
          {/* Watermark Overlay */}
          {watermarkImg ? (
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-[0.05] p-12 z-0">
              <img
                src={watermarkImg}
                alt="Watermark"
                className="max-w-[400px] max-h-[400px] object-contain"
              />
            </div>
          ) : config.statementWatermarkText ? (
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-[0.04] z-0 select-none">
              <span className="text-7xl font-black text-slate-900 rotate-[-25deg] tracking-widest uppercase">
                {config.statementWatermarkText}
              </span>
            </div>
          ) : null}

          {/* Statement Header */}
          <div className="relative z-10 border-b-2 border-slate-900 pb-5">
            <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
              <div className="flex items-center gap-3.5">
                <div className="w-16 h-16 rounded-2xl bg-slate-950 p-2 flex items-center justify-center shrink-0 border border-slate-800 shadow-md">
                  <img
                    src={config.logoUrl || '/logo.svg'}
                    alt="Logo"
                    className="w-full h-full object-contain"
                  />
                </div>
                <div>
                  <h1 className="text-2xl font-black text-slate-950 tracking-tight leading-tight">
                    {config.foundationName}
                  </h1>
                  <p className="text-xs font-bold text-emerald-800 tracking-wider uppercase mt-0.5">
                    BASIS FOUNDATION • DIGITAL COOPERATIVE SYSTEM
                  </p>
                  <p className="text-xs text-slate-600 mt-0.5">
                    {config.foundationSlogan}
                  </p>
                </div>
              </div>

              <div className="text-left sm:text-right text-xs space-y-1">
                <span className="inline-block px-3 py-1 bg-slate-950 text-white font-black rounded-lg text-xs tracking-wider">
                  অফিসিয়াল একাউন্ট স্টেটমেন্ট
                </span>
                <p className="text-slate-600 font-bold">
                  তৈরির তারিখ: <strong className="text-slate-900">{new Date().toLocaleDateString('en-GB')}</strong>
                </p>
                <p className="text-slate-600 font-bold">
                  সময়কাল: <strong className="text-emerald-700 font-black">{periodLabel === 'ALL' ? 'সমগ্র সময়কাল' : periodLabel}</strong>
                </p>
              </div>
            </div>
          </div>

          {/* Member Profile & Account Summary Details */}
          <div className="relative z-10 grid grid-cols-1 sm:grid-cols-2 gap-4 bg-slate-50 border border-slate-200 rounded-2xl p-4 text-xs">
            <div className="space-y-1.5">
              <div className="flex items-center gap-2">
                <span className="text-slate-500 font-bold w-28">হিসাবধারীর নাম:</span>
                <strong className="text-emerald-700 text-base font-black flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-emerald-500 shrink-0 inline-block" />
                  <span>{member.name}</span>
                </strong>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-slate-500 font-bold w-28">সদস্য আইডি:</span>
                <strong className="font-mono text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200 font-black">
                  {member.memberId}
                </strong>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-slate-500 font-bold w-28">যোগাযোগের নম্বর:</span>
                <span className="font-mono text-slate-800 font-bold">{member.phone || 'N/A'}</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-slate-500 font-bold w-28">ইমেইল:</span>
                <span className="text-slate-700">{member.email || 'N/A'}</span>
              </div>
            </div>

            <div className="space-y-1.5">
              <div className="flex items-center gap-2">
                <span className="text-slate-500 font-bold w-28">যোগদানের তারিখ:</span>
                <span className="font-bold text-slate-800">{member.joinDate || 'N/A'}</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-slate-500 font-bold w-28">মনোনীত ব্যক্তি:</span>
                <span className="font-bold text-slate-900">{member.nomineeName || 'N/A'} ({member.nomineeRelation || 'নমিনী'})</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-slate-500 font-bold w-28">নমিনী যোগাযোগ:</span>
                <span className="font-mono text-slate-800">{member.nomineePhone || 'N/A'}</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-slate-500 font-bold w-28">মোট অনুমোদিত জমা:</span>
                <strong className="text-emerald-800 text-sm font-black">
                  {formatCurrencyBengali(totalDeposited)}
                </strong>
              </div>
            </div>
          </div>

          {/* Transactions Ledger Table */}
          <div className="relative z-10 space-y-2">
            <h3 className="font-black text-slate-900 text-sm flex items-center justify-between">
              <span>লেনদেন ও জমার বিবরণী ({toBengaliNumerals(filteredTxs.length)} টি এন্ট্রি):</span>
              <span className="text-xs text-slate-500 font-bold">সকল পরিমাণ বাংলাদেশি টাকায় (BDT)</span>
            </h3>

            <div className="border border-slate-300 rounded-xl overflow-hidden shadow-sm">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="bg-slate-900 text-white font-black">
                    <th className="py-2.5 px-3 text-center w-12">নং</th>
                    <th className="py-2.5 px-3">তারিখ</th>
                    <th className="py-2.5 px-3">সঞ্চয়ের মাস</th>
                    <th className="py-2.5 px-3">পেমেন্ট মাধ্যম</th>
                    <th className="py-2.5 px-3">রেফারেন্স / ভাউচার</th>
                    <th className="py-2.5 px-3 text-center">স্ট্যাটাস</th>
                    <th className="py-2.5 px-3 text-right">পরিমাণ (টাকা)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {filteredTxs.length === 0 ? (
                    <tr>
                      <td colSpan={7} className="py-6 text-center text-slate-500">
                        নির্বাচিত সময়কালে কোনো লেনদেনের রেকর্ড পাওয়া যায়নি।
                      </td>
                    </tr>
                  ) : (
                    filteredTxs.map((tx, idx) => (
                      <tr key={tx.id} className={idx % 2 === 0 ? 'bg-white' : 'bg-slate-50/70'}>
                        <td className="py-2 px-3 text-center font-bold text-slate-500">
                          {toBengaliNumerals(idx + 1)}
                        </td>
                        <td className="py-2 px-3 font-mono font-bold text-slate-800">
                          {new Date(tx.transactionDate).toLocaleDateString('en-GB')}
                        </td>
                        <td className="py-2 px-3 font-bold text-slate-900">
                          {tx.savingsMonth}
                        </td>
                        <td className="py-2 px-3 font-medium text-slate-700">
                          {tx.paymentMethod}
                        </td>
                        <td className="py-2 px-3 font-mono text-[11px] text-slate-600 truncate max-w-[140px]">
                          {tx.transactionRef || 'N/A'}
                        </td>
                        <td className="py-2 px-3 text-center">
                          <span className={`px-2 py-0.5 rounded-full text-[10px] font-black ${
                            tx.status === 'APPROVED'
                              ? 'bg-emerald-100 text-emerald-800'
                              : tx.status === 'PENDING'
                              ? 'bg-amber-100 text-amber-800'
                              : 'bg-rose-100 text-rose-800'
                          }`}>
                            {tx.status === 'APPROVED' ? 'অনুমোদিত' : tx.status === 'PENDING' ? 'অপেক্ষমান' : 'প্রত্যাখ্যাত'}
                          </span>
                        </td>
                        <td className="py-2 px-3 text-right font-black text-slate-900">
                          {formatCurrencyBengali(tx.amount)}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
                <tfoot>
                  <tr className="bg-slate-100 border-t-2 border-slate-300 font-black text-slate-950">
                    <td colSpan={6} className="py-3 px-3 text-right text-xs">
                      সর্বমোট অনুমোদিত জমা (Net Total Approved):
                    </td>
                    <td className="py-3 px-3 text-right text-sm text-emerald-800 font-black">
                      {formatCurrencyBengali(totalDeposited)}
                    </td>
                  </tr>
                </tfoot>
              </table>
            </div>
          </div>

          {/* Official Seals and Authorization Signatures */}
          <div className="relative z-10 pt-6 border-t border-slate-300">
            <div className="grid grid-cols-3 gap-6 text-center text-xs">
              <div className="space-y-4">
                <div className="h-10 flex items-end justify-center">
                  {config.moderatorPanelSignatureImageUrl ? (
                    <img
                      src={extractDirectImageUrl(config.moderatorPanelSignatureImageUrl)}
                      alt="Moderator Panel Signature"
                      className="max-h-10 object-contain mx-auto"
                    />
                  ) : (
                    <span className="font-serif italic text-emerald-800 font-extrabold border-b border-slate-400 pb-1 px-4 text-sm">
                      মডারেটর প্যানেল
                    </span>
                  )}
                </div>
                <div className="border-t border-slate-400 pt-1">
                  <strong className="block text-slate-900 font-black">মডারেটর প্যানেল</strong>
                  <span className="text-[10px] text-slate-500">বেসিস ফাউন্ডেশন</span>
                </div>
              </div>

              <div className="flex flex-col items-center justify-center">
                <div className="w-16 h-16 rounded-full border-2 border-dashed border-emerald-600 flex flex-col items-center justify-center text-emerald-700 text-[9px] font-black leading-tight select-none p-1">
                  <ShieldCheck className="w-5 h-5 text-emerald-600 mb-0.5" />
                  <span>ভেরিফাইড</span>
                  <span>অফিসিয়াল সিল</span>
                </div>
              </div>

              <div className="space-y-4">
                <div className="h-10 flex items-end justify-center">
                  {config.generalSecretarySignatureImageUrl ? (
                    <img
                      src={extractDirectImageUrl(config.generalSecretarySignatureImageUrl)}
                      alt="General Secretary Signature"
                      className="max-h-10 object-contain mx-auto"
                    />
                  ) : (
                    <span className="font-serif italic text-emerald-800 font-extrabold border-b border-slate-400 pb-1 px-4 text-sm">
                      সাবরিনা আক্তার
                    </span>
                  )}
                </div>
                <div className="border-t border-slate-400 pt-1">
                  <strong className="block text-slate-900 font-black">সাধারণ সম্পাদক / অডিটর</strong>
                  <span className="text-[10px] text-slate-500">বেসিস ফাউন্ডেশন</span>
                </div>
              </div>
            </div>
          </div>

          {/* Footer Note */}
          <div className="relative z-10 pt-4 text-center text-[10px] text-slate-500 border-t border-slate-200">
            <p>
              এই স্টেটমেন্টটি বেসিস ফাউন্ডেশন ডিজিটাল কোর ব্যাংকিং ও সমবায় সঞ্চয় প্ল্যাটফর্ম থেকে স্বয়ংক্রিয়ভাবে প্রস্তুতকৃত একটি বৈধ ডিজিটাল রেকর্ড।
            </p>
            <p className="mt-0.5 font-mono">
              ভেরিফিকেশন কিউআর কোড ও ডিজিটাল ট্র্যাকিং কোড: BF-STMT-{member.memberId}-{Date.now()}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
