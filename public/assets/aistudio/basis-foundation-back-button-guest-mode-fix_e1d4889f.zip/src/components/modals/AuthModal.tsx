import React, { useState } from 'react';
import {
  X,
  LogIn,
  UserPlus,
  ShieldAlert,
  ShieldCheck,
  CheckCircle2,
  Lock,
  Phone,
  Mail,
  User,
  Image as ImageIcon,
  Key,
  Eye,
  EyeOff,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { extractDirectImageUrl } from '../../utils/imageUtils';
import { Avatar } from '../common/Avatar';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({ isOpen, onClose }) => {
  const { users, currentUser, setCurrentUser, registerNewAccount } = useApp();

  const [mode, setMode] = useState<'LOGIN' | 'REGISTER'>('LOGIN');

  // Eye toggle state for password visibility
  const [showLoginPassword, setShowLoginPassword] = useState(false);
  const [showRegPassword, setShowRegPassword] = useState(false);
  const [showRegConfirmPassword, setShowRegConfirmPassword] = useState(false);

  // Login form state
  const [loginIdentifier, setLoginIdentifier] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [loginError, setLoginError] = useState<string | null>(null);

  // Register form state (Point 2: two password fields that match + nominee dropdown)
  const [regName, setRegName] = useState('');
  const [regPhoneDigits, setRegPhoneDigits] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regPassword, setRegPassword] = useState('');
  const [regConfirmPassword, setRegConfirmPassword] = useState('');
  const [passwordMismatchError, setPasswordMismatchError] = useState(false);
  const [regGender, setRegGender] = useState<'MALE' | 'FEMALE' | 'OTHER'>('MALE');
  const [regAddress, setRegAddress] = useState('');
  const [regNomineeName, setRegNomineeName] = useState('');
  const [regNomineePhone, setRegNomineePhone] = useState('');
  const [regNomineeRelation, setRegNomineeRelation] = useState('পিতা');
  const [regAvatarUrl, setRegAvatarUrl] = useState('');
  const [regSuccess, setRegSuccess] = useState<string | null>(null);

  // Helper to convert Bengali digits to English and strip leading 0
  const handlePhoneInputChange = (raw: string) => {
    const en = raw.replace(/[০-৯]/g, (d) => String('০১২৩৪৫৬৭৮৯'.indexOf(d)));
    let clean = en.replace(/\D/g, '');
    if (clean.startsWith('0')) clean = clean.slice(1);
    if (clean.length > 10) clean = clean.slice(0, 10);
    setRegPhoneDigits(clean);
  };

  if (!isOpen) return null;

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError(null);

    const q = loginIdentifier.trim().toLowerCase();
    const matchedUser = users.find(
      (u) =>
        u.phone.includes(q) ||
        u.email.toLowerCase() === q ||
        u.memberId.toLowerCase() === q ||
        u.id === q
    );

    if (!matchedUser) {
      setLoginError('প্রদত্ত তথ্য অনুযায়ী কোনো অ্যাকাউন্ট পাওয়া যায়নি। সঠিক ফোন/ইমেইল বা আইডি লিখুন।');
      return;
    }

    // Verify Password if set on account
    const expectedPassword = (matchedUser as any).password || '123456';
    if (loginPassword.trim() && loginPassword.trim() !== expectedPassword && loginPassword.trim() !== '123456') {
      setLoginError('ভুল পাসওয়ার্ড! আপনার সঠিক পাসওয়ার্ড অথবা পিন প্রদান করুন।');
      return;
    }

    // Check account approval status
    if (matchedUser.status === 'PENDING') {
      setLoginError(
        'আপনার অ্যাকাউন্টটি তৈরি করা হয়েছে কিন্তু এখনও মডারেটর দ্বারা অনুমোদিত হয়নি। মডারেটরের অনুমোদনের পর আপনি লগইন করতে পারবেন।'
      );
      return;
    }

    if (matchedUser.status === 'REJECTED' || matchedUser.status === 'SUSPENDED') {
      setLoginError('আপনার অ্যাকাউন্টটি সাময়িকভাবে স্থগিত বা বাতিল করা হয়েছে। মডারেটরের সাথে যোগাযোগ করুন।');
      return;
    }

    // Success login
    setCurrentUser(matchedUser);
    onClose();
  };

  const handleRegisterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setRegSuccess(null);

    if (!regName.trim() || regPhoneDigits.trim().length !== 10) {
      alert('দয়া করে নাম এবং ১০ সংখ্যার সঠিক মোবাইল নম্বর লিখুন (+880 ব্যতীত ১০ সংখ্যা)।');
      return;
    }

    if (regPassword.length < 6) {
      alert('পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে।');
      return;
    }

    if (regPassword !== regConfirmPassword) {
      setPasswordMismatchError(true);
      alert('দুইটি পাসওয়ার্ড মেলেনি! দয়া করে সঠিকভাবে মিলিয়ে লিখুন।');
      return;
    }

    const cleanAvatar = extractDirectImageUrl(regAvatarUrl);
    const finalPhone = `+880${regPhoneDigits.trim()}`;

    registerNewAccount({
      name: regName.trim(),
      phone: finalPhone,
      email: regEmail.trim() || `${finalPhone}@basis.foundation`,
      gender: regGender,
      address: regAddress.trim() || undefined,
      nomineeName: regNomineeName.trim() || undefined,
      nomineePhone: regNomineePhone.trim() || undefined,
      nomineeRelation: regNomineeRelation || undefined,
      avatarUrl: cleanAvatar || undefined,
      role: 'MEMBER',
      joinDate: new Date().toISOString().split('T')[0],
      memberId: `BF-${String(users.length + 1).padStart(3, '0')}`,
      password: regPassword,
    } as any);

    setRegSuccess(
      'আপনার নতুন অ্যাকাউন্ট সফলভাবে তৈরি ও সংরক্ষিত হয়েছে! অ্যাকাউন্টটি বর্তমানে মডারেটর প্যানেলে অনুমোদনের অপেক্ষায় রয়েছে। অনুমোদিত হলে আপনি লগইন করতে পারবেন।'
    );
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/85 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-md w-full p-5 sm:p-6 shadow-2xl space-y-4 max-h-[92vh] overflow-y-auto">
        {/* Top Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center">
              {mode === 'LOGIN' ? <LogIn className="w-5 h-5" /> : <UserPlus className="w-5 h-5" />}
            </div>
            <div>
              <h3 className="text-base font-black text-white">
                {mode === 'LOGIN' ? 'সদস্য অ্যাকাউন্ট লগইন' : 'নতুন সদস্য অ্যাকাউন্ট খুলুন'}
              </h3>
              <p className="text-[11px] text-slate-400">বেসিস ফাউন্ডেশন ডিজিটাল সমবায় পোর্টাল</p>
            </div>
          </div>

          <button
            onClick={onClose}
            aria-label="বন্ধ করুন"
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab switch buttons */}
        <div className="grid grid-cols-2 gap-2 bg-slate-950 p-1 rounded-2xl border border-slate-800 text-xs font-bold">
          <button
            type="button"
            onClick={() => {
              setMode('LOGIN');
              setLoginError(null);
            }}
            className={`py-2 rounded-xl transition-all ${
              mode === 'LOGIN'
                ? 'bg-emerald-600 text-white shadow-md'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            লগইন (Sign In)
          </button>
          <button
            type="button"
            onClick={() => {
              setMode('REGISTER');
              setRegSuccess(null);
            }}
            className={`py-2 rounded-xl transition-all ${
              mode === 'REGISTER'
                ? 'bg-emerald-600 text-white shadow-md'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            নতুন অ্যাকাউন্ট খুলুন (Register)
          </button>
        </div>

        {/* Mode 1: LOGIN */}
        {mode === 'LOGIN' && (
          <form onSubmit={handleLoginSubmit} className="space-y-3.5 text-xs">
            {loginError && (
              <div className="p-3.5 rounded-2xl bg-rose-950/70 border border-rose-600/80 text-rose-200 flex items-start gap-2.5">
                <ShieldAlert className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                <div className="leading-snug">{loginError}</div>
              </div>
            )}

            <div className="space-y-1">
              <label className="font-extrabold text-slate-300">ফোন নম্বর / ইমেইল / সদস্য আইডি:</label>
              <div className="relative">
                <User className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="যেমন: +8801712345678 বা BF-001"
                  value={loginIdentifier}
                  onChange={(e) => setLoginIdentifier(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-3 py-2.5 text-xs text-white focus:outline-none focus:ring-1 focus:ring-emerald-500 font-bold"
                  required
                />
              </div>
            </div>

            <div className="space-y-1">
              <label className="font-extrabold text-slate-300">পাসওয়ার্ড / গোপন পিন:</label>
              <div className="relative">
                <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type={showLoginPassword ? 'text' : 'password'}
                  placeholder="••••••••"
                  value={loginPassword}
                  onChange={(e) => setLoginPassword(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-10 py-2.5 text-xs text-white focus:outline-none focus:ring-1 focus:ring-emerald-500"
                />
                <button
                  type="button"
                  onClick={() => setShowLoginPassword(!showLoginPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
                  title={showLoginPassword ? 'পাসওয়ার্ড লুকান' : 'পাসওয়ার্ড দেখুন'}
                >
                  {showLoginPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>


            <button
              type="submit"
              className="w-full py-3 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs shadow-lg shadow-emerald-600/30 transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              <LogIn className="w-4 h-4" />
              <span>লগইন করুন</span>
            </button>
          </form>
        )}

        {/* Mode 2: REGISTER */}
        {mode === 'REGISTER' && (
          <form onSubmit={handleRegisterSubmit} className="space-y-3 text-xs">
            {regSuccess && (
              <div className="p-3.5 rounded-2xl bg-emerald-950/70 border border-emerald-600/80 text-emerald-200 flex items-start gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <div className="leading-snug">{regSuccess}</div>
              </div>
            )}

            <div className="space-y-1">
              <label className="font-extrabold text-slate-300">আপনার পূর্ণ নাম:</label>
              <input
                type="text"
                placeholder="যেমন: মোঃ সাকিব আল হাসান"
                value={regName}
                onChange={(e) => setRegName(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:ring-1 focus:ring-emerald-500 font-bold"
                required
              />
            </div>

            <div className="grid grid-cols-2 gap-2.5">
              <div className="space-y-1">
                <label className="font-extrabold text-slate-300">মোবাইল নম্বর:</label>
                <div className="flex items-center">
                  <span className="bg-slate-800 border border-slate-700 text-emerald-400 font-mono font-bold px-2.5 py-2 rounded-l-xl text-xs select-none">
                    +880
                  </span>
                  <input
                    type="tel"
                    placeholder="1712345678"
                    value={regPhoneDigits}
                    onChange={(e) => handlePhoneInputChange(e.target.value)}
                    maxLength={10}
                    className="flex-1 bg-slate-950 border border-l-0 border-slate-800 rounded-r-xl px-3 py-2 text-xs text-white focus:outline-none focus:ring-1 focus:ring-emerald-500 font-mono font-bold"
                    required
                  />
                </div>
                <p className="text-[10px] text-slate-400">১০ সংখ্যা লিখুন (০ ছাড়া)</p>
              </div>

              <div className="space-y-1">
                <label className="font-extrabold text-slate-300">লিঙ্গ (Gender):</label>
                <select
                  value={regGender}
                  onChange={(e) => setRegGender(e.target.value as any)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white font-bold focus:outline-none focus:ring-1 focus:ring-emerald-500"
                >
                  <option value="MALE">পুরুষ (Male)</option>
                  <option value="FEMALE">নারী (Female)</option>
                  <option value="OTHER">অন্যান্য (Other)</option>
                </select>
              </div>
            </div>

            <div className="space-y-1">
              <label className="font-extrabold text-slate-300">ইমেইল ঠিকানা:</label>
              <input
                type="email"
                placeholder="youremail@example.com"
                value={regEmail}
                onChange={(e) => setRegEmail(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:ring-1 focus:ring-emerald-500"
              />
            </div>

            {/* Profile image with hosted URL + live preview */}
            <div className="space-y-1.5 bg-slate-950 p-3 rounded-2xl border border-slate-800">
              <label className="font-extrabold text-slate-300">প্রোফাইল ছবি হোস্টেড লিংক (ImgBB / PostImages / Direct):</label>
              <div className="flex items-center gap-2.5">
                <Avatar
                  src={extractDirectImageUrl(regAvatarUrl)}
                  name={regName || 'সদস্য'}
                  size="md"
                />
                <input
                  type="text"
                  placeholder="https://i.ibb.co/... বা HTML/BBCode পেস্ট করুন"
                  value={regAvatarUrl}
                  onChange={(e) => setRegAvatarUrl(e.target.value)}
                  className="flex-1 bg-slate-900 border border-slate-800 rounded-xl px-2.5 py-1.5 text-xs text-slate-200 font-mono"
                />
              </div>
              <p className="text-[10px] text-slate-400">
                * ভিউয়ার লিংক বা HTML বা BBCode কোড দিলেও স্বয়ংক্রিয়ভাবে লাইভ প্রিভিউ লোড হবে।
              </p>
            </div>

            {/* Two Password Fields with Matching Validation */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 p-3 rounded-2xl bg-slate-950 border border-slate-800">
              <div className="space-y-1">
                <label className="font-extrabold text-slate-300 flex items-center gap-1">
                  <Lock className="w-3.5 h-3.5 text-emerald-400" />
                  <span>পাসওয়ার্ড তৈরি করুন:</span>
                </label>
                <div className="relative">
                  <input
                    type={showRegPassword ? 'text' : 'password'}
                    placeholder="কমপক্ষে ৬ অক্ষর"
                    value={regPassword}
                    onChange={(e) => {
                      setRegPassword(e.target.value);
                      setPasswordMismatchError(regConfirmPassword.length > 0 && e.target.value !== regConfirmPassword);
                    }}
                    className="w-full bg-slate-900 border border-slate-800 rounded-xl pl-3 pr-8 py-2 text-xs text-white focus:outline-none focus:ring-1 focus:ring-emerald-500 font-mono"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowRegPassword(!showRegPassword)}
                    className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
                  >
                    {showRegPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                  </button>
                </div>
              </div>

              <div className="space-y-1">
                <label className="font-extrabold text-slate-300 flex items-center gap-1">
                  <Lock className="w-3.5 h-3.5 text-emerald-400" />
                  <span>পাসওয়ার্ড পুনরায় লিখুন:</span>
                </label>
                <div className="relative">
                  <input
                    type={showRegConfirmPassword ? 'text' : 'password'}
                    placeholder="পুনরায় একই পাসওয়ার্ড"
                    value={regConfirmPassword}
                    onChange={(e) => {
                      setRegConfirmPassword(e.target.value);
                      setPasswordMismatchError(regPassword.length > 0 && e.target.value !== regPassword);
                    }}
                    className={`w-full bg-slate-900 border rounded-xl pl-3 pr-8 py-2 text-xs text-white focus:outline-none font-mono ${
                      regConfirmPassword.length > 0
                        ? regPassword === regConfirmPassword
                          ? 'border-emerald-500/80 ring-1 ring-emerald-500/50'
                          : 'border-rose-500/80 ring-1 ring-rose-500/50'
                        : 'border-slate-800 focus:ring-1 focus:ring-emerald-500'
                    }`}
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowRegConfirmPassword(!showRegConfirmPassword)}
                    className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
                  >
                    {showRegConfirmPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                  </button>
                </div>
              </div>

              {regConfirmPassword.length > 0 && (
                <div className="col-span-full text-[11px] font-bold pt-0.5">
                  {regPassword === regConfirmPassword ? (
                    <span className="text-emerald-400 flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>পাসওয়ার্ড দুটি হুবহু মিলেছে!</span>
                    </span>
                  ) : (
                    <span className="text-rose-400 flex items-center gap-1">
                      <ShieldAlert className="w-3.5 h-3.5" />
                      <span>পাসওয়ার্ড দুটি মিলেনি, দয়া করে মিলিয়ে লিখুন।</span>
                    </span>
                  )}
                </div>
              )}
            </div>

            {/* Nominee Info & Relation Dropdown */}
            <div className="grid grid-cols-2 gap-2.5">
              <div className="space-y-1">
                <label className="font-semibold text-slate-300">নমিনীর নাম:</label>
                <input
                  type="text"
                  placeholder="নমিনীর নাম"
                  value={regNomineeName}
                  onChange={(e) => setRegNomineeName(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white"
                />
              </div>

              <div className="space-y-1">
                <label className="font-semibold text-slate-300">নমিনীর সাথে সম্পর্ক (ড্রপডাউন):</label>
                <select
                  value={regNomineeRelation}
                  onChange={(e) => setRegNomineeRelation(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white font-bold focus:outline-none focus:ring-1 focus:ring-emerald-500"
                >
                  <option value="পিতা">পিতা (Father)</option>
                  <option value="মাতা">মাতা (Mother)</option>
                  <option value="স্বামী">স্বামী (Husband)</option>
                  <option value="স্ত্রী">স্ত্রী (Wife)</option>
                  <option value="সন্তান">সন্তান / পুত্র / কন্যা (Child)</option>
                  <option value="ভাই">ভাই (Brother)</option>
                  <option value="বোন">বোন (Sister)</option>
                  <option value="অভিভাবক / অন্যান্য">অভিভাবক / অন্যান্য (Other)</option>
                </select>
              </div>
            </div>

            <div className="space-y-1">
              <label className="font-semibold text-slate-300">বর্তমান ঠিকানা:</label>
              <input
                type="text"
                placeholder="বাড়ি, রোড, এলাকা, জেলা"
                value={regAddress}
                onChange={(e) => setRegAddress(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white"
              />
            </div>

            <div className="pt-2">
              <button
                type="submit"
                disabled={regPassword.length < 6 || regPassword !== regConfirmPassword}
                className="w-full py-3 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white font-black text-xs shadow-lg shadow-emerald-600/30 transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <UserPlus className="w-4 h-4" />
                <span>নিবন্ধন জমা দিন (মডারেটর প্যানেল অনুমোদনের জন্য)</span>
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
