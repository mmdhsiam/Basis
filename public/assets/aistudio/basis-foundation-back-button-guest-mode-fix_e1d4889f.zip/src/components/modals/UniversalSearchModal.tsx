import React, { useState, useEffect, useRef } from 'react';
import {
  Search,
  X,
  User,
  Receipt,
  ArrowRight,
  CreditCard,
  FileSpreadsheet,
  CheckCircle2,
  Calendar,
  Building2,
  TrendingDown,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { formatCurrencyBengali, toBengaliNumerals } from '../../utils/calculations';
import { Avatar } from '../common/Avatar';
import { formatUserPhone } from '../../utils/userPrivacy';

interface UniversalSearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectTab: (tab: string) => void;
}

export const UniversalSearchModal: React.FC<UniversalSearchModalProps> = ({
  isOpen,
  onClose,
  onSelectTab,
}) => {
  const {
    users,
    savings,
    receipts,
    expenses,
    currentUser,
    setActivePrintReceipt,
    setActivePrivateChatUser,
  } = useApp();

  const [query, setQuery] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      setTimeout(() => {
        inputRef.current?.focus();
      }, 100);
    } else {
      setQuery('');
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const q = query.trim().toLowerCase();

  // 1. Matched Members
  const matchedMembers = q
    ? users.filter(
        (u) =>
          u.name.toLowerCase().includes(q) ||
          u.memberId.toLowerCase().includes(q) ||
          (u.phone && u.phone.toLowerCase().includes(q))
      )
    : [];

  // 2. Matched Savings Transactions
  const matchedSavings = q
    ? savings.filter(
        (s) =>
          s.id.toLowerCase().includes(q) ||
          s.memberName.toLowerCase().includes(q) ||
          s.memberId.toLowerCase().includes(q) ||
          (s.transactionRef && s.transactionRef.toLowerCase().includes(q)) ||
          s.savingsMonth.toLowerCase().includes(q)
      )
    : [];

  // 3. Matched Receipts
  const matchedReceipts = q
    ? receipts.filter(
        (r) =>
          r.receiptNumber.toLowerCase().includes(q) ||
          r.memberName.toLowerCase().includes(q) ||
          r.memberId.toLowerCase().includes(q) ||
          (r.transactionRef && r.transactionRef.toLowerCase().includes(q))
      )
    : [];

  // 4. Matched Expenses
  const matchedExpenses = q
    ? expenses.filter(
        (e) =>
          e.title.toLowerCase().includes(q) ||
          (e.voucherRef && e.voucherRef.toLowerCase().includes(q))
      )
    : [];

  const totalResults =
    matchedMembers.length + matchedSavings.length + matchedReceipts.length + matchedExpenses.length;

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center p-3 sm:p-6 bg-slate-950/85 backdrop-blur-md animate-in fade-in duration-150 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-2xl w-full shadow-2xl overflow-hidden mt-6 sm:mt-12 flex flex-col max-h-[85vh]">
        {/* Search Header Bar */}
        <div className="p-4 bg-slate-950 border-b border-slate-800 flex items-center gap-3">
          <Search className="w-5 h-5 text-emerald-400 shrink-0" />
          <input
            ref={inputRef}
            type="text"
            placeholder="সদস্য আইডি (BF-001), নাম, রসিদ নম্বর, স্টেটমেন্ট বা ট্রানজেকশন খুঁজুন..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="flex-1 bg-transparent text-sm text-white placeholder-slate-500 focus:outline-none font-medium"
          />
          {query && (
            <button
              onClick={() => setQuery('')}
              className="p-1 rounded-lg text-slate-400 hover:text-white"
            >
              ✕
            </button>
          )}
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Results Container */}
        <div className="p-4 overflow-y-auto space-y-5 text-xs flex-1">
          {!q ? (
            <div className="p-8 text-center text-slate-400 space-y-2">
              <Search className="w-10 h-10 text-slate-600 mx-auto" />
              <p className="font-bold text-slate-300 text-sm">সার্বজনীন সার্চ কনসোল</p>
              <p className="text-xs text-slate-500 max-w-sm mx-auto">
                সদস্যের নাম, মেম্বার আইডি (যেমন: BF-001), রসিদ নম্বর, ট্রানজেকশন রেফারেন্স বা ব্যয় ভাউচার নম্বর লিখে সার্চ করুন।
              </p>
            </div>
          ) : totalResults === 0 ? (
            <div className="p-8 text-center text-slate-400 space-y-1">
              <p className="text-white font-bold text-sm">কোনো ফলাফল পাওয়া যায়নি</p>
              <p className="text-xs text-slate-500">"{query}" এর সাথে মিল রেখে কোনো রেকর্ড নেই।</p>
            </div>
          ) : (
            <>
              {/* 1. Matched Members */}
              {matchedMembers.length > 0 && (
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-slate-400 font-bold px-1">
                    <span className="flex items-center gap-1.5 text-emerald-400 font-black">
                      <User className="w-4 h-4" />
                      <span>সদস্যবৃন্দ ({toBengaliNumerals(matchedMembers.length)})</span>
                    </span>
                  </div>
                  <div className="space-y-1.5">
                    {matchedMembers.map((m) => {
                      const displayPhone = formatUserPhone(m, currentUser.role, currentUser.id);
                      return (
                        <div
                          key={m.id}
                          onClick={() => {
                            setActivePrivateChatUser(m);
                            onClose();
                          }}
                          className="p-3 rounded-2xl bg-slate-950 border border-slate-800 hover:border-emerald-500/50 flex items-center justify-between transition-all cursor-pointer group"
                        >
                          <div className="flex items-center gap-3">
                            <Avatar src={m.avatarUrl} name={m.name} size="sm" />
                            <div>
                              <div className="flex items-center gap-1.5">
                                <strong className="text-white font-black group-hover:text-emerald-400 transition-colors">
                                  {m.name}
                                </strong>
                                {m.role !== 'MEMBER' && (
                                  <CheckCircle2 className="w-3.5 h-3.5 text-blue-400 fill-blue-500 text-white" />
                                )}
                              </div>
                              <p className="text-[11px] text-slate-400 font-mono">
                                {m.memberId} • 📞 {displayPhone}
                              </p>
                            </div>
                          </div>
                          <div className="flex items-center gap-1 text-emerald-400 font-bold text-[11px]">
                            <span>বার্তা দিন</span>
                            <ArrowRight className="w-3.5 h-3.5" />
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* 2. Matched Receipts */}
              {matchedReceipts.length > 0 && (
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-slate-400 font-bold px-1">
                    <span className="flex items-center gap-1.5 text-amber-400 font-black">
                      <Receipt className="w-4 h-4" />
                      <span>ডিজিটাল রসিদসমূহ ({toBengaliNumerals(matchedReceipts.length)})</span>
                    </span>
                  </div>
                  <div className="space-y-1.5">
                    {matchedReceipts.map((r) => (
                      <div
                        key={r.receiptNumber}
                        onClick={() => {
                          setActivePrintReceipt(r);
                          onClose();
                        }}
                        className="p-3 rounded-2xl bg-slate-950 border border-slate-800 hover:border-amber-500/50 flex items-center justify-between transition-all cursor-pointer group"
                      >
                        <div className="space-y-0.5">
                          <div className="flex items-center gap-2">
                            <span className="font-mono text-amber-300 font-black bg-amber-500/10 px-2 py-0.5 rounded">
                              {r.receiptNumber}
                            </span>
                            <strong className="text-white font-bold">{r.memberName}</strong>
                            <span className="text-slate-400 font-mono">({r.memberId})</span>
                          </div>
                          <p className="text-[11px] text-slate-400">
                            মাস: {r.savingsMonth} • মাধ্যম: {r.paymentMethod} {r.transactionRef && `• রেফ: ${r.transactionRef}`}
                          </p>
                        </div>
                        <div className="text-right">
                          <span className="font-black text-emerald-400 block">
                            {formatCurrencyBengali(r.amount)}
                          </span>
                          <span className="text-[10px] text-amber-400 group-hover:underline">
                            রসিদ প্রিন্ট →
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* 3. Matched Savings Transactions */}
              {matchedSavings.length > 0 && (
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-slate-400 font-bold px-1">
                    <span className="flex items-center gap-1.5 text-blue-400 font-black">
                      <CreditCard className="w-4 h-4" />
                      <span>সঞ্চয় ও জমার এন্ট্রি ({toBengaliNumerals(matchedSavings.length)})</span>
                    </span>
                  </div>
                  <div className="space-y-1.5">
                    {matchedSavings.map((s) => (
                      <div
                        key={s.id}
                        onClick={() => {
                          onSelectTab('savings');
                          onClose();
                        }}
                        className="p-3 rounded-2xl bg-slate-950 border border-slate-800 hover:border-blue-500/50 flex items-center justify-between transition-all cursor-pointer group"
                      >
                        <div className="space-y-0.5">
                          <div className="flex items-center gap-2">
                            <span className="font-mono text-slate-400 font-bold">#{s.id.slice(-6)}</span>
                            <strong className="text-white font-bold">{s.memberName}</strong>
                            <span className="text-emerald-400 font-mono font-bold">({s.memberId})</span>
                          </div>
                          <p className="text-[11px] text-slate-400">
                            মাস: {s.savingsMonth} • তারিখ: {s.transactionDate} {s.transactionRef && `• ভাউচার: ${s.transactionRef}`}
                          </p>
                        </div>
                        <div className="text-right">
                          <span className="font-black text-emerald-400 block">
                            {formatCurrencyBengali(s.amount)}
                          </span>
                          <span className="text-[10px] text-slate-400">
                            {s.status === 'APPROVED' ? 'অনুমোদিত' : s.status === 'PENDING' ? 'অপেক্ষমান' : 'প্রত্যাখ্যাত'}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* 4. Matched Expenses */}
              {matchedExpenses.length > 0 && (
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-slate-400 font-bold px-1">
                    <span className="flex items-center gap-1.5 text-rose-400 font-black">
                      <TrendingDown className="w-4 h-4" />
                      <span>প্রাতিষ্ঠানিক ব্যয় ও খরচ ({toBengaliNumerals(matchedExpenses.length)})</span>
                    </span>
                  </div>
                  <div className="space-y-1.5">
                    {matchedExpenses.map((exp) => (
                      <div
                        key={exp.id}
                        onClick={() => {
                          onSelectTab('bank');
                          onClose();
                        }}
                        className="p-3 rounded-2xl bg-slate-950 border border-slate-800 hover:border-rose-500/50 flex items-center justify-between transition-all cursor-pointer group"
                      >
                        <div>
                          <strong className="text-white font-black">{exp.title}</strong>
                          <p className="text-[11px] text-slate-400">
                            তারিখ: {exp.expenseDate} {exp.voucherRef && `• ভাউচার: ${exp.voucherRef}`}
                          </p>
                        </div>
                        <span className="font-black text-rose-400 text-sm">
                          -{formatCurrencyBengali(exp.amount)}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
};
