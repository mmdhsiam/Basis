import React, { useState, useRef, useEffect } from 'react';
import {
  MessageSquare,
  ShieldCheck,
  Send,
  Vote,
  PhoneCall,
  User,
  Lock,
  Clock,
  CheckCircle2,
  Share2,
  AtSign,
  ShieldAlert,
  ArrowRight,
  Bell,
  Search,
  Reply,
  Smile,
  X,
  Trash2,
  Edit3,
  Check,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { toBengaliNumerals } from '../../utils/calculations';
import { Avatar } from '../common/Avatar';
import { UserProfile, ChatMessage } from '../../types';
import { MemberDetailsModal } from '../members/MemberDetailsModal';

interface ChatViewProps {
  onInitiateCall: () => void;
}

export const ChatView: React.FC<ChatViewProps> = ({ onInitiateCall }) => {
  const {
    currentUser,
    users,
    chatMessages,
    sendChatMessage,
    deleteChatMessage,
    forwardChatMessage,
    toggleMessageReaction,
    polls,
    votePoll,
    createPoll,
    deletePoll,
    updatePollOption,
    privateMessages,
    sendPrivateMessage,
    deletePrivateMessage,
    activePrivateChatUser,
    setActivePrivateChatUser,
  } = useApp();

  const [activeChannel, setActiveChannel] = useState<'GENERAL' | 'MODERATOR_ONLY' | 'PERSONAL'>('GENERAL');
  const [inputText, setInputText] = useState('');
  const [showPollCreator, setShowPollCreator] = useState(false);
  const [pollQuestion, setPollQuestion] = useState('');
  const [pollOptions, setPollOptions] = useState(['হ্যাঁ', 'না', 'মতামত বিবেচনাধীন']);
  const [editingPollOption, setEditingPollOption] = useState<{ pollId: string; optId: string; text: string } | null>(null);

  // Mention autocomplete state
  const [showMentions, setShowMentions] = useState(false);
  const [mentionFilter, setMentionFilter] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);

  // Profile modal on mention click
  const [selectedMemberForDetails, setSelectedMemberForDetails] = useState<UserProfile | null>(null);

  // Personal chat selected user
  const [selectedPersonalUser, setSelectedPersonalUser] = useState<UserProfile | null>(
    activePrivateChatUser || users.find((u) => u.id !== currentUser?.id) || null
  );

  const [personalInputText, setPersonalInputText] = useState('');
  const [personalSearch, setPersonalSearch] = useState('');

  const isModeratorOrAppMod =
    currentUser?.role === 'APP_MODERATOR' || currentUser?.role === 'MODERATOR';

  // Ensure normal members can never stay on MODERATOR_ONLY channel
  useEffect(() => {
    if (!isModeratorOrAppMod && activeChannel === 'MODERATOR_ONLY') {
      setActiveChannel('GENERAL');
    }
  }, [isModeratorOrAppMod, activeChannel]);

  // Keep selected personal user synced with context if opened from other views
  useEffect(() => {
    if (activePrivateChatUser) {
      setSelectedPersonalUser(activePrivateChatUser);
      setActiveChannel('PERSONAL');
    }
  }, [activePrivateChatUser]);

  // Filter messages by channel
  const filteredMessages = chatMessages.filter((m) => m.channel === activeChannel);
  const filteredPolls = polls.filter((p) => p.channel === activeChannel);

  // Mention candidates based on active channel
  const mentionCandidates = (
    activeChannel === 'MODERATOR_ONLY'
      ? users.filter((u) => u.role !== 'MEMBER')
      : users
  ).filter((u) => u.name.toLowerCase().includes(mentionFilter.toLowerCase()));

  // Handle typing to detect '@'
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    setInputText(val);

    const atIndex = val.lastIndexOf('@');
    if (atIndex !== -1 && atIndex === val.length - 1) {
      setShowMentions(true);
      setMentionFilter('');
    } else if (atIndex !== -1 && atIndex < val.length) {
      const query = val.slice(atIndex + 1);
      if (!query.includes(' ')) {
        setShowMentions(true);
        setMentionFilter(query);
      } else {
        setShowMentions(false);
      }
    } else {
      setShowMentions(false);
    }
  };

  // Reply to message state (Requirement 21)
  const [replyingToMessage, setReplyingToMessage] = useState<ChatMessage | null>(null);

  // Long-press emoji reaction popup state (Requirement 6)
  const [holdReactionMessageId, setHoldReactionMessageId] = useState<string | null>(null);
  const longPressTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  const handleTouchStart = (msgId: string) => {
    longPressTimeoutRef.current = setTimeout(() => {
      setHoldReactionMessageId(msgId);
    }, 450);
  };

  const handleTouchEnd = () => {
    if (longPressTimeoutRef.current) {
      clearTimeout(longPressTimeoutRef.current);
      longPressTimeoutRef.current = null;
    }
  };

  const handleSelectMention = (userName: string) => {
    const atIndex = inputText.lastIndexOf('@');
    if (atIndex !== -1) {
      const before = inputText.slice(0, atIndex);
      setInputText(`${before}@${userName} `);
    }
    setShowMentions(false);
    if (inputRef.current) inputRef.current.focus();
  };

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;

    if (activeChannel === 'MODERATOR_ONLY' && !isModeratorOrAppMod) {
      alert('শুধুমাত্র মডারেটরগণ এই চ্যানেলে মেসেজ পাঠাতে পারবেন।');
      return;
    }

    sendChatMessage(
      activeChannel as 'GENERAL' | 'MODERATOR_ONLY',
      inputText.trim(),
      undefined,
      replyingToMessage
        ? {
            id: replyingToMessage.id,
            text: replyingToMessage.text,
            senderName: replyingToMessage.senderName,
          }
        : undefined
    );
    setInputText('');
    setReplyingToMessage(null);
    setShowMentions(false);
  };

  const handleCreatePoll = (e: React.FormEvent) => {
    e.preventDefault();
    if (!pollQuestion.trim()) return;
    createPoll(activeChannel as 'GENERAL' | 'MODERATOR_ONLY', pollQuestion.trim(), pollOptions.filter((o) => o.trim()));
    setShowPollCreator(false);
    setPollQuestion('');
  };

  // Requirement 2 & 7: Parse text and render @mentions for full names (including multi-word Bengali names)
  const renderMessageContent = (text: string) => {
    // Sort users by name length descending so multi-word names match first
    const sorted = [...users].sort((a, b) => b.name.length - a.name.length);
    const escapedNames = sorted
      .map((u) => u.name.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'))
      .join('|');

    // Regex matching @FullName or fallback word
    const pattern = new RegExp(`(@(?:${escapedNames}|[^\\s.,!?]+))`, 'g');
    const parts = text.split(pattern);

    return parts.map((chunk, idx) => {
      if (chunk.startsWith('@')) {
        const rawName = chunk.slice(1).trim();
        const matched = users.find(
          (u) =>
            u.name.toLowerCase() === rawName.toLowerCase() ||
            u.memberId.toLowerCase() === rawName.toLowerCase() ||
            u.name.toLowerCase().startsWith(rawName.toLowerCase())
        );

        return (
          <span
            key={idx}
            onClick={() => {
              if (matched) {
                setSelectedMemberForDetails(matched);
              }
            }}
            title={matched ? `${matched.name} (${matched.memberId}) এর সম্পূর্ণ প্রোফাইল বিবরণ দেখুন` : 'সদস্য প্রোফাইল'}
            className="font-black text-emerald-400 bg-emerald-950/80 hover:bg-emerald-900 border border-emerald-800/70 px-1.5 py-0.5 rounded cursor-pointer underline transition-all inline-flex items-center gap-0.5 mx-0.5 shadow-sm"
          >
            {chunk}
          </span>
        );
      }
      return <span key={idx}>{chunk}</span>;
    });
  };

  // Personal Messages filter
  const conversationMessages = selectedPersonalUser && currentUser
    ? privateMessages.filter(
        (m) =>
          (m.senderId === currentUser.id && m.receiverId === selectedPersonalUser.id) ||
          (m.senderId === selectedPersonalUser.id && m.receiverId === currentUser.id)
      )
    : [];

  // Gender Policy Enforcement in Personal Chat
  const isTargetFemale = selectedPersonalUser?.gender === 'FEMALE';
  const isRegularMaleUser = currentUser?.gender === 'MALE' && currentUser?.role === 'MEMBER';
  const femaleInitiatedPrior = selectedPersonalUser && currentUser
    ? privateMessages.some(
        (m) => m.senderId === selectedPersonalUser.id && m.receiverId === currentUser.id
      )
    : false;

  const isBlockedByGenderRule = isTargetFemale && isRegularMaleUser && !femaleInitiatedPrior;

  const handleSendPersonalMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!personalInputText.trim() || !selectedPersonalUser) return;
    if (!currentUser) {
      alert('বার্তা পাঠাতে অনুগ্রহ করে লগইন করুন।');
      return;
    }

    if (isBlockedByGenderRule) {
      alert(
        'সদস্য সুরক্ষা নীতিমালার কারণে সাধারণ পুরুষ সদস্য কোনো নারী সদস্যকে প্রথম বার্তা দিতে পারবেন না।'
      );
      return;
    }

    sendPrivateMessage(selectedPersonalUser.id, personalInputText.trim());
    setPersonalInputText('');
  };

  // Recent personal chat partners
  const personalPartners = users
    .filter((u) => u.id !== currentUser?.id)
    .filter((u) =>
      personalSearch
        ? u.name.toLowerCase().includes(personalSearch.toLowerCase()) ||
          u.memberId.toLowerCase().includes(personalSearch.toLowerCase())
        : true
    );

  // Incoming unread messages for current user
  const unreadPersonalMessages = currentUser
    ? privateMessages.filter((m) => m.receiverId === currentUser.id && !m.isRead)
    : [];

  return (
    <div className="space-y-4 pb-16">
      {/* Header & Channel Switcher */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-4 sm:p-5 shadow-sm space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h2 className="text-xl font-bold text-white flex items-center gap-2">
              <MessageSquare className="w-5 h-5 text-emerald-400" />
              <span>কমিউনিটি বার্তালাপ ও ইনবক্স</span>
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              সকল সদস্যের উন্মুক্ত সাধারণ চ্যাট, মডারেটরদের অভ্যন্তরীণ চ্যানেল এবং ব্যক্তিগত ১-অন-১ সুরক্ষিত ইনবক্স।
            </p>
          </div>

          <div className="flex items-center gap-2">
            {activeChannel !== 'PERSONAL' && (
              <button
                onClick={() => setShowPollCreator(!showPollCreator)}
                className="py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold transition-colors flex items-center gap-1.5 border border-slate-700 cursor-pointer"
              >
                <Vote className="w-4 h-4 text-emerald-400" />
                <span>নতুন জরিপ</span>
              </button>
            )}
            <button
              onClick={onInitiateCall}
              className="py-2 px-3.5 rounded-xl bg-emerald-600/20 text-emerald-400 border border-emerald-500/30 hover:bg-emerald-600/30 font-semibold text-xs transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <PhoneCall className="w-4 h-4" />
              <span className="hidden sm:inline">অডিও/ভিডিও কল</span>
            </button>
          </div>
        </div>

        {/* Channel Switcher Tabs (Requirement 2 & 13) */}
        <div className="flex items-center gap-2 pt-2 border-t border-slate-800 overflow-x-auto scrollbar-none">
          <button
            onClick={() => setActiveChannel('GENERAL')}
            className={`py-2 px-4 rounded-xl text-xs font-bold transition-colors flex items-center gap-1.5 shrink-0 cursor-pointer ${
              activeChannel === 'GENERAL'
                ? 'bg-emerald-600 text-white shadow'
                : 'bg-slate-950 text-slate-300 hover:bg-slate-800'
            }`}
          >
            <MessageSquare className="w-4 h-4" />
            <span>সাধারণ সদস্য গ্রুপ চ্যাট</span>
          </button>

          {isModeratorOrAppMod && (
            <button
              onClick={() => setActiveChannel('MODERATOR_ONLY')}
              className={`py-2 px-4 rounded-xl text-xs font-bold transition-colors flex items-center gap-1.5 shrink-0 cursor-pointer ${
                activeChannel === 'MODERATOR_ONLY'
                  ? 'bg-blue-600 text-white shadow'
                  : 'bg-slate-950 text-slate-300 hover:bg-slate-800'
              }`}
            >
              <Lock className="w-3.5 h-3.5 text-amber-400" />
              <span>মডারেটর-অনলি চ্যানেল (গোপনীয়)</span>
            </button>
          )}

          {/* Requirement 2: Personal Inbox Tab inside ChatView */}
          <button
            onClick={() => setActiveChannel('PERSONAL')}
            className={`py-2 px-4 rounded-xl text-xs font-bold transition-colors flex items-center gap-1.5 shrink-0 relative cursor-pointer ${
              activeChannel === 'PERSONAL'
                ? 'bg-indigo-600 text-white shadow'
                : 'bg-slate-950 text-slate-300 hover:bg-slate-800'
            }`}
          >
            <User className="w-4 h-4 text-emerald-400" />
            <span>পার্সোনাল ইনবক্স (১-অন-১)</span>
            {unreadPersonalMessages.length > 0 && (
              <span className="w-4 h-4 rounded-full bg-rose-500 text-[10px] text-white font-black flex items-center justify-center animate-pulse">
                {toBengaliNumerals(unreadPersonalMessages.length)}
              </span>
            )}
          </button>
        </div>
      </div>

      {/* Poll Creator Box */}
      {showPollCreator && activeChannel !== 'PERSONAL' && (
        <form onSubmit={handleCreatePoll} className="bg-slate-900 border border-slate-800 p-4 rounded-2xl space-y-3 text-xs">
          <h4 className="font-bold text-white text-sm">নতুন মতামত জরিপ শুরু করুন:</h4>
          <input
            type="text"
            placeholder="জরিপের প্রশ্ন লিখুন..."
            value={pollQuestion}
            onChange={(e) => setPollQuestion(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-xs text-white"
            required
          />
          <div className="flex justify-end gap-2">
            <button
              type="button"
              onClick={() => setShowPollCreator(false)}
              className="py-1.5 px-3 rounded-lg bg-slate-800 text-slate-400"
            >
              বাতিল
            </button>
            <button
              type="submit"
              className="py-1.5 px-4 rounded-lg bg-emerald-600 text-white font-bold cursor-pointer"
            >
              জরিপ প্রকাশ করুন
            </button>
          </div>
        </form>
      )}

      {/* Main View: Group/Mod Channels OR Personal Inbox */}
      {activeChannel === 'PERSONAL' ? (
        /* Requirement 2: 1-on-1 Personal Inbox Integrated Interface */
        <div className="bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden grid grid-cols-1 md:grid-cols-3 h-[580px] shadow-sm">
          {/* Left Column: Member List for 1-on-1 Chat */}
          <div className="border-r border-slate-800 bg-slate-950/70 p-3 flex flex-col h-full overflow-hidden">
            <div className="relative mb-2">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="সদস্য সার্চ করুন..."
                value={personalSearch}
                onChange={(e) => setPersonalSearch(e.target.value)}
                className="w-full bg-slate-900 border border-slate-800 rounded-xl pl-8 pr-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none"
              />
            </div>

            <div className="flex-1 overflow-y-auto space-y-1">
              {personalPartners.map((u) => {
                const isSelected = selectedPersonalUser?.id === u.id;
                const lastMsg = privateMessages
                  .filter(
                    (m) =>
                      (m.senderId === currentUser.id && m.receiverId === u.id) ||
                      (m.senderId === u.id && m.receiverId === currentUser.id)
                  )
                  .slice(-1)[0];

                return (
                  <div
                    key={u.id}
                    onClick={() => setSelectedPersonalUser(u)}
                    className={`p-2.5 rounded-2xl flex items-center justify-between cursor-pointer transition-colors ${
                      isSelected
                        ? 'bg-indigo-600/20 border border-indigo-500/40 text-white'
                        : 'hover:bg-slate-900 text-slate-300'
                    }`}
                  >
                    <div className="flex items-center gap-2.5 truncate">
                      <Avatar src={u.avatarUrl} name={u.name} size="sm" />
                      <div className="truncate">
                        <div className="flex items-center gap-1">
                          <span className="font-bold text-xs truncate">{u.name}</span>
                          {u.role !== 'MEMBER' && (
                            <CheckCircle2 className="w-3 h-3 text-blue-400 fill-blue-500 text-white shrink-0" />
                          )}
                        </div>
                        <p className="text-[10px] text-slate-400 truncate">
                          {lastMsg ? lastMsg.text : `${u.gender === 'FEMALE' ? 'নারী' : 'পুরুষ'} • ${u.memberId}`}
                        </p>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Right 2 Columns: Selected 1-on-1 Conversation */}
          <div className="col-span-2 flex flex-col h-full bg-slate-900/50">
            {selectedPersonalUser ? (
              <>
                {/* Conversation Header */}
                <div className="p-3.5 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <Avatar
                      src={selectedPersonalUser.avatarUrl}
                      name={selectedPersonalUser.name}
                      size="sm"
                      ringColor={
                        selectedPersonalUser.role !== 'MEMBER' ? 'ring-blue-500' : 'ring-emerald-500'
                      }
                    />
                    <div>
                      <div className="flex items-center gap-1.5">
                        <h4 className="font-black text-white text-xs">{selectedPersonalUser.name}</h4>
                        {selectedPersonalUser.role !== 'MEMBER' && (
                          <span className="text-[9px] px-1.5 py-0.2 rounded bg-blue-500/20 text-blue-400 font-bold border border-blue-500/30">
                            {selectedPersonalUser.role === 'APP_MODERATOR' ? 'অ্যাডমিন' : 'মডারেটর'}
                          </span>
                        )}
                      </div>
                      <span className="text-[10px] text-slate-400 font-mono">
                        {selectedPersonalUser.memberId} • {selectedPersonalUser.gender === 'FEMALE' ? 'নারী' : 'পুরুষ'}
                      </span>
                    </div>
                  </div>

                  <button
                    onClick={() => setSelectedMemberForDetails(selectedPersonalUser)}
                    className="py-1 px-2.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-[11px] font-bold cursor-pointer"
                  >
                    প্রোফাইল দেখুন
                  </button>
                </div>

                {/* Messages Feed */}
                <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-slate-900/40">
                  {conversationMessages.length === 0 ? (
                    <div className="text-center py-16 text-slate-500 text-xs space-y-1">
                      <p className="font-bold text-slate-400">{selectedPersonalUser.name} এর সাথে কোনো পূর্ববর্তী বার্তা নেই।</p>
                      <p className="text-[11px]">নিচের বক্স থেকে বার্তা লিখে প্রেরণ করুন।</p>
                    </div>
                  ) : (
                    conversationMessages.map((msg) => {
                      const isMe = currentUser ? msg.senderId === currentUser.id : false;
                      return (
                        <div
                          key={msg.id}
                          className={`flex gap-2 ${isMe ? 'justify-end' : 'justify-start'}`}
                        >
                          <div className={`max-w-[75%] space-y-1 ${isMe ? 'items-end' : 'items-start'}`}>
                            {msg.isDeleted ? (
                              <div
                                className={`p-2.5 rounded-2xl text-xs italic ${
                                  isMe
                                    ? 'bg-slate-950/70 border border-slate-800 text-slate-400 rounded-br-none'
                                    : 'bg-slate-950/70 border border-slate-800 text-slate-400 rounded-bl-none'
                                }`}
                              >
                                <span className="flex items-center gap-1.5 text-[11px]">
                                  <Trash2 className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                                  <span>ব্যবহারকারী বার্তাটি ডিলিট করেছেন</span>
                                </span>
                              </div>
                            ) : (
                              <div
                                onContextMenu={(e) => {
                                  if (isMe) {
                                    e.preventDefault();
                                    if (confirm('আপনি কি এই বার্তাটি ডিলিট করতে চান?')) {
                                      deletePrivateMessage(msg.id);
                                    }
                                  }
                                }}
                                className={`p-3 rounded-2xl text-xs leading-relaxed ${
                                  isMe
                                    ? 'bg-indigo-600 text-white rounded-br-none shadow-sm font-medium'
                                    : 'bg-slate-800 border border-slate-700/80 text-slate-100 rounded-bl-none shadow-sm'
                                }`}
                              >
                                <p className="whitespace-pre-wrap">{msg.text}</p>
                              </div>
                            )}

                            <div className="flex items-center gap-2 text-[10px] text-slate-500 px-1">
                              <span>
                                {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                              </span>
                              {!msg.isDeleted && (
                                <button
                                  type="button"
                                  onClick={() => setPersonalInputText(`↩ "${msg.text.slice(0, 30)}${msg.text.length > 30 ? '...' : ''}" `)}
                                  title="রিপ্লাই দিন"
                                  className="hover:text-indigo-400 text-slate-400 flex items-center gap-0.5 cursor-pointer font-bold"
                                >
                                  <Reply className="w-2.5 h-2.5" />
                                  <span>রিপ্লাই</span>
                                </button>
                              )}
                              {!msg.isDeleted && isMe && (
                                <button
                                  type="button"
                                  onClick={() => {
                                    if (confirm('আপনি কি এই বার্তাটি ডিলিট করতে চান?')) {
                                      deletePrivateMessage(msg.id);
                                    }
                                  }}
                                  title="বার্তা ডিলিট করুন"
                                  className="hover:text-rose-400 text-slate-400 flex items-center gap-0.5 cursor-pointer font-bold transition-colors ml-1"
                                >
                                  <Trash2 className="w-2.5 h-2.5" />
                                  <span>ডিলিট</span>
                                </button>
                              )}
                            </div>
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>

                {/* Bottom Input with Gender Restriction */}
                <div className="p-3 bg-slate-950 border-t border-slate-800">
                  {isBlockedByGenderRule ? (
                    <div className="p-3 rounded-2xl bg-rose-950/60 border border-rose-800/80 flex items-start gap-2.5 text-xs text-rose-300">
                      <ShieldAlert className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                      <div>
                        <strong className="font-black text-rose-200 block">সদস্য সুরক্ষা নীতিমালা:</strong>
                        <p className="text-[11px] leading-relaxed mt-0.5">
                          নীতিমালা অনুযায়ী কোনো পুরুষ সদস্য কোনো নারী সদস্যকে প্রথম বার্তা পাঠাতে পারবেন না। তবে নারী সদস্য পূর্বে বার্তা পাঠিয়ে থাকলে কথোপকথন চালু রাখা যাবে।
                        </p>
                      </div>
                    </div>
                  ) : (
                    <form onSubmit={handleSendPersonalMessage} className="flex items-center gap-2">
                      <input
                        type="text"
                        placeholder={`${selectedPersonalUser.name} কে বার্তা লিখুন...`}
                        value={personalInputText}
                        onChange={(e) => setPersonalInputText(e.target.value)}
                        className="flex-1 bg-slate-900 border border-slate-800 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-indigo-500"
                      />
                      <button
                        type="submit"
                        disabled={!personalInputText.trim()}
                        className="p-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 text-white transition-all shadow-md cursor-pointer shrink-0"
                      >
                        <Send className="w-4 h-4" />
                      </button>
                    </form>
                  )}
                </div>
              </>
            ) : (
              <div className="flex-1 flex items-center justify-center p-8 text-center text-slate-500 text-xs">
                বাম পাশের তালিকা থেকে সদস্য নির্বাচন করুন
              </div>
            )}
          </div>
        </div>
      ) : (
        /* Channels: GENERAL & MODERATOR_ONLY */
        <div className="bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden flex flex-col h-[540px] shadow-sm relative">
          {/* Messages Scroll Area */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {/* Active Polls in this channel */}
            {filteredPolls.map((poll) => (
              <div
                key={poll.id}
                onContextMenu={(e) => {
                  if (isModeratorOrAppMod) {
                    e.preventDefault();
                    if (confirm('মডারেটর হিসেবে আপনি কি এই জরিপটি মুছে ফেলতে চান?')) {
                      deletePoll(poll.id);
                    }
                  }
                }}
                className="bg-slate-950 border border-slate-800 rounded-2xl p-4 space-y-3 text-xs shadow-inner relative group"
              >
                <div className="flex items-center justify-between border-b border-slate-800/80 pb-2">
                  <div className="flex items-center gap-1.5 font-black text-emerald-400">
                    <Vote className="w-4 h-4" />
                    <span>চলমান কমিউনিটি জরিপ</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] text-slate-500">শুরু করেছেন: {poll.creatorName}</span>
                    {isModeratorOrAppMod && (
                      <button
                        type="button"
                        onClick={() => {
                          if (confirm('আপনি কি এই জরিপটি মুছে ফেলতে চান?')) {
                            deletePoll(poll.id);
                          }
                        }}
                        title="জরিপটি মুছুন (মডারেটর এক্সেস)"
                        className="text-slate-500 hover:text-rose-400 p-1 rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>

                <p className="font-extrabold text-white text-sm">{poll.question}</p>

                <div className="space-y-1.5">
                  {poll.options.map((opt) => {
                    const totalVotes = poll.options.reduce((sum, o) => sum + o.votes.length, 0);
                    const percent = totalVotes > 0 ? Math.round((opt.votes.length / totalVotes) * 100) : 0;
                    const hasVotedThis = currentUser ? opt.votes.includes(currentUser.id) : false;
                    const isEditingThis =
                      editingPollOption?.pollId === poll.id && editingPollOption?.optId === opt.id;

                    if (isEditingThis) {
                      return (
                        <div key={opt.id} className="flex items-center gap-1.5 bg-slate-900 p-1.5 rounded-xl border border-emerald-500">
                          <input
                            type="text"
                            value={editingPollOption.text}
                            onChange={(e) =>
                              setEditingPollOption({ ...editingPollOption, text: e.target.value })
                            }
                            className="flex-1 bg-slate-950 border border-slate-800 rounded-lg px-2 py-1 text-xs text-white focus:outline-none"
                            autoFocus
                          />
                          <button
                            type="button"
                            onClick={() => {
                              if (editingPollOption.text.trim()) {
                                updatePollOption(poll.id, opt.id, editingPollOption.text.trim());
                              }
                              setEditingPollOption(null);
                            }}
                            className="p-1 rounded bg-emerald-600 text-white hover:bg-emerald-500 cursor-pointer"
                            title="সংরক্ষণ করুন"
                          >
                            <Check className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => setEditingPollOption(null)}
                            className="p-1 rounded bg-slate-800 text-slate-400 hover:text-white cursor-pointer"
                            title="বাতিল"
                          >
                            <X className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      );
                    }

                    return (
                      <div key={opt.id} className="flex items-center gap-1">
                        <button
                          type="button"
                          onClick={() => {
                            if (!currentUser) {
                              alert('ভোট প্রদান করতে লগইন করুন।');
                              return;
                            }
                            votePoll(poll.id, opt.id);
                          }}
                          className={`flex-1 text-left p-2.5 rounded-xl border transition-all flex items-center justify-between relative overflow-hidden cursor-pointer ${
                            hasVotedThis
                              ? 'border-emerald-500 bg-emerald-950/40 font-black text-white'
                              : 'border-slate-800 bg-slate-900/60 hover:bg-slate-800 text-slate-300'
                          }`}
                        >
                          <div
                            className="absolute left-0 top-0 bottom-0 bg-emerald-500/15 pointer-events-none transition-all duration-300"
                            style={{ width: `${percent}%` }}
                          />
                          <span className="relative z-10 flex items-center gap-2">
                            {hasVotedThis && <span className="text-emerald-400 font-black">✓</span>}
                            <span>{opt.text}</span>
                          </span>
                          <span className="relative z-10 font-mono text-[11px] font-bold text-slate-400">
                            {toBengaliNumerals(opt.votes.length)} ভোট ({toBengaliNumerals(percent)}%)
                          </span>
                        </button>

                        {isModeratorOrAppMod && (
                          <button
                            type="button"
                            onClick={() =>
                              setEditingPollOption({ pollId: poll.id, optId: opt.id, text: opt.text })
                            }
                            title="অপশন টেক্সট এডিট করুন"
                            className="p-2 rounded-xl text-slate-500 hover:text-emerald-400 hover:bg-slate-800 transition-colors shrink-0 cursor-pointer"
                          >
                            <Edit3 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            ))}

            {/* Empty State */}
            {filteredMessages.length === 0 && (
              <div className="text-center py-20 space-y-2">
                <div className="w-12 h-12 rounded-2xl bg-slate-800 text-slate-500 flex items-center justify-center mx-auto">
                  <MessageSquare className="w-6 h-6" />
                </div>
                <p className="text-xs text-slate-400">এই চ্যানেলে এখনও কোনো বার্তা নেই।</p>
                <p className="text-[11px] text-slate-500">প্রথম বার্তা বা মতামত প্রদান করুন।</p>
              </div>
            )}

            {/* Messages Feed */}
            {filteredMessages.map((msg) => {
              const isMe = currentUser ? msg.senderId === currentUser.id : false;
              const senderUser = users.find((u) => u.id === msg.senderId);
              const isSenderMod = msg.senderRole !== 'MEMBER';
              const canDelete = isMe || isModeratorOrAppMod;

              return (
                <div
                  key={msg.id}
                  className={`flex gap-2.5 ${isMe ? 'justify-end' : 'justify-start'}`}
                >
                  {!isMe && (
                    <Avatar
                      src={msg.senderAvatar || senderUser?.avatarUrl}
                      name={msg.senderName}
                      size="sm"
                      ringColor={isSenderMod ? 'ring-blue-500' : 'ring-slate-700'}
                    />
                  )}

                  <div className={`max-w-[78%] space-y-1 ${isMe ? 'items-end' : 'items-start'}`}>
                    {!isMe && (
                      <div className="flex items-center gap-1.5 text-[11px]">
                        <span className="font-bold text-slate-300">{msg.senderName}</span>
                        {isSenderMod && (
                          <span title="ভেরিফাইড মডারেটর" className="inline-flex items-center">
                            <CheckCircle2 className="w-3.5 h-3.5 text-blue-400 fill-blue-500 text-white inline-block" />
                          </span>
                        )}
                        {msg.senderRole !== 'MEMBER' && (
                          <span className="text-[9px] px-1.5 py-0.2 rounded bg-blue-500/20 text-blue-400 border border-blue-500/30 font-bold">
                            {msg.senderRole === 'APP_MODERATOR' ? 'অ্যাডমিন' : 'মডারেটর'}
                          </span>
                        )}
                      </div>
                    )}

                    {msg.isDeleted ? (
                      <div
                        className={`p-2.5 rounded-2xl text-xs italic ${
                          isMe
                            ? 'bg-slate-950/70 border border-slate-800 text-slate-400 rounded-br-none'
                            : 'bg-slate-950/70 border border-slate-800 text-slate-400 rounded-bl-none'
                        }`}
                      >
                        <span className="flex items-center gap-1.5 text-[11px]">
                          <Trash2 className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                          <span>ব্যবহারকারী বার্তাটি ডিলিট করেছেন</span>
                        </span>
                      </div>
                    ) : (
                      <div
                        onTouchStart={() => handleTouchStart(msg.id)}
                        onTouchEnd={handleTouchEnd}
                        onMouseDown={() => handleTouchStart(msg.id)}
                        onMouseUp={handleTouchEnd}
                        onContextMenu={(e) => {
                          e.preventDefault();
                          setHoldReactionMessageId(msg.id);
                        }}
                        className={`p-3 rounded-2xl text-xs leading-relaxed select-text cursor-pointer relative ${
                          isMe
                            ? 'bg-emerald-600 text-white rounded-br-none shadow-sm font-medium'
                            : 'bg-slate-800 border border-slate-700/80 text-slate-100 rounded-bl-none shadow-sm'
                        }`}
                      >
                        {msg.replyToSender && (
                          <div className="mb-2 p-2 rounded-xl bg-black/25 border-l-2 border-emerald-300 text-[10px] space-y-0.5">
                            <span className="font-bold text-emerald-300 block flex items-center gap-1">
                              <Reply className="w-2.5 h-2.5" />
                              <span>{msg.replyToSender} এর বার্তার উত্তর:</span>
                            </span>
                            <p className="line-clamp-1 italic text-slate-200">{msg.replyToText}</p>
                          </div>
                        )}

                        <p className="whitespace-pre-wrap">{renderMessageContent(msg.text)}</p>
                      </div>
                    )}

                    {/* Floating Reaction Bar when Message is Clicked & Held */}
                    {holdReactionMessageId === msg.id && !msg.isDeleted && (
                      <div className="flex items-center gap-1 p-1 rounded-2xl bg-slate-950 border border-slate-700 shadow-2xl animate-in zoom-in-95 duration-150 my-1">
                        {['👍', '❤️', '😂', '😮', '😢', '🔥', '🤲', '👏'].map((emoji) => (
                          <button
                            key={emoji}
                            type="button"
                            onClick={() => {
                              toggleMessageReaction(msg.id, emoji);
                              setHoldReactionMessageId(null);
                            }}
                            className="text-sm hover:scale-125 transition-transform p-1 cursor-pointer"
                          >
                            {emoji}
                          </button>
                        ))}
                        {canDelete && (
                          <button
                            type="button"
                            onClick={() => {
                              if (confirm('আপনি কি এই বার্তাটি ডিলিট করতে চান?')) {
                                deleteChatMessage(msg.id);
                              }
                              setHoldReactionMessageId(null);
                            }}
                            title="বার্তা ডিলিট করুন"
                            className="text-rose-400 hover:text-rose-300 px-1.5 py-0.5 text-xs flex items-center gap-1 border-l border-slate-800 cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                            <span>মুছুন</span>
                          </button>
                        )}
                        <button
                          type="button"
                          onClick={() => setHoldReactionMessageId(null)}
                          className="text-slate-400 hover:text-white text-xs px-1.5 border-l border-slate-800"
                        >
                          ✕
                        </button>
                      </div>
                    )}

                    <div className="flex items-center gap-2.5 text-[10px] text-slate-500 px-1 flex-wrap">
                      <span>{new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>

                      {!msg.isDeleted && (
                        <button
                          type="button"
                          onClick={() => {
                            setReplyingToMessage(msg);
                            if (inputRef.current) inputRef.current.focus();
                          }}
                          title="এই বার্তার রিপ্লাই দিন"
                          className="text-emerald-400 hover:text-emerald-300 flex items-center gap-0.5 font-bold cursor-pointer transition-colors"
                        >
                          <Reply className="w-3 h-3" />
                          <span>রিপ্লাই</span>
                        </button>
                      )}

                      {!msg.isDeleted && (
                        <button
                          type="button"
                          onClick={() => setHoldReactionMessageId(holdReactionMessageId === msg.id ? null : msg.id)}
                          className="hover:text-amber-300 text-slate-400 flex items-center gap-0.5 cursor-pointer transition-colors"
                          title="রিয়েক্ট সিলেক্ট করুন"
                        >
                          <Smile className="w-3 h-3" />
                        </button>
                      )}

                      {!msg.isDeleted && canDelete && (
                        <button
                          type="button"
                          onClick={() => {
                            if (confirm('আপনি কি এই বার্তাটি ডিলিট করতে চান?')) {
                              deleteChatMessage(msg.id);
                            }
                          }}
                          title="বার্তা ডিলিট করুন"
                          className="text-slate-500 hover:text-rose-400 flex items-center gap-0.5 font-bold cursor-pointer transition-colors"
                        >
                          <Trash2 className="w-3 h-3" />
                          <span>ডিলিট</span>
                        </button>
                      )}

                      {activeChannel === 'MODERATOR_ONLY' && isModeratorOrAppMod && !msg.isDeleted && (
                        <button
                          onClick={() => forwardChatMessage(msg.id)}
                          title="এই বার্তাটি সাধারণ গ্রুপ চ্যাটে ফরোয়ার্ড করুন"
                          className="text-blue-400 hover:text-blue-300 flex items-center gap-0.5 font-bold cursor-pointer transition-colors"
                        >
                          <Share2 className="w-3 h-3" />
                          <span>ফরোয়ার্ড</span>
                        </button>
                      )}

                      {/* Reactions Pill */}
                      {msg.reactions && Object.keys(msg.reactions).length > 0 && (
                        <div className="flex items-center gap-1">
                          {Object.entries(msg.reactions).map(([emoji, userIds]) => (
                            <button
                              key={emoji}
                              onClick={() => toggleMessageReaction(msg.id, emoji)}
                              className="bg-slate-800/80 hover:bg-slate-700 px-1.5 py-0.5 rounded-full text-[11px] border border-slate-700 cursor-pointer text-white"
                            >
                              {emoji} {userIds.length > 1 && toBengaliNumerals(userIds.length)}
                            </button>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Mention Suggestions Floating Dropdown (Requirement 13) */}
          {showMentions && (
            <div className="absolute bottom-16 left-4 right-4 sm:left-6 sm:w-80 bg-slate-950 border border-slate-700 rounded-2xl shadow-2xl p-2 z-30 space-y-1 max-h-48 overflow-y-auto">
              <div className="flex items-center gap-1.5 px-2 py-1 text-[11px] font-black text-emerald-400 border-b border-slate-800">
                <AtSign className="w-3.5 h-3.5" />
                <span>
                  {activeChannel === 'MODERATOR_ONLY'
                    ? 'মডারেটরদের মেনশন করুন'
                    : 'সদস্যদের মেনশন করুন'}
                </span>
              </div>
              {mentionCandidates.length === 0 ? (
                <p className="text-[11px] text-slate-500 p-2 italic">কোনো সদস্য পাওয়া যায়নি</p>
              ) : (
                mentionCandidates.map((cand) => (
                  <button
                    key={cand.id}
                    type="button"
                    onClick={() => handleSelectMention(cand.name)}
                    className="w-full text-left px-2.5 py-1.5 rounded-xl hover:bg-slate-800 flex items-center justify-between text-xs text-slate-200 transition-colors cursor-pointer"
                  >
                    <div className="flex items-center gap-2">
                      <Avatar src={cand.avatarUrl} name={cand.name} size="xs" />
                      <span className="font-bold text-white">{cand.name}</span>
                      {cand.role !== 'MEMBER' && (
                        <CheckCircle2 className="w-3 h-3 text-blue-400 fill-blue-500 text-white inline-block" />
                      )}
                    </div>
                    <span className="font-mono text-[10px] text-slate-500 font-bold">{cand.memberId}</span>
                  </button>
                ))
              )}
            </div>
          )}

          {/* Replying Banner Above Input (Requirement 21) */}
          {replyingToMessage && (
            <div className="px-3.5 py-2 bg-slate-900 border-t border-slate-800 flex items-center justify-between text-xs animate-in slide-in-from-bottom-2">
              <div className="flex items-center gap-2 truncate">
                <Reply className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                <div className="truncate">
                  <span className="font-black text-emerald-300">{replyingToMessage.senderName}</span>
                  <span className="text-slate-300 text-[11px] ml-1.5 truncate">
                    "{replyingToMessage.text.slice(0, 45)}{replyingToMessage.text.length > 45 ? '...' : ''}"
                  </span>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setReplyingToMessage(null)}
                className="p-1 hover:bg-slate-800 rounded-lg text-slate-400 hover:text-white cursor-pointer"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          )}

          {/* Message Input Bar */}
          <div className="p-3 bg-slate-950 border-t border-slate-800">
            <form onSubmit={handleSendMessage} className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => {
                  setShowMentions(true);
                  setMentionFilter('');
                  if (inputRef.current) {
                    inputRef.current.focus();
                    setInputText((prev) => `${prev}@`);
                  }
                }}
                title="@ দিয়ে সদস্য মেনশন করুন"
                className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors shrink-0 cursor-pointer"
              >
                <AtSign className="w-4 h-4 text-emerald-400" />
              </button>

              <input
                ref={inputRef}
                type="text"
                placeholder={
                  activeChannel === 'MODERATOR_ONLY'
                    ? 'মডারেটর চ্যানেলে গোপনীয় বার্তা লিখুন (@ দিয়ে মডারেটর মেনশন)...'
                    : 'সকল সদস্যের উদ্দেশ্যে বার্তা লিখুন (@ দিয়ে সদস্য মেনশন করুন)...'
                }
                value={inputText}
                onChange={handleInputChange}
                className="flex-1 bg-slate-900 border border-slate-800 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-emerald-500"
              />

              <button
                type="submit"
                disabled={!inputText.trim()}
                className="p-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 text-white font-bold transition-all shadow-md shadow-emerald-600/30 cursor-pointer shrink-0"
              >
                <Send className="w-4 h-4" />
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Member Details Modal for @mentions (Requirement 7) */}
      {selectedMemberForDetails && (
        <MemberDetailsModal
          member={selectedMemberForDetails}
          onClose={() => setSelectedMemberForDetails(null)}
          onOpenReceipt={() => {}}
        />
      )}
    </div>
  );
};
