import React, { useState, useRef, useEffect } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Header } from './components/layout/Header';
import { NavigationDrawer } from './components/layout/NavigationDrawer';
import { BottomNav } from './components/layout/BottomNav';
import { HomeDashboard } from './components/dashboard/HomeDashboard';
import { MemberList } from './components/members/MemberList';
import { SavingsView } from './components/savings/SavingsView';
import { ReceiptsView } from './components/receipts/ReceiptsView';
import { FinancialAnalyticsView } from './components/analytics/FinancialAnalyticsView';
import { ModeratorPanel } from './components/moderator/ModeratorPanel';
import { AppModeratorPanel } from './components/appmoderator/AppModeratorPanel';
import { ChatView } from './components/chat/ChatView';
import { AboutUsView } from './components/more/AboutUsView';
import { NoticesView } from './components/more/NoticesView';
import { RulesView } from './components/more/RulesView';
import { ComplaintsView } from './components/more/ComplaintsView';
import { FeatureRequestsView } from './components/more/FeatureRequestsView';
import { GoogleSheetsView } from './components/more/GoogleSheetsView';
import { SettingsView } from './components/settings/SettingsView';
import { ProfileView } from './components/profile/ProfileView';
import { BankInformationView } from './components/bank/BankInformationView';
import { ExecutiveCouncilView } from './components/more/ExecutiveCouncilView';
import { RotateCw } from 'lucide-react';

// Modals
import { ExitConfirmationModal } from './components/modals/ExitConfirmationModal';
import { CallModal } from './components/modals/CallModal';
import { AppUpdateModal } from './components/modals/AppUpdateModal';
import { NewSavingsModal } from './components/savings/NewSavingsModal';
import { NewMemberModal } from './components/members/NewMemberModal';
import { FirebaseGuideModal } from './components/modals/FirebaseGuideModal';
import { ReceiptPrintModal } from './components/modals/ReceiptPrintModal';
import { SuccessCelebrationModal } from './components/modals/SuccessCelebrationModal';
import { PrivateChatModal } from './components/chat/PrivateChatModal';
import { AuthModal } from './components/modals/AuthModal';
import { UniversalSearchModal } from './components/modals/UniversalSearchModal';

function MainAppShell() {
  const {
    unreadCount,
    isGuestMode,
    activeUpdateDialog,
    setActiveUpdateDialog,
    showExitDialog,
    setShowExitDialog,
    isOnline,
    theme,
    successMessage,
    closeSuccess,
    activePrintReceipt,
    setActivePrintReceipt,
    config,
    activePrivateChatUser,
    setActivePrivateChatUser,
    isAuthModalOpen,
    setIsAuthModalOpen,
    isSearchModalOpen,
    setIsSearchModalOpen,
    refreshAllData,
    isRefreshing,
  } = useApp();

  const [activeTab, setActiveTab] = useState<string>('home');
  const [isDrawerOpen, setIsDrawerOpen] = useState<boolean>(false);
  const [isCallModalOpen, setIsCallModalOpen] = useState<boolean>(false);
  const [isNewSavingsModalOpen, setIsNewSavingsModalOpen] = useState<boolean>(false);
  const [isNewMemberModalOpen, setIsNewMemberModalOpen] = useState<boolean>(false);
  const [isFirebaseGuideOpen, setIsFirebaseGuideOpen] = useState<boolean>(false);
  const [targetReceiptTxId, setTargetReceiptTxId] = useState<string | undefined>(undefined);

  const activeTabRef = useRef<string>('home');
  const modalStateRef = useRef({
    isSearchModalOpen, isNewSavingsModalOpen, isNewMemberModalOpen,
    isFirebaseGuideOpen, isDrawerOpen, isCallModalOpen, activePrintReceipt,
    activePrivateChatUser, isAuthModalOpen,
  });

  useEffect(() => { activeTabRef.current = activeTab; }, [activeTab]);
  useEffect(() => {
    modalStateRef.current = {
      isSearchModalOpen, isNewSavingsModalOpen, isNewMemberModalOpen,
      isFirebaseGuideOpen, isDrawerOpen, isCallModalOpen, activePrintReceipt,
      activePrivateChatUser, isAuthModalOpen,
    };
  }, [isSearchModalOpen, isNewSavingsModalOpen, isNewMemberModalOpen,
      isFirebaseGuideOpen, isDrawerOpen, isCallModalOpen, activePrintReceipt,
      activePrivateChatUser, isAuthModalOpen]);

  const handleTabChange = (newTab: string) => {
    if (newTab !== activeTabRef.current) {
      window.history.pushState({ appTab: newTab }, '', `#${newTab}`);
      activeTabRef.current = newTab;
      setActiveTab(newTab);
    }
  };

  const handleOpenReceipt = (txId: string) => {
    setTargetReceiptTxId(txId);
    handleTabChange('receipts');
  };

  const handleOpenNewSavings = () => {
    if (isGuestMode) {
      setIsAuthModalOpen(true);
      return;
    }
    setIsNewSavingsModalOpen(true);
  };

  // Android/browser back handling. Initialize history only once; do not reset
  // it every time a tab/modal changes, otherwise Android exits the WebView.
  useEffect(() => {
    if (!window.history.state?.appRoot) {
      window.history.replaceState({ appRoot: true, appTab: 'home' }, '', '#home');
      // A duplicate root entry gives Android hardware Back one safe step to
      // intercept before the WebView is closed.
      window.history.pushState({ appRoot: true, appTab: 'home' }, '', '#home');
    }

    const handlePopState = (event: PopStateEvent) => {
      const modal = modalStateRef.current;
      if (modal.isSearchModalOpen) { setIsSearchModalOpen(false); return; }
      if (modal.isNewSavingsModalOpen) { setIsNewSavingsModalOpen(false); return; }
      if (modal.isNewMemberModalOpen) { setIsNewMemberModalOpen(false); return; }
      if (modal.isFirebaseGuideOpen) { setIsFirebaseGuideOpen(false); return; }
      if (modal.isDrawerOpen) { setIsDrawerOpen(false); return; }
      if (modal.isCallModalOpen) { setIsCallModalOpen(false); return; }
      if (modal.activePrintReceipt) { setActivePrintReceipt(null); return; }
      if (modal.activePrivateChatUser) { setActivePrivateChatUser(null); return; }
      if (modal.isAuthModalOpen) { setIsAuthModalOpen(false); return; }

      const previousTab = activeTabRef.current;
      const targetTab = typeof event.state?.appTab === 'string' ? event.state.appTab : 'home';
      activeTabRef.current = targetTab;
      setActiveTab(targetTab);

      // Returning from another tab to Home is normal navigation. A second
      // Back press at Home asks for exit confirmation and restores the sentinel.
      if (targetTab === 'home' && previousTab === 'home') {
        setShowExitDialog(true);
        window.history.pushState({ appRoot: true, appTab: 'home' }, '', '#home');
      }
    };

    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, [setActivePrintReceipt, setIsAuthModalOpen, setIsCallModalOpen,
      setIsDrawerOpen, setIsFirebaseGuideOpen, setIsNewMemberModalOpen,
      setIsNewSavingsModalOpen, setIsSearchModalOpen, setShowExitDialog,
      setActivePrivateChatUser]);

  // Requirement 10: Auto-scroll input into visible viewport above keyboard when typing
  React.useEffect(() => {
    const handleFocus = (e: FocusEvent) => {
      const el = e.target as HTMLElement | null;
      if (el && (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA' || el.isContentEditable)) {
        setTimeout(() => {
          el.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }, 200);
      }
    };

    document.addEventListener('focusin', handleFocus);

    if (window.visualViewport) {
      const handleResize = () => {
        const active = document.activeElement as HTMLElement | null;
        if (active && (active.tagName === 'INPUT' || active.tagName === 'TEXTAREA')) {
          active.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
      };
      window.visualViewport.addEventListener('resize', handleResize);
      return () => {
        document.removeEventListener('focusin', handleFocus);
        window.visualViewport?.removeEventListener('resize', handleResize);
      };
    }

    return () => {
      document.removeEventListener('focusin', handleFocus);
    };
  }, []);

  // Requirement 21: Mouse Cursor Hold-and-Drag to Scroll
  useEffect(() => {
    let isDown = false;
    let startY = 0;
    let scrollTop = 0;

    const onMouseDown = (e: MouseEvent) => {
      const target = e.target as HTMLElement | null;
      if (!target) return;
      if (target.closest('button, input, textarea, select, a, [role="button"]') || target.closest('.no-drag')) {
        return;
      }
      isDown = true;
      startY = e.pageY - window.scrollY;
      scrollTop = window.scrollY;
    };

    const onMouseMove = (e: MouseEvent) => {
      if (!isDown) return;
      e.preventDefault();
      const y = e.pageY - window.scrollY;
      const walk = (y - startY) * 1.5;
      window.scrollTo({ top: scrollTop - walk, behavior: 'auto' });
    };

    const onMouseUp = () => {
      isDown = false;
    };

    window.addEventListener('mousedown', onMouseDown);
    window.addEventListener('mousemove', onMouseMove);
    window.addEventListener('mouseup', onMouseUp);

    return () => {
      window.removeEventListener('mousedown', onMouseDown);
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('mouseup', onMouseUp);
    };
  }, []);

  // Requirement 24: Pull-to-Refresh Swipe Down
  const [pullY, setPullY] = useState(0);
  const touchStartY = useRef(0);
  const isTouchingTop = useRef(false);

  const handleTouchStart = (e: React.TouchEvent) => {
    if (window.scrollY <= 5) {
      touchStartY.current = e.touches[0].clientY;
      isTouchingTop.current = true;
    } else {
      isTouchingTop.current = false;
    }
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (!isTouchingTop.current || window.scrollY > 5) return;
    const currentY = e.touches[0].clientY;
    const diff = currentY - touchStartY.current;
    if (diff > 0) {
      setPullY(Math.min(diff * 0.45, 80));
    }
  };

  const handleTouchEnd = async () => {
    if (pullY > 45) {
      setPullY(55);
      await refreshAllData();
    }
    setPullY(0);
    isTouchingTop.current = false;
  };

  const handleConfirmExit = () => {
    setShowExitDialog(false);
    alert('অ্যাপ্লিকেশন সেশন সমাপ্ত হয়েছে। আবার দেখা হবে!');
  };


  return (
    <div
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
      className={`min-h-screen flex flex-col transition-colors duration-200 selection:bg-emerald-500 selection:text-white cursor-default select-none ${
        theme === 'dark' ? 'bg-slate-950 text-slate-100' : 'bg-slate-100 text-slate-900'
      }`}
    >
      {/* Pull-to-Refresh Indicator & Real-time Cloud Sync Feedback */}
      {(pullY > 0 || isRefreshing) && (
        <div
          style={{ transform: `translateY(${Math.max(pullY, isRefreshing ? 48 : 0)}px)` }}
          className="fixed top-2 left-1/2 -translate-x-1/2 z-50 flex items-center gap-2 px-4 py-2 rounded-full bg-slate-900/95 border border-emerald-500/80 shadow-2xl text-xs font-bold text-white transition-all backdrop-blur-md"
        >
          <RotateCw className={`w-4 h-4 text-emerald-400 ${(pullY > 45 || isRefreshing) ? 'animate-spin' : ''}`} />
          <span>{isRefreshing ? 'তথ্য সিঙ্ক ও আপডেট হচ্ছে...' : pullY > 45 ? 'ছেড়ে দিন এবং সিঙ্ক করুন' : 'টেনে রিফ্রেশ করুন'}</span>
        </div>
      )}

      {/* Offline Alert Banner */}
      {!isOnline && (
        <div className="bg-rose-600 text-white text-xs py-2 px-4 text-center font-black sticky top-0 z-50 shadow-md flex items-center justify-center gap-2">
          <span>ইন্টারনেট সংযোগ চালু করে আবার চেষ্টা করুন। (সার্ভারের সাথে সংযোগ বিচ্ছিন্ন)</span>
        </div>
      )}

      {/* Main Top Header */}
      <Header
        onOpenDrawer={() => setIsDrawerOpen(true)}
        activeTab={activeTab}
        setActiveTab={handleTabChange}
        onInitiateCall={() => setIsCallModalOpen(true)}
      />

      {/* Navigation Drawer */}
      <NavigationDrawer
        isOpen={isDrawerOpen}
        onClose={() => setIsDrawerOpen(false)}
        activeTab={activeTab}
        setActiveTab={handleTabChange}
        onShowExitDialog={() => setShowExitDialog(true)}
        onOpenFirebaseGuide={() => setIsFirebaseGuideOpen(true)}
      />

      {/* Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-3 sm:p-5">
        {activeTab === 'home' && (
          <HomeDashboard
            setActiveTab={handleTabChange}
            onOpenNewSavingsModal={handleOpenNewSavings}
          />
        )}

        {activeTab === 'about-us' && (
          <AboutUsView onOpenFirebaseGuide={() => setIsFirebaseGuideOpen(true)} />
        )}

        {activeTab === 'members' && (
          <MemberList
            onOpenReceipt={handleOpenReceipt}
            onOpenNewMemberModal={() => setIsNewMemberModalOpen(true)}
          />
        )}

        {activeTab === 'savings' && (
          <SavingsView
            onOpenNewSavingsModal={handleOpenNewSavings}
            onOpenReceipt={handleOpenReceipt}
          />
        )}

        {activeTab === 'receipts' && (
          <ReceiptsView selectedReceiptTxId={targetReceiptTxId} />
        )}

        {activeTab === 'analytics' && <FinancialAnalyticsView />}

        {activeTab === 'moderator' && (
          <ModeratorPanel
            onOpenReceipt={handleOpenReceipt}
            setActiveTab={setActiveTab}
          />
        )}

        {activeTab === 'app-moderator' && <AppModeratorPanel />}

        {activeTab === 'chat' && (
          <ChatView onInitiateCall={() => setIsCallModalOpen(true)} />
        )}

        {activeTab === 'notices' && <NoticesView />}

        {activeTab === 'executive' && <ExecutiveCouncilView />}

        {activeTab === 'rules' && <RulesView />}

        {activeTab === 'complaints' && <ComplaintsView />}

        {activeTab === 'features' && <FeatureRequestsView />}

        {activeTab === 'sheets' && <GoogleSheetsView />}

        {activeTab === 'profile' && (
          <ProfileView onOpenReceipt={handleOpenReceipt} />
        )}

        {activeTab === 'bank' && <BankInformationView />}

        {activeTab === 'settings' && (
          <SettingsView
            onShowExitDialog={() => setShowExitDialog(true)}
            onOpenFirebaseGuide={() => setIsFirebaseGuideOpen(true)}
          />
        )}
      </main>

      {/* Bottom Navigation for Mobile */}
      <BottomNav
        activeTab={activeTab}
        setActiveTab={handleTabChange}
        onOpenDrawer={() => setIsDrawerOpen(true)}
        unreadCount={unreadCount}
      />

      {/* Requirement 3: Universal Search Modal */}
      <UniversalSearchModal
        isOpen={isSearchModalOpen}
        onClose={() => setIsSearchModalOpen(false)}
        onSelectTab={handleTabChange}
      />

      {/* Exit Confirmation Modal */}
      <ExitConfirmationModal
        isOpen={showExitDialog}
        onClose={() => setShowExitDialog(false)}
        onConfirmExit={handleConfirmExit}
      />

      {/* Real-Time Call Modal */}
      <CallModal
        isOpen={isCallModalOpen}
        onClose={() => setIsCallModalOpen(false)}
      />

      {/* App Release Update Modal */}
      <AppUpdateModal
        release={activeUpdateDialog}
        onClose={() => setActiveUpdateDialog(null)}
      />

      {/* New Savings Entry Modal */}
      <NewSavingsModal
        isOpen={isNewSavingsModalOpen}
        onClose={() => setIsNewSavingsModalOpen(false)}
      />

      {/* New Member Registration Modal */}
      <NewMemberModal
        isOpen={isNewMemberModalOpen}
        onClose={() => setIsNewMemberModalOpen(false)}
      />

      {/* Firebase Setup & Login Guide Modal */}
      <FirebaseGuideModal
        isOpen={isFirebaseGuideOpen}
        onClose={() => setIsFirebaseGuideOpen(false)}
      />

      {/* Requirement 1: Unbreakable High-Res Receipt Print & Preview Modal */}
      <ReceiptPrintModal
        receipt={activePrintReceipt}
        config={config}
        onClose={() => setActivePrintReceipt(null)}
      />

      {/* Requirement 9: Success Celebration Micro-Animation Modal */}
      <SuccessCelebrationModal
        message={successMessage}
        onClose={closeSuccess}
      />

      {/* Requirement 16: 1-on-1 Private Direct Messaging Modal with Gender Policy */}
      <PrivateChatModal
        isOpen={!!activePrivateChatUser}
        targetUser={activePrivateChatUser}
        onClose={() => setActivePrivateChatUser(null)}
      />

      {/* Requirement 17: User Login & Account Registration Modal with Moderator Approval Flow */}
      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
      />
    </div>
  );
}

export default function App() {
  return (
    <AppProvider>
      <MainAppShell />
    </AppProvider>
  );
}
