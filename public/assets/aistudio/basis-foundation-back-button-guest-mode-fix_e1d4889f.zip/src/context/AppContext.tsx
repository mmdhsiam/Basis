import React, { createContext, useContext, useState, useEffect, useMemo, ReactNode } from 'react';
import {
  UserProfile,
  SavingsTransaction,
  ApprovalRequest,
  ElectronicReceipt,
  NoticeItem,
  ComplaintItem,
  FeatureRequestItem,
  FoundationRule,
  ChatMessage,
  ChatPoll,
  AuditLogItem,
  AppConfiguration,
  AppRelease,
  UserRole,
  PrivateMessage,
  FoundationExpense,
  ExecutiveMember,
  UserNotification,
} from '../types';
import {
  INITIAL_CONFIG,
  INITIAL_USERS,
  INITIAL_SAVINGS,
  INITIAL_APPROVALS,
  INITIAL_NOTICES,
  INITIAL_RULES,
  INITIAL_COMPLAINTS,
  INITIAL_FEATURE_REQUESTS,
  INITIAL_CHAT_MESSAGES,
  INITIAL_POLLS,
  INITIAL_RELEASES,
  INITIAL_AUDIT_LOGS,
  INITIAL_EXPENSES,
} from '../data/initialData';
import {
  evaluateApprovalState,
  calculateFinancialTotals,
  calculateGrowthRate,
  generateReceiptNumber,
  aggregateSavingsByMonth,
  formatDateTimeBengali,
  formatCurrencyBengali,
} from '../utils/calculations';
import {
  initRealtimeSync,
  syncConfigToFirestore,
  syncNoticeToFirestore,
  deleteNoticeFromFirestore,
  syncRuleToFirestore,
  deleteRuleFromFirestore,
  syncExecutiveMemberToFirestore,
  deleteExecutiveMemberFromFirestore,
  syncSavingsTransactionToFirestore,
  syncApprovalToFirestore,
  syncUserToFirestore,
  syncChatMessageToFirestore,
  SyncStatus,
} from '../utils/firebaseSync';


// Read-only-style guest identity used only to render the ordinary MEMBER view
// before login or after logout. It is never persisted as a real user account.
const GUEST_USER: UserProfile = {
  id: '__guest__',
  memberId: 'GUEST',
  name: 'অতিথি দর্শক',
  email: '',
  phone: '',
  role: 'MEMBER',
  status: 'APPROVED',
  joinDate: new Date().toISOString().slice(0, 10),
  gender: 'OTHER',
};


interface AppContextType {
  // Theme & System
  theme: 'dark' | 'light';
  setTheme: (t: 'dark' | 'light') => void;
  isOnline: boolean;
  setIsOnline: (online: boolean) => void;
  isDemoMode: boolean;
  setIsDemoMode: (demo: boolean) => void;
  showExitDialog: boolean;
  setShowExitDialog: (show: boolean) => void;
  soundEnabled: boolean;
  setSoundEnabled: (enabled: boolean) => void;
  hapticEnabled: boolean;
  setHapticEnabled: (enabled: boolean) => void;

  // Success Celebration Animation (Requirement 9)
  successMessage: string | null;
  triggerSuccess: (message: string) => void;
  closeSuccess: () => void;

  // Active User & Authentication (Requirement 17)
  currentUser: UserProfile | null;
  isGuestMode: boolean;
  setCurrentUser: (user: UserProfile | null) => void;
  logoutUser: () => void;
  maskPhoneForPrivacy: (phone: string, targetGender?: 'MALE' | 'FEMALE' | 'OTHER') => string;
  switchUserRole: (userId: string) => void;
  users: UserProfile[];
  updateUserProfile: (userId: string, partial: Partial<UserProfile>) => void;
  requestProfileChange: (userId: string, proposedChanges: { field: string; oldValue: any; newValue: any }[]) => void;
  registerNewAccount: (userData: Partial<UserProfile>) => void;
  approveUserAccount: (userId: string) => void;
  rejectUserAccount: (userId: string) => void;
  updateUserDesignation: (userId: string, moderatorTitle: string, role?: UserRole) => void;
  removeUser: (userId: string) => void;
  isAuthModalOpen: boolean;
  setIsAuthModalOpen: (open: boolean) => void;

  // Reminders for Overdue (Requirement 6)
  overdueReminders: string[];
  sendOverdueReminder: (memberId: string) => void;

  // Direct 1-on-1 Private Messaging (Requirement 16)
  privateMessages: PrivateMessage[];
  sendPrivateMessage: (receiverId: string, text: string) => void;
  deletePrivateMessage: (messageId: string) => void;
  activePrivateChatUser: UserProfile | null;
  setActivePrivateChatUser: (user: UserProfile | null) => void;

  // Financial & Savings
  savings: SavingsTransaction[];
  createSavingsEntry: (data: {
    memberId: string;
    amount: number;
    savingsMonth: string;
    savingsYear: number;
    paymentMethod: any;
    transactionRef?: string;
    notes?: string;
  }) => void;
  reverseTransaction: (txId: string, reason: string) => void;

  // Approvals & Workflows
  approvals: ApprovalRequest[];
  voteOnApproval: (approvalId: string, vote: 'APPROVE' | 'REJECT', reason?: string) => void;

  // Receipts & Print Modal (Requirement 1)
  receipts: ElectronicReceipt[];
  getReceiptForTransaction: (txId: string) => ElectronicReceipt | undefined;
  activePrintReceipt: ElectronicReceipt | null;
  setActivePrintReceipt: (receipt: ElectronicReceipt | null) => void;

  // Communication & Chat (Requirement 4, 5, 13 & 21)
  chatMessages: ChatMessage[];
  sendChatMessage: (
    channel: 'GENERAL' | 'MODERATOR_ONLY',
    text: string,
    imageUrl?: string,
    replyTo?: { id: string; text: string; senderName: string }
  ) => void;
  deleteChatMessage: (messageId: string) => void;
  forwardChatMessage: (messageId: string) => void;
  toggleMessageReaction: (messageId: string, emoji: string) => void;
  polls: ChatPoll[];
  votePoll: (pollId: string, optionId: string) => void;
  createPoll: (channel: 'GENERAL' | 'MODERATOR_ONLY', question: string, options: string[]) => void;
  deletePoll: (pollId: string) => void;
  updatePollOption: (pollId: string, optionId: string, text: string) => void;
  updatePollQuestion: (pollId: string, question: string) => void;
  chatUnreadCount: number;
  markChatSeen: () => void;
  hasUnreadNotices: boolean;
  markNoticesSeen: () => void;

  // Calling Feature (Requirement 4)
  activeCall: {
    callId: string;
    callerId: string;
    callerName: string;
    targetName?: string;
    channel: string;
    startedAt: string;
    status: 'RINGING' | 'CONNECTED' | 'ENDED';
  } | null;
  startCall: (channel?: 'GENERAL' | 'MODERATOR_ONLY' | 'PERSONAL', targetName?: string) => void;
  endCall: (durationSec?: number) => void;

  // Executive Committee (Requirement 20)
  executiveMembers: ExecutiveMember[];
  addExecutiveMember: (member: Omit<ExecutiveMember, 'id'>) => void;
  removeExecutiveMember: (id: string) => void;
  updateExecutiveMember: (id: string, partial: Partial<ExecutiveMember>) => void;

  // Online Tracking (Requirement 7)
  onlineUserIds: string[];

  // Notices, Complaints, Rules, Features
  notices: NoticeItem[];
  addNotice: (notice: Omit<NoticeItem, 'id' | 'createdAt' | 'authorName' | 'authorRole'>) => void;
  updateNotice: (noticeId: string, partial: Partial<NoticeItem>) => void;
  deleteNotice: (noticeId: string) => void;
  complaints: ComplaintItem[];
  submitComplaint: (title: string, description: string) => void;
  updateComplaintStatus: (id: string, status: ComplaintItem['status'], moderatorNotes?: string) => void;
  featureRequests: FeatureRequestItem[];
  submitFeatureRequest: (title: string, description: string) => void;
  voteFeatureRequest: (id: string) => void;
  rules: FoundationRule[];
  updateRule: (ruleId: string, title: string, description: string) => void;

  // App Moderator & Configuration (Requirement 10)
  config: AppConfiguration;
  updateConfig: (newConfig: Partial<AppConfiguration>) => void;
  auditLogs: AuditLogItem[];
  releases: AppRelease[];
  publishAppRelease: (release: Omit<AppRelease, 'id'>) => void;
  activeUpdateDialog: AppRelease | null;
  setActiveUpdateDialog: (rel: AppRelease | null) => void;

  // Auto-Refresh & Pull-to-Refresh (Requirement 15)
  refreshAllData: () => Promise<void>;
  isRefreshing: boolean;

  // Backup & Restore
  exportBackupData: () => string;
  restoreFromBackup: (jsonData: string) => { success: boolean; message: string };
  resetToInitialDemo: () => void;

  // Requirement 11: Foundation Expenses & Actual Balance
  expenses: FoundationExpense[];
  addExpense: (expense: Omit<FoundationExpense, 'id'>) => void;
  removeExpense: (id: string) => void;
  totalExpenses: number;
  netReserveBalance: number;

  // Requirement 20: Universal Search Modal
  isSearchModalOpen: boolean;
  setIsSearchModalOpen: (open: boolean) => void;

  // Real-time Cloud Synchronization (Firebase Firestore)
  cloudSyncStatus: SyncStatus;
  lastSyncTimestamp: string;
  triggerCloudSync: () => Promise<void>;

  // User Targeted Notifications & System Push (Points 9 & 15)
  userNotifications: UserNotification[];
  sendUserNotification: (
    targetUserId: string,
    title: string,
    message: string,
    type: UserNotification['type'],
    color: UserNotification['color']
  ) => void;
  markNotificationRead: (id: string) => void;
  markAllNotificationsRead: () => void;

  // Pending Deposit duplicate submission prevention (Point 3)
  pendingDepositModalOpen: boolean;
  setPendingDepositModalOpen: (open: boolean) => void;
  checkUserHasPendingDeposit: (memberId: string) => boolean;

  // Aggregated summaries
  financialTotals: ReturnType<typeof calculateFinancialTotals>;
  growthRate: ReturnType<typeof calculateGrowthRate>;
  monthlyAggregates: Record<string, number>;
  eligibleModeratorsCount: number;
  unreadCount: number;
  uniqueDailyVisitors: number;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const STORAGE_KEY = 'basis_foundation_storage_v1';

const getInitialSaved = () => {
  if (typeof window === 'undefined') return null;
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) return JSON.parse(raw);
  } catch (e) {
    console.error('Failed to parse stored data', e);
  }
  return null;
};

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const initialSaved = getInitialSaved();

  // Theme state
  const [theme, setTheme] = useState<'dark' | 'light'>('dark');
  const [isOnline, setIsOnline] = useState<boolean>(true);
  const [isDemoMode, setIsDemoMode] = useState<boolean>(true);
  const [showExitDialog, setShowExitDialog] = useState<boolean>(false);
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);
  const [hapticEnabled, setHapticEnabled] = useState<boolean>(true);

  // Entities state with LocalStorage auto-restoration (Requirement 11 & 12)
  const [config, setConfig] = useState<AppConfiguration>(() => initialSaved?.config || INITIAL_CONFIG);
  const [users, setUsers] = useState<UserProfile[]>(() => initialSaved?.users || INITIAL_USERS);
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(() => {
    if (initialSaved?.currentUserId && initialSaved?.users) {
      const found = initialSaved.users.find((u: any) => u.id === initialSaved.currentUserId);
      if (found) return found;
    }
    return GUEST_USER; // Clean install opens in guest/member-view mode
  });
  const isGuestMode = !currentUser || currentUser.id === '__guest__';

  const logoutUser = () => {
    setCurrentUser(GUEST_USER);
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        delete parsed.currentUserId;
        localStorage.setItem(STORAGE_KEY, JSON.stringify(parsed));
      }
    } catch {}
    triggerSuccess('সফলভাবে লগআউট সম্পন্ন হয়েছে!');
  };

  const maskPhoneForPrivacy = (phone: string, targetGender?: 'MALE' | 'FEMALE' | 'OTHER') => {
    if (!phone) return '';
    const isPrivileged = currentUser?.role === 'APP_MODERATOR' || currentUser?.role === 'MODERATOR';
    if (targetGender === 'FEMALE' && !isPrivileged) {
      const clean = phone.replace(/\s+/g, '');
      const prefix = clean.slice(0, 5);
      return `${prefix}**-****** (গোপনীয়)`;
    }
    return phone;
  };
  const [savings, setSavings] = useState<SavingsTransaction[]>(() => initialSaved?.savings || INITIAL_SAVINGS);
  const [approvals, setApprovals] = useState<ApprovalRequest[]>(() => initialSaved?.approvals || INITIAL_APPROVALS);
  const [receipts, setReceipts] = useState<ElectronicReceipt[]>(() => initialSaved?.receipts || []);
  const [notices, setNotices] = useState<NoticeItem[]>(() => initialSaved?.notices || INITIAL_NOTICES);
  const [rules, setRules] = useState<FoundationRule[]>(() => initialSaved?.rules || INITIAL_RULES);
  const [complaints, setComplaints] = useState<ComplaintItem[]>(() => initialSaved?.complaints || INITIAL_COMPLAINTS);
  const [featureRequests, setFeatureRequests] = useState<FeatureRequestItem[]>(() => initialSaved?.featureRequests || INITIAL_FEATURE_REQUESTS);
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>(() => initialSaved?.chatMessages || INITIAL_CHAT_MESSAGES);
  const [polls, setPolls] = useState<ChatPoll[]>(() => initialSaved?.polls || []);
  const [releases, setReleases] = useState<AppRelease[]>(() => initialSaved?.releases || INITIAL_RELEASES);
  const [auditLogs, setAuditLogs] = useState<AuditLogItem[]>(() => initialSaved?.auditLogs || INITIAL_AUDIT_LOGS);
  const [activeUpdateDialog, setActiveUpdateDialog] = useState<AppRelease | null>(null);
  const [uniqueDailyVisitors] = useState<number>(342);

  // Success celebration animation state
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  // Authentication & Registration state
  const [isAuthModalOpen, setIsAuthModalOpen] = useState<boolean>(false);

  // Overdue reminders state
  const [overdueReminders, setOverdueReminders] = useState<string[]>(['BF-004']);

  // Read status indicators for badges (Requirement 7: clear badge once seen)
  const [chatUnreadCount, setChatUnreadCount] = useState<number>(2);
  const [hasUnreadNotices, setHasUnreadNotices] = useState<boolean>(true);

  const markChatSeen = () => setChatUnreadCount(0);
  const markNoticesSeen = () => setHasUnreadNotices(false);

  // 1-on-1 Private Messaging state
  const [privateMessages, setPrivateMessages] = useState<PrivateMessage[]>(() => initialSaved?.privateMessages || [
    {
      id: 'pm-1',
      conversationId: 'user-mod-2_user-mod-3',
      senderId: 'user-mod-3',
      senderName: 'সাবরিনা আক্তার',
      receiverId: 'user-mod-2',
      receiverName: 'তানভীর আহমেদ',
      text: 'আসসালামু আলাইকুম তানভীর ভাই, চলতি মাসের সঞ্চয় অডিট রিপোর্ট কি প্রস্তুত হয়েছে?',
      timestamp: new Date(Date.now() - 7200000).toISOString(),
      isRead: true,
    },
    {
      id: 'pm-2',
      conversationId: 'user-mod-2_user-mod-3',
      senderId: 'user-mod-2',
      senderName: 'তানভীর আহমেদ',
      receiverId: 'user-mod-3',
      receiverName: 'সাবরিনা আক্তার',
      text: 'ওয়ালাইকুমুস সালাম আপা। হ্যাঁ, আলহামদুলিল্লাহ প্রস্তুত হয়েছে। ড্যাশবোর্ডে আপডেট পেয়ে যাবেন।',
      timestamp: new Date(Date.now() - 3600000).toISOString(),
      isRead: true,
    },
  ]);
  const [activePrivateChatUser, setActivePrivateChatUser] = useState<UserProfile | null>(null);

  // Printable receipt state
  const [activePrintReceipt, setActivePrintReceipt] = useState<ElectronicReceipt | null>(null);

  // Pull-to-refresh & auto refresh state
  const [isRefreshing, setIsRefreshing] = useState<boolean>(false);

  // Requirement 11: Foundation Expenses state
  const [expenses, setExpenses] = useState<FoundationExpense[]>(() => initialSaved?.expenses || INITIAL_EXPENSES);

  // Universal Search Modal state
  const [isSearchModalOpen, setIsSearchModalOpen] = useState<boolean>(false);

  // Requirement 4: Real-time call state
  const [activeCall, setActiveCall] = useState<{
    callId: string;
    callerId: string;
    callerName: string;
    targetName?: string;
    channel: string;
    startedAt: string;
    status: 'RINGING' | 'CONNECTED' | 'ENDED';
  } | null>(null);

  const startCall = (channel: 'GENERAL' | 'MODERATOR_ONLY' | 'PERSONAL' = 'GENERAL', targetName?: string) => {
    if (!currentUser) {
      setIsAuthModalOpen(true);
      return;
    }
    const callObj = {
      callId: `call-${Date.now()}`,
      callerId: currentUser.id,
      callerName: currentUser.name,
      targetName: targetName || (channel === 'GENERAL' ? 'সকল সাধারণ সদস্য' : 'মডারেটর প্যানেল'),
      channel,
      startedAt: new Date().toISOString(),
      status: 'RINGING' as const,
    };
    setActiveCall(callObj);
  };

  const endCall = (durationSec: number = 0) => {
    if (!activeCall) return;
    const durFormatted = durationSec > 0
      ? `${Math.floor(durationSec / 60)} মিনিট ${durationSec % 60} সেকেন্ড`
      : 'কয়েক সেকেন্ড';
    const msg = `📞 [কল সমাপ্ত]\n${activeCall.callerName} এর সাথে অডিও/ভিডিও কল সমাপ্ত হয়েছে। মোট স্থিতিকাল: ${durFormatted}`;
    if (activeCall.channel === 'GENERAL' || activeCall.channel === 'MODERATOR_ONLY') {
      sendChatMessage(activeCall.channel, msg);
    }
    setActiveCall(null);
  };

  // Requirement 20: Executive Committee state
  const [executiveMembers, setExecutiveMembers] = useState<ExecutiveMember[]>(() => [
    {
      id: 'exec-1',
      name: 'মাহমুদুল হাসান সিয়াম',
      designation: 'প্রধান অ্যাপ মডারেটর ও সমন্বয়ক',
      phone: '০১৭০০-০০০০০১',
      avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150',
      responsibilities: 'অ্যাপ্লিকেশনের প্রযুক্তিগত পরিচালনা, ডিজিটাল কোর ব্যাংকিং ও নিরাপত্তা নিয়ন্ত্রণ।',
      order: 1,
      approvedDate: '২০২৫-০১-১০',
    },
    {
      id: 'exec-2',
      name: 'তানভীর আহমেদ',
      designation: 'সভাপতি / প্রধান নির্বাহী',
      phone: '০১৭০০-০০০০০২',
      avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150',
      responsibilities: 'কার্যনির্বাহী পরিষদের সার্বিক তদারকি ও প্রাতিষ্ঠানিক প্রতিনিধিত্ব।',
      order: 2,
      approvedDate: '২০২৫-০১-১০',
    },
    {
      id: 'exec-3',
      name: 'সাবরিনা আক্তার',
      designation: 'সাধারণ সম্পাদক ও প্রধান অডিটর',
      phone: '০১৭০০-০০০০০৩',
      avatarUrl: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150',
      responsibilities: 'সদস্য সমন্বয়, সভার কার্যবিবরণী ও আর্থিক হিসাব অডিট অনুমোদন।',
      order: 3,
      approvedDate: '২০২৫-০১-১০',
    },
    {
      id: 'exec-4',
      name: 'রাশেদুল করিম',
      designation: 'কোষাধ্যক্ষ (Treasurer)',
      phone: '০১৭০০-০০০০০৪',
      avatarUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150',
      responsibilities: 'যৌথ ব্যাংক হিসাব পরিচালনা ও মাসিক জমার হিসাবপত্র সংরক্ষণ।',
      order: 4,
      approvedDate: '২০২৫-০১-১০',
    },
  ]);

  const addExecutiveMember = (member: Omit<ExecutiveMember, 'id'>) => {
    const newExec: ExecutiveMember = {
      ...member,
      id: `exec-${Date.now()}`,
      order: executiveMembers.length + 1,
      approvedDate: new Date().toLocaleDateString('en-GB'),
    };
    setExecutiveMembers((prev) => [...prev, newExec]);
    syncExecutiveMemberToFirestore(newExec);
    triggerSuccess('কার্যনির্বাহী পর্ষদে নতুন সদস্য অনুমোদিত ও যুক্ত হয়েছে!');
  };

  const removeExecutiveMember = (id: string) => {
    setExecutiveMembers((prev) => prev.filter((m) => m.id !== id));
    deleteExecutiveMemberFromFirestore(id);
    triggerSuccess('কার্যনির্বাহী পর্ষদ থেকে পদবি বাতিল ও সদস্য অপসারণ করা হয়েছে।');
  };

  const updateExecutiveMember = (id: string, partial: Partial<ExecutiveMember>) => {
    setExecutiveMembers((prev) => {
      const updated = prev.map((m) => (m.id === id ? { ...m, ...partial } : m));
      const target = updated.find((m) => m.id === id);
      if (target) syncExecutiveMemberToFirestore(target);
      return updated;
    });
    triggerSuccess('কার্যনির্বাহী পর্ষদের তথ্য সফলভাবে হালনাগাদ করা হয়েছে!');
  };

  // Real-time Cloud Synchronization (Firebase Firestore)
  const [cloudSyncStatus, setCloudSyncStatus] = useState<SyncStatus>('LOCAL');
  const [lastSyncTimestamp, setLastSyncTimestamp] = useState<string>(() => new Date().toLocaleTimeString('bn-BD'));
  const [pendingDepositModalOpen, setPendingDepositModalOpen] = useState<boolean>(false);

  // User Notifications state (Points 9 & 15)
  const [userNotifications, setUserNotifications] = useState<UserNotification[]>(() => initialSaved?.userNotifications || [
    {
      id: 'notif-welcome',
      userId: 'ALL',
      title: 'বেসিস ফাউন্ডেশনে স্বাগতম',
      message: 'ডিজিタル সমবায় সঞ্চয় প্ল্যাটফর্মে আপনার স্বাগতম। প্রতি মাসের ১০ তারিখের মধ্যে আপনার সঞ্চয় জমা সম্পন্ন করুন।',
      type: 'GENERAL',
      color: 'emerald',
      createdAt: new Date().toISOString(),
      read: false,
    },
  ]);

  const checkUserHasPendingDeposit = (memberId: string): boolean => {
    return savings.some((s) => s.memberId === memberId && s.status === 'PENDING');
  };

  const sendUserNotification = (
    targetUserId: string,
    title: string,
    message: string,
    type: UserNotification['type'],
    color: UserNotification['color']
  ) => {
    const newNotif: UserNotification = {
      id: `notif-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      userId: targetUserId,
      title,
      message,
      type,
      color,
      createdAt: new Date().toISOString(),
      read: false,
    };
    setUserNotifications((prev) => [newNotif, ...prev]);

    // Send to mobile notification bar (Point 15)
    if (typeof window !== 'undefined' && 'Notification' in window && Notification.permission === 'granted') {
      try {
        new Notification(title, {
          body: message,
          icon: '/logo.svg',
          badge: '/logo.svg',
          tag: newNotif.id,
        });
      } catch (err) {
        console.warn('Push notification delivery error:', err);
      }
    }
  };

  const markNotificationRead = (id: string) => {
    setUserNotifications((prev) =>
      prev.map((n) => (n.id === id ? { ...n, read: true } : n))
    );
  };

  const markAllNotificationsRead = () => {
    setUserNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
  };

  // Real-time Firestore synchronization listener
  useEffect(() => {
    const unsubscribe = initRealtimeSync({
      onConfigChange: (remoteConfig) => {
        setConfig((prev) => ({ ...prev, ...remoteConfig }));
      },
      onNoticesChange: (remoteNotices) => {
        if (remoteNotices && remoteNotices.length > 0) {
          setNotices(remoteNotices);
        }
      },
      onRulesChange: (remoteRules) => {
        if (remoteRules && remoteRules.length > 0) {
          setRules(remoteRules);
        }
      },
      onExecutiveMembersChange: (remoteMembers) => {
        if (remoteMembers && remoteMembers.length > 0) {
          setExecutiveMembers(remoteMembers);
        }
      },
      onSavingsChange: (remoteSavings) => {
        if (remoteSavings && remoteSavings.length > 0) {
          setSavings((prev) => {
            const map = new Map<string, SavingsTransaction>();
            INITIAL_SAVINGS.forEach((t) => map.set(t.id, t));
            prev.forEach((t) => map.set(t.id, t));
            remoteSavings.forEach((t) => map.set(t.id, t));
            return Array.from(map.values()).sort(
              (a, b) => new Date(b.transactionDate).getTime() - new Date(a.transactionDate).getTime()
            );
          });
        }
      },
      onUsersChange: (remoteUsers) => {
        if (remoteUsers && remoteUsers.length > 0) {
          setUsers((prev) => {
            const map = new Map<string, UserProfile>();
            prev.forEach((u) => map.set(u.id, u));
            remoteUsers.forEach((u) => map.set(u.id, u));
            return Array.from(map.values());
          });
        }
      },
      onApprovalsChange: (remoteApprovals) => {
        if (remoteApprovals && remoteApprovals.length > 0) {
          setApprovals((prev) => {
            const map = new Map<string, ApprovalRequest>();
            prev.forEach((a) => map.set(a.id, a));
            remoteApprovals.forEach((a) => map.set(a.id, a));
            return Array.from(map.values()).sort(
              (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
            );
          });
        }
      },
      onChatChange: (remoteChat) => {
        if (remoteChat && remoteChat.length > 0) {
          setChatMessages(remoteChat);
        }
      },
      onStatusChange: (status, timestamp) => {
        setCloudSyncStatus(status);
        setLastSyncTimestamp(timestamp);
      },
    });

    return () => {
      unsubscribe();
    };
  }, []);

  const triggerCloudSync = async () => {
    setCloudSyncStatus('SYNCING');
    try {
      await Promise.all([
        syncConfigToFirestore(config),
        ...notices.map((n) => syncNoticeToFirestore(n)),
        ...rules.map((r) => syncRuleToFirestore(r)),
        ...executiveMembers.map((m) => syncExecutiveMemberToFirestore(m)),
      ]);
      setCloudSyncStatus('SYNCED');
      setLastSyncTimestamp(new Date().toLocaleTimeString('bn-BD'));
      triggerSuccess('ফায়ারবেজ ক্লাউডে সমস্ত ডাটা সফলভাবে সিংক সম্পন্ন!');
    } catch (err) {
      setCloudSyncStatus('LOCAL');
      triggerSuccess('লোকাল স্টোরেজে সংরক্ষিত হয়েছে।');
    }
  };


  // Requirement 7: Online User Tracking
  const onlineUserIds = useMemo(() => {
    if (!isOnline) return [];
    return users.map((u) => u.id);
  }, [isOnline, users]);

  // Sync dark/light class on HTML element
  useEffect(() => {
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
      document.documentElement.classList.remove('light');
    } else {
      document.documentElement.classList.remove('dark');
      document.documentElement.classList.add('light');
    }
  }, [theme]);

  // Sync font size scaling directly on document root
  useEffect(() => {
    const sizeMap: Record<string, string> = {
      small: '13.5px',
      medium: '16px',
      large: '18.5px',
      xlarge: '21px',
    };
    const targetSize = sizeMap[config.fontSize || 'medium'] || '16px';
    document.documentElement.style.fontSize = targetSize;
    document.documentElement.classList.remove('font-scale-small', 'font-scale-medium', 'font-scale-large', 'font-scale-xlarge');
    document.documentElement.classList.add(`font-scale-${config.fontSize || 'medium'}`);
  }, [config.fontSize]);

  // Inject manual custom font if provided
  useEffect(() => {
    if (config.customFontUrl && config.customFontUrl.trim() !== '') {
      const existing = document.getElementById('custom-font-link');
      if (existing) existing.remove();
      const link = document.createElement('link');
      link.id = 'custom-font-link';
      link.rel = 'stylesheet';
      link.href = config.customFontUrl;
      document.head.appendChild(link);
    }
    if (config.customFontFamily && config.customFontFamily.trim() !== '') {
      document.body.style.fontFamily = `'${config.customFontFamily}', var(--font-bengali)`;
    } else {
      document.body.style.fontFamily = `var(--font-bengali)`;
    }
  }, [config.customFontUrl, config.customFontFamily]);

  // Requirement 9: Inject and apply uploaded TTF/WOFF/OTF font file dynamically
  useEffect(() => {
    if (config.uploadedFontDataUrl) {
      const fontName = config.uploadedFontName || 'UserCustomFont';
      let styleTag = document.getElementById('app-uploaded-font-style') as HTMLStyleElement | null;
      if (!styleTag) {
        styleTag = document.createElement('style');
        styleTag.id = 'app-uploaded-font-style';
        document.head.appendChild(styleTag);
      }
      styleTag.textContent = `
        @font-face {
          font-family: '${fontName}';
          src: url("${config.uploadedFontDataUrl}") format('truetype'),
               url("${config.uploadedFontDataUrl}") format('woff2'),
               url("${config.uploadedFontDataUrl}") format('woff'),
               url("${config.uploadedFontDataUrl}") format('opentype');
          font-weight: 100 900;
          font-display: swap;
        }
        body, html, input, button, select, textarea {
          font-family: '${fontName}', var(--font-bengali), system-ui, sans-serif !important;
        }
      `;
    }
  }, [config.uploadedFontDataUrl, config.uploadedFontName]);

  // Requirement 11 & 14: Auto-sync all entity states to LocalStorage
  useEffect(() => {
    try {
      const payload = {
        config,
        users,
        currentUserId: currentUser && currentUser.id !== '__guest__' ? currentUser.id : null,
        savings,
        approvals,
        receipts,
        notices,
        rules,
        complaints,
        featureRequests,
        chatMessages,
        polls,
        releases,
        auditLogs,
        expenses,
        privateMessages,
      };
      localStorage.setItem(STORAGE_KEY, JSON.stringify(payload));
    } catch (e) {
      console.error('Failed to auto-save to localStorage', e);
    }
  }, [
    config,
    users,
    currentUser?.id,
    savings,
    approvals,
    receipts,
    notices,
    rules,
    complaints,
    featureRequests,
    chatMessages,
    polls,
    releases,
    auditLogs,
    expenses,
    privateMessages,
  ]);

  // Generate initial receipts for approved transactions on mount
  useEffect(() => {
    const existingApproved = savings.filter((t) => t.status === 'APPROVED');
    const genReceipts: ElectronicReceipt[] = existingApproved.map((tx, idx) => ({
      receiptNumber: tx.receiptId || generateReceiptNumber(tx.savingsMonth, tx.memberId, idx + 1),
      transactionId: tx.id,
      memberId: tx.memberId,
      memberName: tx.memberName,
      savingsMonth: tx.savingsMonth,
      savingsYear: tx.savingsYear,
      amount: tx.amount,
      paymentMethod: tx.paymentMethod,
      transactionDate: tx.transactionDate,
      transactionRef: tx.transactionRef,
      approvalStatus: 'APPROVED',
      approvingModeratorNames: tx.approvingModerators.map((id) => {
        const u = users.find((usr) => usr.id === id);
        return u ? u.name : 'Authorized Moderator';
      }),
      generatedAt: tx.transactionDate,
      verificationHash: `BF-HASH-${tx.id}-${tx.memberId}-${Math.floor(tx.amount * 3.1415)}`,
    }));
    setReceipts(genReceipts);
  }, []);

  // Eligible moderators count
  const eligibleModeratorsCount = useMemo(() => {
    return users.filter(
      (u) => (u.role === 'APP_MODERATOR' || u.role === 'MODERATOR') && u.status === 'APPROVED'
    ).length;
  }, [users]);

  // Financial aggregates
  const financialTotals = useMemo(() => {
    return calculateFinancialTotals(savings);
  }, [savings]);

  // Monthly aggregates
  const monthlyAggregates = useMemo(() => {
    return aggregateSavingsByMonth(savings);
  }, [savings]);

  // Month-over-month growth rate
  const growthRate = useMemo(() => {
    const currentMonth = '2026-10';
    const previousMonth = '2026-09';
    const currentTotal = monthlyAggregates[currentMonth] || 0;
    const prevTotal = monthlyAggregates[previousMonth] || 0;
    return calculateGrowthRate(currentTotal, prevTotal);
  }, [monthlyAggregates]);

  // Requirement 11: Total Expenses & Net Reserve Balance
  const totalExpenses = useMemo(() => {
    return expenses.reduce((sum, e) => sum + e.amount, 0);
  }, [expenses]);

  const netReserveBalance = useMemo(() => {
    return financialTotals.totalApproved - totalExpenses;
  }, [financialTotals.totalApproved, totalExpenses]);

  const addExpense = (expenseData: Omit<FoundationExpense, 'id'>) => {
    const newExp: FoundationExpense = {
      ...expenseData,
      id: `exp-${Date.now()}`,
    };
    setExpenses((prev) => [newExp, ...prev]);
    logAudit('EXPENSE_RECORDED', 'FINANCE', newExp.id, `ব্যয় রেকর্ড: ${newExp.title} (৳${newExp.amount})`);
    triggerSuccess('ব্যয়ের হিসাব সফলভাবে যুক্ত করা হয়েছে!');
  };

  const removeExpense = (id: string) => {
    setExpenses((prev) => prev.filter((e) => e.id !== id));
    logAudit('EXPENSE_DELETED', 'FINANCE', id, `ব্যয় রেকর্ড অপসারণ করা হয়েছে।`);
    triggerSuccess('ব্যয় রেকর্ড সফলভাবে অপসারণ করা হয়েছে!');
  };

  // Unread badge count
  const unreadCount = useMemo(() => {
    const pendingApprovals = approvals.filter((a) => a.status === 'PENDING').length;
    const pendingComplaints = complaints.filter((c) => c.status === 'SUBMITTED').length;
    return pendingApprovals + pendingComplaints;
  }, [approvals, complaints]);

  // Switch role helper
  const switchUserRole = (userId: string) => {
    const found = users.find((u) => u.id === userId);
    if (found) {
      setCurrentUser(found);
    }
  };

  // Add an audit log entry
  const logAudit = (
    actionType: AuditLogItem['actionType'],
    targetType: string,
    targetId: string,
    details: string
  ) => {
    const newLog: AuditLogItem = {
      id: `log-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      actorId: currentUser?.id || 'system',
      actorName: currentUser?.name || 'অতিথি বা সিস্টেম',
      actorRole: currentUser?.role || 'MEMBER',
      actionType,
      targetType,
      targetId,
      timestamp: new Date().toISOString(),
      details,
      status: 'SUCCESS',
    };
    setAuditLogs((prev) => [newLog, ...prev]);
  };

  // Create savings transaction
  const createSavingsEntry = (data: {
    memberId: string;
    amount: number;
    savingsMonth: string;
    savingsYear: number;
    paymentMethod: any;
    transactionRef?: string;
    notes?: string;
  }) => {
    const member = users.find((u) => u.memberId === data.memberId);
    if (!member) return;

    const txId = `tx-${Date.now()}`;
    const entryCreatorId = currentUser?.id || data.memberId;
    const entryCreatorName = currentUser?.name || member.name;
    const isMod = currentUser && currentUser.role !== 'MEMBER';

    const newTx: SavingsTransaction = {
      id: txId,
      memberId: data.memberId,
      memberName: member.name,
      amount: data.amount,
      savingsMonth: data.savingsMonth,
      savingsYear: data.savingsYear,
      transactionDate: new Date().toISOString(),
      paymentMethod: data.paymentMethod,
      transactionRef: data.transactionRef,
      entryCreatorId,
      entryCreatorName,
      status: 'PENDING',
      approvingModerators: isMod ? [currentUser.id] : [],
      notes: data.notes,
    };

    // Create approval request
    const approvalId = `appr-${Date.now()}`;
    const newApproval: ApprovalRequest = {
      id: approvalId,
      requestType: 'SAVINGS_ENTRY',
      targetRecordId: txId,
      requestingUserId: entryCreatorId,
      requestingUserName: entryCreatorName,
      title: `সঞ্চয় জমা অনুমোদন (${member.name})`,
      description: `${member.name} (${data.memberId}) এর ${data.savingsMonth} মাসের ৳${data.amount.toLocaleString()} জমার অনুমোদন প্রক্রিয়া।`,
      createdAt: new Date().toISOString(),
      requiredApprovalCount: Math.ceil((eligibleModeratorsCount * 2) / 3),
      eligibleModeratorsCount,
      approvalVotes: isMod ? [currentUser.id] : [],
      rejectionVotes: [],
      status: 'PENDING',
    };

    setSavings((prev) => [newTx, ...prev]);
    setApprovals((prev) => [newApproval, ...prev]);

    syncSavingsTransactionToFirestore(newTx);
    syncApprovalToFirestore(newApproval);
    sendUserNotification(
      member.memberId,
      'জমা দাখিল সম্পন্ন',
      `আপনার ${data.savingsMonth} মাসের ৳${data.amount.toLocaleString()} জমার তথ্য দাখিল হয়েছে, মডারেটর পরিষদ অনুমোদনের জন্য অপেক্ষা করুন।`,
      'DEPOSIT_SUBMITTED',
      'purple'
    );

    logAudit(
      'SAVINGS_CREATED',
      'SAVINGS_TRANSACTION',
      txId,
      `${member.name} (${data.memberId}) এর জন্য ৳${data.amount} এর সঞ্চয় এন্ট্রি তৈরি করা হয়েছে।`
    );
  };

  // Vote on approval (with 2/3rds ceiling logic evaluation)
  const voteOnApproval = (approvalId: string, vote: 'APPROVE' | 'REJECT', reason?: string) => {
    if (!currentUser) {
      setIsAuthModalOpen(true);
      return;
    }
    const currentUserId = currentUser.id;
    setApprovals((prev) =>
      prev.map((appr) => {
        if (appr.id !== approvalId) return appr;

        // Disallow duplicate votes
        if (appr.approvalVotes.includes(currentUserId) || appr.rejectionVotes.includes(currentUserId)) {
          return appr;
        }

        const newApprovals = vote === 'APPROVE' ? [...appr.approvalVotes, currentUserId] : appr.approvalVotes;
        const newRejections = vote === 'REJECT' ? [...appr.rejectionVotes, currentUserId] : appr.rejectionVotes;

        // Evaluate using our tested pure 2/3rds calculation
        const evaluation = evaluateApprovalState(appr.eligibleModeratorsCount, newApprovals, newRejections);

        const updated: ApprovalRequest = {
          ...appr,
          approvalVotes: newApprovals,
          rejectionVotes: newRejections,
          status: evaluation.status,
          finalizedAt: evaluation.isFinalized ? new Date().toISOString() : undefined,
        };

        syncApprovalToFirestore(updated);

        // If approved, finalize the underlying entity!
        if (evaluation.isFinalized && evaluation.status === 'APPROVED') {
          if (appr.requestType === 'SAVINGS_ENTRY') {
            finalizeApprovedSavings(appr.targetRecordId, newApprovals);
          } else if (appr.requestType === 'NEW_MEMBER') {
            finalizeApprovedMember(appr.targetRecordId);
          } else if (appr.requestType === 'PROFILE_CHANGE') {
            finalizeApprovedProfileChange(appr.targetRecordId, appr.proposedChanges);
          }

          logAudit(
            'SAVINGS_APPROVED',
            'APPROVAL_REQUEST',
            appr.id,
            `অনুমোদন নং ${appr.id} সফলভাবে ২/৩ সিলিং সংখ্যাগরিষ্ঠতায় অনুমোদিত হয়েছে।`
          );
        } else if (evaluation.isFinalized && evaluation.status === 'REJECTED') {
          if (appr.requestType === 'SAVINGS_ENTRY') {
            setSavings((sPrev) =>
              sPrev.map((t) => {
                if (t.id === appr.targetRecordId) {
                  const rejectedTx = { ...t, status: 'REJECTED' as const, rejectionReason: reason };
                  syncSavingsTransactionToFirestore(rejectedTx);
                  return rejectedTx;
                }
                return t;
              })
            );
          }
          logAudit(
            'SAVINGS_REJECTED',
            'APPROVAL_REQUEST',
            appr.id,
            `অনুমোদন নং ${appr.id} বাতিল/প্রত্যাখ্যাত হয়েছে। কারণ: ${reason || 'পর্যাপ্ত ভোট পাওয়া যায়নি'}`
          );
        }

        return updated;
      })
    );
  };

  // Finalize approved savings & generate official receipt
  const finalizeApprovedSavings = (txId: string, approvingModIds: string[]) => {
    let finalizedTx: SavingsTransaction | undefined;

    setSavings((prev) =>
      prev.map((tx) => {
        if (tx.id !== txId) return tx;
        const receiptId = generateReceiptNumber(tx.savingsMonth, tx.memberId, receipts.length + 1);
        finalizedTx = {
          ...tx,
          status: 'APPROVED',
          approvingModerators: approvingModIds,
          receiptId,
        };
        return finalizedTx;
      })
    );

    if (finalizedTx) {
      const receipt: ElectronicReceipt = {
        receiptNumber: finalizedTx.receiptId!,
        transactionId: finalizedTx.id,
        memberId: finalizedTx.memberId,
        memberName: finalizedTx.memberName,
        savingsMonth: finalizedTx.savingsMonth,
        savingsYear: finalizedTx.savingsYear,
        amount: finalizedTx.amount,
        paymentMethod: finalizedTx.paymentMethod,
        transactionDate: finalizedTx.transactionDate,
        transactionRef: finalizedTx.transactionRef,
        approvalStatus: 'APPROVED',
        approvingModeratorNames: approvingModIds.map((id) => {
          const u = users.find((usr) => usr.id === id);
          return u ? u.name : 'মডারেটর';
        }),
        generatedAt: new Date().toISOString(),
        verificationHash: `BF-HASH-${finalizedTx.id}-${finalizedTx.memberId}-${Math.floor(finalizedTx.amount * 3.1415)}`,
      };
      setReceipts((prev) => [receipt, ...prev]);

      // Sync transaction to Firestore
      syncSavingsTransactionToFirestore(finalizedTx);

      // Auto update live deposit ticker so text scrolls in latest deposit ticker (Point 3)
      updateConfig({
        latestDepositTicker: {
          depositorName: finalizedTx.memberName,
          amount: finalizedTx.amount,
          time: 'এখনই অনুমোদিত',
        },
      });

      // Point 9: Notify specific user with green color
      sendUserNotification(
        finalizedTx.memberId,
        'সঞ্চয় জমা অনুমোদিত!',
        `আপনার ${finalizedTx.savingsMonth} মাসের ${formatCurrencyBengali(finalizedTx.amount)} সঞ্চয় জমা মডারেটর পরিষদ কর্তৃক সফলভাবে অনুমোদিত হয়েছে।`,
        'DEPOSIT_APPROVED',
        'emerald'
      );
    }
  };

  // Finalize member approval
  const finalizeApprovedMember = (userId: string) => {
    setUsers((prev) =>
      prev.map((u) => (u.id === userId ? { ...u, status: 'APPROVED' } : u))
    );
    logAudit('MEMBER_APPROVAL', 'USER', userId, `নতুন সদস্যের আবেদন অনুমোদিত হয়েছে।`);
  };

  // Finalize profile change
  const finalizeApprovedProfileChange = (userId: string, changes?: { field: string; newValue: any }[]) => {
    if (!changes) return;
    setUsers((prev) =>
      prev.map((u) => {
        if (u.id !== userId) return u;
        const updated = { ...u };
        for (const ch of changes) {
          (updated as any)[ch.field] = ch.newValue;
        }
        return updated;
      })
    );
    logAudit('PROFILE_CHANGE', 'USER', userId, `প্রোফাইল পরিবর্তনের আবেদন অনুমোদিত ও কার্যকর হয়েছে।`);
  };

  // Reversal / Correction preserving audit trail
  const reverseTransaction = (txId: string, reason: string) => {
    setSavings((prev) => {
      const target = prev.find((t) => t.id === txId);
      if (!target) return prev;

      const reversalRecord: SavingsTransaction = {
        id: `rev-${Date.now()}`,
        memberId: target.memberId,
        memberName: target.memberName,
        amount: -target.amount,
        savingsMonth: target.savingsMonth,
        savingsYear: target.savingsYear,
        transactionDate: new Date().toISOString(),
        paymentMethod: target.paymentMethod,
        entryCreatorId: currentUser.id,
        entryCreatorName: currentUser.name,
        status: 'APPROVED',
        approvingModerators: [currentUser.id],
        isCorrection: true,
        originalTransactionId: target.id,
        notes: `সংশোধন/রিভার্সাল: ${reason}`,
      };

      logAudit(
        'FINANCIAL_CORRECTION',
        'SAVINGS_TRANSACTION',
        txId,
        `ট্রানজেকশন ${txId} এর বিপরীতে সংশোধন এন্ট্রি তৈরি। কারণ: ${reason}`
      );

      return [reversalRecord, ...prev];
    });
  };

  // Request a profile change
  const requestProfileChange = (
    userId: string,
    proposedChanges: { field: string; oldValue: any; newValue: any }[]
  ) => {
    const user = users.find((u) => u.id === userId);
    if (!user) return;

    const approvalId = `appr-prof-${Date.now()}`;
    const approval: ApprovalRequest = {
      id: approvalId,
      requestType: 'PROFILE_CHANGE',
      targetRecordId: userId,
      requestingUserId: currentUser.id,
      requestingUserName: currentUser.name,
      title: `প্রোফাইল পরিবর্তন প্রস্তাব (${user.name})`,
      description: `${user.name} এর প্রোফাইল তথ্য হালনাগাদের আবেদন।`,
      proposedChanges,
      createdAt: new Date().toISOString(),
      requiredApprovalCount: Math.ceil((eligibleModeratorsCount * 2) / 3),
      eligibleModeratorsCount,
      approvalVotes: [],
      rejectionVotes: [],
      status: 'PENDING',
    };

    setApprovals((prev) => [approval, ...prev]);
  };

  const updateUserProfile = (userId: string, partial: Partial<UserProfile>) => {
    setUsers((prev) => prev.map((u) => (u.id === userId ? { ...u, ...partial } : u)));
    if (currentUser.id === userId) {
      setCurrentUser((prev) => ({ ...prev, ...partial }));
    }
  };

  const getReceiptForTransaction = (txId: string) => {
    return receipts.find((r) => r.transactionId === txId);
  };

  // Chat methods with Reply support (Requirement 13 & 21)
  const sendChatMessage = (
    channel: 'GENERAL' | 'MODERATOR_ONLY',
    text: string,
    imageUrl?: string,
    replyTo?: { id: string; text: string; senderName: string }
  ) => {
    if (!currentUser) {
      setIsAuthModalOpen(true);
      return;
    }
    const newMsg: ChatMessage = {
      id: `msg-${Date.now()}`,
      channel,
      senderId: currentUser.id,
      senderName: currentUser.name,
      senderRole: currentUser.role,
      senderAvatar: currentUser.avatarUrl,
      text,
      timestamp: new Date().toISOString(),
      imageUrl,
      replyToId: replyTo?.id,
      replyToText: replyTo?.text,
      replyToSender: replyTo?.senderName,
    };
    setChatMessages((prev) => [...prev, newMsg]);
    syncChatMessageToFirestore(newMsg);
  };

  const deleteChatMessage = (messageId: string) => {
    setChatMessages((prev) =>
      prev.map((msg) =>
        msg.id === messageId
          ? {
              ...msg,
              isDeleted: true,
              text: 'ব্যবহারকারী বার্তাটি ডিলিট করেছেন',
            }
          : msg
      )
    );
  };

  const toggleMessageReaction = (messageId: string, emoji: string) => {
    if (!currentUser) return;
    setChatMessages((prev) =>
      prev.map((msg) => {
        if (msg.id !== messageId) return msg;
        const reactions = { ...(msg.reactions || {}) };
        const userList = reactions[emoji] || [];

        if (userList.includes(currentUser.id)) {
          reactions[emoji] = userList.filter((id) => id !== currentUser.id);
          if (reactions[emoji].length === 0) delete reactions[emoji];
        } else {
          reactions[emoji] = [...userList, currentUser.id];
        }
        return { ...msg, reactions };
      })
    );
  };

  const votePoll = (pollId: string, optionId: string) => {
    if (!currentUser) {
      setIsAuthModalOpen(true);
      return;
    }
    setPolls((prev) =>
      prev.map((poll) => {
        if (poll.id !== pollId) return poll;
        return {
          ...poll,
          options: poll.options.map((opt) => {
            const hasVoted = opt.votes.includes(currentUser.id);
            if (opt.id === optionId) {
              return { ...opt, votes: hasVoted ? opt.votes : [...opt.votes, currentUser.id] };
            } else {
              return { ...opt, votes: opt.votes.filter((id) => id !== currentUser.id) };
            }
          }),
        };
      })
    );
  };

  const createPoll = (channel: 'GENERAL' | 'MODERATOR_ONLY', question: string, optionTexts: string[]) => {
    if (!currentUser) {
      setIsAuthModalOpen(true);
      return;
    }
    const newPoll: ChatPoll = {
      id: `poll-${Date.now()}`,
      channel,
      question,
      creatorName: currentUser.name,
      options: optionTexts.map((txt, idx) => ({ id: `opt-${idx + 1}`, text: txt, votes: [] })),
      createdAt: new Date().toISOString(),
    };
    setPolls((prev) => [newPoll, ...prev]);
    triggerSuccess('নতুন জরিপ প্রকাশ করা হয়েছে!');
  };

  const deletePoll = (pollId: string) => {
    setPolls((prev) => prev.filter((p) => p.id !== pollId));
    triggerSuccess('জরিপটি সফলভাবে মুছে ফেলা হয়েছে!');
  };

  const updatePollOption = (pollId: string, optionId: string, text: string) => {
    setPolls((prev) =>
      prev.map((poll) => {
        if (poll.id !== pollId) return poll;
        return {
          ...poll,
          options: poll.options.map((opt) => (opt.id === optionId ? { ...opt, text } : opt)),
        };
      })
    );
    triggerSuccess('জরিপের অপশন টেক্সট আপডেট করা হয়েছে!');
  };

  const updatePollQuestion = (pollId: string, question: string) => {
    setPolls((prev) =>
      prev.map((poll) => (poll.id === pollId ? { ...poll, question } : poll))
    );
    triggerSuccess('জরিপের প্রশ্ন আপডেট করা হয়েছে!');
  };

  // Notices
  const addNotice = (notice: Omit<NoticeItem, 'id' | 'createdAt' | 'authorName' | 'authorRole'>) => {
    const authorName = currentUser?.name || 'বেসিস ফাউন্ডেশন প্রশাসন';
    const authorRole = currentUser?.role || 'APP_MODERATOR';
    const newNotice: NoticeItem = {
      ...notice,
      id: `notice-${Date.now()}`,
      authorName,
      authorRole,
      createdAt: new Date().toISOString(),
    };
    setNotices((prev) => [newNotice, ...prev]);
    syncNoticeToFirestore(newNotice);

    // If marked for top announcement ticker, also sync into scrolling announcement
    if (newNotice.showInTicker) {
      updateConfig({
        scrollingAnnouncement: `[জরুরি বিজ্ঞপ্তি] ${newNotice.title}: ${newNotice.content.slice(0, 100)}`,
      });
    }

    sendUserNotification(
      'ALL',
      `নতুন নোটিশ: ${newNotice.title}`,
      newNotice.content.slice(0, 85) + '...',
      'NEW_NOTICE',
      'amber'
    );
    logAudit('CONFIG_UPDATED', 'NOTICE', newNotice.id, `নতুন নোটিশ প্রকাশ: "${notice.title}"`);
  };

  const updateNotice = (noticeId: string, partial: Partial<NoticeItem>) => {
    setNotices((prev) => {
      const updated = prev.map((n) => (n.id === noticeId ? { ...n, ...partial } : n));
      const target = updated.find((n) => n.id === noticeId);
      if (target) syncNoticeToFirestore(target);
      return updated;
    });
    triggerSuccess('নোটিশ তথ্য সফলভাবে হালনাগাদ করা হয়েছে!');
  };

  const deleteNotice = (noticeId: string) => {
    setNotices((prev) => prev.filter((n) => n.id !== noticeId));
    deleteNoticeFromFirestore(noticeId);
    triggerSuccess('নোটিশ সফলভাবে মুছে ফেলা হয়েছে!');
  };

  // Complaints
  const submitComplaint = (title: string, description: string) => {
    const newComp: ComplaintItem = {
      id: `comp-${Date.now()}`,
      submitterId: currentUser.id,
      submitterName: currentUser.name,
      title,
      description,
      status: 'SUBMITTED',
      createdAt: new Date().toISOString(),
    };
    setComplaints((prev) => [newComp, ...prev]);
  };

  const updateComplaintStatus = (
    id: string,
    status: ComplaintItem['status'],
    moderatorNotes?: string
  ) => {
    setComplaints((prev) =>
      prev.map((c) =>
        c.id === id
          ? {
              ...c,
              status,
              assignedModeratorName: currentUser.name,
              moderatorNotes: moderatorNotes || c.moderatorNotes,
            }
          : c
      )
    );
  };

  // Feature Requests
  const submitFeatureRequest = (title: string, description: string) => {
    const newReq: FeatureRequestItem = {
      id: `feat-${Date.now()}`,
      submitterId: currentUser.id,
      submitterName: currentUser.name,
      memberId: currentUser.memberId,
      title,
      description,
      createdAt: new Date().toISOString(),
      status: 'PENDING',
      votesCount: 1,
      votedUserIds: [currentUser.id],
    };
    setFeatureRequests((prev) => [newReq, ...prev]);
  };

  const voteFeatureRequest = (id: string) => {
    setFeatureRequests((prev) =>
      prev.map((item) => {
        if (item.id !== id) return item;
        const hasVoted = item.votedUserIds.includes(currentUser.id);
        const updatedUserIds = hasVoted
          ? item.votedUserIds.filter((uid) => uid !== currentUser.id)
          : [...item.votedUserIds, currentUser.id];
        return {
          ...item,
          votedUserIds: updatedUserIds,
          votesCount: updatedUserIds.length,
        };
      })
    );
  };

  // Rules
  const updateRule = (ruleId: string, title: string, description: string) => {
    setRules((prev) => {
      const updated = prev.map((r) =>
        r.id === ruleId
          ? {
              ...r,
              title,
              description,
              version: r.version + 1,
              lastUpdated: new Date().toISOString().split('T')[0],
            }
          : r
      );
      const target = updated.find((r) => r.id === ruleId);
      if (target) syncRuleToFirestore(target);
      return updated;
    });
    logAudit('CONFIG_UPDATED', 'FOUNDATION_RULE', ruleId, `নিয়মাবলী নং ${ruleId} হালনাগাদ করা হয়েছে।`);
  };

  // Configuration update (App Moderator) - real-time Firestore sync
  const updateConfig = (newConfig: Partial<AppConfiguration>) => {
    setConfig((prev) => {
      const merged = { ...prev, ...newConfig };
      syncConfigToFirestore(merged);
      return merged;
    });
    logAudit('CONFIG_UPDATED', 'SYSTEM_CONFIG', 'app-config', 'সিস্টেম কনফিগারেশন ও ব্র্যান্ডিং আপডেট করা হয়েছে।');
  };

  // Publish App Release (App Moderator)
  const publishAppRelease = (release: Omit<AppRelease, 'id'>) => {
    const newRelease: AppRelease = {
      ...release,
      id: `rel-${Date.now()}`,
    };
    setReleases((prev) => [newRelease, ...prev]);
    logAudit(
      'APK_PUBLISHED',
      'APP_RELEASE',
      newRelease.versionName,
      `নতুন অ্যাপ সংস্করণ ${newRelease.versionName} (Build ${newRelease.versionCode}) প্রকাশ করা হয়েছে।`
    );
  };

  // Backup export
  const exportBackupData = () => {
    const backupObj = {
      version: '1.0',
      exportedAt: new Date().toISOString(),
      exportedBy: currentUser.email,
      foundation: config.foundationName,
      data: {
        config,
        users,
        savings,
        approvals,
        receipts,
        notices,
        rules,
        complaints,
        featureRequests,
        auditLogs,
      },
    };
    logAudit('BACKUP_CREATED', 'DATABASE', 'full-export', 'সম্পূর্ণ ডাটাবেজ ব্যাকআপ এক্সপোর্ট করা হয়েছে।');
    return JSON.stringify(backupObj, null, 2);
  };

  // Restore backup
  const restoreFromBackup = (jsonData: string): { success: boolean; message: string } => {
    try {
      const parsed = JSON.parse(jsonData);
      if (!parsed.data || !parsed.data.savings || !parsed.data.users) {
        return { success: false, message: 'অকার্যকর ব্যাকআপ ফাইল: ডাটা স্কিমা সঠিক নয়।' };
      }
      setConfig(parsed.data.config || config);
      setUsers(parsed.data.users);
      setSavings(parsed.data.savings);
      setApprovals(parsed.data.approvals || []);
      setReceipts(parsed.data.receipts || []);
      setNotices(parsed.data.notices || []);
      setRules(parsed.data.rules || []);
      setComplaints(parsed.data.complaints || []);
      setFeatureRequests(parsed.data.featureRequests || []);
      setAuditLogs(parsed.data.auditLogs || []);

      logAudit('BACKUP_RESTORED', 'DATABASE', 'full-restore', 'ব্যাকআপ থেকে ডাটাবেজ সফলভাবে রিস্টোর করা হয়েছে।');
      return { success: true, message: 'সফলভাবে ডাটা রিস্টোর সম্পন্ন হয়েছে।' };
    } catch (e: any) {
      return { success: false, message: `রিস্টোর ব্যর্থ: ${e?.message || 'ত্রুটি'}` };
    }
  };

  // Trigger success celebration micro-animation (Requirement 9)
  const triggerSuccess = (message: string) => {
    setSuccessMessage(message);
    if (soundEnabled && typeof window !== 'undefined' && 'AudioContext' in window) {
      try {
        const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(587.33, audioCtx.currentTime); // D5
        osc.frequency.exponentialRampToValueAtTime(880, audioCtx.currentTime + 0.15); // A5
        gain.gain.setValueAtTime(0.12, audioCtx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.25);
        osc.connect(gain);
        gain.connect(audioCtx.destination);
        osc.start();
        osc.stop(audioCtx.currentTime + 0.25);
      } catch {}
    }
    if (hapticEnabled && typeof navigator !== 'undefined' && navigator.vibrate) {
      try {
        navigator.vibrate([40, 60, 40]);
      } catch {}
    }
  };

  const closeSuccess = () => {
    setSuccessMessage(null);
  };

  // Register New Account with PENDING status (Requirement 17)
  const registerNewAccount = (userData: Partial<UserProfile>) => {
    const newId = `user-reg-${Date.now()}`;
    const newUser: UserProfile = {
      id: newId,
      memberId: userData.memberId || `BF-${String(users.length + 1).padStart(3, '0')}`,
      name: userData.name || 'নতুন সদস্য',
      email: userData.email || '',
      phone: userData.phone || '',
      role: userData.role || 'MEMBER',
      status: 'PENDING', // PENDING until moderator approval
      gender: userData.gender || 'MALE',
      joinDate: new Date().toISOString().split('T')[0],
      avatarUrl: userData.avatarUrl,
      address: userData.address,
      nomineeName: userData.nomineeName,
      nomineeRelation: userData.nomineeRelation,
      nomineePhone: userData.nomineePhone,
      password: (userData as any).password || '123456',
    };

    setUsers((prev) => [...prev, newUser]);
    syncUserToFirestore(newUser);

    // Create approval request in moderator panel
    const newApproval: ApprovalRequest = {
      id: `appr-user-${Date.now()}`,
      requestType: 'NEW_MEMBER',
      targetRecordId: newId,
      requestingUserId: newId,
      requestingUserName: newUser.name,
      title: `নতুন সদস্য অ্যাকাউন্ট নিবন্ধন অনুমোদন (${newUser.name})`,
      description: `${newUser.name} (${newUser.phone}) নতুন অ্যাকাউন্ট নিবন্ধনের আবেদন করেছেন।`,
      createdAt: new Date().toISOString(),
      requiredApprovalCount: 1, // Single moderator approval sufficient for account creation
      eligibleModeratorsCount,
      approvalVotes: [],
      rejectionVotes: [],
      status: 'PENDING',
    };
    setApprovals((prev) => [newApproval, ...prev]);
    syncApprovalToFirestore(newApproval);

    logAudit('MEMBER_REGISTRATION', 'USER', newId, `${newUser.name} নতুন অ্যাকাউন্ট নিবন্ধনের আবেদন দাখিল করেছেন।`);
    triggerSuccess('অ্যাকাউন্ট নিবন্ধন সফল হয়েছে! মডারেটরের অনুমোদনের অপেক্ষায় রয়েছে।');
  };

  // Approve User Account (Requirement 17)
  const approveUserAccount = (userId: string) => {
    let approvedUser: UserProfile | undefined;
    setUsers((prev) =>
      prev.map((u) => {
        if (u.id === userId) {
          approvedUser = { ...u, status: 'APPROVED' };
          return approvedUser;
        }
        return u;
      })
    );
    setApprovals((prev) =>
      prev.map((a) =>
        a.targetRecordId === userId ? { ...a, status: 'APPROVED', finalizedAt: new Date().toISOString() } : a
      )
    );
    if (approvedUser) {
      syncUserToFirestore(approvedUser);
      sendUserNotification(
        (approvedUser as UserProfile).memberId,
        'অ্যাকাউন্ট অনুমোদন সফল!',
        'বেসিস ফাউন্ডেশনে আপনার সদস্যপদ অনুমোদিত হয়েছে। এখন আপনি সম্পূর্ণ সুবিধা ব্যবহার করতে পারবেন।',
        'PROFILE_APPROVED',
        'blue'
      );
    }
    logAudit('MEMBER_APPROVAL', 'USER', userId, `ব্যবহারকারী অ্যাকাউন্ট অনুমোদন প্রদান করা হয়েছে।`);
    triggerSuccess('সদস্য অ্যাকাউন্ট সফলভাবে অনুমোদিত হয়েছে!');
  };

  // Reject User Account (Requirement 17)
  const rejectUserAccount = (userId: string) => {
    setUsers((prev) =>
      prev.map((u) => (u.id === userId ? { ...u, status: 'REJECTED' } : u))
    );
    setApprovals((prev) =>
      prev.map((a) =>
        a.targetRecordId === userId ? { ...a, status: 'REJECTED', finalizedAt: new Date().toISOString() } : a
      )
    );
    triggerSuccess('সদস্য অ্যাকাউন্ট প্রত্যাখ্যান করা হয়েছে।');
  };

  // Update Member / Moderator Designation (Requirement 11)
  const updateUserDesignation = (userId: string, moderatorTitle: string, role?: UserRole) => {
    setUsers((prev) =>
      prev.map((u) => {
        if (u.id !== userId) return u;
        return {
          ...u,
          moderatorTitle,
          role: role || u.role,
          isPublicModerator: (role || u.role) !== 'MEMBER',
        };
      })
    );
    logAudit('PROFILE_CHANGE', 'USER', userId, `সদস্য পদবী পরিবর্তন: "${moderatorTitle}"`);
    triggerSuccess('পদবী ও দায়িত্ব সফলভাবে সংরক্ষিত হয়েছে!');
  };

  // Remove / Delete User (Requirement 3)
  const removeUser = (userId: string) => {
    setUsers((prev) => prev.filter((u) => u.id !== userId));
    logAudit('PROFILE_CHANGE', 'USER', userId, `সদস্য রেকর্ড স্থায়ীভাবে অপসারণ করা হয়েছে।`);
    triggerSuccess('সদস্য সফলভাবে মুছে ফেলা হয়েছে!');
  };

  // Send Overdue Reminder (Requirement 6)
  const sendOverdueReminder = (memberId: string) => {
    setOverdueReminders((prev) => (prev.includes(memberId) ? prev : [...prev, memberId]));
    triggerSuccess('বকেয়া তাগিদ বার্তা সফলভাবে পাঠানো হয়েছে!');
  };

  // Direct 1-on-1 Private Messaging (Requirement 16)
  const sendPrivateMessage = (receiverId: string, text: string) => {
    const receiver = users.find((u) => u.id === receiverId);
    if (!receiver) return;

    const convId = [currentUser.id, receiverId].sort().join('_');
    const newMsg: PrivateMessage = {
      id: `pm-${Date.now()}`,
      conversationId: convId,
      senderId: currentUser.id,
      senderName: currentUser.name,
      receiverId,
      receiverName: receiver.name,
      text,
      timestamp: new Date().toISOString(),
      isRead: false,
    };

    setPrivateMessages((prev) => [...prev, newMsg]);
  };

  const deletePrivateMessage = (messageId: string) => {
    setPrivateMessages((prev) =>
      prev.map((msg) =>
        msg.id === messageId
          ? {
              ...msg,
              isDeleted: true,
              text: 'ব্যবহারকারী বার্তাটি ডিলিট করেছেন',
            }
          : msg
      )
    );
  };

  // Forward Message from Moderator-Only to General Chat (Requirement 13)
  const forwardChatMessage = (messageId: string) => {
    const targetMsg = chatMessages.find((m) => m.id === messageId);
    if (!targetMsg) return;

    const forwardedText = `📢 [মডারেটর চ্যানেল থেকে ফরোয়ার্ডকৃত]\n${targetMsg.text}\n(মূল প্রেরক: ${targetMsg.senderName})`;
    sendChatMessage('GENERAL', forwardedText);
    triggerSuccess('বার্তাটি সাধারণ গ্রুপ চ্যাটে ফরোয়ার্ড করা হয়েছে!');
  };

  // Auto-Refresh & Pull-to-Refresh (Requirement 15)
  const refreshAllData = async () => {
    setIsRefreshing(true);
    await new Promise((resolve) => setTimeout(resolve, 600));
    setIsRefreshing(false);
    triggerSuccess('সকল তথ্য ও লাইভ হিসাব রিফ্রেশ সম্পন্ন!');
  };

  // Network Reconnect Auto-Refresh Listener (Requirement 15)
  useEffect(() => {
    const handleOnline = () => {
      setIsOnline(true);
      refreshAllData();
      triggerSuccess('ইন্টারনেট সংযোগ পুনরুদ্ধার হয়েছে — ডাটা অটো-রিফ্রেশ সম্পন্ন!');
    };
    const handleOffline = () => {
      setIsOnline(false);
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const resetToInitialDemo = () => {
    setConfig(INITIAL_CONFIG);
    setUsers(INITIAL_USERS);
    setCurrentUser(INITIAL_USERS[0]);
    setSavings(INITIAL_SAVINGS);
    setApprovals(INITIAL_APPROVALS);
    setNotices(INITIAL_NOTICES);
    setRules(INITIAL_RULES);
    setComplaints(INITIAL_COMPLAINTS);
    setFeatureRequests(INITIAL_FEATURE_REQUESTS);
    setChatMessages(INITIAL_CHAT_MESSAGES);
    setPolls(INITIAL_POLLS);
    setReleases(INITIAL_RELEASES);
    setAuditLogs(INITIAL_AUDIT_LOGS);
    setOverdueReminders(['BF-004']);
  };

  return (
    <AppContext.Provider
      value={{
        theme,
        setTheme,
        isOnline,
        setIsOnline,
        isDemoMode,
        setIsDemoMode,
        showExitDialog,
        setShowExitDialog,
        soundEnabled,
        setSoundEnabled,
        hapticEnabled,
        setHapticEnabled,
        successMessage,
        triggerSuccess,
        closeSuccess,
        currentUser,
        isGuestMode,
        setCurrentUser,
        logoutUser,
        maskPhoneForPrivacy,
        switchUserRole,
        users,
        updateUserProfile,
        requestProfileChange,
        registerNewAccount,
        approveUserAccount,
        rejectUserAccount,
        updateUserDesignation,
        removeUser,
        isAuthModalOpen,
        setIsAuthModalOpen,
        overdueReminders,
        sendOverdueReminder,
        privateMessages,
        sendPrivateMessage,
        deletePrivateMessage,
        activePrivateChatUser,
        setActivePrivateChatUser,
        savings,
        createSavingsEntry,
        reverseTransaction,
        approvals,
        voteOnApproval,
        receipts,
        getReceiptForTransaction,
        activePrintReceipt,
        setActivePrintReceipt,
        chatMessages,
        sendChatMessage,
        deleteChatMessage,
        forwardChatMessage,
        toggleMessageReaction,
        polls,
        votePoll,
        createPoll,
        deletePoll,
        updatePollOption,
        updatePollQuestion,
        chatUnreadCount,
        markChatSeen,
        hasUnreadNotices,
        markNoticesSeen,
        notices,
        addNotice,
        updateNotice,
        deleteNotice,
        complaints,
        submitComplaint,
        updateComplaintStatus,
        featureRequests,
        submitFeatureRequest,
        voteFeatureRequest,
        rules,
        updateRule,
        config,
        updateConfig,
        auditLogs,
        releases,
        publishAppRelease,
        activeUpdateDialog,
        setActiveUpdateDialog,
        refreshAllData,
        isRefreshing,
        exportBackupData,
        restoreFromBackup,
        resetToInitialDemo,
        expenses,
        addExpense,
        removeExpense,
        totalExpenses,
        netReserveBalance,
        isSearchModalOpen,
        setIsSearchModalOpen,
        deleteChatMessage,
        deletePrivateMessage,
        activeCall,
        startCall,
        endCall,
        executiveMembers,
        addExecutiveMember,
        removeExecutiveMember,
        updateExecutiveMember,
        onlineUserIds,
        cloudSyncStatus,
        lastSyncTimestamp,
        triggerCloudSync,
        userNotifications,
        sendUserNotification,
        markNotificationRead,
        markAllNotificationsRead,
        pendingDepositModalOpen,
        setPendingDepositModalOpen,
        checkUserHasPendingDeposit,
        financialTotals,
        growthRate,
        monthlyAggregates,
        eligibleModeratorsCount,
        unreadCount,
        uniqueDailyVisitors,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
