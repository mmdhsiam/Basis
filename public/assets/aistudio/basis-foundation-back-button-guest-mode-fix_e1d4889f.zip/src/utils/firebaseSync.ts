import {
  doc,
  setDoc,
  deleteDoc,
  collection,
  onSnapshot,
  getDocs,
  Firestore,
} from 'firebase/firestore';
import { getFirebaseDb } from './firebase';
import {
  AppConfiguration,
  NoticeItem,
  FoundationRule,
  ExecutiveMember,
  SavingsTransaction,
  UserProfile,
  ApprovalRequest,
  ChatMessage,
} from '../types';

/**
 * Strips out undefined values from an object so Firestore does not throw an error.
 */
function cleanForFirestore<T extends Record<string, any>>(obj: T): Record<string, any> {
  const result: Record<string, any> = {};
  for (const key of Object.keys(obj)) {
    const val = obj[key];
    if (val !== undefined) {
      if (val !== null && typeof val === 'object' && !Array.isArray(val) && !(val instanceof Date)) {
        result[key] = cleanForFirestore(val);
      } else {
        result[key] = val;
      }
    }
  }
  return result;
}

export type SyncStatus = 'SYNCED' | 'SYNCING' | 'OFFLINE' | 'LOCAL';

export interface RealtimeSyncCallbacks {
  onConfigChange?: (config: AppConfiguration) => void;
  onNoticesChange?: (notices: NoticeItem[]) => void;
  onRulesChange?: (rules: FoundationRule[]) => void;
  onExecutiveMembersChange?: (members: ExecutiveMember[]) => void;
  onSavingsChange?: (savings: SavingsTransaction[]) => void;
  onUsersChange?: (users: UserProfile[]) => void;
  onApprovalsChange?: (approvals: ApprovalRequest[]) => void;
  onChatChange?: (messages: ChatMessage[]) => void;
  onStatusChange?: (status: SyncStatus, lastSyncedAt: string) => void;
}

/**
 * Writes application configuration & custom fonts/titles to Firestore doc `app_configuration/main`.
 */
export async function syncConfigToFirestore(config: AppConfiguration): Promise<boolean> {
  try {
    const db = getFirebaseDb();
    if (!db) return false;
    const ref = doc(db, 'app_configuration', 'main');
    await setDoc(ref, cleanForFirestore({ ...config, updatedAt: new Date().toISOString() }), { merge: true });
    return true;
  } catch (err) {
    console.warn('Firestore config write warning (continuing with local state):', err);
    return false;
  }
}

/**
 * Writes a notice item to Firestore.
 */
export async function syncNoticeToFirestore(notice: NoticeItem): Promise<boolean> {
  try {
    const db = getFirebaseDb();
    if (!db) return false;
    const ref = doc(db, 'notices', notice.id);
    await setDoc(ref, cleanForFirestore(notice), { merge: true });
    return true;
  } catch (err) {
    console.warn('Firestore notice write warning:', err);
    return false;
  }
}

export async function deleteNoticeFromFirestore(noticeId: string): Promise<boolean> {
  try {
    const db = getFirebaseDb();
    if (!db) return false;
    await deleteDoc(doc(db, 'notices', noticeId));
    return true;
  } catch (err) {
    console.warn('Firestore notice delete warning:', err);
    return false;
  }
}

/**
 * Writes a foundation rule to Firestore.
 */
export async function syncRuleToFirestore(rule: FoundationRule): Promise<boolean> {
  try {
    const db = getFirebaseDb();
    if (!db) return false;
    const ref = doc(db, 'rules', rule.id);
    await setDoc(ref, cleanForFirestore(rule), { merge: true });
    return true;
  } catch (err) {
    console.warn('Firestore rule write warning:', err);
    return false;
  }
}

export async function deleteRuleFromFirestore(ruleId: string): Promise<boolean> {
  try {
    const db = getFirebaseDb();
    if (!db) return false;
    await deleteDoc(doc(db, 'rules', ruleId));
    return true;
  } catch (err) {
    console.warn('Firestore rule delete warning:', err);
    return false;
  }
}

/**
 * Writes an executive committee member to Firestore.
 */
export async function syncExecutiveMemberToFirestore(member: ExecutiveMember): Promise<boolean> {
  try {
    const db = getFirebaseDb();
    if (!db) return false;
    const ref = doc(db, 'executive_members', member.id);
    await setDoc(ref, cleanForFirestore(member), { merge: true });
    return true;
  } catch (err) {
    console.warn('Firestore executive member write warning:', err);
    return false;
  }
}

export async function deleteExecutiveMemberFromFirestore(memberId: string): Promise<boolean> {
  try {
    const db = getFirebaseDb();
    if (!db) return false;
    await deleteDoc(doc(db, 'executive_members', memberId));
    return true;
  } catch (err) {
    console.warn('Firestore executive member delete warning:', err);
    return false;
  }
}

/**
 * Writes a savings transaction to Firestore.
 */
export async function syncSavingsTransactionToFirestore(tx: SavingsTransaction): Promise<boolean> {
  try {
    const db = getFirebaseDb();
    if (!db) return false;
    const ref = doc(db, 'savings_transactions', tx.id);
    await setDoc(ref, cleanForFirestore(tx), { merge: true });
    return true;
  } catch (err) {
    console.warn('Firestore savings write warning:', err);
    return false;
  }
}

/**
 * Writes an approval request to Firestore.
 */
export async function syncApprovalToFirestore(appr: ApprovalRequest): Promise<boolean> {
  try {
    const db = getFirebaseDb();
    if (!db) return false;
    const ref = doc(db, 'approvals', appr.id);
    await setDoc(ref, cleanForFirestore(appr), { merge: true });
    return true;
  } catch (err) {
    console.warn('Firestore approval write warning:', err);
    return false;
  }
}

/**
 * Writes a user profile to Firestore.
 */
export async function syncUserToFirestore(user: UserProfile): Promise<boolean> {
  try {
    const db = getFirebaseDb();
    if (!db) return false;
    const ref = doc(db, 'users', user.id);
    await setDoc(ref, cleanForFirestore(user), { merge: true });
    return true;
  } catch (err) {
    console.warn('Firestore user write warning:', err);
    return false;
  }
}

/**
 * Writes a chat message to Firestore.
 */
export async function syncChatMessageToFirestore(msg: ChatMessage): Promise<boolean> {
  try {
    const db = getFirebaseDb();
    if (!db) return false;
    const ref = doc(db, 'chat_messages', msg.id);
    await setDoc(ref, cleanForFirestore(msg), { merge: true });
    return true;
  } catch (err) {
    console.warn('Firestore chat write warning:', err);
    return false;
  }
}

/**
 * Establishes real-time listeners on Firestore collections.
 * Returns an unsubscription function.
 */
export function initRealtimeSync(callbacks: RealtimeSyncCallbacks): () => void {
  const unsubscribers: (() => void)[] = [];

  try {
    const db = getFirebaseDb();
    if (!db) {
      callbacks.onStatusChange?.('LOCAL', new Date().toLocaleTimeString('bn-BD'));
      return () => {};
    }

    callbacks.onStatusChange?.('SYNCING', new Date().toLocaleTimeString('bn-BD'));

    // 1. App Configuration listener (fonts, titles, texts, branding)
    const unsubConfig = onSnapshot(
      doc(db, 'app_configuration', 'main'),
      (snapshot) => {
        if (snapshot.exists()) {
          const data = snapshot.data() as AppConfiguration;
          callbacks.onConfigChange?.(data);
          callbacks.onStatusChange?.('SYNCED', new Date().toLocaleTimeString('bn-BD'));
        }
      },
      (err) => {
        console.warn('Config snapshot listener warning:', err);
        callbacks.onStatusChange?.('LOCAL', new Date().toLocaleTimeString('bn-BD'));
      }
    );
    unsubscribers.push(unsubConfig);

    // 2. Notices listener
    const unsubNotices = onSnapshot(
      collection(db, 'notices'),
      (snapshot) => {
        if (!snapshot.empty) {
          const list: NoticeItem[] = [];
          snapshot.forEach((docSnap) => {
            list.push(docSnap.data() as NoticeItem);
          });
          // Sort by creation date descending
          list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
          callbacks.onNoticesChange?.(list);
          callbacks.onStatusChange?.('SYNCED', new Date().toLocaleTimeString('bn-BD'));
        }
      },
      (err) => console.warn('Notices listener warning:', err)
    );
    unsubscribers.push(unsubNotices);

    // 3. Rules listener
    const unsubRules = onSnapshot(
      collection(db, 'rules'),
      (snapshot) => {
        if (!snapshot.empty) {
          const list: FoundationRule[] = [];
          snapshot.forEach((docSnap) => {
            list.push(docSnap.data() as FoundationRule);
          });
          list.sort((a, b) => a.order - b.order);
          callbacks.onRulesChange?.(list);
        }
      },
      (err) => console.warn('Rules listener warning:', err)
    );
    unsubscribers.push(unsubRules);

    // 4. Executive Members listener
    const unsubExec = onSnapshot(
      collection(db, 'executive_members'),
      (snapshot) => {
        if (!snapshot.empty) {
          const list: ExecutiveMember[] = [];
          snapshot.forEach((docSnap) => {
            list.push(docSnap.data() as ExecutiveMember);
          });
          list.sort((a, b) => a.order - b.order);
          callbacks.onExecutiveMembersChange?.(list);
        }
      },
      (err) => console.warn('Executive members listener warning:', err)
    );
    unsubscribers.push(unsubExec);

    // 5. Savings Transactions listener
    const unsubSavings = onSnapshot(
      collection(db, 'savings_transactions'),
      (snapshot) => {
        if (!snapshot.empty) {
          const list: SavingsTransaction[] = [];
          snapshot.forEach((docSnap) => {
            list.push(docSnap.data() as SavingsTransaction);
          });
          list.sort((a, b) => new Date(b.transactionDate).getTime() - new Date(a.transactionDate).getTime());
          callbacks.onSavingsChange?.(list);
          callbacks.onStatusChange?.('SYNCED', new Date().toLocaleTimeString('bn-BD'));
        }
      },
      (err) => console.warn('Savings listener warning:', err)
    );
    unsubscribers.push(unsubSavings);

    // 6. Users listener
    const unsubUsers = onSnapshot(
      collection(db, 'users'),
      (snapshot) => {
        if (!snapshot.empty) {
          const list: UserProfile[] = [];
          snapshot.forEach((docSnap) => {
            list.push(docSnap.data() as UserProfile);
          });
          callbacks.onUsersChange?.(list);
        }
      },
      (err) => console.warn('Users listener warning:', err)
    );
    unsubscribers.push(unsubUsers);

    // 7. Approvals listener
    const unsubApprovals = onSnapshot(
      collection(db, 'approvals'),
      (snapshot) => {
        if (!snapshot.empty) {
          const list: ApprovalRequest[] = [];
          snapshot.forEach((docSnap) => {
            list.push(docSnap.data() as ApprovalRequest);
          });
          callbacks.onApprovalsChange?.(list);
        }
      },
      (err) => console.warn('Approvals listener warning:', err)
    );
    unsubscribers.push(unsubApprovals);

    // 8. Chat Messages listener
    const unsubChat = onSnapshot(
      collection(db, 'chat_messages'),
      (snapshot) => {
        if (!snapshot.empty) {
          const list: ChatMessage[] = [];
          snapshot.forEach((docSnap) => {
            list.push(docSnap.data() as ChatMessage);
          });
          list.sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
          callbacks.onChatChange?.(list);
        }
      },
      (err) => console.warn('Chat listener warning:', err)
    );
    unsubscribers.push(unsubChat);

    callbacks.onStatusChange?.('SYNCED', new Date().toLocaleTimeString('bn-BD'));
  } catch (err) {
    console.warn('Realtime sync setup error (using local resilience):', err);
    callbacks.onStatusChange?.('LOCAL', new Date().toLocaleTimeString('bn-BD'));
  }

  return () => {
    unsubscribers.forEach((unsub) => {
      try {
        unsub();
      } catch (e) {
        // ignore
      }
    });
  };
}
